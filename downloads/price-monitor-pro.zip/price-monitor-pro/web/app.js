/* Price Monitor Pro — admin SPA (vanilla JS, no dependencies) */
'use strict';

const $ = (s, r = document) => r.querySelector(s);
const $$ = (s, r = document) => Array.from(r.querySelectorAll(s));
const esc = (v) => String(v ?? '').replace(/[&<>"']/g, (c) => ({'&': '&amp;','<': '&lt;','>': '&gt;','"': '&quot;',"'": '&#39;'}[c]));
const num = (n, d = 0) => Number(n ?? 0).toLocaleString('ru-RU', {minimumFractionDigits: d, maximumFractionDigits: d});
const money = (n, cur = 'RUB') => cur === 'USD' ? '$' + num(n, 2) : cur === 'EUR' ? '€' + num(n, 2) : num(n) + ' ₽';
const ts = (t) => t ? new Date(t * 1000).toLocaleString('ru-RU', {day: '2-digit', month: 'short', hour: '2-digit', minute: '2-digit'}) : '—';
const ago = (t) => {
  if (!t) return 'не проверялся';
  const d = Math.max(0, Math.floor(Date.now() / 1000 - t));
  if (d < 60) return d + ' сек назад';
  if (d < 3600) return Math.floor(d / 60) + ' мин назад';
  if (d < 86400) return Math.floor(d / 3600) + ' ч назад';
  return Math.floor(d / 86400) + ' дн назад';
};

const state = { stats: null, sources: [], history: [], settings: {}, mode: 'index', q: '' };

async function api(path, opts = {}) {
  const res = await fetch(path, {
    ...opts,
    headers: {'Content-Type': 'application/json', ...(opts.headers || {})},
    body: opts.body ? JSON.stringify(opts.body) : undefined,
  });
  let data = {};
  try { data = await res.json(); } catch (e) {}
  if (!res.ok) throw new Error(data.error || 'Ошибка ' + res.status);
  return data;
}

function toast(text, isErr = false) {
  const el = document.createElement('div');
  el.className = 'toast' + (isErr ? ' err' : '');
  el.textContent = text;
  $('#toasts').appendChild(el);
  setTimeout(() => { el.style.opacity = '0'; el.style.transform = 'translateX(8px)'; }, 3200);
  setTimeout(() => el.remove(), 3600);
}

/* ---------- auth ---------- */
$('#loginForm').addEventListener('submit', async (e) => {
  e.preventDefault();
  $('#loginErr').textContent = '';
  try {
    await api('/api/login', {method: 'POST', body: {password: $('#password').value}});
    await boot();
  } catch (err) { $('#loginErr').textContent = err.message; }
});
$('#logoutBtn').onclick = async () => { await api('/api/logout', {method: 'POST'}); location.reload(); };

async function boot() {
  const me = await api('/api/me');
  if (!me.authenticated) { $('#loginScreen').hidden = false; $('#app').hidden = true; return; }
  $('#loginScreen').hidden = true;
  $('#app').hidden = false;
  await Promise.all([loadSources(), loadSettings()]);
  await loadDashboard();
  route();
  $('#todayChip').textContent = new Date().toLocaleDateString('ru-RU', {day: '2-digit', month: 'long', year: 'numeric'});
}

/* ---------- router ---------- */
const TITLES = {
  dashboard: ['Обзор', 'Сводка по конкурентам за 30 дней'],
  sources: ['Источники', 'Страницы, которые отслеживает планировщик'],
  history: ['История цен', 'Все зафиксированные значения'],
  export: ['Экспорт', 'XLSX, CSV и JSON для отчётов'],
  settings: ['Настройки', 'Алерты, парсер и безопасность'],
};

function route() {
  const name = TITLES[(location.hash || '#dashboard').slice(1)] ? (location.hash || '#dashboard').slice(1) : 'dashboard';
  $$('.view').forEach((v) => v.classList.toggle('active', v.id === 'view-' + name));
  $$('.nav a').forEach((a) => a.classList.toggle('active', a.dataset.view === name));
  $('#pageTitle').textContent = TITLES[name][0];
  $('#pageSub').textContent = TITLES[name][1];
  if (name === 'dashboard') loadDashboard();
  if (name === 'history') loadHistory();
  if (name === 'export') renderExportPreview();
  window.scrollTo({top: 0});
}
window.addEventListener('hashchange', route);
document.addEventListener('click', (e) => {
  const a = e.target.closest('[data-view]');
  if (a && a.tagName === 'A') { e.preventDefault(); location.hash = '#' + a.dataset.view; }
});

/* ---------- dashboard ---------- */
async function loadDashboard() {
  const {data} = await api('/api/stats');
  state.stats = data;
  const avg = data.avg_change;
  $('#kpis').innerHTML = [
    ['Источников', data.active, `из ${data.sources} активны`, '☰', ''],
    ['Проверок за 24ч', data.checks_today, 'планировщик работает', '↻', ''],
    ['Подешевело', data.drops, `подорожало ${data.ups}`, '↓', 'down'],
    ['Среднее изменение', (avg > 0 ? '+' : '') + num(avg, 1) + '%', `потенциал экономии ${money(data.potential, data.currency)}`, avg > 0 ? '↑' : '↓', avg > 0 ? 'up' : 'down'],
  ].map(([label, value, sub, ico, cls]) => `
    <div class="kpi">
      <div class="k-label">${label}<span class="ico">${ico}</span></div>
      <div class="k-value">${value}</div>
      <div class="k-sub"><b class="${cls}">${sub}</b></div>
    </div>`).join('');
  renderChart(data);
  renderChanges(data.changes);
  renderCheapest(data.cheapest, data.currency);
  loadEvents();
}

function smooth(points) {
  if (!points.length) return '';
  let d = `M ${points[0][0]},${points[0][1]}`;
  for (let i = 0; i < points.length - 1; i++) {
    const p0 = points[i - 1] || points[i], p1 = points[i], p2 = points[i + 1], p3 = points[i + 2] || p2;
    d += ` C ${p1[0] + (p2[0] - p0[0]) / 6},${p1[1] + (p2[1] - p0[1]) / 6} ${p2[0] - (p3[0] - p1[0]) / 6},${p2[1] - (p3[1] - p1[1]) / 6} ${p2[0]},${p2[1]}`;
  }
  return d;
}

function renderChart(s) {
  const key = state.mode;
  const vals = s.series.map((d) => d[key]);
  if (!vals.length) { $('#mainChart').innerHTML = '<text x="380" y="130" text-anchor="middle" fill="#94a3b8" font-size="12">Нет данных</text>'; return; }
  const W = 760, H = 260, pad = {t: 16, r: 10, b: 26, l: 10};
  const iw = W - pad.l - pad.r, ih = H - pad.t - pad.b;
  const min = Math.min(...vals), max = Math.max(...vals);
  const span = (max - min) || 1;
  const y = (v) => pad.t + ih - ((v - min) / span) * ih * 0.9 - ih * 0.05;
  const pts = vals.map((v, i) => [pad.l + (i * iw) / Math.max(1, vals.length - 1), y(v)]);
  const line = smooth(pts);
  const area = `${line} L ${pts[pts.length - 1][0]},${H - pad.b} L ${pts[0][0]},${H - pad.b} Z`;

  const grid = [0, .25, .5, .75, 1].map((p) => {
    const yy = pad.t + ih * p;
    const val = max - (max - min) * p;
    return `<line x1="${pad.l}" y1="${yy}" x2="${W - pad.r}" y2="${yy}" stroke="#eef1f7" stroke-dasharray="4 5"/>
            <text x="${pad.l + 2}" y="${yy - 4}" fill="#94a3b8" font-size="9">${key === 'index' ? num(val, 1) : num(val)}</text>`;
  }).join('');
  const labels = s.series.map((d, i) => (i % Math.ceil(vals.length / 6) === 0 || i === vals.length - 1)
    ? `<text x="${pts[i][0]}" y="${H - 6}" text-anchor="middle" fill="#94a3b8" font-size="9">${d.date}</text>` : '').join('');
  const dots = pts.map((p, i) => `<circle class="pt" data-i="${i}" cx="${p[0]}" cy="${p[1]}" r="8" fill="transparent"/>
    <circle cx="${p[0]}" cy="${p[1]}" r="2.6" fill="#fff" stroke="#4f46e5" stroke-width="1.8" opacity="${i === pts.length - 1 ? 1 : 0}"/>`).join('');

  $('#mainChart').innerHTML = `
    <defs><linearGradient id="g" x1="0" y1="0" x2="0" y2="1">
      <stop offset="0%" stop-color="#4f46e5" stop-opacity=".22"/><stop offset="100%" stop-color="#4f46e5" stop-opacity="0"/></linearGradient></defs>
    ${grid}
    <path d="${area}" fill="url(#g)"/>
    <path d="${line}" fill="none" stroke="#4f46e5" stroke-width="2.4" stroke-linecap="round"/>
    ${dots}${labels}`;

  const tip = $('#tip');
  $$('.pt').forEach((c) => {
    c.addEventListener('mouseenter', () => {
      const i = +c.dataset.i, d = s.series[i], box = $('#mainChart').getBoundingClientRect();
      const r = c.getBoundingClientRect();
      tip.innerHTML = `<b>${d.date}</b> · ${state.mode === 'index' ? d.index : money(d.avg_price, s.currency)}`;
      tip.style.left = (r.left - box.left + 4) + 'px';
      tip.style.top = (r.top - box.top) + 'px';
      tip.style.opacity = '1';
    });
    c.addEventListener('mouseleave', () => { tip.style.opacity = '0'; });
  });
}

$('#chartSeg').addEventListener('click', (e) => {
  const b = e.target.closest('button'); if (!b) return;
  $$('#chartSeg button').forEach((x) => x.classList.toggle('active', x === b));
  state.mode = b.dataset.mode;
  if (state.stats) renderChart(state.stats);
});

function renderChanges(changes) {
  const el = $('#changesList');
  if (!changes.length) { el.innerHTML = '<div class="empty">Изменений пока нет</div>'; return; }
  el.innerHTML = changes.map((c) => {
    const down = c.change_pct < 0;
    return `<div class="row">
      <div class="nm"><div>${esc(c.name)}</div><small>${ts(c.last_checked)}</small></div>
      <div class="price-now">${money(c.last_price, c.currency)}</div>
      <span class="delta ${down ? 'down' : 'up'}">${down ? '▼' : '▲'} ${Math.abs(c.change_pct).toFixed(1)}%</span>
    </div>`;
  }).join('');
}

function renderCheapest(items, cur) {
  const el = $('#cheapest');
  if (!items.length) { el.innerHTML = '<div class="empty">Нет данных</div>'; return; }
  el.innerHTML = items.map((p, i) => `<div class="row">
    <div class="rank">${i + 1}</div>
    <div class="nm">${esc(p.name)}</div>
    <div class="pr">${money(p.last_price, p.currency || cur)}</div>
    <span class="badge neutral">мин ${money(p.best, p.currency || cur)}</span>
  </div>`).join('');
}

async function loadEvents() {
  const {data} = await api('/api/events');
  $('#events').innerHTML = data.length ? data.map((e) => `
    <div class="row"><div class="ic">${({price: '📉', alert: '🔔', error: '⚠️', source: '＋', system: '✨', settings: '⚙', auth: '🔐'})[e.kind] || '•'}</div>
      <div><div class="tx">${esc(e.message)}</div><div class="tm">${ts(e.created_at)}</div></div></div>`).join('')
    : '<div class="empty">Событий нет</div>';
}

/* ---------- sources ---------- */
async function loadSources() {
  const {data} = await api('/api/sources');
  state.sources = data;
  renderSources();
  const sel = $('#historySource');
  const current = sel.value;
  sel.innerHTML = data.map((s) => `<option value="${s.id}">${esc(s.name)}</option>`).join('');
  if (current) sel.value = current;
}

function statusBadge(s) {
  const map = {ok: ['ok', 'OK'], new: ['neutral', 'не проверялся'], 'network-error': ['err', 'сеть'], 'not-found': ['warn', 'не найдено']};
  const [cls, label] = map[s] || (String(s).startsWith('http') ? ['err', String(s)] : ['warn', s]);
  return `<span class="badge ${cls}">${esc(label)}</span>`;
}

function renderSources() {
  const q = state.q.toLowerCase();
  const rows = state.sources.filter((s) => !q || s.name.toLowerCase().includes(q) || s.host.includes(q));
  $('#sourcesBody').innerHTML = rows.length ? rows.map((s) => {
    const ch = Math.abs(s.change_pct ?? 0) < 0.05 ? null : s.change_pct;
    const delta = ch === null || ch === undefined ? '<span class="mono">—</span>'
      : `<span class="delta ${ch < 0 ? 'down' : 'up'}">${ch < 0 ? '▼' : '▲'} ${Math.abs(ch).toFixed(1)}%</span>`;
    return `<tr>
      <td><div class="t-name"><div class="fav">${esc(s.name.slice(0, 2).toUpperCase())}</div>
        <div><div>${esc(s.name)}</div><div class="t-sub">${esc(s.host)}${s.selector ? ' · ' + esc(s.selector) : ' · авто'}</div></div></div></td>
      <td><div class="price-now">${s.last_price !== null ? money(s.last_price, s.currency) : '—'}</div>
        <div class="t-sub">${statusBadge(s.last_status)}</div></td>
      <td>${delta}</td>
      <td class="nowrap muted">${s.min_price !== null ? num(s.min_price) : '—'} / ${s.max_price !== null ? num(s.max_price) : '—'}</td>
      <td class="nowrap">${s.interval_min} мин</td>
      <td class="nowrap muted">${ago(s.last_checked)}</td>
      <td><div class="actions">
        <button class="btn ghost sm" data-check="${s.id}" title="Проверить сейчас">↻</button>
        <button class="btn ghost sm" data-edit="${s.id}" title="Изменить">✎</button>
        <button class="btn danger sm" data-del="${s.id}" title="Удалить">✕</button>
      </div></td>
    </tr>`;
  }).join('') : '<tr><td colspan="7"><div class="empty">Источников нет — добавьте первую ссылку</div></td></tr>';
}

$('#sourceSearch').addEventListener('input', (e) => { state.q = e.target.value; renderSources(); });
$('#sourcesBody').addEventListener('click', async (e) => {
  const chk = e.target.closest('[data-check]');
  const ed = e.target.closest('[data-edit]');
  const del = e.target.closest('[data-del]');
  if (chk) {
    const btn = chk; btn.disabled = true; btn.textContent = '…';
    try {
      const r = await api(`/api/sources/${chk.dataset.check}/check`, {method: 'POST'});
      toast(`Проверено: ${money(r.data.price, r.source.currency)}`);
      await loadSources(); await loadDashboard();
    } catch (err) { toast(err.message, true); }
    finally { btn.disabled = false; btn.textContent = '↻'; }
  }
  if (ed) openSourceModal(state.sources.find((s) => s.id === +ed.dataset.edit));
  if (del) {
    if (!confirm('Удалить источник и всю историю цен?')) return;
    await api('/api/sources/' + del.dataset.del, {method: 'DELETE'});
    toast('Источник удалён'); await loadSources(); await loadDashboard();
  }
});

function openSourceModal(s = null) {
  const isEdit = !!s;
  s = s || {name: '', url: '', selector: '', currency: 'RUB', interval_min: 60, active: 1};
  $('#modalTitle').textContent = isEdit ? 'Изменить источник' : 'Новый источник';
  $('#modalSub').textContent = 'Страница конкурента и CSS-селектор цены';
  $('#modalBody').innerHTML = `
    <div class="form-grid">
      <div class="full"><label>Название товара</label><input class="input" name="name" value="${esc(s.name)}" required></div>
      <div class="full"><label>URL страницы</label><input class="input" name="url" value="${esc(s.url)}" placeholder="https://competitor.ru/product/123" required>
        <div class="hint-inline">Страница должна отдавать цену в HTML (без JS-рендеринга).</div></div>
      <div class="full"><label>CSS-селектор цены</label><input class="input" name="selector" value="${esc(s.selector)}" placeholder=".product-price">
        <div class="hint-inline">Пусто = автоматически из schema.org / JSON-LD / meta.</div></div>
      <div><label>Валюта</label><select class="input" name="currency">
        ${['RUB', 'USD', 'EUR'].map((c) => `<option value="${c}" ${c === s.currency ? 'selected' : ''}>${c}</option>`).join('')}</select></div>
      <div><label>Интервал, минут</label><input class="input" name="interval_min" type="number" min="5" step="5" value="${s.interval_min}"></div>
      <div><label>Статус</label><select class="input" name="active">
        <option value="1" ${s.active ? 'selected' : ''}>Активен</option>
        <option value="0" ${!s.active ? 'selected' : ''}>Пауза</option></select></div>
    </div>`;
  const form = $('#modalForm');
  form.dataset.id = isEdit ? s.id : '';
  modalSubmit = async (f) => {
    const body = Object.fromEntries(new FormData(f).entries());
    body.interval_min = +body.interval_min;
    body.active = +body.active;
    try {
      if (form.dataset.id) await api('/api/sources/' + form.dataset.id, {method: 'PUT', body});
      else await api('/api/sources', {method: 'POST', body});
      closeModal(); await loadSources(); await loadDashboard(); toast('Источник сохранён');
    } catch (err) { toast(err.message, true); }
  };
  openModal();
}
$('#addSourceBtn').onclick = () => openSourceModal();

/* ---------- history ---------- */
async function loadHistory() {
  const sid = $('#historySource').value || (state.sources[0] && state.sources[0].id);
  if (!sid) return;
  const {data} = await api('/api/history?source=' + sid + '&limit=200');
  state.history = data;
  const src = state.sources.find((s) => s.id === +sid);
  $('#historyTitle').textContent = src ? `${src.name} · ${src.host}` : 'Источник';
  $('#historyCount').textContent = data.length + ' записей';
  drawHistoryChart(data, src);
  $('#historyBody').innerHTML = data.length ? data.map((h) => `
    <tr><td class="nowrap">${ts(h.checked_at)}</td><td>${esc(src ? src.name : '')}</td>
    <td><b>${h.price !== null ? money(h.price, src ? src.currency : 'RUB') : '—'}</b></td>
    <td>${statusBadge(h.status)}</td></tr>`).join('')
    : '<tr><td colspan="4"><div class="empty">История пуста</div></td></tr>';
}

function drawHistoryChart(rows, src) {
  const ptsData = rows.slice().reverse().filter((r) => r.price !== null);
  const svg = $('#historyChart');
  if (ptsData.length < 2) { svg.innerHTML = '<text x="380" y="110" text-anchor="middle" fill="#94a3b8" font-size="12">Нужно минимум 2 проверки</text>'; return; }
  const W = 760, H = 220, pad = {t: 12, r: 10, b: 24, l: 10};
  const vals = ptsData.map((r) => r.price);
  const min = Math.min(...vals), max = Math.max(...vals), span = (max - min) || 1;
  const iw = W - pad.l - pad.r, ih = H - pad.t - pad.b;
  const pts = vals.map((v, i) => [pad.l + (i * iw) / (vals.length - 1), pad.t + ih - ((v - min) / span) * ih * 0.9 - ih * 0.05]);
  const line = smooth(pts);
  svg.innerHTML = `
    <defs><linearGradient id="hg" x1="0" y1="0" x2="0" y2="1">
      <stop offset="0%" stop-color="#10b981" stop-opacity=".2"/><stop offset="100%" stop-color="#10b981" stop-opacity="0"/></linearGradient></defs>
    <path d="${line} L ${pts[pts.length - 1][0]},${H - pad.b} L ${pts[0][0]},${H - pad.b} Z" fill="url(#hg)"/>
    <path d="${line}" fill="none" stroke="#059669" stroke-width="2.2" stroke-linecap="round"/>
    <circle cx="${pts[pts.length - 1][0]}" cy="${pts[pts.length - 1][1]}" r="3.4" fill="#fff" stroke="#059669" stroke-width="2"/>
    <text x="${pad.l + 2}" y="${pad.t + 6}" fill="#94a3b8" font-size="9">${num(max)}</text>
    <text x="${pad.l + 2}" y="${H - pad.b - 2}" fill="#94a3b8" font-size="9">${num(min)}</text>`;
}
$('#historySource').addEventListener('change', loadHistory);

/* ---------- export ---------- */
async function renderExportPreview() {
  const rows = state.sources.slice(0, 8);
  $('#exportPreview').innerHTML = rows.map((s) => `
    <tr><td>${esc(s.name)}</td><td><b>${s.last_price !== null ? money(s.last_price, s.currency) : '—'}</b></td>
    <td>${s.min_price !== null ? num(s.min_price) : '—'}</td><td>${s.max_price !== null ? num(s.max_price) : '—'}</td>
    <td>${s.change_pct !== null && Math.abs(s.change_pct) >= 0.05 ? `<span class="delta ${s.change_pct < 0 ? 'down' : 'up'}">${s.change_pct > 0 ? '+' : ''}${s.change_pct.toFixed(1)}%</span>` : '<span class="muted">—</span>'}</td>
    <td>${s.currency}</td></tr>`).join('');
}
$('#exportQuick').onclick = () => { location.href = '/api/export.xlsx'; };
$('#copyApi').onclick = async () => {
  const url = location.origin + '/api/sources';
  try { await navigator.clipboard.writeText(url); toast('Скопировано: ' + url); }
  catch (e) { toast(url); }
};

/* ---------- settings ---------- */
async function loadSettings() {
  const {data} = await api('/api/settings');
  state.settings = data;
  $('#setToken').value = data.telegram_token || '';
  $('#setChat').value = data.telegram_chat || '';
  $('#setThreshold').value = data.alert_threshold_pct || 3;
  $('#setTimeout').value = data.request_timeout || 20;
  $('#setUa').value = data.user_agent || '';
  $('#setCurrency').value = data.currency || 'RUB';
}

$('#saveSettings').onclick = async () => {
  const body = {
    telegram_token: $('#setToken').value,
    telegram_chat: $('#setChat').value,
    alert_threshold_pct: $('#setThreshold').value,
    request_timeout: $('#setTimeout').value,
    user_agent: $('#setUa').value,
    currency: $('#setCurrency').value,
  };
  const p1 = $('#setPass').value, p2 = $('#setPass2').value;
  if (p1 || p2) {
    if (p1 !== p2) return toast('Пароли не совпадают', true);
    if (p1.length < 8) return toast('Пароль короче 8 символов', true);
    body.new_password = p1; body.new_password_repeat = p2;
  }
  try {
    await api('/api/settings', {method: 'PUT', body});
    toast('Настройки сохранены');
    $('#setPass').value = ''; $('#setPass2').value = '';
    await loadSettings();
  } catch (err) { toast(err.message, true); }
};

$('#testTg').onclick = async () => {
  try { await api('/api/test-telegram', {method: 'POST'}); toast('Тестовое сообщение отправлено'); }
  catch (err) { toast(err.message, true); }
};

$('#checkAllBtn').onclick = async () => {
  const btn = $('#checkAllBtn');
  btn.disabled = true; btn.textContent = 'Проверяем…';
  try {
    const r = await api('/api/check-all', {method: 'POST'});
    toast(`Проверено источников: ${r.checked}`);
    await loadSources(); await loadDashboard();
  } catch (err) { toast(err.message, true); }
  finally { btn.disabled = false; btn.textContent = '↻ Проверить всё'; }
};

/* ---------- modal ---------- */
let modalSubmit = null;
function openModal() { $('#modalBack').classList.add('open'); }
function closeModal() { $('#modalBack').classList.remove('open'); }
$('#modalCancel').onclick = closeModal;
$('#modalBack').addEventListener('click', (e) => { if (e.target === $('#modalBack')) closeModal(); });
$('#modalForm').addEventListener('submit', async (e) => {
  e.preventDefault();
  if (modalSubmit) await modalSubmit(e.currentTarget);
});
document.addEventListener('keydown', (e) => { if (e.key === 'Escape') closeModal(); });

boot().catch((e) => { $('#loginScreen').hidden = false; $('#loginErr').textContent = e.message; });
setInterval(() => { if (!$('#app').hidden) loadDashboard().catch(() => {}); }, 45000);
