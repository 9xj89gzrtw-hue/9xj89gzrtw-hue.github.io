"""Тесты Price Monitor Pro: парсер, XLSX, API. python3 -m unittest discover -s tests -v"""
from __future__ import annotations

import io
import json
import os
import sys
import tempfile
import threading
import unittest
import urllib.error
import urllib.request
import zipfile
from http.cookiejar import CookieJar
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))
os.environ.setdefault("PM_QUIET", "1")

from app.core import DB, hash_password, verify_password  # noqa: E402
from app.scraper import extract_price, parse_html, parse_price, select  # noqa: E402
from app.server import Handler  # noqa: E402
from app.xlsx import build_csv, build_xlsx  # noqa: E402

FIXTURE_HTML = """<!doctype html><html><body>
<h1 class="title">iPhone 15 Pro</h1>
<div class="product"><span class="price">89 990 ₽</span>
  <span class="old">99 990 ₽</span></div>
<div id="stock" data-price="87500">в наличии</div>
<script type="application/ld+json">
{"@context":"https://schema.org","@type":"Product","offers":{"@type":"Offer","price":"84990","priceCurrency":"RUB"}}
</script>
</body></html>"""


class FixtureHandler(BaseHTTPRequestHandler):
    def do_GET(self):
        body = FIXTURE_HTML.encode()
        self.send_response(200)
        self.send_header("Content-Type", "text/html; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def log_message(self, *a):
        pass


class ParserTest(unittest.TestCase):
    def test_parse_price_formats(self):
        cases = {
            "89 990 ₽": 89990, "1 234,56 руб.": 1234.56, "1,234.56 USD": 1234.56,
            "$12.99": 12.99, "1.234.567": 1234567, "€ 99,00": 99.0, "Цена: 7 490": 7490,
        }
        for raw, expected in cases.items():
            self.assertAlmostEqual(parse_price(raw), expected, places=2, msg=raw)

    def test_parse_price_rejects_garbage(self):
        self.assertIsNone(parse_price("нет в наличии"))
        self.assertIsNone(parse_price(""))

    def test_select_class_and_descendant(self):
        root = parse_html(FIXTURE_HTML)
        self.assertEqual(len(select(root, ".price")), 1)
        self.assertEqual(select(root, ".price")[0].text(), "89 990 ₽")
        self.assertEqual(len(select(root, "div.product .price")), 1)
        self.assertEqual(len(select(root, "#stock")), 1)

    def test_select_attr(self):
        root = parse_html(FIXTURE_HTML)
        nodes = select(root, "[data-price]")
        self.assertEqual(len(nodes), 1)
        self.assertEqual(nodes[0].attrs["data-price"], "87500")

    def test_extract_selector(self):
        price, method = extract_price(FIXTURE_HTML, ".price")
        self.assertEqual(price, 89990)
        self.assertEqual(method, "selector")

    def test_extract_jsonld_fallback(self):
        price, method = extract_price(FIXTURE_HTML, "")
        self.assertEqual(price, 84990)
        self.assertEqual(method, "json-ld")

    def test_extract_missing(self):
        price, method = extract_price("<html><body><p>Нет цены</p></body></html>", ".price")
        self.assertIsNone(price)
        self.assertEqual(method, "selector-not-found")


class XlsxTest(unittest.TestCase):
    def test_xlsx_is_valid_zip(self):
        blob = build_xlsx([["Товар", "Цена"], ["iPhone", 89990]], "Цены")
        z = zipfile.ZipFile(io.BytesIO(blob))
        names = z.namelist()
        self.assertIn("xl/workbook.xml", names)
        self.assertIn("xl/worksheets/sheet1.xml", names)
        sheet = z.read("xl/worksheets/sheet1.xml").decode()
        self.assertIn("iPhone", sheet)
        self.assertIn("89990", sheet)
        self.assertIn("Цены", z.read("xl/workbook.xml").decode())

    def test_csv_bom(self):
        blob = build_csv([["a", "b"], [1, 2]])
        self.assertTrue(blob.startswith(b"\xef\xbb\xbf"))
        self.assertIn(b"a;b", blob)


class MonitorApiTest(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.tmp = tempfile.TemporaryDirectory()
        cls.db = DB(Path(cls.tmp.name) / "test.db")
        cls.db.set_setting("admin_password", hash_password("test-pass-123"))
        Handler.db = cls.db
        Handler.scheduler = None
        cls.httpd = ThreadingHTTPServer(("127.0.0.1", 0), Handler)
        cls.port = cls.httpd.server_address[1]
        threading.Thread(target=cls.httpd.serve_forever, daemon=True).start()
        cls.jar = CookieJar()
        cls.opener = urllib.request.build_opener(urllib.request.HTTPCookieProcessor(cls.jar))
        cls.base = f"http://127.0.0.1:{cls.port}"

        cls.fixture = ThreadingHTTPServer(("127.0.0.1", 0), FixtureHandler)
        cls.fixture_port = cls.fixture.server_address[1]
        threading.Thread(target=cls.fixture.serve_forever, daemon=True).start()

    @classmethod
    def tearDownClass(cls):
        cls.httpd.shutdown(); cls.httpd.server_close()
        cls.fixture.shutdown(); cls.fixture.server_close()
        cls.tmp.cleanup()

    def call(self, path, method="GET", payload=None, raw=False):
        data = json.dumps(payload).encode() if payload is not None else None
        req = urllib.request.Request(self.base + path, data=data, method=method)
        req.add_header("Content-Type", "application/json")
        try:
            with self.opener.open(req, timeout=10) as resp:
                body = resp.read()
                return resp.status, body if raw else json.loads(body)
        except urllib.error.HTTPError as e:
            return e.code, json.loads(e.read().decode())

    def login(self):
        code, _ = self.call("/api/login", "POST", {"password": "test-pass-123"})
        self.assertEqual(code, 200)

    def test_01_health_and_auth(self):
        code, body = self.call("/api/health")
        self.assertEqual(code, 200)
        self.assertEqual(body["service"], "price-monitor-pro")
        code, _ = self.call("/api/stats")
        self.assertEqual(code, 401)
        self.login()
        code, body = self.call("/api/stats")
        self.assertEqual(code, 200)
        self.assertIn("series", body["data"])

    def test_02_source_crud(self):
        self.login()
        code, body = self.call("/api/sources", "POST", {
            "name": "Тест", "url": "https://example.com/p/1", "selector": ".price",
        })
        self.assertEqual(code, 201)
        sid = body["id"]

        code, body = self.call(f"/api/sources/{sid}", "PUT", {"name": "Тест 2"})
        self.assertEqual(code, 200)
        code, body = self.call(f"/api/sources/{sid}")
        self.assertEqual(body["data"]["name"], "Тест 2")

        code, body = self.call("/api/sources", "POST", {"name": "bad", "url": "ftp://x"})
        self.assertEqual(code, 400)

        code, _ = self.call(f"/api/sources/{sid}", "DELETE")
        self.assertEqual(code, 200)

    def test_03_record_history(self):
        self.login()
        _, body = self.call("/api/sources", "POST", {
            "name": "Hist", "url": "https://example.com/p/2", "selector": ".price"})
        sid = body["id"]
        self.db.record_price(sid, 100.0)
        self.db.record_price(sid, 90.0)
        src = self.db.source(sid)
        self.assertEqual(src["last_price"], 90.0)
        self.assertEqual(src["prev_price"], 100.0)
        code, body = self.call(f"/api/history?source={sid}")
        self.assertEqual(code, 200)
        self.assertEqual(len(body["data"]), 2)
        code, body = self.call("/api/changes")
        self.assertTrue(any(c["id"] == sid for c in body["data"]))

    def test_04_check_source_against_fixture(self):
        self.login()
        _, body = self.call("/api/sources", "POST", {
            "name": "Fixture", "url": f"http://127.0.0.1:{self.fixture_port}/",
            "selector": ".price"})
        sid = body["id"]
        # без планировщика API отвечает 503 — это ожидаемо и документировано
        code, body = self.call(f"/api/sources/{sid}/check", "POST")
        self.assertEqual(code, 503)

    def test_05_exports(self):
        self.login()
        code, blob = self.call("/api/export.xlsx", raw=True)
        self.assertEqual(code, 200)
        self.assertTrue(blob.startswith(b"PK"))
        z = zipfile.ZipFile(io.BytesIO(blob))
        self.assertIn("xl/worksheets/sheet1.xml", z.namelist())
        code, blob = self.call("/api/export.csv", raw=True)
        self.assertEqual(code, 200)
        self.assertIn("Источник".encode(), blob)

    def test_06_settings(self):
        self.login()
        code, body = self.call("/api/settings")
        self.assertNotIn("admin_password", body["data"])
        code, _ = self.call("/api/settings", "PUT", {"alert_threshold_pct": "5"})
        self.assertEqual(code, 200)
        self.assertEqual(self.db.get("alert_threshold_pct"), "5")

    def test_07_password(self):
        stored = hash_password("abc12345")
        self.assertTrue(verify_password("abc12345", stored))
        self.assertFalse(verify_password("abc12346", stored))


if __name__ == "__main__":
    unittest.main(verbosity=2)
