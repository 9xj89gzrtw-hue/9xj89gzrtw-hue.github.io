"""Пакет Price Monitor Pro."""
__version__ = "1.0.0"
