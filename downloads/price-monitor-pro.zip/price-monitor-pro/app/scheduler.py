"""Планировщик проверок и Telegram-алерты."""
from __future__ import annotations

import heapq
import json
import threading
import time
import urllib.error
import urllib.request

from .core import DB, now
from .scraper import check_source


class Notifier:
    def __init__(self, db: DB):
        self.db = db

    def send(self, text: str) -> bool:
        token = self.db.get("telegram_token")
        chat = self.db.get("telegram_chat")
        if not token or not chat:
            return False
        url = f"https://api.telegram.org/bot{token}/sendMessage"
        data = json.dumps({"chat_id": chat, "text": text,
                           "parse_mode": "HTML", "disable_web_page_preview": True}).encode()
        req = urllib.request.Request(url, data=data, method="POST")
        req.add_header("Content-Type", "application/json")
        try:
            with urllib.request.urlopen(req, timeout=15) as resp:
                return resp.status == 200
        except (urllib.error.URLError, TimeoutError, OSError) as e:
            print("[alert] telegram error:", e)
            return False


class Scheduler:
    """Фоновый обход источников. Один поток, последовательные проверки,
    чтобы не долбить чужие сайты параллельно."""

    def __init__(self, db: DB, notifier: Notifier | None = None):
        self.db = db
        self.notifier = notifier or Notifier(db)
        self._stop = threading.Event()
        self._wake = threading.Event()
        self._thread: threading.Thread | None = None

    def start(self) -> None:
        if self._thread and self._thread.is_alive():
            return
        self._thread = threading.Thread(target=self._loop, name="price-scheduler", daemon=True)
        self._thread.start()

    def stop(self) -> None:
        self._stop.set()
        self._wake.set()

    def wake(self) -> None:
        self._wake.set()

    def _loop(self) -> None:
        while not self._stop.is_set():
            try:
                due = self.db.due_sources()
                for src in due:
                    if self._stop.is_set():
                        break
                    self.check_one(src)
            except Exception as e:  # noqa: BLE001
                print("[scheduler] error:", repr(e))
            self._wake.wait(timeout=60)
            self._wake.clear()

    def check_one(self, src: dict) -> dict:
        timeout = int(self.db.get("request_timeout", "20") or 20)
        ua = self.db.get("user_agent", "PriceMonitorPro/1.0")
        result = check_source(src, timeout=timeout, user_agent=ua)
        outcome = self.db.record_price(src["id"], result["price"], result["status"])
        if result["price"] is None:
            self.db.log("error", f"⚠️ {src['name']}: не удалось получить цену ({result['status']})")
            return {**result, "changed": False}

        src_now = self.db.source(src["id"]) or src
        self._maybe_alert(src_now, outcome or {})
        return {**result, **(outcome or {})}

    def _maybe_alert(self, src: dict, outcome: dict) -> None:
        if not outcome.get("changed"):
            return
        threshold = float(self.db.get("alert_threshold_pct", "3") or 3)
        pct = outcome.get("change_pct") or 0
        if abs(pct) < threshold:
            return
        arrow = "📉" if pct < 0 else "📈"
        text = (f"{arrow} <b>{src['name']}</b>\n"
                f"{outcome['prev']:.0f} → <b>{outcome['price']:.0f} {src['currency']}</b> "
                f"({pct:+.1f}%)\n{src['url']}")
        if self.notifier.send(text):
            self.db.log("alert", f"Алерт отправлен: {src['name']} ({pct:+.1f}%)")
