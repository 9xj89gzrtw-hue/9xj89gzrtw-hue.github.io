"""Price Monitor Pro — ядро: источники, история цен, статистика, демо-данные.

Zero-dependency: стандартная библиотека Python 3.9+.
"""
from __future__ import annotations

import hashlib
import random
import secrets
import sqlite3
import threading
import time
from pathlib import Path
from urllib.parse import urlparse

BASE_DIR = Path(__file__).resolve().parent.parent
DATA_DIR = BASE_DIR / "data"
DATA_DIR.mkdir(exist_ok=True)
DB_PATH = DATA_DIR / "monitor.db"

DEFAULTS = {
    "admin_password": "",
    "telegram_token": "",
    "telegram_chat": "",
    "alert_threshold_pct": "3",
    "check_hour": "9",
    "demo_mode": "1",
    "request_timeout": "20",
    "user_agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 "
                  "(KHTML, like Gecko) Chrome/124.0 Safari/537.36 PriceMonitorPro/1.0",
    "currency": "RUB",
}

CURRENCY_SIGNS = {"₽": "RUB", "руб": "RUB", "р.": "RUB", "$": "USD", "€": "EUR", "£": "GBP", "₸": "KZT"}


def now() -> int:
    return int(time.time())


def hash_password(password: str, salt: str | None = None) -> str:
    salt = salt or secrets.token_hex(16)
    digest = hashlib.pbkdf2_hmac("sha256", password.encode(), salt.encode(), 120_000)
    return f"{salt}${digest.hex()}"


def verify_password(password: str, stored: str) -> bool:
    if not stored or "$" not in stored:
        return False
    salt, _ = stored.split("$", 1)
    return secrets.compare_digest(hash_password(password, salt), stored)


class DB:
    def __init__(self, path: Path | str = DB_PATH):
        self.path = str(path)
        self._local = threading.local()
        self.conn.execute("PRAGMA journal_mode=WAL")
        self.conn.execute("PRAGMA busy_timeout=5000")
        self._init_schema()
        self._seed_defaults()

    @property
    def conn(self) -> sqlite3.Connection:
        conn = getattr(self._local, "conn", None)
        if conn is None:
            conn = sqlite3.connect(self.path, timeout=10, check_same_thread=False)
            conn.row_factory = sqlite3.Row
            conn.execute("PRAGMA journal_mode=WAL")
            conn.execute("PRAGMA busy_timeout=5000")
            self._local.conn = conn
        return conn

    def _init_schema(self) -> None:
        self.conn.executescript(
            """
            CREATE TABLE IF NOT EXISTS sources(
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT NOT NULL,
                url TEXT NOT NULL,
                selector TEXT NOT NULL DEFAULT '',
                currency TEXT NOT NULL DEFAULT 'RUB',
                interval_min INTEGER NOT NULL DEFAULT 60,
                active INTEGER NOT NULL DEFAULT 1,
                created_at INTEGER NOT NULL,
                last_price REAL,
                prev_price REAL,
                last_checked INTEGER DEFAULT 0,
                last_status TEXT DEFAULT 'new',
                checks INTEGER DEFAULT 0,
                min_price REAL,
                max_price REAL
            );
            CREATE TABLE IF NOT EXISTS history(
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                source_id INTEGER NOT NULL REFERENCES sources(id) ON DELETE CASCADE,
                price REAL,
                status TEXT NOT NULL DEFAULT 'ok',
                checked_at INTEGER NOT NULL
            );
            CREATE TABLE IF NOT EXISTS settings(key TEXT PRIMARY KEY, value TEXT NOT NULL);
            CREATE TABLE IF NOT EXISTS events(
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                kind TEXT NOT NULL,
                message TEXT NOT NULL,
                created_at INTEGER NOT NULL
            );
            CREATE INDEX IF NOT EXISTS idx_hist_source ON history(source_id, checked_at);
            """
        )
        self.conn.commit()

    def _seed_defaults(self) -> None:
        for k, v in DEFAULTS.items():
            self.conn.execute("INSERT OR IGNORE INTO settings(key,value) VALUES(?,?)", (k, v))
        row = self.conn.execute("SELECT value FROM settings WHERE key='admin_password'").fetchone()
        if row and not row["value"]:
            self.set_setting("admin_password", hash_password("admin123"))
            self.log("system", "Создан пароль администратора по умолчанию (admin123) — смените его.")
        self.conn.commit()

    # ---------- settings ----------
    def get(self, key: str, default: str = "") -> str:
        row = self.conn.execute("SELECT value FROM settings WHERE key=?", (key,)).fetchone()
        return row["value"] if row else default

    def set_setting(self, key: str, value) -> None:
        self.conn.execute(
            "INSERT INTO settings(key,value) VALUES(?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value",
            (key, str(value)))
        self.conn.commit()

    def settings(self, safe: bool = True) -> dict:
        data = {r["key"]: r["value"] for r in self.conn.execute("SELECT * FROM settings")}
        if safe:
            data.pop("admin_password", None)
            for k in ("telegram_token",):
                if data.get(k):
                    v = data[k]
                    data[k] = v[:4] + "•" * 8 + v[-4:] if len(v) > 8 else "•" * len(v)
        return data

    # ---------- events ----------
    def log(self, kind: str, message: str) -> None:
        self.conn.execute("INSERT INTO events(kind,message,created_at) VALUES(?,?,?)",
                          (kind, message, now()))
        self.conn.commit()

    def events(self, limit: int = 12) -> list[dict]:
        return [dict(r) for r in self.conn.execute(
            "SELECT * FROM events ORDER BY id DESC LIMIT ?", (limit,))]

    # ---------- sources ----------
    def sources(self, active_only: bool = False) -> list[dict]:
        sql = "SELECT * FROM sources"
        if active_only:
            sql += " WHERE active=1"
        sql += " ORDER BY id"
        rows = []
        for r in self.conn.execute(sql):
            d = dict(r)
            d["host"] = urlparse(d["url"]).netloc
            d["change_pct"] = round((d["last_price"] - d["prev_price"]) / d["prev_price"] * 100, 2) \
                if d["last_price"] and d["prev_price"] else None
            rows.append(d)
        return rows

    def source(self, sid: int) -> dict | None:
        row = self.conn.execute("SELECT * FROM sources WHERE id=?", (sid,)).fetchone()
        return dict(row) if row else None

    def add_source(self, name: str, url: str, selector: str, currency: str = "RUB",
                   interval_min: int = 60, active: int = 1) -> int:
        cur = self.conn.execute(
            """INSERT INTO sources(name,url,selector,currency,interval_min,active,created_at)
               VALUES(?,?,?,?,?,?,?)""",
            (name.strip(), url.strip(), selector.strip(), currency, int(interval_min),
             int(active), now()))
        self.conn.commit()
        return int(cur.lastrowid)

    def update_source(self, sid: int, **fields) -> None:
        allowed = {"name", "url", "selector", "currency", "interval_min", "active"}
        data = {k: v for k, v in fields.items() if k in allowed}
        if not data:
            return
        sets = ", ".join(f"{k}=?" for k in data)
        self.conn.execute(f"UPDATE sources SET {sets} WHERE id=?", (*data.values(), sid))
        self.conn.commit()

    def delete_source(self, sid: int) -> None:
        self.conn.execute("DELETE FROM sources WHERE id=?", (sid,))
        self.conn.commit()

    def record_price(self, sid: int, price: float | None, status: str = "ok") -> dict | None:
        src = self.source(sid)
        if not src:
            return None
        ts = now()
        prev = src["last_price"]
        if price is not None and prev is not None and abs(price - prev) < 0.005:
            price = prev  # не плодим шум от округления
        self.conn.execute(
            "INSERT INTO history(source_id,price,status,checked_at) VALUES(?,?,?,?)",
            (sid, price, status, ts))
        self.conn.execute(
            """UPDATE sources SET prev_price=COALESCE(?,prev_price), last_price=COALESCE(?,last_price),
               last_checked=?, last_status=?, checks=checks+1,
               min_price=CASE WHEN ? IS NULL THEN min_price ELSE MIN(COALESCE(min_price,?),?) END,
               max_price=CASE WHEN ? IS NULL THEN max_price ELSE MAX(COALESCE(max_price,?),?) END
               WHERE id=?""",
            (prev, price, ts, status, price, price, price, price, price, price, sid))
        self.conn.commit()
        changed = price is not None and prev is not None and abs(price - prev) >= 0.005
        if changed:
            pct = (price - prev) / prev * 100
            arrow = "📉" if pct < 0 else "📈"
            self.log("price", f"{arrow} {src['name']}: {prev:,.0f} → {price:,.0f} {src['currency']} "
                              f"({pct:+.1f}%)".replace(",", " "))
        return {"price": price, "prev": prev, "changed": changed,
                "change_pct": round((price - prev) / prev * 100, 2) if changed else None}

    def history(self, sid: int | None = None, limit: int = 500) -> list[dict]:
        if sid:
            rows = self.conn.execute(
                "SELECT * FROM history WHERE source_id=? ORDER BY checked_at DESC LIMIT ?",
                (sid, limit))
        else:
            rows = self.conn.execute(
                "SELECT h.*, s.name, s.currency FROM history h JOIN sources s ON s.id=h.source_id "
                "ORDER BY h.checked_at DESC LIMIT ?", (limit,))
        return [dict(r) for r in rows]

    # ---------- analytics ----------
    def changes(self, limit: int = 20) -> list[dict]:
        rows = self.conn.execute(
            """SELECT s.id, s.name, s.currency, s.last_price, s.prev_price, s.last_checked
               FROM sources s WHERE s.last_price IS NOT NULL AND s.prev_price IS NOT NULL
                 AND ABS(s.last_price - s.prev_price) >= 0.005
               ORDER BY ABS(s.last_price - s.prev_price)/s.prev_price DESC LIMIT ?""", (limit,))
        out = []
        for r in rows:
            d = dict(r)
            d["change_pct"] = round((d["last_price"] - d["prev_price"]) / d["prev_price"] * 100, 2)
            d["diff"] = round(d["last_price"] - d["prev_price"], 2)
            out.append(d)
        return out

    def stats(self, days: int = 30) -> dict:
        total = self.conn.execute("SELECT COUNT(*) n FROM sources").fetchone()["n"]
        active = self.conn.execute("SELECT COUNT(*) n FROM sources WHERE active=1").fetchone()["n"]
        checks_today = self.conn.execute(
            "SELECT COUNT(*) n FROM history WHERE checked_at>=?",
            (now() - 86400,)).fetchone()["n"]
        drops = self.conn.execute(
            """SELECT COUNT(*) n FROM sources WHERE last_price IS NOT NULL AND prev_price IS NOT NULL
               AND last_price < prev_price - 0.005""").fetchone()["n"]
        ups = self.conn.execute(
            """SELECT COUNT(*) n FROM sources WHERE last_price IS NOT NULL AND prev_price IS NOT NULL
               AND last_price > prev_price + 0.005""").fetchone()["n"]
        avg_change = self.conn.execute(
            """SELECT AVG((last_price-prev_price)/prev_price*100) v FROM sources
               WHERE last_price IS NOT NULL AND prev_price IS NOT NULL AND prev_price>0""").fetchone()["v"]
        potential = self.conn.execute(
            """SELECT SUM(COALESCE(max_price,last_price)-last_price) v FROM sources
               WHERE last_price IS NOT NULL AND max_price IS NOT NULL""").fetchone()["v"] or 0

        # индекс цен: средняя цена по дням (нормируем к 100 на старте окна)
        series = []
        day0 = now() - days * 86400
        rows = self.conn.execute(
            """SELECT (checked_at/86400)*86400 d, AVG(price) p FROM history
               WHERE price IS NOT NULL AND checked_at>=? GROUP BY d ORDER BY d""", (day0,)).fetchall()
        base = rows[0]["p"] if rows else None
        for r in rows:
            series.append({
                "date": time.strftime("%d.%m", time.localtime(r["d"])),
                "index": round(r["p"] / base * 100, 1) if base else 100,
                "avg_price": round(r["p"], 2),
            })

        cheapest = [dict(r) for r in self.conn.execute(
            """SELECT name, last_price, currency, (SELECT MIN(price) FROM history h
               WHERE h.source_id=s.id AND price IS NOT NULL) best
               FROM sources s WHERE last_price IS NOT NULL ORDER BY last_price LIMIT 5""")]

        return {
            "sources": total, "active": active, "checks_today": checks_today,
            "drops": drops, "ups": ups,
            "avg_change": round(avg_change, 2) if avg_change is not None else 0,
            "potential": round(potential, 2),
            "series": series,
            "changes": self.changes(8),
            "cheapest": cheapest,
            "currency": self.get("currency", "RUB"),
        }

    def due_sources(self) -> list[dict]:
        cutoff = now() - 60
        return [dict(r) for r in self.conn.execute(
            """SELECT * FROM sources WHERE active=1 AND (last_checked=0 OR last_checked + interval_min*60 <= ?)
               AND last_checked <= ?""", (now(), cutoff))]


def seed_demo(db: DB) -> None:
    if db.conn.execute("SELECT COUNT(*) n FROM sources").fetchone()["n"]:
        return
    demo = [
        ("iPhone 15 Pro 128GB", "https://shop.example.ru/iphone-15-pro", ".product-price", 89_990, 60),
        ("Samsung Galaxy S24 256GB", "https://shop.example.ru/galaxy-s24", "[data-price]", 74_490, 60),
        ("AirPods Pro 2 USB-C", "https://market.example.ru/airpods-pro-2", ".price__value", 21_990, 120),
        ("Dyson V15 Detect", "https://market.example.ru/dyson-v15", "span.price", 64_900, 180),
        ("MacBook Air M3 13\"", "https://shop.example.ru/macbook-air-m3", "#price", 109_900, 60),
        ("PlayStation 5 Slim", "https://market.example.ru/ps5-slim", ".product__price", 54_990, 120),
    ]
    ids = [db.add_source(name, url, sel, "RUB", interval) for name, url, sel, _, interval in demo]
    rnd = random.Random(42)
    base_prices = [d[3] for d in demo]
    for i, sid in enumerate(ids):
        price = float(base_prices[i])
        for day in range(29, -1, -1):
            ts = now() - day * 86400 - 7200
            drift = rnd.choice([0, 0, 0, -0.004, 0.003, -0.007, 0.002])
            price = round(price * (1 + drift), 0)
            db.conn.execute(
                "INSERT INTO history(source_id,price,status,checked_at) VALUES(?,?,?,?)",
                (sid, price, "ok", ts))
        # последняя точка — текущая
        h = db.conn.execute(
            "SELECT price FROM history WHERE source_id=? ORDER BY checked_at DESC LIMIT 1 OFFSET 1",
            (sid,)).fetchone()
        prev = h["price"] if h else price
        db.conn.execute(
            """UPDATE sources SET last_price=?, prev_price=?, last_checked=?, checks=?,
               last_status='ok',
               min_price=(SELECT MIN(price) FROM history WHERE source_id=?),
               max_price=(SELECT MAX(price) FROM history WHERE source_id=?) WHERE id=?""",
            (price, prev, now() - 600 - i * 300, 30, sid, sid, sid))
    db.conn.commit()
    db.log("system", "Демо-данные: 6 источников, 30 дней истории цен.")
