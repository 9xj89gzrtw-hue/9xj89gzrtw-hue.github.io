"""Price Monitor Pro — HTTP-сервер админки и API."""
from __future__ import annotations

import hmac
import json
import mimetypes
import os
import re
import secrets
import time
from http import cookies
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import parse_qs, urlparse

from .core import BASE_DIR, DATA_DIR, DB, hash_password, now, verify_password
from .scheduler import Scheduler
from .xlsx import build_csv, build_xlsx

WEB_DIR = BASE_DIR / "web"
SECRET_FILE = DATA_DIR / "secret.key"
COOKIE = "pm_session"
TTL = 60 * 60 * 12


def _secret() -> bytes:
    if SECRET_FILE.exists():
        return SECRET_FILE.read_bytes()
    value = secrets.token_bytes(32)
    SECRET_FILE.write_bytes(value)
    try:
        SECRET_FILE.chmod(0o600)
    except OSError:
        pass
    return value


SECRET = _secret()


def make_session() -> str:
    ts = str(int(time.time()))
    sig = hmac.new(SECRET, ts.encode(), "sha256").hexdigest()[:40]
    return f"{ts}.{sig}"


def valid_session(token: str) -> bool:
    if not token or "." not in token:
        return False
    ts, sig = token.split(".", 1)
    expected = hmac.new(SECRET, ts.encode(), "sha256").hexdigest()[:40]
    if not hmac.compare_digest(sig, expected):
        return False
    try:
        return time.time() - int(ts) < TTL
    except ValueError:
        return False


class ApiError(Exception):
    def __init__(self, message: str, status: int = 400):
        super().__init__(message)
        self.message = message
        self.status = status


class Handler(BaseHTTPRequestHandler):
    db: DB
    scheduler: Scheduler | None = None
    server_version = "PriceMonitorPro/1.0"

    def log_message(self, fmt, *args):
        if os.environ.get("PM_QUIET") == "1":
            return
        print("[http] " + fmt % args)

    def _send(self, status: int, body: bytes, ctype="application/json; charset=utf-8",
              extra: dict | None = None):
        self.send_response(status)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(body)))
        self.send_header("X-Content-Type-Options", "nosniff")
        self.send_header("Cache-Control", "no-store")
        for k, v in (extra or {}).items():
            self.send_header(k, v)
        self.end_headers()
        if self.command != "HEAD":
            self.wfile.write(body)

    def json(self, data, status=200, extra=None):
        self._send(status, json.dumps(data, ensure_ascii=False).encode(), extra=extra)

    def error(self, message, status=400):
        self.json({"ok": False, "error": message}, status)

    def token(self) -> str:
        jar = cookies.SimpleCookie()
        try:
            jar.load(self.headers.get("Cookie", ""))
        except cookies.CookieError:
            return ""
        m = jar.get(COOKIE)
        return m.value if m else ""

    def require_auth(self):
        if not valid_session(self.token()):
            raise ApiError("Требуется вход в панель", 401)

    def body(self) -> dict:
        length = int(self.headers.get("Content-Length") or 0)
        if length > 2_000_000:
            raise ApiError("Слишком большой запрос", 413)
        raw = self.rfile.read(length) if length else b""
        if not raw:
            return {}
        try:
            data = json.loads(raw.decode("utf-8"))
        except (ValueError, UnicodeDecodeError):
            raise ApiError("Некорректный JSON")
        if not isinstance(data, dict):
            raise ApiError("Ожидался JSON-объект")
        return data

    def do_GET(self):
        parsed = urlparse(self.path)
        try:
            if parsed.path.startswith("/api/"):
                self.api("GET", parsed.path, parse_qs(parsed.query), None)
            else:
                self.static(parsed.path)
        except ApiError as e:
            self.error(e.message, e.status)
        except BrokenPipeError:
            pass
        except Exception as e:  # noqa: BLE001
            print("[error]", repr(e))
            self.error("Внутренняя ошибка сервера", 500)

    do_HEAD = do_GET

    def do_POST(self):
        self.mutate("POST")

    def do_PUT(self):
        self.mutate("PUT")

    def do_DELETE(self):
        self.mutate("DELETE")

    def mutate(self, method):
        parsed = urlparse(self.path)
        try:
            self.api(method, parsed.path, parse_qs(parsed.query), self.body())
        except ApiError as e:
            self.error(e.message, e.status)
        except BrokenPipeError:
            pass
        except Exception as e:  # noqa: BLE001
            print("[error]", repr(e))
            self.error("Внутренняя ошибка сервера", 500)

    def static(self, path: str):
        if path in ("/", ""):
            path = "/index.html"
        target = (WEB_DIR / path.lstrip("/")).resolve()
        if not str(target).startswith(str(WEB_DIR.resolve())) or not target.is_file():
            target = WEB_DIR / "index.html"
        if not target.is_file():
            return self.error("Не найдено", 404)
        ctype = mimetypes.guess_type(str(target))[0] or "application/octet-stream"
        if ctype.startswith("text/") or "javascript" in ctype:
            ctype += "; charset=utf-8"
        self._send(200, target.read_bytes(), ctype)

    # ---------- export ----------
    def export_rows(self) -> list[list]:
        rows = [["Источник", "URL", "Селектор", "Текущая цена", "Мин. цена", "Макс. цена",
                 "Изменение, %", "Валюта", "Проверено"]]
        for s in self.db.sources():
            change = s.get("change_pct")
            rows.append([
                s["name"], s["url"], s["selector"] or "(авто)",
                s["last_price"] if s["last_price"] is not None else "—",
                s["min_price"] if s["min_price"] is not None else "—",
                s["max_price"] if s["max_price"] is not None else "—",
                change if change is not None else "—",
                s["currency"],
                time.strftime("%d.%m.%Y %H:%M", time.localtime(s["last_checked"])) if s["last_checked"] else "—",
            ])
        return rows

    # ---------- api ----------
    def api(self, method: str, path: str, query: dict, data: dict | None):
        db = self.db

        if path == "/api/health":
            return self.json({"ok": True, "service": "price-monitor-pro", "version": "1.0.0"})

        if path == "/api/login" and method == "POST":
            if verify_password(str((data or {}).get("password", "")), db.get("admin_password")):
                return self.json({"ok": True}, extra={
                    "Set-Cookie": f"{COOKIE}={make_session()}; Path=/; HttpOnly; SameSite=Lax; Max-Age={TTL}"})
            db.log("auth", "Неудачная попытка входа")
            return self.error("Неверный пароль", 401)

        if path == "/api/logout" and method == "POST":
            return self.json({"ok": True}, extra={
                "Set-Cookie": f"{COOKIE}=; Path=/; HttpOnly; SameSite=Lax; Max-Age=0"})

        if path == "/api/me":
            return self.json({"ok": True, "authenticated": valid_session(self.token())})

        self.require_auth()

        if path == "/api/stats":
            return self.json({"ok": True, "data": db.stats()})

        if path == "/api/events":
            return self.json({"ok": True, "data": db.events()})

        if path == "/api/sources":
            if method == "GET":
                return self.json({"ok": True, "data": db.sources()})
            if method == "POST":
                payload = data or {}
                name = str(payload.get("name", "")).strip()
                url = str(payload.get("url", "")).strip()
                if not name:
                    raise ApiError("Укажите название товара")
                if not re.match(r"^https?://", url):
                    raise ApiError("URL должен начинаться с http:// или https://")
                sid = db.add_source(name, url, str(payload.get("selector", "")),
                                    str(payload.get("currency", "RUB")),
                                    int(payload.get("interval_min", 60)),
                                    int(payload.get("active", 1)))
                db.log("source", f"Добавлен источник «{name}»")
                return self.json({"ok": True, "id": sid}, 201)

        m = re.match(r"^/api/sources/(\d+)$", path)
        if m:
            sid = int(m.group(1))
            if method == "GET":
                src = db.source(sid)
                if not src:
                    raise ApiError("Источник не найден", 404)
                return self.json({"ok": True, "data": src})
            if method == "PUT":
                db.update_source(sid, **(data or {}))
                return self.json({"ok": True})
            if method == "DELETE":
                db.delete_source(sid)
                db.log("source", f"Источник #{sid} удалён")
                return self.json({"ok": True})

        m = re.match(r"^/api/sources/(\d+)/check$", path)
        if m and method == "POST":
            sid = int(m.group(1))
            src = db.source(sid)
            if not src:
                raise ApiError("Источник не найден", 404)
            if not self.scheduler:
                raise ApiError("Планировщик не запущен", 503)
            result = self.scheduler.check_one(src)
            if result.get("price") is None:
                raise ApiError(f"Не удалось получить цену: {result.get('status')}", 422)
            return self.json({"ok": True, "data": result, "source": db.source(sid)})

        if path == "/api/check-all" and method == "POST":
            if not self.scheduler:
                raise ApiError("Планировщик не запущен", 503)
            checked = 0
            for src in db.sources(active_only=True):
                try:
                    self.scheduler.check_one(src)
                    checked += 1
                except Exception:  # noqa: BLE001
                    continue
            return self.json({"ok": True, "checked": checked})

        if path == "/api/history":
            sid = query.get("source", [None])[0]
            limit = int(query.get("limit", ["300"])[0])
            return self.json({"ok": True, "data": db.history(int(sid) if sid else None, limit)})

        if path == "/api/changes":
            return self.json({"ok": True, "data": db.changes(30)})

        if path == "/api/export.xlsx":
            body = build_xlsx(self.export_rows(), "Мониторинг цен")
            return self._send(200, body,
                              "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                              {"Content-Disposition": 'attachment; filename="price-monitor.xlsx"'})

        if path == "/api/export.csv":
            body = build_csv(self.export_rows())
            return self._send(200, body, "text/csv; charset=utf-8",
                              {"Content-Disposition": 'attachment; filename="price-monitor.csv"'})

        if path == "/api/settings":
            if method == "GET":
                return self.json({"ok": True, "data": db.settings()})
            if method == "PUT":
                payload = data or {}
                if payload.get("new_password"):
                    pwd = str(payload.pop("new_password"))
                    payload.pop("new_password_repeat", None)
                    if len(pwd) < 8:
                        raise ApiError("Пароль короче 8 символов")
                    db.set_setting("admin_password", hash_password(pwd))
                for k, v in payload.items():
                    if k == "admin_password":
                        continue
                    db.set_setting(k, v)
                db.log("settings", "Настройки обновлены")
                return self.json({"ok": True})

        if path == "/api/test-telegram" and method == "POST":
            if not self.scheduler:
                raise ApiError("Планировщик не запущен", 503)
            ok = self.scheduler.notifier.send("✅ Price Monitor Pro: тестовое уведомление")
            if not ok:
                raise ApiError("Telegram не принял сообщение — проверьте токен и chat_id", 422)
            return self.json({"ok": True})

        raise ApiError("Метод API не найден", 404)


def serve(port: int = 8070, host: str = "127.0.0.1", with_scheduler: bool = True):
    db = DB()
    Handler.db = db
    scheduler = Scheduler(db)
    Handler.scheduler = scheduler
    if with_scheduler:
        scheduler.start()
    httpd = ThreadingHTTPServer((host, port), Handler)
    httpd.daemon_threads = True
    httpd.scheduler = scheduler  # type: ignore[attr-defined]
    return httpd
