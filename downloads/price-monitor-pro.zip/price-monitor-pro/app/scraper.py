"""Парсер цен: HTML → DOM → CSS-селектор → число.

Поддерживается подмножество CSS: tag, .class, #id, [attr], [attr=value],
`*`, потомки через пробел и `>`; группы через запятую.
Если селектор пуст — цена ищется в schema.org/JSON-LD и meta-тегах.
"""
from __future__ import annotations

import json
import re
import urllib.error
import urllib.request
from html.parser import HTMLParser
from typing import Iterable

VOID = {"area", "base", "br", "col", "embed", "hr", "img", "input", "link",
        "meta", "param", "source", "track", "wbr"}


class Node:
    __slots__ = ("tag", "attrs", "children", "parent")

    def __init__(self, tag: str, attrs: dict | None = None, parent: "Node | None" = None):
        self.tag = tag
        self.attrs = attrs or {}
        self.children: list[Node] = []
        self.parent = parent

    def text(self) -> str:
        parts: list[str] = []
        for child in self.children:
            if isinstance(child, str):
                parts.append(child)
            else:
                parts.append(child.text())
        return " ".join(" ".join(parts).split())

    def classes(self) -> list[str]:
        return (self.attrs.get("class") or "").split()

    def __repr__(self) -> str:  # pragma: no cover
        return f"<{self.tag} class={self.attrs.get('class', '')!r}>"


class TreeBuilder(HTMLParser):
    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.root = Node("#document")
        self.stack = [self.root]

    def handle_starttag(self, tag, attrs):
        node = Node(tag.lower(), {k.lower(): (v or "") for k, v in attrs}, self.stack[-1])
        self.stack[-1].children.append(node)
        if tag.lower() not in VOID:
            self.stack.append(node)

    def handle_startendtag(self, tag, attrs):
        node = Node(tag.lower(), {k.lower(): (v or "") for k, v in attrs}, self.stack[-1])
        self.stack[-1].children.append(node)

    def handle_endtag(self, tag):
        tag = tag.lower()
        for i in range(len(self.stack) - 1, 0, -1):
            if self.stack[i].tag == tag:
                del self.stack[i:]
                break

    def handle_data(self, data):
        if data:
            self.stack[-1].children.append(data)


def parse_html(html_text: str) -> Node:
    builder = TreeBuilder()
    try:
        builder.feed(html_text)
        builder.close()
    except Exception:  # noqa: BLE001 - битый HTML не должен ронять монитор
        pass
    return builder.root


# ---------- selectors ----------
_SIMPLE = re.compile(r"(?P<tag>[a-zA-Z][\w-]*|\*)?"
                     r"(?P<id>#[\w-]+)?"
                     r"(?P<cls>(?:\.[\w-]+)+)?"
                     r"(?P<attr>(?:\[[^\]]+\])*)")


class Simple:
    def __init__(self, raw: str):
        m = _SIMPLE.fullmatch(raw.strip())
        if not m:
            raise ValueError(f"Неподдерживаемый селектор: {raw!r}")
        self.tag = (m.group("tag") or "*").lower()
        self.id = (m.group("id") or "")[1:] or None
        self.classes = [c for c in (m.group("cls") or "").split(".") if c]
        self.attrs: list[tuple[str, str | None]] = []
        for chunk in re.findall(r"\[([^\]]+)\]", m.group("attr") or ""):
            if "=" in chunk:
                k, v = chunk.split("=", 1)
                self.attrs.append((k.strip().lower(), v.strip().strip("'\"")))
            else:
                self.attrs.append((chunk.strip().lower(), None))

    def matches(self, node: Node) -> bool:
        if node.tag == "#document" or (self.tag != "*" and node.tag != self.tag):
            return False
        if self.id and node.attrs.get("id") != self.id:
            return False
        node_classes = node.classes()
        if any(c not in node_classes for c in self.classes):
            return False
        for key, value in self.attrs:
            if key not in node.attrs:
                return False
            if value is not None and node.attrs.get(key) != value:
                return False
        return True


def _parse_chain(part: str) -> list[tuple[str, Simple]]:
    tokens = part.replace(">", " > ").split()
    chain: list[tuple[str, Simple]] = []
    combinator = " "
    for token in tokens:
        if token == ">":
            combinator = ">"
            continue
        chain.append((combinator, Simple(token)))
        combinator = " "
    return chain


def _matches_chain(node: Node, chain: list[tuple[str, Simple]], index: int) -> bool:
    combinator, simple = chain[index]
    if not simple.matches(node):
        return False
    if index == 0:
        return True
    if combinator == ">":
        return node.parent is not None and _matches_chain(node.parent, chain, index - 1)
    parent = node.parent
    while parent is not None:
        if _matches_chain(parent, chain, index - 1):
            return True
        parent = parent.parent
    return False


def select(root: Node, selector: str) -> list[Node]:
    result: list[Node] = []
    seen: set[int] = set()
    for group in selector.split(","):
        group = group.strip()
        if not group:
            continue
        try:
            chain = _parse_chain(group)
        except ValueError:
            continue
        stack = [root]
        while stack:
            node = stack.pop()
            if _matches_chain(node, chain, len(chain) - 1) and id(node) not in seen:
                seen.add(id(node))
                result.append(node)
            for child in node.children:
                if isinstance(child, Node):
                    stack.append(child)
    return result


# ---------- price extraction ----------
_CLEAN = re.compile(r"[\u00a0\u202f\u2009]")
_NUM = re.compile(r"\d[\d\s.,]*\d|\d")


def parse_price(text: str) -> float | None:
    if not text:
        return None
    text = _CLEAN.sub(" ", text)
    best = None
    for raw in _NUM.findall(text):
        candidate = raw.strip()
        if not candidate:
            continue
        if "," in candidate and "." in candidate:
            if candidate.rfind(",") > candidate.rfind("."):
                candidate = candidate.replace(".", "").replace(",", ".")
            else:
                candidate = candidate.replace(",", "")
        elif "," in candidate:
            decimal = candidate.split(",")[-1]
            candidate = candidate.replace(",", ".") if len(decimal) <= 2 else candidate.replace(",", "")
        else:
            # 1.234 — либо тысячи, либо дробь
            if candidate.count(".") == 1 and len(candidate.split(".")[-1]) == 3:
                candidate = candidate.replace(".", "")
            elif candidate.count(".") > 1:
                candidate = candidate.replace(".", "")
        candidate = candidate.replace(" ", "")
        try:
            value = float(candidate)
        except ValueError:
            continue
        if value <= 0:
            continue
        if best is None or value > best and value < 10_000_000:
            best = value
    return round(best, 2) if best is not None else None


def extract_jsonld_price(html_text: str) -> float | None:
    for match in re.finditer(r'<script[^>]+application/ld\+json[^>]*>(.*?)</script>',
                             html_text, re.S | re.I):
        raw = match.group(1).strip()
        try:
            data = json.loads(raw)
        except ValueError:
            continue
        stack = data if isinstance(data, list) else [data]
        while stack:
            item = stack.pop()
            if isinstance(item, dict):
                offers = item.get("offers")
                if isinstance(offers, dict):
                    price = offers.get("price") or offers.get("lowPrice")
                    if price is not None:
                        value = parse_price(str(price))
                        if value:
                            return value
                elif isinstance(offers, list) and offers:
                    value = parse_price(str(offers[0].get("price", "")))
                    if value:
                        return value
                stack.extend(item.values())
            elif isinstance(item, list):
                stack.extend(item)
    for pattern in (r'itemprop=["\']price["\'][^>]*content=["\']([\d.,]+)',
                    r'content=["\']([\d.,]+)["\'][^>]*itemprop=["\']price["\']',
                    r'property=["\']product:price:amount["\'][^>]*content=["\']([\d.,]+)'):
        m = re.search(pattern, html_text, re.I)
        if m:
            value = parse_price(m.group(1))
            if value:
                return value
    return None


def extract_price(html_text: str, selector: str = "") -> tuple[float | None, str]:
    """Возвращает (цена, способ)."""
    if selector.strip():
        root = parse_html(html_text)
        for node in select(root, selector):
            value = parse_price(node.text())
            if value:
                return value, "selector"
            for attr in ("content", "data-price", "value"):
                if attr in node.attrs:
                    value = parse_price(node.attrs[attr])
                    if value:
                        return value, "selector-attr"
        return None, "selector-not-found"
    value = extract_jsonld_price(html_text)
    if value:
        return value, "json-ld"
    # последний шанс: meta og:price
    m = re.search(r'<meta[^>]+(?:og:price:amount|product:price:amount)[^>]+content=["\']([\d.,]+)',
                  html_text, re.I)
    if m:
        return parse_price(m.group(1)), "meta"
    return None, "not-found"


def fetch(url: str, timeout: int = 20, user_agent: str = "PriceMonitorPro/1.0") -> tuple[int, str]:
    req = urllib.request.Request(url, headers={
        "User-Agent": user_agent,
        "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
        "Accept-Language": "ru-RU,ru;q=0.9,en;q=0.8",
    })
    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            raw = resp.read(3_000_000)
            charset = resp.headers.get_content_charset() or "utf-8"
            return resp.status, raw.decode(charset, "replace")
    except urllib.error.HTTPError as e:
        return e.code, ""
    except (urllib.error.URLError, TimeoutError, OSError):
        return 0, ""


def check_source(src: dict, timeout: int = 20, user_agent: str = "PriceMonitorPro/1.0") -> dict:
    """Проверяет один источник; возвращает результат для записи в БД."""
    status, html_text = fetch(src["url"], timeout=timeout, user_agent=user_agent)
    if status != 200 or not html_text:
        return {"price": None, "status": f"http-{status}" if status else "network-error",
                "method": "none"}
    price, method = extract_price(html_text, src.get("selector", ""))
    if price is None:
        return {"price": None, "status": "not-found", "method": method}
    return {"price": price, "status": "ok", "method": method}
