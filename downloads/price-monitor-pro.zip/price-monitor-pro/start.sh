#!/usr/bin/env bash
# Price Monitor Pro — запуск одной командой
set -euo pipefail
cd "$(dirname "$0")"

PY="${PYTHON:-python3}"
if ! command -v "$PY" >/dev/null 2>&1; then
  echo "❌ Python 3 не найден. Установите Python 3.9+."
  exit 1
fi

PORT="${PORT:-8070}"
echo "📊  Price Monitor Pro"
echo "    панель: http://127.0.0.1:${PORT}"
echo "    логин:  admin / admin123"
echo

exec "$PY" run.py --port "$PORT" --demo "$@"
