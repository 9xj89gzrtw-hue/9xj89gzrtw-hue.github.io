# 📊 Price Monitor Pro

**A web panel for competitor price monitoring with Telegram alerts and Excel export.**
Installs in a minute, runs with zero pip dependencies, stores everything in local SQLite.

![Dashboard](screenshots/01-dashboard.png)

---

## Features

| Feature | Details |
|---|---|
| **Monitoring** | Any HTML page: CSS price selector or automatic schema.org / JSON-LD detection |
| **Scheduling** | Per-product interval (5 minutes – 24 hours) |
| **History** | Every check is stored; price chart and full table |
| **Alerts** | Telegram notification when change exceeds a threshold (3% by default) |
| **Export** | `.xlsx` report, `.csv` for CRM, JSON API |
| **Analytics** | Price index, risers/fallers, savings potential |
| **Reliability** | Timeouts, broken-markup tolerance, error statuses |

**Stack:** Python 3.9+, standard library, SQLite. **No** `pip install`, **no** CDN.
Runs on a $3 VPS, a Raspberry Pi or Windows.

---

## Screenshots

| Sources | Price history | Export |
|---|---|---|
| ![](screenshots/02-sources.png) | ![](screenshots/03-history.png) | ![](screenshots/04-export.png) |

---

## Quick start

### macOS / Linux
```bash
unzip price-monitor-pro.zip && cd price-monitor-pro
./start.sh
```

### Windows
Double-click **`start.bat`**.

### Docker
```bash
docker compose up -d --build
```

Panel: **http://127.0.0.1:8070** · password **`admin123`** (change it in settings).

---

## Adding a competitor

1. Open the competitor's product page in a browser.
2. Right-click the price → **Inspect** → copy the element's `class` or `id`.
3. In the panel: **Sources → Add source**:
   - **URL** — page address;
   - **CSS selector** — e.g. `.product-price`, `#price`, `[data-price]`;
   - **Interval** — how often to check.
4. Press **↻** to check immediately.

Leave the selector empty and the parser will try `application/ld+json` (schema.org Offer)
and `meta` tags — this works on most Bitrix, WordPress/WooCommerce and Tilda stores.

### Selector examples
| Markup | Selector |
|---|---|
| `<span class="product-price">89 990 ₽</span>` | `.product-price` |
| `<div id="price">…</div>` | `#price` |
| `<div class="card"><b class="sum">…</b></div>` | `.card .sum` |
| `<meta itemprop="price" content="89990">` | leave empty |

---

## Telegram alerts

1. **@BotFather** → `/newbot` → token.
2. Send `/start` to your bot (it cannot message you first).
3. Get your chat_id from **@userinfobot**.
4. Panel → **Settings → Telegram alerts** → paste token and chat_id → **Send test**.

A message arrives when the price moves beyond the threshold:
```
📉 iPhone 15 Pro 128GB
89 990 → 86 268 RUB (-4.1%)
https://shop.example.ru/iphone-15-pro
```

---

## Export

| Format | Contents |
|---|---|
| **XLSX** | All sources: price, min/max, change %, currency, last check. Styled header, auto-filter |
| **CSV** | `;` delimiter, UTF-8 BOM — opens cleanly in Excel |
| **JSON** | `/api/sources`, `/api/history`, `/api/stats`, `/api/changes` |

XLSX is produced by a built-in OOXML writer (`zipfile`) — no openpyxl, no pandas.

---

## Layout

```
price-monitor-pro/
├── run.py
├── app/
│   ├── core.py        # database, analytics, demo seed
│   ├── scraper.py     # HTML → DOM → CSS selector → number
│   ├── scheduler.py   # background checks + Telegram
│   ├── xlsx.py        # XLSX/CSV without dependencies
│   └── server.py      # HTTP API and admin panel
├── web/               # SPA (HTML/CSS/JS, no CDN)
├── tests/             # 16 tests: parser, XLSX, API
├── data/              # SQLite (auto-created)
├── start.sh / start.bat / docker-compose.yml
```

---

## Tests

```bash
python3 -m unittest discover -s tests -v
```
```
Ran 16 tests in 1.1s — OK
```

Covers price parsing (`1 234,56`, `$12.99`, `1.234.567`), CSS selectors, JSON-LD fallback,
XLSX validity, source CRUD, history, exports and auth.

---

## FAQ

**The site renders prices with JavaScript — what now?** The parser reads HTML only.
Look for JSON-LD/meta (often present) or use a server-rendered page. Headless-browser
support is planned for the next version.

**Will my IP get banned?** Default interval is 60 minutes and checks run sequentially —
the load is minimal. Don't set 5 minutes across dozens of sites.

**Can I run it on a server?** Yes: `HOST=0.0.0.0 ./start.sh` or Docker. Put an HTTPS
reverse proxy in front for public access.

**Where is the backup?** Copy `data/monitor.db` — sources and full history live there.

---

## License

Commercial usage license (see `LICENSE.txt`): unlimited own projects, no resale of the archive.

© 2026 Price Monitor Pro · v1.0.0
