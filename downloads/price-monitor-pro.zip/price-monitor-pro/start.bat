@echo off
rem Price Monitor Pro - Windows launcher
setlocal
cd /d "%~dp0"

where python >nul 2>nul
if errorlevel 1 (
  echo Python 3 not found. Install Python 3.9+ from python.org and run again.
  pause
  exit /b 1
)

if "%PORT%"=="" set PORT=8070
echo.
echo   Price Monitor Pro
echo   panel: http://127.0.0.1:%PORT%
echo   login: admin / admin123
echo.
python run.py --port %PORT% --demo %*
pause
