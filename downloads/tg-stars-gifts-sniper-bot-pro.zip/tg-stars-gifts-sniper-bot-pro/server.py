"""Local HTTP server for the gift sniper desk. stdlib only.

Binds to 127.0.0.1 on purpose: the tool may hold a Telegram bot token in the
environment and it has no authentication layer, so it is not a service, it is a
desk you open in a tab.

    python3 server.py                 # fixture, works offline
    python3 server.py --live          # poll fragment.com + tonapi.io
    python3 server.py --live --port 8791

Routes
------
GET  /                    terminal.html
GET  /api/health          liveness, mode, cache age
GET  /api/scan            the full summary (?live=1 to refresh from the network)
GET  /api/board           the watched book with SNIPE/WATCH/PASS labels
GET  /api/collections     per-collection floors
GET  /api/history         floor samples this process has seen (sparklines)
GET  /api/export.csv      the board as CSV
POST /api/simulate        {budget_ton, max_per_trade_ton} -> fills + PnL
POST /api/alert           {limit} -> Telegram-ready HTML (no network unless send=1)
POST /api/config          merge a partial config (fee, thresholds)
"""

from __future__ import annotations

import csv
import io
import json
import os
import sys
import threading
import time
from datetime import datetime, timezone
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from typing import Any
from urllib.parse import parse_qs, urlparse

import feeds
import gifts

VERSION = "1.0.0"
ROOT = Path(__file__).resolve().parent
FIXTURE = ROOT / "tests" / "fixtures" / "listings.json"
CONFIG_PATH = Path(os.environ.get("GIFT_CONFIG", ROOT / "config.json"))
CACHE_TTL = 30.0

_lock = threading.Lock()
_cache: dict[str, Any] = {"summary": None, "at": 0.0, "mode": "fixture", "errors": []}
_history: list[dict] = []          # floor samples for sparklines
MAX_HISTORY = 240

WATCH_DEFAULT = [
    "plushpepe", "durovscap", "heartlocket", "signetring", "swisswatch", "iongem",
    "astralshard", "toybear", "jellybunny", "freshsocks", "sharptongue",
    "deskcalendar", "instantramen", "vicecream", "lunarsnake", "xmasstocking",
]


def load_config() -> dict:
    cfg = dict(gifts.DEFAULT_CONFIG)
    if CONFIG_PATH.exists():
        try:
            cfg.update(json.loads(CONFIG_PATH.read_text()))
        except (OSError, ValueError):
            pass
    return cfg


SECRET_KEYS = {"tg_bot_token", "tg_chat_id"}
WRITABLE = set(gifts.DEFAULT_CONFIG) | {"watch"} | SECRET_KEYS


def redact(cfg: dict) -> dict:
    out = json.loads(json.dumps(cfg))
    for key in list(out):
        if key in SECRET_KEYS or any(w in key.lower() for w in ("token", "secret", "password")):
            out[key] = "***" if out[key] else ""
    return out


def save_config(patch: dict) -> dict:
    cfg = load_config()
    cfg.update({k: v for k, v in patch.items() if k in WRITABLE})
    CONFIG_PATH.write_text(json.dumps(cfg, indent=2) + "\n")
    try:
        os.chmod(CONFIG_PATH, 0o600)
    except OSError:
        pass
    return cfg


def _record_history(summary: dict) -> None:
    stamp = summary.get("at")
    with _lock:
        if _history and _history[-1]["at"] == stamp:
            return
        _history.append({
            "at": stamp,
            "floors": {c["slug"]: c["floor_ton"] for c in summary.get("collections", [])},
            "net_ton": summary.get("totals", {}).get("net_ton", 0),
            "signals": summary.get("counts", {}).get("opportunities", 0),
        })
        del _history[:-MAX_HISTORY]


def build_summary(live: bool = False, force: bool = False) -> dict:
    now = time.time()
    with _lock:
        if not force and _cache["summary"] and now - _cache["at"] < CACHE_TTL:
            return _cache["summary"]

    cfg = load_config()
    errors: list[str] = []
    source = "fixture"
    payload: dict

    if live:
        scan = feeds.FragmentFeed().scan(cfg.get("watch") or WATCH_DEFAULT)
        errors.extend(scan.errors)
        rates, rate_errors = feeds.Rates().fetch()
        errors.extend(rate_errors)
        payload = scan.payload
        payload["rates"] = {**rates, "star_usd": cfg["star_usd"]}
        source = scan.source
        if not payload.get("collections"):
            fallback = gifts.load_fixture(FIXTURE)
            payload = fallback
            payload["rates"] = {**rates, "star_usd": cfg["star_usd"]}
            source = "fixture (live failed)"
    else:
        payload = gifts.load_fixture(FIXTURE)
        payload.setdefault("rates", {})["star_usd"] = cfg["star_usd"]

    data = gifts.summary(payload, cfg, source=source, errors=errors)
    data["config"] = redact(cfg)
    data["watch"] = cfg.get("watch") or WATCH_DEFAULT

    with _lock:
        _cache.update(summary=data, at=now, mode="live" if live else "fixture", errors=errors)
    _record_history(data)
    return data


def to_csv(rows: list[dict]) -> str:
    fields = ["status", "collection", "name", "num", "ask_ton", "next_ask_ton", "gap_pct",
              "discount_pct", "net_ton", "score", "tier", "listed_at", "url"]
    buf = io.StringIO()
    writer = csv.DictWriter(buf, fieldnames=fields, extrasaction="ignore")
    writer.writeheader()
    for row in rows:
        writer.writerow({k: row.get(k) for k in fields})
    return buf.getvalue()


class Handler(BaseHTTPRequestHandler):
    server_version = f"GiftSniper/{VERSION}"
    protocol_version = "HTTP/1.1"

    def _send(self, status: int, body: bytes, ctype: str) -> None:
        self.send_response(status)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.send_header("X-Content-Type-Options", "nosniff")
        self.send_header("Referrer-Policy", "no-referrer")
        self.end_headers()
        if self.command != "HEAD":
            self.wfile.write(body)

    def _json(self, payload: Any, status: int = 200) -> None:
        self._send(status, json.dumps(payload, indent=2, default=str).encode(),
                   "application/json; charset=utf-8")

    def _html(self, text: str) -> None:
        self._send(200, text.encode(), "text/html; charset=utf-8")

    def _body(self) -> dict:
        length = int(self.headers.get("Content-Length") or 0)
        if length <= 0:
            return {}
        if length > 65_536:
            raise ValueError("body too large")
        return json.loads(self.rfile.read(length).decode("utf-8") or "{}")

    def log_message(self, fmt: str, *args: Any) -> None:
        if "/api/" in (args[0] if args else ""):
            sys.stderr.write("[%s] %s\n" % (time.strftime("%H:%M:%S"), fmt % args))

    def do_HEAD(self) -> None:
        self.do_GET()

    def do_GET(self) -> None:
        parsed = urlparse(self.path)
        path, query = parsed.path, parse_qs(parsed.query)
        live = query.get("live", ["0"])[0] in ("1", "true", "yes")
        try:
            if path in ("/", "/index.html", "/terminal"):
                page = ROOT / "terminal.html"
                return self._html(page.read_text() if page.exists() else "<h1>terminal.html missing</h1>")

            if path == "/api/health":
                return self._json({
                    "ok": True, "version": VERSION, "python": sys.version.split()[0],
                    "mode": _cache["mode"],
                    "telegram": feeds.Telegram().enabled,
                    "cacheAgeSec": round(time.time() - _cache["at"], 1) if _cache["at"] else None,
                    "fixture": FIXTURE.exists(),
                })

            if path == "/api/scan":
                return self._json(build_summary(live=live, force=query.get("force", ["0"])[0] in ("1", "true")))

            if path == "/api/board":
                data = build_summary(live=live)
                return self._json({"source": data["source"], "board": data.get("board", [])})

            if path == "/api/collections":
                data = build_summary(live=live)
                return self._json({"source": data["source"], "collections": data.get("collections", [])})

            if path == "/api/history":
                with _lock:
                    return self._json({"samples": list(_history)})

            if path == "/api/export.csv":
                data = build_summary(live=live)
                body = to_csv(data.get("board", [])).encode()
                self.send_response(200)
                self.send_header("Content-Type", "text/csv; charset=utf-8")
                self.send_header("Content-Disposition", 'attachment; filename="gift-board.csv"')
                self.send_header("Content-Length", str(len(body)))
                self.end_headers()
                return self.wfile.write(body)

            return self._json({"error": "not found", "path": path}, 404)
        except Exception as exc:  # noqa: BLE001
            return self._json({"error": f"{type(exc).__name__}: {exc}"}, 500)

    def do_POST(self) -> None:
        path = urlparse(self.path).path
        try:
            body = self._body()
        except ValueError as exc:
            return self._json({"error": str(exc)}, 400)

        try:
            if path == "/api/config":
                return self._json(redact(save_config(body)))

            if path == "/api/simulate":
                data = build_summary(live=bool(body.get("live")))
                cfg = load_config()
                ops = [gifts.Opportunity(**{k: v for k, v in row.items()
                                            if k in gifts.Opportunity.__dataclass_fields__})
                       for row in data.get("opportunities", [])]
                result = gifts.simulate(
                    ops, cfg,
                    budget_ton=body.get("budget_ton"),
                    max_per_trade=body.get("max_per_trade_ton"),
                )
                return self._json(result)

            if path == "/api/alert":
                data = build_summary(live=bool(body.get("live")))
                ops = [gifts.Opportunity(**{k: v for k, v in row.items()
                                            if k in gifts.Opportunity.__dataclass_fields__})
                       for row in data.get("opportunities", [])]
                text = gifts.render_alert(
                    ops, limit=int(body.get("limit") or 5), rates=data.get("rates"),
                    bot_name=body.get("bot_name") or "Gift Sniper",
                )
                out = {"text": text, "chars": len(text), "sent": False}
                if body.get("send"):
                    cfg = load_config()
                    sender = feeds.Telegram(token=cfg.get("tg_bot_token") or None,
                                            chat_id=cfg.get("tg_chat_id") or None)
                    payload = sender.send(text)
                    out["sent"] = True
                    out["message_id"] = payload.get("message_id")
                return self._json(out)

            return self._json({"error": "not found", "path": path}, 404)
        except feeds.FeedError as exc:
            return self._json({"error": str(exc)}, 400)
        except Exception as exc:  # noqa: BLE001
            return self._json({"error": f"{type(exc).__name__}: {exc}"}, 500)


def serve(host: str = "127.0.0.1", port: int = 8790, live: bool = False) -> None:
    if live:
        build_summary(live=True)
    else:
        build_summary()
    httpd = ThreadingHTTPServer((host, port), Handler)
    httpd.daemon_threads = True
    print(f"tg-stars-gifts-sniper-bot-pro {VERSION}")
    print(f"  http://{host}:{port}/")
    print(f"  data: {'live (fragment.com + tonapi.io)' if live else 'fixture snapshot'}")
    print("  Ctrl-C to stop")
    try:
        httpd.serve_forever()
    except KeyboardInterrupt:
        print("\nstopped")
    finally:
        httpd.server_close()


def main(argv: list[str] | None = None) -> int:
    import argparse

    ap = argparse.ArgumentParser(description="gift sniper local desk")
    ap.add_argument("--host", default="127.0.0.1")
    ap.add_argument("--port", type=int, default=8790)
    ap.add_argument("--live", action="store_true", help="poll the network on startup")
    args = ap.parse_args(argv)
    serve(args.host, args.port, args.live)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
