#!/usr/bin/env python3
"""Self-check for tg-stars-gifts-sniper-bot-pro.

Runs offline. No Telegram token, no Fragment requests, no tonapi calls. Every
assertion is either exact arithmetic on the engine, a parser fed a canned page,
or an HTTP request against a server this script starts on a random localhost
port.

    python3 verify.py             # human output
    python3 verify.py --quiet     # exit code only
    python3 verify.py --json      # machine-readable

A failure exits 1 and prints why. A verifier that hides its failures is worse
than no verifier at all.
"""

from __future__ import annotations

import json
import random
import socket
import sys
import threading
import traceback
import urllib.error
import urllib.request
from http.server import ThreadingHTTPServer
from pathlib import Path

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))

import feeds  # noqa: E402
import gifts  # noqa: E402
import server  # noqa: E402

RESULTS: list[tuple[str, bool, str]] = []
FIXTURE = ROOT / "tests" / "fixtures" / "listings.json"


def check(name: str):
    def wrap(fn):
        try:
            detail = fn()
            RESULTS.append((name, True, "" if detail is None else str(detail)))
        except Exception:  # noqa: BLE001
            RESULTS.append((name, False, traceback.format_exc(limit=3).strip().splitlines()[-1]))
        return fn
    return wrap


def eq(actual, expected, label=""):
    if actual != expected:
        raise AssertionError(f"{label or 'value'}: got {actual!r}, want {expected!r}")
    return actual


def truthy(value, label=""):
    if not value:
        raise AssertionError(f"{label or 'value'}: expected truthy, got {value!r}")
    return value


def near(actual, expected, tol=1e-6, label=""):
    if abs(float(actual) - float(expected)) > tol:
        raise AssertionError(f"{label or 'value'}: got {actual}, want {expected} ±{tol}")
    return actual


FIX = gifts.load_fixture(FIXTURE)
CFG = dict(gifts.DEFAULT_CONFIG)


# --- fixture ----------------------------------------------------------------

@check("fixture: file exists and parses")
def _():
    truthy(FIXTURE.exists())
    return f"{FIXTURE.stat().st_size // 1024} KiB"


@check("fixture: has collections and asks")
def _():
    cols = FIX["collections"]
    truthy(len(cols) >= 10, "collections")
    asks = sum(len(v) for v in cols.values())
    truthy(asks >= 200, "asks")
    return f"{len(cols)} collections, {asks} asks"


@check("fixture: every row has a positive TON price")
def _():
    bad = [(s, r) for s, rows in FIX["collections"].items() for r in rows
           if not isinstance(r.get("price_ton"), (int, float)) or r["price_ton"] <= 0]
    eq(bad, [], "invalid rows")
    return "all positive"


@check("fixture: rates carry a plausible TON/USD")
def _():
    ton_usd = FIX["rates"]["ton_usd"]
    truthy(0.1 < ton_usd < 100, "ton_usd out of plausible range")
    return f"${ton_usd}"


@check("fixture: capture timestamp is ISO-8601 Z")
def _():
    stamp = FIX["captured_at"]
    truthy(stamp.endswith("Z") and "T" in stamp, stamp)
    return stamp


# --- parsing ----------------------------------------------------------------

@check("ton(): thousands separators are stripped")
def _():
    eq(gifts.ton("88,888"), 88888.0)
    eq(gifts.ton("5"), 5.0)
    eq(gifts.ton(1234), 1234.0)


@check("parse_listings: drops sold items")
def _():
    payload = {"items": [
        {"slug": "toybear-1", "name": "Toy Bear", "price_ton": 10, "status": "Sold"},
        {"slug": "toybear-2", "name": "Toy Bear", "price_ton": 11, "status": "For sale"},
    ]}
    rows = gifts.parse_listings(payload)
    eq(len(rows), 1)
    eq(rows[0].num, 2)
    return "1 of 2 survived"


@check("parse_listings: collection inferred from the slug")
def _():
    rows = gifts.parse_listings({"items": [{"slug": "plushpepe-77", "name": "Plush Pepe",
                                            "price_ton": 9, "status": "For sale"}]})
    eq(rows[0].collection, "plushpepe")
    eq(rows[0].key, "plushpepe#77")


@check("parse_listings: fixture shape yields every live ask")
def _():
    rows = gifts.parse_listings(FIX)
    truthy(len(rows) >= 200, "rows")
    truthy(all(r.price_ton > 0 for r in rows))
    return len(rows)


# --- statistics -------------------------------------------------------------

@check("trimmed_baseline: empty book is 0, not an exception")
def _():
    eq(gifts.trimmed_baseline([]), 0.0)


@check("trimmed_baseline: single price is itself")
def _():
    eq(gifts.trimmed_baseline([7.0]), 7.0)


@check("trimmed_baseline: trims both tails")
def _():
    prices = [1, 2, 3, 4, 5, 6, 7, 8, 9, 1000]
    # 10 values, 15% -> k=1, core = 2..9, median 5.5
    near(gifts.trimmed_baseline(prices, 15), 5.5)


@check("trimmed_baseline: an outlier cannot move the median")
def _():
    base = [10.0] * 20
    near(gifts.trimmed_baseline(base, 15), gifts.trimmed_baseline(base + [999999.0], 15))


@check("trimmed_baseline: trim_pct is clamped to 40%")
def _():
    prices = list(range(1, 11))
    # clamped: k=4, core=[5,6], median 5.5 — not an empty list
    near(gifts.trimmed_baseline(prices, 90), 5.5)


@check("stats_for: floor is the minimum ask")
def _():
    rows = [gifts.Listing("x", "X", i, p) for i, p in enumerate([50, 40, 60, 45, 55, 70])]
    st = gifts.stats_for(rows)[0]
    eq(st.floor_ton, 40.0)
    eq(st.asks, 6)


@check("stats_for: next_ask is the second distinct price")
def _():
    rows = [gifts.Listing("x", "X", i, p) for i, p in enumerate([40, 40, 44, 90, 91, 92])]
    st = gifts.stats_for(rows)[0]
    eq(st.floor_ton, 40.0)
    eq(st.next_ask_ton, 44.0)


@check("stats_for: depth counts asks within 2% of the floor")
def _():
    rows = [gifts.Listing("x", "X", i, p) for i, p in enumerate([100, 101, 102, 200, 300, 400])]
    st = gifts.stats_for(rows)[0]
    eq(st.depth_at_floor, 3)


@check("stats_for: p25 <= baseline <= p75")
def _():
    rows = gifts.parse_listings(FIX)
    for st in gifts.stats_for(rows):
        truthy(st.p25_ton <= st.baseline_ton * 1.001, f"{st.slug} p25")
        truthy(st.baseline_ton <= st.p75_ton * 1.001, f"{st.slug} p75")
    return "16 collections consistent"


@check("stats_for: sorts by floor, richest first")
def _():
    rows = gifts.parse_listings(FIX)
    floors = [s.floor_ton for s in gifts.stats_for(rows)]
    eq(floors, sorted(floors, reverse=True))


@check("stats_for: catalog supplies the display name")
def _():
    rows = [gifts.Listing("plushpepe", "PE PE", i, p) for i, p in enumerate([10, 11, 12, 13, 14, 15])]
    st = gifts.stats_for(rows)[0]
    eq(st.name, "Plush Pepe")


# --- fees -------------------------------------------------------------------

@check("buy_cost: ask + slippage + gas")
def _():
    cfg = {**CFG, "slippage_bps": 100, "settle_gas_ton": 0.05}
    near(gifts.buy_cost(100.0, cfg), 101.05)


@check("cost_to_sell: 5% fee and gas come off the top")
def _():
    near(gifts.cost_to_sell(100.0, CFG), 94.95)


@check("round trip at the same price always loses money")
def _():
    truthy(gifts.cost_to_sell(100.0, CFG) < gifts.buy_cost(100.0, CFG))


@check("fee is 500 bps by default")
def _():
    eq(CFG["fragment_fee_bps"], 500)


# --- scoring ----------------------------------------------------------------

@check("score: bounded to 0..100")
def _():
    for discount in (-50, 0, 5, 25, 60, 500):
        score = gifts.score_opportunity(discount, 3, "rare", 30)
        truthy(0 <= score <= 100, score)
    return "six inputs in range"


@check("score: a deeper book beats a thin one at the same discount")
def _():
    thin = gifts.score_opportunity(30, 1, "rare", 30)
    deep = gifts.score_opportunity(30, 8, "rare", 30)
    truthy(deep > thin, f"{deep} !> {thin}")


@check("score: a bigger discount wins at the same depth")
def _():
    truthy(gifts.score_opportunity(40, 4, "rare", 30) > gifts.score_opportunity(20, 4, "rare", 30))


@check("score: legendary outranks common at equal inputs")
def _():
    truthy(gifts.score_opportunity(30, 4, "legendary", 30) > gifts.score_opportunity(30, 4, "common", 30))


@check("score: an unknown tier falls back, it does not crash")
def _():
    truthy(gifts.score_opportunity(30, 4, "mythic", 30) > 0)


# --- opportunities ----------------------------------------------------------

@check("opportunities: every row clears both thresholds")
def _():
    ops = gifts.find_opportunities(gifts.parse_listings(FIX))
    truthy(ops, "no opportunities in the fixture")
    for op in ops:
        truthy(op.gap_pct >= CFG["min_gap_pct"], f"gap {op.gap_pct}")
        truthy(op.discount_pct >= CFG["min_discount_pct"], f"discount {op.discount_pct}")
    return f"{len(ops)} signals"


@check("opportunities: net is strictly positive")
def _():
    for op in gifts.find_opportunities(gifts.parse_listings(FIX)):
        truthy(op.net_ton > 0, op.ref)


@check("opportunities: sorted by score then net")
def _():
    ops = gifts.find_opportunities(gifts.parse_listings(FIX))
    keys = [(-o.score, -o.net_ton) for o in ops]
    eq(keys, sorted(keys))


@check("opportunities: exit is min(baseline, next ask)")
def _():
    for op in gifts.find_opportunities(gifts.parse_listings(FIX)):
        truthy(op.exit_ton <= op.baseline_ton + 1e-9, op.ref)
        truthy(op.exit_ton > op.ask_ton, op.ref)


@check("opportunities: a thin collection is skipped")
def _():
    rows = [gifts.Listing("thin", "Thin", 1, 1.0), gifts.Listing("thin", "Thin", 2, 100.0)]
    eq(gifts.find_opportunities(rows), [])


@check("opportunities: raising the discount threshold removes rows")
def _():
    base = len(gifts.find_opportunities(gifts.parse_listings(FIX)))
    strict = len(gifts.find_opportunities(gifts.parse_listings(FIX),
                                          config={"min_discount_pct": 90.0}))
    truthy(strict < base, f"{strict} !< {base}")


@check("opportunities: raising the gap threshold removes rows")
def _():
    base = len(gifts.find_opportunities(gifts.parse_listings(FIX)))
    strict = len(gifts.find_opportunities(gifts.parse_listings(FIX), config={"min_gap_pct": 95.0}))
    eq(strict, 0)


# --- board ------------------------------------------------------------------

@check("board: labels are drawn from the three allowed values")
def _():
    rows = gifts.board(gifts.parse_listings(FIX))
    truthy(rows, "empty board")
    eq({r["status"] for r in rows} - {"SNIPE", "WATCH", "PASS"}, set())


@check("board: SNIPE rows match the opportunity set")
def _():
    board = gifts.board(gifts.parse_listings(FIX))
    snipes = {r["ref"] for r in board if r["status"] == "SNIPE"}
    ops = {o.ref for o in gifts.find_opportunities(gifts.parse_listings(FIX))}
    eq(snipes, ops)


@check("board: SNIPE rows come first")
def _():
    board = gifts.board(gifts.parse_listings(FIX))
    order = {"SNIPE": 0, "WATCH": 1, "PASS": 2}
    seq = [order[r["status"]] for r in board]
    eq(seq, sorted(seq))


@check("board: limit is respected")
def _():
    eq(len(gifts.board(gifts.parse_listings(FIX), limit=5)), 5)


# --- simulation -------------------------------------------------------------

@check("simulate: never exceeds the budget")
def _():
    ops = gifts.find_opportunities(gifts.parse_listings(FIX))
    sim = gifts.simulate(ops, CFG, budget_ton=2000, max_per_trade=1200)
    truthy(sim["invested_ton"] <= 2000 + 1e-6, sim["invested_ton"])
    truthy(sim["idle_ton"] >= -1e-6)


@check("simulate: never exceeds the per-trade cap")
def _():
    ops = gifts.find_opportunities(gifts.parse_listings(FIX))
    sim = gifts.simulate(ops, CFG, budget_ton=99999, max_per_trade=100)
    for fill in sim["fills"]:
        truthy(fill["buy_ton"] <= 100 + 1e-6, fill["buy_ton"])


@check("simulate: pnl is the sum of the fills")
def _():
    ops = gifts.find_opportunities(gifts.parse_listings(FIX))
    sim = gifts.simulate(ops, CFG, budget_ton=3000, max_per_trade=1200)
    near(sim["pnl_ton"], sum(f["pnl_ton"] for f in sim["fills"]), 1e-6)


@check("simulate: a zero budget fills nothing")
def _():
    ops = gifts.find_opportunities(gifts.parse_listings(FIX))
    sim = gifts.simulate(ops, CFG, budget_ton=0)
    eq(sim["n_fills"], 0)
    eq(sim["roi_pct"], 0.0)


@check("simulate: fills are all UNDERPRICE opportunities")
def _():
    ops = gifts.find_opportunities(gifts.parse_listings(FIX))
    sim = gifts.simulate(ops, CFG)
    truthy(all(f["ref"] in {o.ref for o in ops} for f in sim["fills"]))


# --- stars leg --------------------------------------------------------------

@check("star_arbitrage: no verified cost means no rows")
def _():
    stats = gifts.stats_for(gifts.parse_listings(FIX))
    rows = gifts.star_arbitrage(stats, {"ton_usd": 1.2}, gifts.COLLECTION_CATALOG, CFG)
    eq(rows, [], "catalog has only null star_costs")


@check("star_arbitrage: a known cost produces a priced row")
def _():
    stats = [gifts.CollectionStats("demo", "Demo", 10, 500.0, 550.0, 480.0, 600.0, 3, 20.0, "rare", 560.0)]
    catalog = {"demo": {"name": "Demo", "star_cost": 50, "tier": "rare"}}
    rows = gifts.star_arbitrage(stats, {"ton_usd": 1.0}, catalog, CFG)
    eq(len(rows), 1)
    near(rows[0].roi_pct, (500 * 0.95 - 0.05 - 50 * 0.013) / (50 * 0.013) * 100, 0.01)


@check("star_arbitrage: no rate means no rows")
def _():
    stats = [gifts.CollectionStats("demo", "Demo", 10, 500.0, 550.0, 480.0, 600.0, 3, 20.0, "rare", 560.0)]
    rows = gifts.star_arbitrage(stats, {}, {"demo": {"star_cost": 50}}, CFG)
    eq(rows, [])


# --- alerts -----------------------------------------------------------------

@check("alert: renders the limited number of signals")
def _():
    ops = gifts.find_opportunities(gifts.parse_listings(FIX))
    text = gifts.render_alert(ops, limit=2)
    eq(text.count("score"), min(2, len(ops)))


@check("alert: escapes HTML in collection names")
def _():
    op = gifts.Opportunity("UNDERPRICE", "x", "<script>", 1, 2, 50, 1, 10, 50, 1, "rare", url=None, ref="x#1")
    text = gifts.render_alert([op])
    truthy("&lt;script&gt;" in text, text)
    truthy("<script>" not in text)


@check("alert: carries the fee disclaimer")
def _():
    ops = gifts.find_opportunities(gifts.parse_listings(FIX))
    truthy("re-check the ask" in gifts.render_alert(ops))


@check("alert: converts to dollars when a rate is known")
def _():
    ops = gifts.find_opportunities(gifts.parse_listings(FIX))
    text = gifts.render_alert(ops[:1], rates={"ton_usd": 2.0})
    truthy("$" in text)


# --- feeds ------------------------------------------------------------------

@check("feeds: parses the Fragment grid")
def _():
    page = """<a href="/gift/toybear-1?collection=all&filter=sale" class="tm-grid-item">
      <div class="tm-grid-item-content"><span class="item-name">Toy Bear</span>
      <span class="item-num">&nbsp;#1</span></div>
      <div class="tm-grid-item-values"><div class="tm-grid-item-value tm-value icon-before icon-ton">1,234</div>
      <div class="tm-grid-item-status tm-status-avail">For sale</div></div></a>"""
    rows = []
    for slug, body in feeds.ITEM_RE.findall(page):
        rows.append((slug, feeds.NAME_RE.search(body).group(1),
                     feeds.PRICE_RE.search(body).group(1)))
    eq(rows, [("toybear-1", "Toy Bear", "1,234")])


@check("feeds: rate drift above 2% is reported")
def _():
    r = feeds.Rates()
    calls = {"n": 0}

    def fake(url, timeout=15.0):
        calls["n"] += 1
        return ({"rates": {"TON": {"prices": {"USD": 1.00}}}}
                if "tonapi" in url else {"the-open-network": {"usd": 1.10}})

    r._json = fake  # type: ignore[assignment]
    rates, errors = r.fetch()
    truthy(rates["ton_usd"] == 1.00, "conservative price should win")
    truthy(any("disagree" in e for e in errors), errors)


@check("feeds: one source down still returns a rate")
def _():
    r = feeds.Rates()

    def fake(url, timeout=15.0):
        if "tonapi" in url:
            raise OSError("boom")
        return {"the-open-network": {"usd": 1.5}}

    r._json = fake  # type: ignore[assignment]
    rates, errors = r.fetch()
    eq(rates["ton_usd"], 1.5)
    truthy(any("tonapi" in e for e in errors))


@check("feeds: both sources down returns nothing and says why")
def _():
    r = feeds.Rates()

    def fake(url, timeout=15.0):
        raise OSError("offline")

    r._json = fake  # type: ignore[assignment]
    rates, errors = r.fetch()
    eq(rates, {})
    eq(len(errors), 2)


@check("telegram: disabled without a token")
def _():
    t = feeds.Telegram(token="", chat_id="")
    eq(t.enabled, False)
    try:
        t.send("hi")
    except feeds.FeedError as exc:
        truthy("not configured" in str(exc))
    else:
        raise AssertionError("send should refuse without a token")


@check("telegram: reports enabled when both vars exist")
def _():
    eq(feeds.Telegram(token="x", chat_id="y").enabled, True)


# --- server -----------------------------------------------------------------

def free_port() -> int:
    with socket.socket() as sock:
        sock.bind(("127.0.0.1", 0))
        return sock.getsockname()[1]


class Live:
    def __init__(self):
        self.port = free_port()
        self.httpd = ThreadingHTTPServer(("127.0.0.1", self.port), server.Handler)
        self.httpd.daemon_threads = True
        self.thread = threading.Thread(target=self.httpd.serve_forever, daemon=True)

    def __enter__(self):
        server.build_summary()
        self.thread.start()
        return self

    def __exit__(self, *exc):
        self.httpd.shutdown()
        self.httpd.server_close()

    def get(self, path: str, timeout: float = 10.0):
        url = f"http://127.0.0.1:{self.port}{path}"
        try:
            with urllib.request.urlopen(url, timeout=timeout) as resp:
                return resp.status, resp.read()
        except urllib.error.HTTPError as exc:
            return exc.code, exc.read()

    def post(self, path: str, payload: dict, timeout: float = 10.0):
        req = urllib.request.Request(
            f"http://127.0.0.1:{self.port}{path}",
            data=json.dumps(payload).encode(),
            headers={"content-type": "application/json"}, method="POST")
        try:
            with urllib.request.urlopen(req, timeout=timeout) as resp:
                return resp.status, resp.read()
        except urllib.error.HTTPError as exc:
            return exc.code, exc.read()


@check("server: GET / serves the terminal")
def _():
    with Live() as live:
        status, body = live.get("/")
    eq(status, 200)
    truthy(b"GIFT SNIPER" in body)
    truthy(b"<!DOCTYPE html>" in body)


@check("server: the terminal has no external asset")
def _():
    text = (ROOT / "terminal.html").read_text()
    for bad in ("http://", "https://cdn", "<script src=", "@import url("):
        truthy(bad not in text, bad)
    return "self-contained"


@check("server: CSP is declared in the page")
def _():
    truthy("Content-Security-Policy" in (ROOT / "terminal.html").read_text())


@check("server: /api/health reports the mode")
def _():
    with Live() as live:
        status, body = live.get("/api/health")
    data = json.loads(body)
    eq(status, 200)
    eq(data["ok"], True)
    truthy(data["version"])


@check("server: /api/scan returns the summary")
def _():
    with Live() as live:
        status, body = live.get("/api/scan")
    data = json.loads(body)
    eq(status, 200)
    truthy(data["counts"]["listings"] > 0)
    truthy(len(data["collections"]) > 0)


@check("server: /api/scan hides the bot token")
def _():
    with Live() as live:
        _, body = live.get("/api/scan")
    text = body.decode()
    truthy("tg_bot_token" not in text or "***" in text)


@check("server: /api/board labels every row")
def _():
    with Live() as live:
        _, body = live.get("/api/board")
    rows = json.loads(body)["board"]
    truthy(rows)
    truthy({r["status"] for r in rows} <= {"SNIPE", "WATCH", "PASS"})


@check("server: /api/collections lists floors")
def _():
    with Live() as live:
        _, body = live.get("/api/collections")
    cols = json.loads(body)["collections"]
    truthy(all(c["floor_ton"] > 0 for c in cols))
    return f"{len(cols)} collections"


@check("server: /api/export.csv has a header and a row per ask")
def _():
    with Live() as live:
        status, body = live.get("/api/export.csv")
    text = body.decode()
    eq(status, 200)
    truthy(text.startswith("status,collection,name"))
    eq(len(text.strip().splitlines()) > 5, True)


@check("server: POST /api/simulate runs the budget")
def _():
    with Live() as live:
        status, body = live.post("/api/simulate", {"budget_ton": 2500, "max_per_trade_ton": 1200})
    data = json.loads(body)
    eq(status, 200)
    truthy("fills" in data)
    truthy(data["invested_ton"] <= 2500)


@check("server: POST /api/alert renders HTML")
def _():
    with Live() as live:
        status, body = live.post("/api/alert", {"limit": 2})
    data = json.loads(body)
    eq(status, 200)
    truthy("<b>" in data["text"])
    eq(data["sent"], False)


@check("server: POST /api/alert refuses to send without a token")
def _():
    import os
    saved = (os.environ.get("TG_BOT_TOKEN"), os.environ.get("TG_CHAT_ID"))
    os.environ["TG_BOT_TOKEN"] = ""
    os.environ["TG_CHAT_ID"] = ""
    try:
        with Live() as live:
            status, body = live.post("/api/alert", {"limit": 1, "send": True})
        eq(status, 400)
        truthy("not configured" in json.loads(body)["error"])
    finally:
        os.environ["TG_BOT_TOKEN"] = saved[0] or ""
        os.environ["TG_CHAT_ID"] = saved[1] or ""


@check("server: unknown route is a 404, not a traceback")
def _():
    with Live() as live:
        status, body = live.get("/api/nope")
    eq(status, 404)
    eq(json.loads(body)["error"], "not found")


@check("server: an oversized body is refused")
def _():
    with Live() as live:
        status, _ = live.post("/api/simulate", {"x": "a" * 70000})
    eq(status, 400)


@check("server: /api/history records floor samples")
def _():
    with Live() as live:
        live.get("/api/scan")
        status, body = live.get("/api/history")
    data = json.loads(body)
    eq(status, 200)
    truthy(len(data["samples"]) >= 1)
    truthy("floors" in data["samples"][0])


@check("server: config round-trips and redacts secrets")
def _():
    with Live() as live:
        status, body = live.post("/api/config", {"min_gap_pct": 9.5, "tg_bot_token": "secret"})
    data = json.loads(body)
    eq(status, 200)
    eq(data["min_gap_pct"], 9.5)
    eq(data["tg_bot_token"], "***")
    # restore
    server.save_config({"min_gap_pct": gifts.DEFAULT_CONFIG["min_gap_pct"]})


@check("server: a HEAD request returns headers only")
def _():
    with Live() as live:
        req = urllib.request.Request(f"http://127.0.0.1:{live.port}/api/health", method="HEAD")
        with urllib.request.urlopen(req, timeout=10) as resp:
            eq(resp.status, 200)
            eq(resp.read(), b"")


@check("server: deterministic output for the same fixture")
def _():
    a = gifts.summary(gifts.load_fixture(FIXTURE))
    b = gifts.summary(gifts.load_fixture(FIXTURE))
    for key in ("counts", "totals", "collections", "opportunities"):
        eq(json.dumps(a[key], sort_keys=True), json.dumps(b[key], sort_keys=True), key)


@check("engine: random books never produce a negative net")
def _():
    rng = random.Random(7)
    for _ in range(40):
        rows = []
        for slug in ("a", "b", "c"):
            base = rng.uniform(5, 500)
            for i in range(8):
                rows.append(gifts.Listing(slug, slug.upper(), i, round(base * rng.uniform(0.8, 1.6), 2)))
        for op in gifts.find_opportunities(rows):
            truthy(op.net_ton > 0, op.ref)
    return "40 random books"


@check("engine: a flat book yields no signal")
def _():
    rows = [gifts.Listing("flat", "Flat", i, 100.0) for i in range(10)]
    eq(gifts.find_opportunities(rows), [])


# --- report -----------------------------------------------------------------

def main(argv: list[str] | None = None) -> int:
    argv = argv if argv is not None else sys.argv[1:]
    quiet = "--quiet" in argv
    as_json = "--json" in argv

    passed = sum(1 for _, ok, _ in RESULTS if ok)
    failed = [(n, d) for n, ok, d in RESULTS if not ok]

    if as_json:
        print(json.dumps({
            "total": len(RESULTS),
            "passed": passed,
            "failed": len(failed),
            "checks": [{"name": n, "ok": ok, "detail": d} for n, ok, d in RESULTS],
        }, indent=2))
    elif not quiet:
        width = max(len(n) for n, _, _ in RESULTS) + 2
        for name, ok, detail in RESULTS:
            mark = "ok  " if ok else "FAIL"
            line = f"  {mark} {name.ljust(width)}"
            if not ok:
                line += f"  {detail}"
            print(line)
        print()
        print(f"  {passed}/{len(RESULTS)} checks passed")
        if failed:
            print(f"  {len(failed)} failed")
    return 0 if not failed else 1


if __name__ == "__main__":
    raise SystemExit(main())
