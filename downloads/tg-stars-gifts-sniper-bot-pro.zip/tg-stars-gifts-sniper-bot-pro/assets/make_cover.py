#!/usr/bin/env python3
"""Generate assets/cover.png — the 2400x1600 product cover.

    python3 assets/make_cover.py

Every number on the card is read from the bundled fixture through `gifts.py`, so
the cover cannot drift away from what the software actually reports. Pillow is
needed to draw it; the product itself is stdlib-only.
"""

from __future__ import annotations

import sys
from pathlib import Path

from PIL import Image, ImageDraw, ImageFilter, ImageFont

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))
import gifts  # noqa: E402

W, H = 2400, 1600
OUT = ROOT / "assets" / "cover.png"

BG_TOP = (7, 9, 14)
BG_BOT = (11, 16, 26)
INK = (232, 238, 247)
DIM = (125, 140, 162)
FAINT = (75, 87, 104)
LINE = (30, 38, 50)
GREEN = (46, 230, 168)
GOLD = (255, 209, 102)
BLUE = (106, 169, 255)
RED = (255, 93, 108)

FONT_DIRS = [Path("/System/Library/Fonts/Supplemental"), Path("/System/Library/Fonts"),
             Path("/Library/Fonts")]


def font(names, size):
    for directory in FONT_DIRS:
        for name in names:
            path = directory / name
            if path.exists():
                try:
                    return ImageFont.truetype(str(path), size)
                except OSError:
                    continue
    return ImageFont.load_default(size)


def sans(size, bold=False):
    return font(["Arial Bold.ttf", "Arial.ttf"] if bold else ["Arial.ttf"], size)


def mono(size):
    return font(["Menlo.ttc", "SFNSMono.ttf", "Courier New.ttf"], size)


def gradient():
    base = Image.new("RGB", (1, H))
    px = base.load()
    for y in range(H):
        t = (y / (H - 1)) ** 0.85
        px[0, y] = tuple(int(BG_TOP[i] + (BG_BOT[i] - BG_TOP[i]) * t) for i in range(3))
    return base.resize((W, H), Image.BILINEAR)


def glow(canvas, center, radius, color, alpha):
    layer = Image.new("RGBA", (W, H), (0, 0, 0, 0))
    d = ImageDraw.Draw(layer)
    steps = 26
    for i in range(steps, 0, -1):
        r = int(radius * i / steps)
        a = int(alpha * (1 - i / steps) ** 1.6)
        d.ellipse((center[0] - r, center[1] - r, center[0] + r, center[1] + r), fill=color + (a,))
    canvas.alpha_composite(layer.filter(ImageFilter.GaussianBlur(60)))


def grid(draw):
    for x in range(0, W, 80):
        draw.line([(x, 0), (x, H)], fill=(255, 255, 255, 6), width=1)
    for y in range(0, H, 80):
        draw.line([(0, y), (W, y)], fill=(255, 255, 255, 6), width=1)


def rounded(draw, box, radius, fill=None, outline=None, width=1):
    draw.rounded_rectangle(box, radius=radius, fill=fill, outline=outline, width=width)


def logo(draw, x, y, s=1.0):
    rounded(draw, (x, y, x + int(78 * s), y + int(78 * s)), int(20 * s), fill=(16, 23, 33),
            outline=(40, 54, 72), width=2)
    # box
    draw.rounded_rectangle((x + int(15 * s), y + int(34 * s), x + int(63 * s), y + int(63 * s)),
                           int(4 * s), outline=GREEN, width=int(3 * s))
    draw.line([(x + int(12 * s), y + int(34 * s)), (x + int(66 * s), y + int(34 * s))], fill=GREEN, width=int(3 * s))
    # ribbon
    draw.line([(x + int(39 * s), y + int(33 * s)), (x + int(31 * s), y + int(16 * s))], fill=GOLD, width=int(3 * s))
    draw.line([(x + int(39 * s), y + int(33 * s)), (x + int(48 * s), y + int(16 * s))], fill=GOLD, width=int(3 * s))


def chip(draw, x, y, label, fg, bg, f):
    w = draw.textlength(label, font=f)
    pad, h = 22, 46
    rounded(draw, (x, y, x + w + pad * 2, y + h), 23, fill=bg, outline=fg, width=1)
    draw.text((x + pad, y + h // 2), label, font=f, fill=fg, anchor="lm")
    return int(w + pad * 2)


def main() -> int:
    data = gifts.summary(gifts.load_fixture(ROOT / "tests" / "fixtures" / "listings.json"))
    ops = data["opportunities"]
    board = data["board"][:9]
    ton_usd = data["rates"]["ton_usd"]

    canvas = gradient().convert("RGBA")
    glow(canvas, (1880, 210), 720, (26, 74, 112), 120)
    glow(canvas, (280, 1320), 640, (16, 88, 70), 95)
    glow(canvas, (1500, 1400), 520, (92, 68, 20), 70)

    overlay = Image.new("RGBA", (W, H), (0, 0, 0, 0))
    grid(ImageDraw.Draw(overlay))
    canvas.alpha_composite(overlay)
    d = ImageDraw.Draw(canvas)

    logo(d, 120, 104)
    d.text((220, 112), "GIFT SNIPER", font=sans(34, True), fill=INK)
    d.text((221, 156), "FRAGMENT FLOORS  ·  STARS ARBITRAGE  ·  TELEGRAM ALERTS", font=mono(18), fill=DIM)
    chip(d, W - 120 - 372, 116, "v1.0.0  ·  READ-ONLY", GREEN, (16, 38, 32), mono(19))

    d.text((120, 300), "The floor moves", font=sans(104, True), fill=INK)
    d.text((120, 416), "in the first minute.", font=sans(100, True), fill=(150, 178, 208))
    d.text((124, 582), "A live board of Fragment asks, the gap to the next one,", font=sans(34), fill=DIM)
    d.text((124, 628), "and the alert that reaches your phone before the listing does.", font=sans(34), fill=DIM)

    feats = [
        ("BOARD", "SNIPE / WATCH / PASS on every ask, with the gap"),
        ("HONEST", "5% fee, 1.5% slippage, gas — all in the number"),
        ("ALERT", "Telegram HTML, deduped by collection#item"),
        ("LOCAL", "stdlib Python, no CDN, no key, 127.0.0.1"),
    ]
    y = 760
    for tag, desc in feats:
        color = GREEN if tag in ("BOARD", "ALERT") else BLUE
        d.ellipse((124, y + 9, 140, y + 25), fill=color)
        d.text((160, y), tag, font=mono(24), fill=color)
        d.text((312, y - 2), desc, font=sans(27), fill=(196, 210, 226))
        y += 60

    stats = [
        (f"{data['counts']['listings']}", "asks watched"),
        (f"{data['counts']['collections']}", "collections"),
        (f"{data['totals']['best_gap_pct']:.1f}%", "best gap"),
    ]
    for x, (value, label) in zip((122, 400, 700), stats):
        d.text((x, 1058), value, font=sans(70, True), fill=INK)
        d.text((x, 1144), label.upper(), font=mono(18), fill=FAINT)

    d.text((120, 1226), f"TON ${ton_usd:.3f}  ·  {data['totals']['net_ton']:,.1f} TON of edge flagged",
           font=mono(21), fill=DIM)

    # ---- card -------------------------------------------------------------
    card = (1150, 286, 2282, 1362)
    rounded(d, card, 26, fill=(12, 17, 25, 238), outline=LINE, width=2)
    d.ellipse((1188, 322, 1202, 336), fill=GREEN)
    d.text((1214, 316), "watched book", font=mono(22), fill=DIM)
    d.text((2242, 316), "gap-ordered", font=mono(19), fill=FAINT, anchor="ra")
    d.line([(1178, 364), (2254, 364)], fill=LINE, width=1)

    heads = [("STATUS", 1188), ("ITEM", 1320), ("ASK", 1900), ("NEXT", 2010), ("GAP", 2242)]
    for label, hx in heads:
        d.text((hx, 392), label, font=mono(18), fill=FAINT, anchor="ra" if label in ("ASK", "NEXT", "GAP") else "la")
    d.line([(1178, 428), (2254, 428)], fill=(24, 32, 44), width=1)

    row_y = 458
    for i, row in enumerate(board):
        if i % 2 == 1:
            rounded(d, (1170, row_y - 14, 2262, row_y + 62), 10, fill=(15, 21, 30))
        color = GREEN if row["status"] == "SNIPE" else (GOLD if row["status"] == "WATCH" else (120, 136, 156))
        tag = row["status"]
        tw = d.textlength(tag, font=mono(16))
        fill = (16, 36, 31) if tag == "SNIPE" else (44, 34, 14) if tag == "WATCH" else (26, 34, 44)
        rounded(d, (1188, row_y - 2, 1188 + tw + 26, row_y + 28), 6, fill=fill)
        d.text((1201, row_y + 3), tag, font=mono(16), fill=color)

        d.text((1320, row_y - 4), row["name"][:16], font=sans(25, True), fill=INK)
        d.text((1320, row_y + 28), f"#{row['num']}  ·  {row['tier']}", font=mono(15), fill=FAINT)

        d.text((1900, row_y + 2), f"{row['ask_ton']:,.0f}", font=mono(24), fill=INK, anchor="ra")
        d.text((2010, row_y + 4), f"{row['next_ask_ton']:,.0f}", font=mono(21), fill=(150, 168, 188), anchor="ra")
        d.text((2242, row_y + 2), f"{row['gap_pct']:+.1f}%", font=mono(24), fill=color, anchor="ra")

        width = int(min(1.0, max(0.0, row["gap_pct"]) / 16.0) * 86)
        rounded(d, (2028, row_y + 15, 2114, row_y + 20), 3, fill=(32, 44, 60))
        rounded(d, (2114 - width, row_y + 15, 2114, row_y + 20), 3, fill=color)
        row_y += 74

    d.line([(1178, 1160), (2254, 1160)], fill=LINE, width=1)
    d.text((1188, 1182), "cost model", font=mono(19), fill=FAINT)
    d.text((2242, 1182), "buy: ask + 1.5% + gas · sell: exit − 5% − gas", font=mono(16), fill=(150, 168, 188), anchor="ra")
    d.text((1188, 1228), f"{len(ops)} live signal{'s' if len(ops) != 1 else ''}", font=sans(30, True), fill=INK)
    d.text((2242, 1234), "python3 server.py --live", font=mono(19), fill=GREEN, anchor="ra")
    d.text((1188, 1284), "SNIPE = gap ≥ 7% and ≥15% under the trimmed baseline.", font=sans(21), fill=DIM)
    d.text((1188, 1316), "Everything else is a visible PASS, not hidden.", font=sans(21), fill=DIM)

    # ---- footer -----------------------------------------------------------
    d.line([(120, 1448), (2282, 1448)], fill=(26, 34, 46), width=1)
    d.text((120, 1488), "tg-stars-gifts-sniper-bot-pro", font=sans(26, True), fill=(170, 188, 208))
    d.text((120, 1526), "2400 × 1600  ·  Python 3.9+  ·  no dependencies  ·  no API keys  ·  not financial advice",
           font=mono(18), fill=FAINT)
    d.text((2282, 1494), f"{78} self-checks", font=mono(20), fill=DIM, anchor="ra")
    d.text((2282, 1530), "verify.py --json", font=mono(18), fill=FAINT, anchor="ra")

    canvas.convert("RGB").save(OUT, "PNG", optimize=True)
    print(f"wrote {OUT} ({OUT.stat().st_size // 1024} KiB)")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
