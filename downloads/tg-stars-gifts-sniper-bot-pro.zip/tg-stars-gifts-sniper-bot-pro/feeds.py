"""Live feeds. Stdlib only, no API keys.

Three sources, each with a declared failure mode:

* `FragmentFeed` — parses the public HTML grid at fragment.com/gifts. This is the
  same page a browser loads; there is no JSON endpoint behind it that does not
  require a session. It gives name, item number, ask in TON and sale status, per
  collection, which is exactly what a sniper needs. If Fragment changes its
  markup the parser returns [] and `scan()` says so instead of inventing prices.
* `Rates` — TON/USD from tonapi.io, with coingecko as a second opinion. Both are
  keyless. The two are reported side by side; a disagreement above 2% is flagged
  rather than averaged away.
* `Telegram` — optional. Sends the rendered alert with a bot token from the
  environment. Nothing is sent unless `TG_BOT_TOKEN` and `TG_CHAT_ID` are set.
"""

from __future__ import annotations

import html as html_lib
import json
import os
import re
import time
import urllib.error
import urllib.parse
import urllib.request
from dataclasses import dataclass
from datetime import datetime, timezone

UA = ("Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 "
      "(KHTML, like Gecko) Chrome/131.0 Safari/537.36")

FRAGMENT = "https://fragment.com"
ITEM_RE = re.compile(
    r'<a href="/gift/([a-z0-9-]+)\?[^"]*" class="tm-grid-item">(.*?)</a>', re.S)
NAME_RE = re.compile(r'item-name">([^<]+)<')
PRICE_RE = re.compile(r'icon-ton">([\d,]+)<')
STATUS_RE = re.compile(r'tm-status-(\w+)">([^<]+)<')
TIME_RE = re.compile(r'<time datetime="([^"]+)"')
NUM_RE = re.compile(r'item-num">&nbsp;#(\d+)<')


class FeedError(RuntimeError):
    pass


def _get(url: str, timeout: float = 25.0, headers: dict | None = None) -> str:
    req = urllib.request.Request(url, headers={"user-agent": UA, "accept": "text/html,*/*",
                                               **(headers or {})})
    with urllib.request.urlopen(req, timeout=timeout) as resp:
        return resp.read().decode("utf-8", "replace")


@dataclass
class ScanResult:
    payload: dict
    errors: list[str]
    source: str


class FragmentFeed:
    """The public listing grid, parsed. One request per collection, politely spaced."""

    def __init__(self, pause: float = 0.55, timeout: float = 25.0):
        self.pause = pause
        self.timeout = timeout
        self._last = 0.0

    def _throttle(self) -> None:
        wait = self.pause - (time.monotonic() - self._last)
        if wait > 0:
            time.sleep(wait)
        self._last = time.monotonic()

    def collection(self, slug: str, limit: int = 24) -> list[dict]:
        self._throttle()
        url = f"{FRAGMENT}/gifts?query={urllib.parse.quote(slug)}&filter=sale"
        try:
            page = _get(url, self.timeout)
        except (urllib.error.URLError, TimeoutError, OSError) as exc:
            raise FeedError(f"fragment {slug}: {exc}") from exc
        rows: list[dict] = []
        for item_slug, body in ITEM_RE.findall(page):
            name = NAME_RE.search(body)
            price = PRICE_RE.search(body)
            if not (name and price):
                continue
            status = STATUS_RE.search(body)
            stamp = TIME_RE.search(body)
            num = NUM_RE.search(body)
            rows.append({
                "slug": item_slug,
                "collection": item_slug.rsplit("-", 1)[0],
                "name": html_lib.unescape(name.group(1)).strip(),
                "num": int(num.group(1)) if num else None,
                "price_ton": float(price.group(1).replace(",", "")),
                "status": status.group(2) if status else "For sale",
                "listed_at": stamp.group(1) if stamp else None,
                "url": f"{FRAGMENT}/gift/{item_slug}",
            })
            if len(rows) >= limit:
                break
        return rows

    def cheapest(self, limit: int = 60) -> list[dict]:
        self._throttle()
        url = f"{FRAGMENT}/gifts?filter=sale&sort=price_asc"
        try:
            page = _get(url, self.timeout)
        except (urllib.error.URLError, TimeoutError, OSError) as exc:
            raise FeedError(f"fragment cheapest: {exc}") from exc
        rows = []
        for item_slug, body in ITEM_RE.findall(page)[:limit]:
            name, price = NAME_RE.search(body), PRICE_RE.search(body)
            if not (name and price):
                continue
            rows.append({
                "slug": item_slug,
                "collection": item_slug.rsplit("-", 1)[0],
                "name": html_lib.unescape(name.group(1)).strip(),
                "num": int(NUM_RE.search(body).group(1)) if NUM_RE.search(body) else None,
                "price_ton": float(price.group(1).replace(",", "")),
                "status": "For sale",
                "url": f"{FRAGMENT}/gift/{item_slug}",
            })
        return rows

    def scan(self, slugs: list[str], limit: int = 24) -> ScanResult:
        collections: dict[str, list[dict]] = {}
        errors: list[str] = []
        for slug in slugs:
            try:
                rows = self.collection(slug, limit)
            except FeedError as exc:
                errors.append(str(exc))
                continue
            if rows:
                collections[slug] = rows
            else:
                errors.append(f"fragment {slug}: 0 rows parsed (markup change or empty book)")
        source = "live" if collections else "live (empty)"
        return ScanResult(
            payload={
                "captured_at": datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ"),
                "source": "fragment.com public listing grid",
                "collections": collections,
            },
            errors=errors,
            source=source,
        )


class Rates:
    """TON/USD from two keyless sources; disagreement is surfaced, not smoothed."""

    TONAPI = "https://tonapi.io/v2/rates?tokens=ton&currencies=usd"
    COINGECKO = ("https://api.coingecko.com/api/v3/simple/price"
                 "?ids=the-open-network&vs_currencies=usd")

    @staticmethod
    def _json(url: str, timeout: float = 15.0) -> dict:
        req = urllib.request.Request(url, headers={"user-agent": UA, "accept": "application/json"})
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            return json.loads(resp.read())

    def fetch(self) -> tuple[dict, list[str]]:
        errors: list[str] = []
        a = b = None
        try:
            a = float(self._json(self.TONAPI)["rates"]["TON"]["prices"]["USD"])
        except Exception as exc:  # noqa: BLE001 - any failure is "no first opinion"
            errors.append(f"tonapi: {type(exc).__name__}: {exc}")
        try:
            b = float(self._json(self.COINGECKO)["the-open-network"]["usd"])
        except Exception as exc:  # noqa: BLE001
            errors.append(f"coingecko: {type(exc).__name__}: {exc}")

        if a and b:
            drift = abs(a - b) / max(a, b) * 100.0
            if drift > 2.0:
                errors.append(f"sources disagree by {drift:.2f}% (tonapi {a:.4f} vs coingecko {b:.4f})")
            price = min(a, b)  # the conservative one: same gift, fewer dollars
            return {"ton_usd": round(price, 6), "tonapi": a, "coingecko": b,
                    "drift_pct": round(drift, 3)}, errors
        if a or b:
            return {"ton_usd": round(float(a or b), 6)}, errors
        return {}, errors


class Telegram:
    """Optional sender. Reads the token from the environment; never logs it."""

    def __init__(self, token: str | None = None, chat_id: str | None = None):
        self.token = token if token is not None else os.environ.get("TG_BOT_TOKEN", "")
        self.chat_id = chat_id if chat_id is not None else os.environ.get("TG_CHAT_ID", "")

    @property
    def enabled(self) -> bool:
        return bool(self.token and self.chat_id)

    def send(self, text: str, timeout: float = 15.0) -> dict:
        if not self.enabled:
            raise FeedError("telegram not configured: set TG_BOT_TOKEN and TG_CHAT_ID")
        body = urllib.parse.urlencode({
            "chat_id": self.chat_id,
            "text": text,
            "parse_mode": "HTML",
            "disable_web_page_preview": "true",
        }).encode()
        req = urllib.request.Request(
            f"https://api.telegram.org/bot{self.token}/sendMessage", data=body,
            headers={"content-type": "application/x-www-form-urlencoded"})
        try:
            with urllib.request.urlopen(req, timeout=timeout) as resp:
                payload = json.loads(resp.read())
        except urllib.error.HTTPError as exc:
            detail = exc.read().decode("utf-8", "replace")[:300]
            raise FeedError(f"telegram HTTP {exc.code}: {detail}") from exc
        if not payload.get("ok"):
            raise FeedError(f"telegram refused: {payload.get('description')}")
        return payload.get("result", {})
