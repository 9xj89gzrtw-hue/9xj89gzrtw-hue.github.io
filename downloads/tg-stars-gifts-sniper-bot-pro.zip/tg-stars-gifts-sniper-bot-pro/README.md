# Gift Sniper — Telegram Gifts floor terminal, Stars arbitrage, Telegram alerts

A local desk for the Telegram Gifts market. It reads the public Fragment listing grid,
computes what each collection actually trades around, and tells you which asks are
underpriced *right now* — with the fee, the slippage and the gas already subtracted.

```
384 asks · 16 collections · 3 live signals · 78 self-checks · Python 3.9+ · no dependencies
```

```
$ python3 server.py
tg-stars-gifts-sniper-bot-pro 1.0.0
  http://127.0.0.1:8790/
  data: fixture snapshot
```

---

## Why the number on the screen is the number you can trade

Most "sniper" tools quote the floor and stop. The floor is the cheapest ask — buying at the
floor and selling at the floor loses 5% plus gas, every time. This desk prices the **exit**:

| leg | what is charged |
| --- | --- |
| buy | `ask + 1.5% slippage + 0.05 TON settlement gas` |
| sell | `exit − 5% Fragment seller fee − 0.05 TON gas` |
| exit reference | `min(trimmed baseline, next distinct ask)` |

The **trimmed baseline** is the median after cutting 15% off each tail. It answers "what does
this collection change hands around" instead of being dragged by the one 88,888 TON ask that
sits in every book.

The **next ask** is what makes a signal actionable: if the floor is 1,444 and the next ask is
1,700, you can buy and flip into a real bid today. If the gap is 1%, you cannot, and the row
says `PASS` — loudly, in the same table, on purpose.

## What you see

| tab | what it answers |
| --- | --- |
| **Board** | every watched ask, labelled `SNIPE` / `WATCH` / `PASS`, with the gap that decided it |
| **Collections** | floor, trimmed baseline, p25/p75, depth at the floor, spread per collection |
| **Simulator** | "what if I deploy 3,000 TON with a 1,200 TON cap" — pessimistic fills, idle cash shown |
| **Alerts** | the exact Telegram HTML that would go out, rendered before it is sent |
| **Stars arb** | mint-from-Stars versus sell-the-floor, once a Star cost is known |

The board is the product. A sniper that shows only hits is lying about how often it hits, so
every row it watched is visible, with the threshold it failed.

## Signal definition

```
SNIPE  gap ≥ 7%  AND  ask ≤ 85% of the trimmed baseline  AND  ≥ 6 asks in the book
WATCH  gap ≥ 3%  AND  ask ≤ 91% of the trimmed baseline
PASS   everything else — still listed, still clickable
```

Score (0-100) weights the discount (58%), the depth at the floor (22%), the breadth of the
book (10%) and the collection tier (10%). The weights live in `gifts.score_opportunity`, in
one function, so they can be argued with instead of guessed at.

## Quickstart

```bash
python3 verify.py            # 78 checks, offline, no token
python3 server.py            # fixture desk on http://127.0.0.1:8790
python3 server.py --live     # poll fragment.com + tonapi.io
python3 server.py --live --port 8791
```

Live mode makes one paced request per watched collection (0.55 s apart), so the default
16-collection watch list is ~9 seconds and does not hammer Fragment.

## Alerts

The desk renders the message; sending it needs a bot:

```bash
export TG_BOT_TOKEN=123456:ABC...
export TG_CHAT_ID=-1001234567890
curl -s -X POST localhost:8790/api/alert \
  -H 'content-type: application/json' \
  -d '{"limit":5,"send":true}'
```

Without both variables the server returns HTTP 400 and the reason. A sniper that silently
drops alerts is worse than one that never had them.

## The Stars leg

Telegram charges Stars per gift; Fragment settles TON. The spread between "mint with Stars"
and "sell the floor" is a real trade, but only when you know what Telegram charges *you* —
the catalogue is regional and changes without notice. So `COLLECTION_CATALOG` ships with
`star_cost: null` for every collection, and the arb table stays empty until you fill in the
numbers you see in your own client:

```python
# gifts.py
"plushpepe": {"name": "Plush Pepe", "star_cost": 100, "supply": 3000, "tier": "legendary"},
```

An empty table is the honest default. A guessed one is a lie with a progress bar.

## Files

```
gifts.py            engine: floors, trimmed baseline, gap, score, simulate, alert text
feeds.py            Fragment grid parser · TON rate (two sources) · optional Telegram sender
server.py           stdlib HTTP, 11 routes, 127.0.0.1 only
terminal.html       the whole UI in one file, no CDN, CSP, no external asset
verify.py           78 offline checks (engine, parsers, feeds, HTTP, failure paths)
tests/              pytest modules + the captured fixture
assets/make_cover.py  2400×1600 cover, numbers read from the same engine
docs/desk.png       real screenshot of the running desk
```

## API

| method | path | returns |
| --- | --- | --- |
| GET | `/api/scan` | the full summary (`?live=1`, `?force=1`) |
| GET | `/api/board` | the labelled book |
| GET | `/api/collections` | floors and depth |
| GET | `/api/history` | floor samples this process has seen |
| GET | `/api/export.csv` | the board as CSV |
| POST | `/api/simulate` | `{budget_ton, max_per_trade_ton}` → fills |
| POST | `/api/alert` | `{limit, send}` → Telegram HTML |
| POST | `/api/config` | merge thresholds, watch list, bot token (redacted on read) |

## Limits, stated plainly

- Fragment's public grid is the only price source. If the markup changes, the parser returns
  zero rows and the desk shows `live (empty)` rather than yesterday's numbers.
- No order placement. There is no Fragment API key in this box, and a tool that half-signs
  transactions is worse than a read-only one.
- Prices move between the render and your click. The alert says so, the board says so, the
  README says so.
- Not financial advice. Telegram gifts are illiquid, the fee is 5% each way, and the floor can
  disappear while you are reading this.

## License

MIT. Use it, fork it, ship it.
