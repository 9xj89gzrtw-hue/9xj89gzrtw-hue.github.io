"""Unit tests for the engine. `python3 -m pytest tests -q` or `verify.py`."""

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import gifts  # noqa: E402

FIX = gifts.load_fixture(Path(__file__).resolve().parent / "fixtures" / "listings.json")


def test_ton_parses_thousands():
    assert gifts.ton("88,888") == 88888.0


def test_parse_drops_sold():
    rows = gifts.parse_listings({"items": [
        {"slug": "a-1", "name": "A", "price_ton": 1, "status": "Sold"},
        {"slug": "a-2", "name": "A", "price_ton": 2, "status": "For sale"},
    ]})
    assert [r.num for r in rows] == [2]


def test_trimmed_baseline_ignores_an_outlier():
    base = [10.0] * 20
    assert gifts.trimmed_baseline(base) == gifts.trimmed_baseline(base + [1e6])


def test_fee_round_trip_loses():
    cfg = gifts.DEFAULT_CONFIG
    assert gifts.cost_to_sell(100, cfg) < gifts.buy_cost(100, cfg)


def test_stats_sorted_by_floor():
    floors = [s.floor_ton for s in gifts.stats_for(gifts.parse_listings(FIX))]
    assert floors == sorted(floors, reverse=True)


def test_opportunities_clear_thresholds():
    for op in gifts.find_opportunities(gifts.parse_listings(FIX)):
        assert op.gap_pct >= gifts.DEFAULT_CONFIG["min_gap_pct"]
        assert op.net_ton > 0


def test_board_labels_are_closed_set():
    labels = {r["status"] for r in gifts.board(gifts.parse_listings(FIX))}
    assert labels <= {"SNIPE", "WATCH", "PASS"}


def test_simulate_respects_budget():
    ops = gifts.find_opportunities(gifts.parse_listings(FIX))
    sim = gifts.simulate(ops, budget_ton=1000, max_per_trade=500)
    assert sim["invested_ton"] <= 1000
    assert all(f["buy_ton"] <= 500 for f in sim["fills"])


def test_alert_escapes():
    op = gifts.Opportunity("UNDERPRICE", "x", "<b>", 1, 2, 50, 1, 10, 50, 1, "rare", ref="x#1")
    assert "&lt;b&gt;" in gifts.render_alert([op])
