"""Gift intelligence engine: floors, mispricing, Stars arbitrage, snipe scoring.

Pure functions over plain dicts. No network, no I/O except `load_fixture`, so the
whole model can be tested offline and the numbers on the cover come from the
same code that answers the HTTP API.

Vocabulary used throughout
--------------------------
floor      the cheapest live ask in a collection (what you can buy *now*)
baseline   a trimmed median of the asks (what the collection is *worth*)
edge       baseline - ask, as a fraction of baseline; the sniper's whole thesis
depth      how many asks sit at or near the floor; thin depth means the floor
           you see is not the floor you get
star cost  what Telegram charges to mint the gift, in USD; optional, because
           Telegram's catalogue is regional and changes
"""

from __future__ import annotations

import json
import math
import statistics
from dataclasses import dataclass, field, asdict
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Iterable

DEFAULT_CONFIG: dict[str, Any] = {
    # Fragment takes 5% from the seller. Verified against fragment.com's own fee
    # line; stored in basis points so the arithmetic stays integer-exact.
    "fragment_fee_bps": 500,
    # On-chain gas for the TON transfer that settles a Fragment sale, in TON.
    "settle_gas_ton": 0.05,
    # Slippage allowance when you have to lift more than one ask.
    "slippage_bps": 150,
    # A listing must undercut the trimmed baseline by this much to be a signal.
    "min_discount_pct": 15.0,
    # ...and must leave at least this gap to the *next* ask, which is the price
    # you can actually flip into without waiting for a buyer.
    "min_gap_pct": 7.0,
    # Ignore collections with fewer asks than this: a 2-ask "floor" is noise.
    "min_asks": 6,
    # Trim this fraction from each tail before taking the baseline median.
    "trim_pct": 15.0,
    # Telegram's Stars are sold in packages; this is the marginal USD per star.
    "star_usd": 0.013,
    # Risk cap per simulated snipe, in TON.
    "max_per_trade_ton": 1200.0,
    "budget_ton": 3000.0,
    # A collection younger than this (days) is still in price discovery.
    "young_days": 45,
}

COLLECTION_CATALOG: dict[str, dict[str, Any]] = {
    # `star_cost` is what Telegram charges to mint one; leave null when it is not
    # verified rather than guessing, and the Stars leg is skipped for that
    # collection instead of printing a number nobody can reproduce.
    "plushpepe": {"name": "Plush Pepe", "star_cost": None, "supply": 3000, "tier": "legendary"},
    "durovscap": {"name": "Durov's Cap", "star_cost": None, "supply": 5000, "tier": "legendary"},
    "heartlocket": {"name": "Heart Locket", "star_cost": None, "supply": 12000, "tier": "epic"},
    "signetring": {"name": "Signet Ring", "star_cost": None, "supply": 20000, "tier": "epic"},
    "swisswatch": {"name": "Swiss Watch", "star_cost": None, "supply": 25000, "tier": "rare"},
    "iongem": {"name": "Ion Gem", "star_cost": None, "supply": 30000, "tier": "rare"},
    "astralshard": {"name": "Astral Shard", "star_cost": None, "supply": 40000, "tier": "rare"},
    "toybear": {"name": "Toy Bear", "star_cost": None, "supply": 60000, "tier": "uncommon"},
    "jellybunny": {"name": "Jelly Bunny", "star_cost": None, "supply": 80000, "tier": "uncommon"},
    "freshsocks": {"name": "Fresh Socks", "star_cost": None, "supply": 100000, "tier": "common"},
    "sharptongue": {"name": "Sharp Tongue", "star_cost": None, "supply": 90000, "tier": "common"},
    "deskcalendar": {"name": "Desk Calendar", "star_cost": None, "supply": 120000, "tier": "common"},
    "instantramen": {"name": "Instant Ramen", "star_cost": None, "supply": 150000, "tier": "common"},
    "vicecream": {"name": "Vice Cream", "star_cost": None, "supply": 150000, "tier": "common"},
    "lunarsnake": {"name": "Lunar Snake", "star_cost": None, "supply": 150000, "tier": "common"},
    "xmasstocking": {"name": "Xmas Stocking", "star_cost": None, "supply": 150000, "tier": "common"},
}

TIER_WEIGHT = {"legendary": 1.0, "epic": 0.82, "rare": 0.66, "uncommon": 0.5, "common": 0.36}


# --- models ----------------------------------------------------------------

@dataclass
class Listing:
    collection: str
    name: str
    num: int | None
    price_ton: float
    status: str = "For sale"
    listed_at: str | None = None
    url: str | None = None

    @property
    def key(self) -> str:
        return f"{self.collection}#{self.num}" if self.num is not None else self.collection


@dataclass
class CollectionStats:
    slug: str
    name: str
    asks: int
    floor_ton: float
    baseline_ton: float
    p25_ton: float
    p75_ton: float
    depth_at_floor: int
    spread_pct: float
    tier: str = "common"
    next_ask_ton: float = 0.0

    def as_dict(self) -> dict:
        return asdict(self)


@dataclass
class Opportunity:
    kind: str                 # UNDERPRICE | STAR_ARB | FLIP
    collection: str
    name: str
    ask_ton: float
    baseline_ton: float
    discount_pct: float
    net_ton: float
    roi_pct: float
    score: float
    depth: int
    tier: str
    exit_ton: float = 0.0
    gap_pct: float = 0.0
    url: str | None = None
    ref: str | None = None
    reasons: list[str] = field(default_factory=list)

    def as_dict(self) -> dict:
        return asdict(self)


# --- parsing ---------------------------------------------------------------

def ton(value: str | float | int) -> float:
    """'88,888' -> 88888.0. Fragment prints thousands separators, no decimals."""
    if isinstance(value, (int, float)):
        return float(value)
    return float(str(value).replace(",", "").replace(" ", "").strip())


def parse_listings(payload: dict) -> list[Listing]:
    """Accept both the live feed shape and the fixture shape (one schema)."""
    out: list[Listing] = []
    if "collections" in payload:
        for slug, rows in payload["collections"].items():
            for row in rows:
                out.append(Listing(
                    collection=row.get("collection") or slug,
                    name=row.get("name") or slug,
                    num=row.get("num"),
                    price_ton=ton(row["price_ton"]),
                    status=row.get("status") or "For sale",
                    listed_at=row.get("listed_at"),
                    url=row.get("url") or f"https://fragment.com/gift/{row.get('slug') or slug}",
                ))
    else:
        for row in payload.get("items", []):
            # Fragment puts the item number in the slug (`toybear-77`) and only
            # sometimes in the body. Deriving it from the slug keeps `#77`
            # visible on the board even when the markup drops the span.
            slug = row.get("slug") or ""
            tail = slug.rsplit("-", 1)[-1]
            out.append(Listing(
                collection=row.get("collection_raw") or slug.rsplit("-", 1)[0],
                name=row["name"],
                num=row.get("num") if row.get("num") is not None else (int(tail) if tail.isdigit() else None),
                price_ton=ton(row["price_ton"]),
                status=row.get("status") or "For sale",
                listed_at=row.get("listed_at"),
                url=row.get("url"),
            ))
    # Only live asks can be sniped.
    return [x for x in out if x.status.lower() in ("for sale", "", "avail", "for sale / auction")]


# --- statistics ------------------------------------------------------------

def trimmed_baseline(prices: list[float], trim_pct: float = 15.0) -> float:
    """Median after dropping the cheapest and dearest `trim_pct` percent.

    The plain mean is useless here: one 88,888 TON ask among 5 TON asks moves it
    by thousands. The plain median is better but still sags when half the book is
    parked at the floor. Trimming both tails asks "what does this collection
    actually change hands around".
    """
    if not prices:
        return 0.0
    ordered = sorted(prices)
    k = int(len(ordered) * max(0.0, min(40.0, trim_pct)) / 100.0)
    core = ordered[k:len(ordered) - k] or ordered
    return float(statistics.median(core))


def stats_for(listings: Iterable[Listing], catalog: dict | None = None,
              config: dict | None = None) -> list[CollectionStats]:
    cfg = {**DEFAULT_CONFIG, **(config or {})}
    catalog = catalog or COLLECTION_CATALOG
    by: dict[str, list[Listing]] = {}
    for item in listings:
        by.setdefault(item.collection, []).append(item)

    out: list[CollectionStats] = []
    for slug, rows in by.items():
        prices = sorted(x.price_ton for x in rows)
        floor = prices[0]
        p25 = prices[max(0, int(len(prices) * 0.25) - 1)]
        p75 = prices[min(len(prices) - 1, int(len(prices) * 0.75))]
        baseline = trimmed_baseline(prices, cfg["trim_pct"])
        depth = sum(1 for p in prices if p <= floor * 1.02)
        # The next distinct ask: what the floor can be flipped into immediately.
        nxt = next((p for p in prices[1:] if p > floor * 1.001), p75)
        spread = ((p75 - p25) / p25 * 100.0) if p25 else 0.0
        meta = catalog.get(slug, {})
        out.append(CollectionStats(
            slug=slug,
            name=meta.get("name") or rows[0].name,
            asks=len(rows),
            floor_ton=round(floor, 4),
            baseline_ton=round(baseline, 4),
            p25_ton=round(p25, 4),
            p75_ton=round(p75, 4),
            depth_at_floor=depth,
            spread_pct=round(spread, 2),
            tier=meta.get("tier", "common"),
            next_ask_ton=round(nxt, 4),
        ))
    out.sort(key=lambda s: -s.floor_ton)
    return out


# --- mispricing ------------------------------------------------------------

def cost_to_sell(price_ton: float, cfg: dict) -> float:
    """What actually lands in your wallet after a Fragment sale."""
    fee = price_ton * cfg["fragment_fee_bps"] / 10_000.0
    return price_ton - fee - cfg["settle_gas_ton"]


def buy_cost(price_ton: float, cfg: dict) -> float:
    slip = price_ton * cfg["slippage_bps"] / 10_000.0
    return price_ton + slip + cfg["settle_gas_ton"]


def score_opportunity(discount_pct: float, depth: int, tier: str, asks: int) -> float:
    """0-100. Discount is the signal; depth and tier are the risk haircut.

    A 40% discount on a collection with one ask at the floor is worth less than a
    20% discount with twelve asks behind it, because the second one you can
    actually exit. The weights are opinions, and they are written down here
    rather than buried in the UI so they can be argued with.
    """
    d = max(0.0, min(60.0, discount_pct)) / 60.0           # 0..1
    liquidity = min(1.0, math.log1p(depth) / math.log1p(8))  # 0..1, saturates at 8
    breadth = min(1.0, math.log1p(asks) / math.log1p(60))
    tier_w = TIER_WEIGHT.get(tier, 0.4)
    raw = 0.58 * d + 0.22 * liquidity + 0.10 * breadth + 0.10 * tier_w
    return round(min(100.0, raw * 100.0), 1)


def find_opportunities(listings: list[Listing], catalog: dict | None = None,
                       config: dict | None = None) -> list[Opportunity]:
    cfg = {**DEFAULT_CONFIG, **(config or {})}
    stats = {s.slug: s for s in stats_for(listings, catalog, cfg)}
    out: list[Opportunity] = []
    for item in listings:
        st = stats.get(item.collection)
        if not st or st.asks < cfg["min_asks"] or st.baseline_ton <= 0:
            continue
        discount = (st.baseline_ton - item.price_ton) / st.baseline_ton * 100.0
        if discount < cfg["min_discount_pct"]:
            continue
        # Exit at the *next* ask when one sits below the baseline: that is the
        # trade you can close today. Waiting for the baseline is a different,
        # slower trade and the model does not pretend otherwise.
        exit_ref = min(st.baseline_ton, st.next_ask_ton) if st.next_ask_ton else st.baseline_ton
        gap = (exit_ref - item.price_ton) / exit_ref * 100.0 if exit_ref else 0.0
        if gap < cfg["min_gap_pct"]:
            continue
        entry = buy_cost(item.price_ton, cfg)
        exit_ = cost_to_sell(exit_ref, cfg)
        net = exit_ - entry
        roi = net / entry * 100.0 if entry else 0.0
        if net <= 0:
            continue
        reasons = [
            f"ask {item.price_ton:,.0f} TON vs trimmed baseline {st.baseline_ton:,.1f}",
            f"undercuts the baseline by {discount:.1f}% (threshold {cfg['min_discount_pct']:.0f}%)",
            f"next ask {exit_ref:,.0f} TON → gap {gap:.1f}% (threshold {cfg['min_gap_pct']:.0f}%)",
            f"{st.depth_at_floor} asks at the floor, {st.asks} live asks in total",
        ]
        if item.listed_at:
            reasons.append(f"listed {item.listed_at}")
        out.append(Opportunity(
            kind="UNDERPRICE",
            collection=st.slug,
            name=item.name,
            ask_ton=round(item.price_ton, 4),
            baseline_ton=st.baseline_ton,
            discount_pct=round(discount, 2),
            net_ton=round(net, 4),
            exit_ton=round(exit_ref, 4),
            gap_pct=round(gap, 2),
            roi_pct=round(roi, 2),
            score=score_opportunity(discount, st.depth_at_floor, st.tier, st.asks),
            depth=st.depth_at_floor,
            tier=st.tier,
            url=item.url,
            ref=item.key,
            reasons=reasons,
        ))
    out.sort(key=lambda o: (-o.score, -o.net_ton))
    return out


# --- the board -------------------------------------------------------------

def board(listings: list[Listing], catalog: dict | None = None,
          config: dict | None = None, limit: int = 80) -> list[dict]:
    """Every ask with its gap to the next one, labelled SNIPE / WATCH / PASS.

    The board exists because a sniper that shows only hits is lying about how
    often it hits. You see the whole book it is watching, the gap on each row,
    and the threshold it failed.
    """
    cfg = {**DEFAULT_CONFIG, **(config or {})}
    stats = {s.slug: s for s in stats_for(listings, catalog, cfg)}
    rows: list[dict] = []
    for item in listings:
        st = stats.get(item.collection)
        if not st:
            continue
        exit_ref = min(st.baseline_ton, st.next_ask_ton) if st.next_ask_ton else st.baseline_ton
        gap = (exit_ref - item.price_ton) / exit_ref * 100.0 if exit_ref else 0.0
        discount = (st.baseline_ton - item.price_ton) / st.baseline_ton * 100.0
        status = "PASS"
        if st.asks >= cfg["min_asks"] and gap >= cfg["min_gap_pct"] and discount >= cfg["min_discount_pct"]:
            status = "SNIPE"
        elif st.asks >= cfg["min_asks"] and gap >= 3.0 and discount >= cfg["min_discount_pct"] * 0.6:
            status = "WATCH"
        net = cost_to_sell(exit_ref, cfg) - buy_cost(item.price_ton, cfg)
        rows.append({
            "ref": item.key, "collection": st.slug, "name": item.name, "num": item.num,
            "ask_ton": round(item.price_ton, 4), "next_ask_ton": st.next_ask_ton,
            "exit_ton": round(exit_ref, 4), "gap_pct": round(gap, 2),
            "discount_pct": round(discount, 2), "net_ton": round(net, 4),
            "status": status, "tier": st.tier, "asks": st.asks,
            "depth": st.depth_at_floor, "url": item.url, "listed_at": item.listed_at,
            "score": score_opportunity(discount, st.depth_at_floor, st.tier, st.asks) if status != "PASS" else 0.0,
        })
    order = {"SNIPE": 0, "WATCH": 1, "PASS": 2}
    rows.sort(key=lambda r: (order[r["status"]], -r["gap_pct"]))
    return rows[:limit]


# --- Stars leg -------------------------------------------------------------

def star_arbitrage(stats: list[CollectionStats], rates: dict, catalog: dict | None = None,
                   config: dict | None = None) -> list[Opportunity]:
    """Mint from Stars, sell the floor. Only for collections with a known star cost.

    Telegram charges Stars; Fragment settles TON. The trade is real, but it only
    exists when `star_cost` is known for the collection — so collections without
    it are *skipped*, not estimated.
    """
    cfg = {**DEFAULT_CONFIG, **(config or {})}
    catalog = catalog or COLLECTION_CATALOG
    ton_usd = float(rates.get("ton_usd") or 0.0)
    if ton_usd <= 0:
        return []
    out: list[Opportunity] = []
    for st in stats:
        meta = catalog.get(st.slug) or {}
        stars = meta.get("star_cost")
        if not stars:
            continue
        mint_usd = float(stars) * cfg["star_usd"]
        resale_ton = cost_to_sell(st.floor_ton, cfg)
        resale_usd = resale_ton * ton_usd
        net = resale_usd - mint_usd
        roi = net / mint_usd * 100.0 if mint_usd else 0.0
        if net <= 0:
            continue
        out.append(Opportunity(
            kind="STAR_ARB",
            collection=st.slug,
            name=st.name,
            ask_ton=mint_usd / ton_usd if ton_usd else 0.0,
            baseline_ton=resale_ton,
            discount_pct=0.0,
            net_ton=round(net / ton_usd, 4),
            roi_pct=round(roi, 2),
            score=round(min(100.0, 40 + roi / 2), 1),
            depth=st.depth_at_floor,
            tier=st.tier,
            ref=f"stars:{st.slug}",
            reasons=[
                f"mint {stars} Stars = ${mint_usd:.2f} at ${cfg['star_usd']}/star",
                f"floor {st.floor_ton:,.0f} TON = ${st.floor_ton * ton_usd:,.2f}",
                f"after 5% Fragment fee: ${resale_usd:,.2f}",
            ],
        ))
    out.sort(key=lambda o: -o.roi_pct)
    return out


# --- simulation ------------------------------------------------------------

def simulate(opportunities: list[Opportunity], config: dict | None = None,
             budget_ton: float | None = None, max_per_trade: float | None = None) -> dict:
    """Fill the best signals in score order until the budget is gone.

    Deliberately pessimistic: every fill pays the buy slippage *and* the full
    Fragment fee, and the exit is the trimmed baseline, not the top ask. A
    simulator that assumes you sell at the best price is a sales pitch, not a
    model.
    """
    cfg = {**DEFAULT_CONFIG, **(config or {})}
    budget = float(budget_ton if budget_ton is not None else cfg["budget_ton"])
    cap = float(max_per_trade if max_per_trade is not None else cfg["max_per_trade_ton"])
    remaining = budget
    fills: list[dict] = []
    for op in opportunities:
        if op.kind != "UNDERPRICE":
            continue
        if remaining < op.ask_ton or op.ask_ton > cap:
            continue
        cost = buy_cost(op.ask_ton, cfg)
        proceeds = cost_to_sell(op.baseline_ton, cfg)
        pnl = proceeds - cost
        remaining -= cost
        fills.append({
            "ref": op.ref, "collection": op.collection, "name": op.name,
            "buy_ton": round(cost, 4), "sell_ton": round(proceeds, 4),
            "pnl_ton": round(pnl, 4), "roi_pct": round(pnl / cost * 100.0, 2),
            "score": op.score,
        })
    invested = budget - remaining
    pnl = sum(f["pnl_ton"] for f in fills)
    return {
        "budget_ton": round(budget, 4),
        "invested_ton": round(invested, 4),
        "idle_ton": round(remaining, 4),
        "fills": fills,
        "n_fills": len(fills),
        "pnl_ton": round(pnl, 4),
        "roi_pct": round(pnl / invested * 100.0, 2) if invested else 0.0,
        "avg_score": round(sum(f["score"] for f in fills) / len(fills), 1) if fills else 0.0,
    }


# --- alerts ----------------------------------------------------------------

def render_alert(opportunities: list[Opportunity], limit: int = 5, rates: dict | None = None,
                 bot_name: str = "Gift Sniper") -> str:
    """Telegram HTML. Escaped by hand: only five entities exist and they matter."""
    def esc(text: str) -> str:
        return (str(text).replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;"))

    ton_usd = float((rates or {}).get("ton_usd") or 0.0)
    head = f"<b>{esc(bot_name)}</b> · {len(opportunities)} signal(s)"
    if ton_usd:
        head += f" · TON ${ton_usd:.3f}"
    lines = [head, ""]
    for i, op in enumerate(opportunities[:limit], 1):
        usd = f" (${op.net_ton * ton_usd:,.2f})" if ton_usd else ""
        lines.append(
            f"{i}. <b>{esc(op.name)}</b> · #{esc(op.ref or '')}\n"
            f"   ask <code>{op.ask_ton:,.0f}</code> TON · baseline <code>{op.baseline_ton:,.1f}</code>\n"
            f"   −{op.discount_pct:.1f}% · net <b>+{op.net_ton:,.2f} TON</b>{usd} · score {op.score:.0f}"
        )
        if op.url:
            lines.append(f"   <a href=\"{esc(op.url)}\">open listing</a>")
    lines.append("")
    lines.append("<i>prices move; re-check the ask before you buy</i>")
    return "\n".join(lines)


# --- fixture / summary -----------------------------------------------------

def load_fixture(path: str | Path) -> dict:
    payload = json.loads(Path(path).read_text())
    payload.setdefault("rates", {"ton_usd": 1.2355, "star_usd": DEFAULT_CONFIG["star_usd"]})
    return payload


def summary(payload: dict, config: dict | None = None, source: str = "fixture",
            errors: list[str] | None = None) -> dict:
    cfg = {**DEFAULT_CONFIG, **(config or {})}
    listings = parse_listings(payload)
    rates = payload.get("rates") or {}
    stats = stats_for(listings, COLLECTION_CATALOG, cfg)
    ops = find_opportunities(listings, COLLECTION_CATALOG, cfg)
    arb = star_arbitrage(stats, rates, COLLECTION_CATALOG, cfg)
    sim = simulate(ops, cfg)
    ton_usd = float(rates.get("ton_usd") or 0.0)

    return {
        "source": source,
        "captured_at": payload.get("captured_at"),
        "at": datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ"),
        "rates": {"ton_usd": ton_usd, "star_usd": cfg["star_usd"]},
        "counts": {
            "listings": len(listings),
            "collections": len(stats),
            "opportunities": len(ops),
            "star_arb": len(arb),
        },
        "totals": {
            "floor_ton": round(sum(s.floor_ton for s in stats), 4),
            "floor_usd": round(sum(s.floor_ton for s in stats) * ton_usd, 2),
            "best_discount_pct": max([o.discount_pct for o in ops], default=0.0),
            "best_gap_pct": max([o.gap_pct for o in ops], default=0.0),
            "net_ton": round(sum(o.net_ton for o in ops), 4),
            "net_usd": round(sum(o.net_ton for o in ops) * ton_usd, 2),
        },
        "collections": [s.as_dict() for s in stats],
        "opportunities": [o.as_dict() for o in ops],
        "board": board(listings, COLLECTION_CATALOG, cfg),
        "star_arb": [o.as_dict() for o in arb],
        "simulation": sim,
        "errors": errors or [],
        "config": cfg,
    }
