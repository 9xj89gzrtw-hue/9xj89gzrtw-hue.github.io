# Quickstart (60 seconds)

```bash
cd tg-stars-gifts-sniper-bot-pro
python3 verify.py          # 78 checks, offline
python3 server.py          # open http://127.0.0.1:8790
```

That is the whole install. No pip, no node, no key.

## Live prices

```bash
python3 server.py --live
```

or flip the **live** toggle in the header. Live mode polls `fragment.com/gifts` once per
watched collection (0.55 s apart) and TON/USD from tonapi.io + coingecko.

## Telegram alerts

```bash
export TG_BOT_TOKEN=123456:ABC...
export TG_CHAT_ID=-1001234567890
python3 server.py --live
# Alerts tab -> Render -> the exact HTML that would be sent
curl -s -X POST localhost:8790/api/alert -H 'content-type: application/json' -d '{"limit":5,"send":true}'
```

## What to look at first

1. **Board** — the `SNIPE` rows are the only ones that clear both thresholds. Everything else
   is a visible `PASS`.
2. Click a row: it opens the actual Fragment listing.
3. **Simulator** — put in the TON you would actually risk. The idle line tells you how much
   the model refused to deploy.
4. **Collections** — a collection with `depth 1` at the floor is a trap: the "floor" is one
   seller away from moving.

## Tuning

`config.json` (created on first save from the API) or `POST /api/config`:

```json
{
  "min_gap_pct": 7.0,
  "min_discount_pct": 15.0,
  "min_asks": 6,
  "fragment_fee_bps": 500,
  "slippage_bps": 150,
  "settle_gas_ton": 0.05,
  "budget_ton": 3000,
  "max_per_trade_ton": 1200
}
```

## Common questions

**Why is a 40% discount a PASS?**
Because the next ask is 2% away. The baseline is what the collection trades around, not a
price you can hit in the next ten minutes.

**Why is the Stars table empty?**
Because Telegram's per-gift Star price is regional and unverified here. Fill in
`COLLECTION_CATALOG[...]["star_cost"]` with what your client shows.

**Does it place orders?**
No. It reads, scores and alerts. Fragment has no public order API, and a half-signed
transaction is worse than no transaction.
