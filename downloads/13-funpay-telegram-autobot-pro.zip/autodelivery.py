"""Instant Auto-Delivery Module with secret link fulfillment."""
import json

def process_new_order(order_id: str, buyer_username: str, product_file: str) -> str:
    delivery_message = f"""Спасибо за покупку, {buyer_username}! 🚀
Ваш заказ #{order_id} готов.
📦 Ссылка на скачивание архива: https://9xj89gzrtw-hue.github.io/downloads/{product_file}

Инструкция: распакуйте архив и запустите по шагам из README.md
🎁 Оставьте положительный отзыв и получите закрытый бонус!"""
    return delivery_message
