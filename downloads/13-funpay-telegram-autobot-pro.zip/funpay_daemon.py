#!/usr/bin/env python3
"""FunPay 24/7 Autonomous Daemon for Agent 4 (danilaonly).
1. Eternal Online status via /runner/ pinging.
2. Periodic Auto-Raise (поднятие предложений) across all registered games.
3. Live Chat Monitoring, lead capture into /tmp/funpay_live_orders.json, and smart auto-replies.
Runs silently in background with zero OS notifications and zero window stealing.
"""
from __future__ import annotations

import datetime
import http.cookiejar
import json
import logging
import os
import re
import time
import urllib.parse
import urllib.request
from pathlib import Path
from bs4 import BeautifulSoup
from post_all_lots import make_session

# Setup quiet file logging
LOG_FILE = Path("/Users/evgenijdanilov/gemini/money4/funpay_daemon.log")
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s",
    handlers=[
        logging.FileHandler(LOG_FILE, encoding="utf-8"),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger("FunPayDaemon")

ORDERS_LOG = Path("/tmp/funpay_live_orders.json")
PERSISTENT_ORDERS = Path("/Users/evgenijdanilov/gemini/money4/funpay_live_orders.json")

GAMES_TO_RAISE = [
    {"game_id": "224", "name": "Telegram", "node_id": "1392", "next_raise": 0},
    {"game_id": "158", "name": "Прочие игры", "node_id": "2046", "next_raise": 0},
]

USER_AGENT = "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15"

class FunPayDaemon:
    def __init__(self):
        self.opener, self.cj = make_session()
        self.user_id: int | None = None
        self.csrf_token: str | None = None
        self.last_runner_time = 0
        self.processed_msg_ids: set[str] = set()
        self.init_session()

    def init_session(self):
        logger.info("Initializing FunPay session and extracting metadata...")
        try:
            req = urllib.request.Request("https://funpay.com/", headers={"User-Agent": USER_AGENT})
            resp = self.opener.open(req)
            html = resp.read().decode("utf-8", errors="ignore")
            soup = BeautifulSoup(html, "html.parser")
            body = soup.find("body")
            if body and body.get("data-app-data"):
                data = json.loads(body.get("data-app-data"))
                self.user_id = data.get("userId")
                self.csrf_token = data.get("csrf-token")
                logger.info(f"Authenticated as userId={self.user_id}, CSRF={self.csrf_token}")
        except Exception as e:
            logger.error(f"Failed to init session: {e}")

    def ping_runner(self) -> dict | None:
        """Pings FunPay /runner/ endpoint to maintain Online status and check chat messages."""
        if not self.user_id or not self.csrf_token:
            self.init_session()
            if not self.user_id:
                return None

        objects = [
            {"type": "chat_bookmarks", "id": str(self.user_id), "data": False},
            {"type": "orders_counters", "id": str(self.user_id), "data": False}
        ]
        data = urllib.parse.urlencode({
            "objects": json.dumps(objects),
            "request": "false",
            "csrf_token": self.csrf_token
        }).encode("utf-8")

        req = urllib.request.Request(
            "https://funpay.com/runner/",
            data=data,
            headers={
                "User-Agent": USER_AGENT,
                "X-Requested-With": "XMLHttpRequest",
                "Content-Type": "application/x-www-form-urlencoded; charset=UTF-8",
                "Referer": "https://funpay.com/"
            }
        )
        try:
            resp = self.opener.open(req)
            res = json.loads(resp.read().decode("utf-8", errors="ignore"))
            self.last_runner_time = time.time()
            return res
        except Exception as e:
            logger.warning(f"Runner ping failed: {e}")
            return None

    def check_and_raise_lots(self):
        """Attempts to raise lots for all registered games when their cooldown timer expires."""
        now = time.time()
        for game in GAMES_TO_RAISE:
            if now < game["next_raise"]:
                continue

            gid = game["game_id"]
            nid = game["node_id"]
            name = game["name"]
            logger.info(f"Triggering Auto-Raise for {name} (game {gid}, node {nid})...")

            data = urllib.parse.urlencode({"game_id": gid, "node_id": nid}).encode("utf-8")
            req = urllib.request.Request(
                "https://funpay.com/lots/raise",
                data=data,
                headers={
                    "User-Agent": USER_AGENT,
                    "X-Requested-With": "XMLHttpRequest",
                    "Referer": f"https://funpay.com/lots/{nid}/trade"
                }
            )
            try:
                resp = self.opener.open(req)
                res = json.loads(resp.read().decode("utf-8", errors="ignore"))
                logger.info(f"Raise {name} result: {res}")
                if res.get("wait"):
                    wait_sec = int(res["wait"])
                    game["next_raise"] = now + wait_sec + 15
                    unlock = res.get("unlock_at", f"+{wait_sec}s")
                    logger.info(f"Game {name} next raise scheduled at: {unlock}")
                elif res.get("msg") and not res.get("error"):
                    logger.info(f"Successfully raised {name}! Scheduling next in 4 hours.")
                    game["next_raise"] = now + 4 * 3600 + 30
            except Exception as e:
                logger.error(f"Raise error for {name}: {e}")
                game["next_raise"] = now + 300  # retry in 5 mins on error

    def send_chat_message(self, node_id: str, text: str):
        """Sends an automated reply to a chat node."""
        if not self.csrf_token:
            return
        logger.info(f"Sending automated reply to chat {node_id}: {text[:60]}...")
        payload = {
            "node": str(node_id),
            "last_message": 0,
            "content": text
        }
        data = urllib.parse.urlencode({
            "objects": "[]",
            "request": json.dumps({"action": "chat_message", "data": payload}),
            "csrf_token": self.csrf_token
        }).encode("utf-8")

        req = urllib.request.Request(
            "https://funpay.com/runner/",
            data=data,
            headers={
                "User-Agent": USER_AGENT,
                "X-Requested-With": "XMLHttpRequest",
                "Content-Type": "application/x-www-form-urlencoded; charset=UTF-8",
                "Referer": f"https://funpay.com/chat/?node={node_id}"
            }
        )
        try:
            self.opener.open(req)
            logger.info(f"Reply sent successfully to {node_id}")
        except Exception as e:
            logger.error(f"Failed to send reply to {node_id}: {e}")

    def process_incoming_messages(self, runner_data: dict):
        """Parses chat bookmarks and handles incoming buyer inquiries."""
        objects = runner_data.get("objects", [])
        for obj in objects:
            if obj.get("type") == "chat_bookmarks":
                data = obj.get("data", {})
                html = data.get("html", "")
                if not html:
                    continue

                soup = BeautifulSoup(html, "html.parser")
                for item in soup.find_all("a", class_="contact-item"):
                    node_id = item.get("data-id")
                    msg_id = item.get("data-user-msg")
                    author = item.find("div", class_="media-user-name")
                    author_name = author.text.strip() if author else "Buyer"
                    msg_elem = item.find("div", class_="contact-item-message")
                    msg_text = msg_elem.text.strip() if msg_elem else ""

                    if not node_id or not msg_id:
                        continue

                    # Ignore FunPay system notices or our own messages
                    if author_name.lower() in ["funpay", "danilaonly"]:
                        continue

                    msg_key = f"{node_id}_{msg_id}"
                    if msg_key in self.processed_msg_ids:
                        continue
                    self.processed_msg_ids.add(msg_key)

                    logger.info(f"🔥 NEW INCOMING MESSAGE from {author_name} (Node {node_id}): {msg_text}")

                    # Log to live orders file for main agent
                    lead = {
                        "timestamp": datetime.datetime.utcnow().isoformat(),
                        "author": author_name,
                        "chat_node": node_id,
                        "message": msg_text
                    }
                    self.record_live_lead(lead)

                    # Smart auto-reply
                    self.handle_smart_reply(node_id, author_name, msg_text)

    def record_live_lead(self, lead: dict):
        try:
            for path in [ORDERS_LOG, PERSISTENT_ORDERS]:
                existing = []
                if path.exists():
                    try:
                        existing = json.loads(path.read_text(encoding="utf-8"))
                    except:
                        existing = []
                existing.append(lead)
                path.write_text(json.dumps(existing, ensure_ascii=False, indent=2), encoding="utf-8")
        except Exception as e:
            logger.error(f"Error saving lead: {e}")

    def handle_smart_reply(self, node_id: str, author_name: str, message: str):
        msg_lower = message.lower()
        if any(w in msg_lower for w in ["бот", "bot", "напиш", "сделай", "скрипт", "парсер", "парс", "заказ", "тз", "разработ"]):
            reply = (
                f"Здравствуйте, {author_name}! Я онлайн и готов выполнить ваш заказ.\n\n"
                "Опишите, пожалуйста, детали задачи (какой функционал нужен / откуда собирать данные / какой стек), "
                "и я сразу приступаю к работе! Обычно выполнение занимает от 20 до 50 минут."
            )
        elif any(w in msg_lower for w in ["как скач", "где архив", "автовыдач", "купил", "ссылк", "код"]):
            reply = (
                f"Здравствуйте, {author_name}! На всех готовых товарах включена моментальная автовыдача ⚡\n\n"
                "Сразу после оплаты на странице заказа и в чате появляется прямая ссылка на скачивание архива с кодом. "
                "Если у вас есть вопросы по установке или нужна помощь с запуском — напишите сюда, помогу!"
            )
        else:
            reply = (
                f"Здравствуйте, {author_name}! Я на связи. Чем могу вам помочь?\n"
                "Готов проконсультировать по готовым товарам или разработать бота/парсер/скрипт под вашу задачу."
            )

        self.send_chat_message(node_id, reply)

    def run_loop(self):
        logger.info("Starting FunPay 24/7 background worker loop...")
        while True:
            try:
                # 1. PING RUNNER (Keep-Alive + Chat Check)
                runner_res = self.ping_runner()
                if runner_res:
                    self.process_incoming_messages(runner_res)

                # 2. AUTO-RAISE CHECK
                self.check_and_raise_lots()

                # Sleep 30 seconds before next ping
                time.sleep(30)
            except Exception as e:
                logger.error(f"Daemon loop exception: {e}")
                time.sleep(15)

if __name__ == "__main__":
    daemon = FunPayDaemon()
    daemon.run_loop()
