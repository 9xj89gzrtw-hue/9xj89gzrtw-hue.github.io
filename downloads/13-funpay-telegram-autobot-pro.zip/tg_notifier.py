"""Telegram Alerts for incoming FunPay orders."""
import urllib.request
import urllib.parse

def send_tg_alert(bot_token: str, chat_id: str, text: str):
    url = f"https://api.telegram.org/bot{bot_token}/sendMessage"
    payload = urllib.parse.urlencode({"chat_id": chat_id, "text": text, "parse_mode": "HTML"}).encode()
    urllib.request.urlopen(url, data=payload)
