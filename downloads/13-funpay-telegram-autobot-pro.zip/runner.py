"""FunPay 24/7 Keep-Alive & Auto-Raise Daemon."""
import time
import logging
import urllib.request
import json
from pathlib import Path

logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(message)s")

class FunPayRunner:
    def __init__(self, golden_key: str):
        self.golden_key = golden_key
        self.headers = {
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36",
            "Cookie": f"golden_key={self.golden_key}"
        }

    def ping(self):
        req = urllib.request.Request("https://funpay.com/runner/", headers=self.headers, method="POST")
        try:
            with urllib.request.urlopen(req, timeout=10) as resp:
                data = json.loads(resp.read().decode())
                logging.info(f"[+] Runner ping OK, active orders: {len(data.get('orders', []))}")
                return data
        except Exception as e:
            logging.error(f"[-] Ping error: {e}")
            return None

    def start_loop(self):
        logging.info("Starting FunPay 24/7 runner loop...")
        while True:
            self.ping()
            time.sleep(60)

if __name__ == "__main__":
    runner = FunPayRunner("YOUR_GOLDEN_KEY")
    runner.start_loop()
