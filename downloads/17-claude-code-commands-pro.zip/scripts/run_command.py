"""CLI runner for custom Claude Code prompt chains."""
import json
import sys

def load_command(cmd_name: str) -> str:
    with open("commands.json") as f:
        cmds = json.load(f)
    return cmds.get(cmd_name, f"Command {cmd_name} not found.")

if __name__ == "__main__":
    if len(sys.argv) > 1:
        print(load_command(sys.argv[1]))
    else:
        print("Available commands: /review, /bugfix, /commit, /security-audit, /refactor, /docs")
