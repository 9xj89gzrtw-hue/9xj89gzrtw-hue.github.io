# ⌨️ Claude Code Custom Commands & Prompts Pro
Коллекция кастомных слэш-команд для Claude Code: /review, /bugfix, /commit, /docs.

Подключение:
Скопируйте файлы в корень проекта или домашнюю директорию.