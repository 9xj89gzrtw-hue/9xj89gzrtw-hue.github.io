# ⌨️ Claude Code Custom Commands & Prompts Pro

Коллекция боевых слэш-команд для терминального ассистента Claude Code:
- `/review`: Глубокий аудит изменений git diff с указанием точных строк
- `/bugfix`: Пошаговый поиск и устранение первопричины багов
- `/security-audit`: Сканирование кода на уязвимости OWASP Top-10
- `/commit`: Генерация идеальных Conventional Commits сообщений

## Установка:
Скопируйте `commands.json` и `.clauderc` в корень вашего проекта или в домашнюю папку `~/.claude/`.
