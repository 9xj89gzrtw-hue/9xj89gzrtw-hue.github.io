// Minimalist Apple-style Popup Controller for Yandex Translation Downloader

document.addEventListener("DOMContentLoaded", async () => {
  const statusText = document.getElementById("status-text");
  const foundContainer = document.getElementById("found-container");
  const emptyContainer = document.getElementById("empty-container");
  const videoTitle = document.getElementById("video-title");
  const downloadBtn = document.getElementById("download-btn");
  const downloadBtnText = document.getElementById("download-btn-text");
  const audioPlayer = document.getElementById("audio-player");

  let currentTab = null;
  let audioData = null;

  try {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (!tab) {
      statusText.textContent = "Вкладка не найдена";
      return;
    }
    currentTab = tab;

    chrome.runtime.sendMessage({ action: "get_audio", tabId: tab.id }, (res) => {
      if (chrome.runtime.lastError) {
        statusText.textContent = "Готово к работе";
        return;
      }

      if (res && res.audio && res.audio.url) {
        audioData = res.audio;
        statusText.textContent = "Готово к скачиванию";
        statusText.style.color = "#34c759";

        videoTitle.textContent = tab.title || audioData.title || "Видео с переводом";
        audioPlayer.src = audioData.url;

        foundContainer.classList.remove("hidden");
        emptyContainer.classList.add("hidden");

        setTimeout(() => downloadBtn.focus(), 50);
      } else {
        statusText.textContent = "Озвучка не найдена";
        foundContainer.classList.add("hidden");
        emptyContainer.classList.remove("hidden");
      }
    });
  } catch (e) {
    statusText.textContent = "Ошибка";
  }

  // Trigger download on click or Enter
  downloadBtn.addEventListener("click", triggerDownload);

  document.addEventListener("keydown", (e) => {
    if (e.key === "Enter" && !downloadBtn.disabled) {
      triggerDownload();
    }
  });

  function triggerDownload() {
    if (!audioData && !currentTab) return;

    downloadBtn.disabled = true;
    downloadBtnText.textContent = "Скачивание...";

    chrome.runtime.sendMessage(
      {
        action: "download_audio",
        url: audioData.url,
        title: (currentTab && currentTab.title) || audioData.title
      },
      (res) => {
        if (chrome.runtime.lastError) {
          downloadBtnText.textContent = "❌ Ошибка связи";
        } else if (res && res.success) {
          downloadBtn.classList.add("success");
          downloadBtnText.textContent = "✅ Скачано в Загрузки";
        } else {
          downloadBtnText.textContent = `❌ Ошибка: ${res?.error || "Сбой"}`;
        }

        setTimeout(() => {
          downloadBtn.classList.remove("success");
          downloadBtn.disabled = false;
          downloadBtnText.textContent = "Скачать перевод (MP3)";
        }, 3000);
      }
    );
  }
});
