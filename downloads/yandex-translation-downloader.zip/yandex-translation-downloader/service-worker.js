// Service worker for Yandex Translation Audio Downloader

// Cache of captured audio tracks per tab: tabId -> { url, title, timestamp, size }
const tabAudios = new Map();

// Helper to sanitize filenames for OS compatibility
function sanitizeFilename(title) {
  if (!title) return "yandex_translation";
  return title
    .replace(/[\\/:*?"<>|]/g, "_")
    .replace(/\s+/g, " ")
    .replace(/ - YouTube$/, "")
    .trim()
    .slice(0, 120);
}

// Sniff network responses for Yandex neural translation audio
chrome.webRequest.onResponseStarted.addListener(
  (details) => {
    const { url, tabId, responseHeaders } = details;
    if (tabId < 0) return;

    // Check if the URL is a Yandex neural voiceover stream
    const isYandexVoiceUrl = 
      url.includes("vtrans") || 
      url.includes("mds.yandex.net/tts") || 
      url.includes("video-translation/audio") ||
      (url.includes("yandex.") && url.includes(".mp3"));

    let isAudioContent = isYandexVoiceUrl;
    let contentLength = 0;

    if (responseHeaders) {
      for (const h of responseHeaders) {
        const name = h.name.toLowerCase();
        const val = (h.value || "").toLowerCase();
        if (name === "content-type" && (val.includes("audio/mpeg") || val.includes("audio/mp3") || val.includes("audio/mp4") || val.includes("audio/ogg") || val.includes("audio/aac"))) {
          if (url.includes("yandex") || url.includes("vtrans") || isYandexVoiceUrl) {
            isAudioContent = true;
          }
        }
        if (name === "content-length") {
          contentLength = parseInt(val, 10) || 0;
        }
      }
    }

    if (isAudioContent) {
      chrome.tabs.get(tabId).then((tab) => {
        const title = tab ? tab.title : "перевод_видео";
        const audioData = {
          url,
          title,
          size: contentLength,
          timestamp: Date.now()
        };

        tabAudios.set(tabId, audioData);

        // Update badge in toolbar/header to signal detected audio
        chrome.action.setBadgeText({ tabId, text: "MP3" });
        chrome.action.setBadgeBackgroundColor({ tabId, color: "#10B981" }); // Emerald Green
        chrome.action.setTitle({ tabId, title: "Русский перевод готов к скачиванию!" });
      }).catch(() => {});
    }
  },
  { urls: ["*://*.yandex.net/*", "*://*.yandex.ru/*", "*://*.yandex.com/*", "*://*/*vtrans*"] },
  ["responseHeaders"]
);

// Clean up closed tabs
chrome.tabs.onRemoved.addListener((tabId) => {
  tabAudios.delete(tabId);
});

// Handle incoming messages from popup
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === "get_audio") {
    const tabId = request.tabId || (sender.tab ? sender.tab.id : null);
    const audio = tabId ? tabAudios.get(tabId) : null;
    sendResponse({ audio });
    return true;
  }

  if (request.action === "download_audio") {
    const { url, title } = request;
    if (!url) {
      sendResponse({ success: false, error: "No URL provided" });
      return true;
    }

    const filename = `${sanitizeFilename(title)}_перевод.mp3`;

    chrome.downloads.download(
      {
        url,
        filename,
        conflictAction: "uniquify",
        saveAs: false
      },
      (downloadId) => {
        if (chrome.runtime.lastError) {
          sendResponse({ success: false, error: chrome.runtime.lastError.message });
        } else {
          sendResponse({ success: true, downloadId });
        }
      }
    );
    return true;
  }
});
