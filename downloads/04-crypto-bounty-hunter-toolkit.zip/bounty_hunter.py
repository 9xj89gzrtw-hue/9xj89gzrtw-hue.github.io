#!/usr/bin/env python3
"""GitHub crypto-bounty hunter: finds repos that pay contributors DIRECTLY
in crypto (USDC/USDT/ETH/SOL/Base address rails) and HARD-BANS payment
processors that require KYC/identity verification.

Ban (payment rails / farms): algora, polar.sh, bountyhub, bounty-plaza,
stripe, gitcoin grind?, clankernation, unsafelabs, spaceapp, xpex.
(Gitcoin wildcard-allowed but flagged — Gitcoin pays crypto but needs wallet
grind; treat as allowed but labelled.)

Allow (evidence of direct payout): BOUNTY.md money lines with wallet
addresses (0x… / base58 SOL), keywords: USDC, USDT, "paid in ETH",
"WALLET", "Base", "BOUNTY.md", "HACKATHON", SECURITY.md bounty programs.

Usage:
  python3 tools/crypto_bounty_hunter.py [--max 60] [--since 2026-08-01]

Outputs a ranked shortlist: repo, evidence line, updated date, stars.
"""
from __future__ import annotations

import argparse
import json
import os
import re
import subprocess
import sys
import urllib.request

PROXY = os.environ.get("BountyProxy") or "socks5h://127.0.0.1:40000"
TOKEN = subprocess.run(["gh", "auth", "token"], capture_output=True,
                       text=True).stdout.strip()

try:
    import socks  # type: ignore
    import socket  # type: ignore
except ImportError:
    pass  # fall back to curl

BAN_TERMS = [
    "algora", "polar.sh", "bountyhub", "bounty-plaza", "clankernation",
    "unsafelabs", "spaceapp", "xpex", "stripe connect", "stripe.com",
    "passport", "kyc required", "identity verification",
]

ALLOW_PATTERNS = [
    re.compile(r"0x[a-fA-F0-9]{40}"),                      # evm wallet
    re.compile(r"\b[1-9A-HJ-NP-Za-km-z]{32,44}\b"),        # solana-ish
    re.compile(r"\bUSDC\b", re.I),
    re.compile(r"\bUSDT\b", re.I),
    re.compile(r"paid in (eth|usd[ct]|crypto)", re.I),
    re.compile(r"payment.*(wallet|address)", re.I),
    re.compile(r"BOUNTY\.md", re.I),
    re.compile(r"bounty.*pay(ment)?", re.I),
]

QUERY_POOL = [
    '"BOUNTY.md" USDC pushed:>2026-08-01',
    '"BOUNTY.md" USDT pushed:>2026-08-01',
    '"BOUNTY.md" "paid in ETH"',
    'BOUNTY.md "wallet address" bounty created:>2026-06-01',
    '"bug bounty" "paid directly" wallet crypto',
    '"USDC on Base" bounty',
    '"payout" "USDC" "KYC-free"',
    'BOUNTY file:BOUNTY.md USDC',
]


def gh_search(q: str, kind: str) -> list[dict]:
    path = "issues" if kind == "issues" else "repositories"
    url = (f"https://api.github.com/search/{path}?q={urllib.parse.quote(q)}"
           f"&per_page=30&sort=updated")
    req = urllib.request.Request(url, headers={
        "Authorization": f"token {TOKEN}",
        "Accept": "application/vnd.github+json",
        "User-Agent": "bounty-hunter/1.0",
    })
    # through proxy via curl (socks5h keeps DNS remote)
    cmd = ["curl", "-s", "-m", "20", "--socks5-hostname", "127.0.0.1:40000",
           "-H", f"Authorization: token {TOKEN}", url]
    raw = subprocess.run(cmd, capture_output=True, text=True).stdout
    try:
        data = json.loads(raw)
    except json.JSONDecodeError:
        return []
    return data.get("items", [])


def fetch_readme(full_name: str) -> str:
    for br in ("main", "master"):
        url = f"https://raw.githubusercontent.com/{full_name}/{br}/BOUNTY.md"
        out = subprocess.run(
            ["curl", "-s", "-m", "12", "--socks5-hostname", "127.0.0.1:40000",
             "-L", url], capture_output=True, text=True).stdout
        if out and "<html" not in out.lower() and len(out) > 50:
            return out
    return ""


def rank(evidence: str) -> int:
    score = 0
    if re.search(r"0x[a-fA-F0-9]{40}", evidence):
        score += 3
    if bool(re.search(r"\bUSDC\b|\bUSDT\b", evidence, re.I)):
        score += 2
    if bool(re.search(r"BOUNTY\.md", evidence, re.I)):
        score += 1
    return score


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--max", type=int, default=40)
    args = ap.parse_args()

    shortlist: dict[str, dict] = {}
    for q in QUERY_POOL:
        for it in (gh_search(q, "repositories") + gh_search(q, "issues")):
            repo = (it.get("repository") or {}).get("full_name") \
                if "repository" in it else it.get("full_name")
            if not repo:
                continue
            evidence = it.get("body") or it.get("description") or ""
            shortlist.setdefault(repo, {
                "repo": repo, "evidence": evidence[:200],
                "updated": it.get("updated_at") or it.get("pushed_at", ""),
                "url": it.get("html_url", ""),
            })

    scored = []
    for repo, info in shortlist.items():
        bmd = fetch_readme(repo)
        full_ev = (info["evidence"] + "\n" + bmd).strip()
        low = full_ev.lower()
        if any(b in low for b in BAN_TERMS):
            continue
        sc = rank(full_ev)
        if sc < 2:
            continue
        scored.append({**info, "score": sc, "bounty_md": len(bmd)})

    scored.sort(key=lambda x: (-x["score"], x["updated"]), reverse=False)
    scored.sort(key=lambda x: (-x["score"]))
    for s in scored[: args.max]:
        print(f"[{s['score']}] {s['repo']} | upd {s['updated'][:10]} | "
              f"{s['evidence'][:120]}")
    print(f"\ntotal: {len(scored)} candidates (after ban-filter)")
    return 0


if __name__ == "__main__":
    sys.exit(main())
