#!/usr/bin/env python3
"""Gibwork Solana bounty & task scanner.
Connects to sdk.gib.work with wallet authentication headers and fetches active USDC / SOL bounties.
"""
from __future__ import annotations

import json
import logging
import time
import urllib.request
import uuid
from typing import Any, Dict, List, Optional

logger = logging.getLogger("gibwork.scanner")

DEFAULT_WALLET = "0x72Aa6edDE71B94f6b99c8e52EdC02B5C75F74d1a"
GIBWORK_API_URL = "https://sdk.gib.work/v2/int/tasks/available"

def scan_gibwork_tasks(wallet_address: str = DEFAULT_WALLET, page: int = 1, limit: int = 50) -> List[Dict[str, Any]]:
    timestamp = str(int(time.time()))
    nonce = str(uuid.uuid4())
    headers = {
        "x-gibwork-wallet-address": wallet_address,
        "x-gibwork-timestamp": timestamp,
        "x-gibwork-nonce": nonce,
        "User-Agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36"
    }
    url = f"{GIBWORK_API_URL}?page={page}&limit={limit}"
    req = urllib.request.Request(url, headers=headers)
    try:
        with urllib.request.urlopen(req, timeout=12) as resp:
            data = json.loads(resp.read().decode("utf-8"))
            tasks = data.get("tasks", []) or data.get("data", [])
            logger.info(f"Fetched {len(tasks)} tasks from Gibwork.")
            return tasks
    except Exception as e:
        logger.warning(f"Could not reach Gibwork API directly: {e}")
        return []

if __name__ == "__main__":
    tasks = scan_gibwork_tasks()
    print(f"Gibwork tasks found: {len(tasks)}")
    for t in tasks[:5]:
        print(f" - {t.get('title')} | Reward: {t.get('reward')} {t.get('token')}")
