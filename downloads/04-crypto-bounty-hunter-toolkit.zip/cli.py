#!/usr/bin/env python3
"""Unified CLI for Onchain Analytics & Crypto Bounty Hunter Toolkit.
Subcommands:
  bounty      - Find GitHub repositories paying contributors directly in crypto.
  gibwork     - Scan Gibwork Solana tasks paying in USDC.
  track       - Walk on-chain USDC transfer logs for a wallet across EVM networks.
  verify      - Check wallet activity and nonce on Base/Arbitrum/EVM.
"""
from __future__ import annotations

import argparse
import sys
import subprocess
from pathlib import Path

def main():
    parser = argparse.ArgumentParser(description="Crypto Bounty Hunter & Onchain Analytics Toolkit")
    subparsers = parser.add_subparsers(dest="command", help="Subcommand to run")

    # Bounty hunter
    bounty_p = subparsers.add_parser("bounty", help="Search GitHub for direct crypto bounty programs")
    bounty_p.add_argument("--max", type=int, default=30, help="Max repos to inspect")
    bounty_p.add_argument("--since", default="2026-08-01", help="Updated since date (YYYY-MM-DD)")

    # Gibwork scanner
    gib_p = subparsers.add_parser("gibwork", help="Scan Gibwork Solana tasks")
    gib_p.add_argument("--wallet", default="0x72Aa6edDE71B94f6b99c8e52EdC02B5C75F74d1a", help="Auth wallet address")

    # Payout tracker
    track_p = subparsers.add_parser("track", help="Scan USDC transfer events for a wallet")
    track_p.add_argument("chain", choices=["base", "arbitrum", "ethereum", "polygon"], help="Blockchain network")
    track_p.add_argument("wallet", help="Target wallet address")
    track_p.add_argument("--days", type=int, default=30, help="Days to look back")
    track_p.add_argument("--direction", choices=["in", "out", "both"], default="in", help="Transfer direction")
    track_p.add_argument("--out", default="", help="Output JSON path")

    # Verify wallet
    ver_p = subparsers.add_parser("verify", help="Verify wallet activity and nonce on EVM")
    ver_p.add_argument("chain", choices=["base", "arbitrum", "ethereum", "polygon"], help="Blockchain network")
    ver_p.add_argument("wallet", help="Target wallet address")

    args = parser.parse_args()

    if not args.command:
        parser.print_help()
        sys.exit(1)

    cur_dir = Path(__file__).resolve().parent

    if args.command == "bounty":
        cmd = [sys.executable, str(cur_dir / "bounty_hunter.py"), "--max", str(args.max), "--since", args.since]
        subprocess.run(cmd)
    elif args.command == "gibwork":
        cmd = [sys.executable, str(cur_dir / "gibwork_scanner.py")]
        subprocess.run(cmd)
    elif args.command == "track":
        cmd = [sys.executable, str(cur_dir / "payout_tracker.py"), "scan", args.chain, args.wallet, "--days", str(args.days), "--direction", args.direction]
        if args.out:
            cmd.extend(["--out", args.out])
        subprocess.run(cmd)
    elif args.command == "verify":
        cmd = [sys.executable, str(cur_dir / "payout_tracker.py"), "verify", args.chain, args.wallet]
        subprocess.run(cmd)

if __name__ == "__main__":
    main()
