# 🚀 Хостинг Telegram-бота на VPS сервере
Готовые конфигурации systemd, Docker и docker-compose для работы бота 24/7 с авторестартом.