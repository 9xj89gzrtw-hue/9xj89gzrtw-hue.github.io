#!/usr/bin/env bash
# Автоматическая настройка чистого сервера Ubuntu под запуск ботов
set -e
echo "=== 🚀 Подготовка VPS Ubuntu ==="
apt update && apt upgrade -y
apt install -y python3 python3-pip python3-venv git curl ufw fail2ban

echo "[+] Настройка фаервола UFW..."
ufw allow 22/tcp
ufw allow 80/tcp
ufw allow 443/tcp
ufw --force enable

echo "✅ Сервер готов к установке ботов!"
