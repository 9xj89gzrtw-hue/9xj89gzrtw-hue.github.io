#!/usr/bin/env bash
# Automated Xray VLESS-Reality installer with REST API daemon
echo "Provisioning Xray Core v1.8+ with REALITY SNI camouflage..."
