# 📈 High-Frequency Cross-DEX Arbitrage & Liquidity Scanner
Инструмент для поиска треугольного арбитража и разницы курсов между пулами ликвидности:
- Анализ Base (Aerodrome, Uniswap) и Solana (Raydium, Meteora).
- Расчет чистой прибыли с учетом комиссии пула и газа.
