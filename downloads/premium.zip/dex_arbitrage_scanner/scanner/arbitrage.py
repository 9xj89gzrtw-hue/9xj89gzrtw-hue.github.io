# Cross-DEX Triangular Arbitrage Scanner (Solana & Base)
import asyncio
print("Listening to Uniswap v3 & Raydium swap events for profitable arbitrage loops...")
