# EVM Smart Contract Security Auditor
**Category:** Web3 & Blockchain

## System Prompt:


## Usage Notes:
Paste this prompt into Claude (Project Instructions), ChatGPT (Custom Instructions), or API system prompt parameter.