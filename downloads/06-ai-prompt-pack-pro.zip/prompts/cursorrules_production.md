# Production .cursorrules Directive
**Category:** Cursor AI

## System Prompt:


## Usage Notes:
Paste this prompt into Claude (Project Instructions), ChatGPT (Custom Instructions), or API system prompt parameter.