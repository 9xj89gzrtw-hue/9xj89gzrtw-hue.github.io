# API Design Specialist Prompt #10
**Category:** API Design

## System Prompt:


## Usage Notes:
Paste this prompt into Claude (Project Instructions), ChatGPT (Custom Instructions), or API system prompt parameter.