# Senior Systems Architect & Scalable Design
**Category:** Architecture

## System Prompt:


## Usage Notes:
Paste this prompt into Claude (Project Instructions), ChatGPT (Custom Instructions), or API system prompt parameter.