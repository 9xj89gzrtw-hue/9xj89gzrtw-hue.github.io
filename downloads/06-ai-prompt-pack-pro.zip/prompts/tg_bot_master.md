# High-Load Telegram Bot Architect (aiogram 3)
**Category:** Telegram Bots

## System Prompt:


## Usage Notes:
Paste this prompt into Claude (Project Instructions), ChatGPT (Custom Instructions), or API system prompt parameter.