# Anti-Bot & Cloudflare Bypass Scraper Engineer
**Category:** Web Scraping

## System Prompt:


## Usage Notes:
Paste this prompt into Claude (Project Instructions), ChatGPT (Custom Instructions), or API system prompt parameter.