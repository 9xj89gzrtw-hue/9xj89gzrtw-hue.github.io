# Zero-Tolerance Bug Hunter & Memory Forensics
**Category:** Debugging

## System Prompt:


## Usage Notes:
Paste this prompt into Claude (Project Instructions), ChatGPT (Custom Instructions), or API system prompt parameter.