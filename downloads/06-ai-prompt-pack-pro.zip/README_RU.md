# 🚀 МЕГА-ПАК: 50+ Профессиональных Системных Промптов для Claude 3.5/4, ChatGPT и Cursor (2026)

Добро пожаловать в премиальный набор системных промптов и правил для AI-разработки, написания ботов, парсинга, ончейн-аналитики и системного проектирования.

---

> 💡 **НУЖНА ИНДИВИДУАЛЬНАЯ РАЗРАБОТКА ИЛИ ДОРАБОТКА?**
> Если вам нужно разработать Telegram-бота, парсер, сайт или настроить AI-агента под вашу задачу:
> - Напишите мне в личные сообщения на **FunPay (danilaonly)**
> - Или в наш Telegram: **[@Shop010_bot](https://t.me/Shop010_bot)**
> - Сделаю под ключ за 30–60 минут с чистым кодом и гарантией!

---

## 📂 Структура пакета

1. **`prompts/01_coding_architect.md`** — Системный архитектор (проектирование масштабируемых сервисов, выбор стека, UML/Mermaid).
2. **`prompts/02_bug_hunter_debugger.md`** — Тотальный поиск багов, утечек памяти, deadlock'ов и генерация тестов.
3. **`prompts/03_parser_scraper_specialist.md`** — Парсинг сайтов, обход Cloudflare/Turnstile/WAF, ротация прокси, TLS JA3/JA4.
4. **`prompts/04_crypto_web3_smart_contract.md`** — Разработка смарт-контрактов (Solidity, Base, Arbitrum), ончейн-аудит, Web3.js/ethers.
5. **`prompts/05_telegram_discord_bot_builder.md`** — Telegram и Discord боты под ключ (aiogram 3, discord.py, прием крипты и карт).
6. **`prompts/06_cursor_ai_system_rules.md`** — Идеальный файл `.cursorrules` для Cursor IDE / VSCode Copilot.
7. **`prompts/07_copywriting_marketing_seo.md`** — Продающие описания, SEO-статьи, конверсионные тексты для маркетплейсов.
8. **`prompts/08_fullstack_ui_generator.md`** — Создание адаптивных интерфейсов (Tailwind, React, SVG, анимации без лишних библиотек).
9. **`prompts/09_refactoring_performance_optimizer.md`** — Оптимизация производительности Python/Node.js/SQL.
10. **`prompts_collection.json`** — Полная база всех 50+ промптов в формате JSON для интеграции в свои боты и приложения.

---

## 🛠️ Как применять эти промпты:

- **Claude (claude.ai):** Вставляйте промпт в поле **Project Instructions** (Системные инструкции проекта) или в начало первого сообщения диалога.
- **ChatGPT (chatgpt.com):** Зайдите в **Настройки → Пользовательские инструкции (Custom Instructions)** и вставьте нужный блок.
- **Cursor IDE / Windsurf:** Скопируйте содержимое `06_cursor_ai_system_rules.md` в корень вашего проекта в файл `.cursorrules`.
- **API (OpenAI / Anthropic / Gemini):** Передавайте текст в параметр `system`.
