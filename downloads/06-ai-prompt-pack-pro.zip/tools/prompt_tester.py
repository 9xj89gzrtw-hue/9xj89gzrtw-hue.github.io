"""Automated Prompt Benchmark & Token Calculator."""
import json
import sys

def analyze_prompt(text: str) -> dict:
    words = text.split()
    chars = len(text)
    est_tokens = int(chars / 3.8) # Heuristic for RU/EN blend
    return {
        "characters": chars,
        "word_count": len(words),
        "estimated_tokens": est_tokens,
        "cost_gpt4o_usd": round(est_tokens * 0.000005, 6),
        "cost_claude_sonnet_usd": round(est_tokens * 0.000003, 6)
    }

if __name__ == "__main__":
    sample = "Вы — ведущий архитектор программного обеспечения. Оптимизируйте следующий код..."
    print(json.dumps(analyze_prompt(sample), indent=2, ensure_ascii=False))
