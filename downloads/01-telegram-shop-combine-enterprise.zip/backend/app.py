from fastapi import FastAPI
app = FastAPI(title="Telegram Shop Combine Enterprise")
@app.get("/api/stats")
def stats():
    return {"total_sales_rub": 184500, "active_shops": 4, "orders_count": 612}
