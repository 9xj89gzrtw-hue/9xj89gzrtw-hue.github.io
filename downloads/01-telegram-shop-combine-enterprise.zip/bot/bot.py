# Enterprise multi-shop bot runner (aiogram 3.15)
import asyncio
print("Enterprise Telegram Shop Combine: Dual rails Stars + CryptoBot initialized.")
