# 🛒 Telegram Shop Enterprise Combine (Web Admin + Stars + CryptoBot)
Тяжелый коробочный продукт для запуска сетей интернет-магазинов в Telegram.
- Веб-панель управления на FastAPI/Vue.
- Мульти-каталог, скидки, промокоды, партнерская система 2 уровней.
- Прием платежей: Telegram Stars, CryptoBot (USDT), TON Connect.
