"""Admin analytics and broadcast script."""
import sqlite3

def print_stats():
    conn = sqlite3.connect("stars_bot.db")
    cur = conn.cursor()
    cur.execute("SELECT COUNT(*), SUM(balance_stars) FROM users")
    users_count, total_stars = cur.fetchone()
    print(f"=== 📊 Статистика Stars Бота ===")
    print(f"Всего пользователей: {users_count}")
    print(f"Куплено Stars: {total_stars or 0} ⭐️")
    conn.close()

if __name__ == "__main__":
    print_stats()
