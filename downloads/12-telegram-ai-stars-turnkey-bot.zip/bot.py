"""Telegram Stars AI Monetized Bot (aiogram 3 + Native Invoices)."""
import asyncio
import logging
import sqlite3
from aiogram import Bot, Dispatcher, types, F
from aiogram.filters import Command
from aiogram.types import LabeledPrice, PreCheckoutQuery

logging.basicConfig(level=logging.INFO)
BOT_TOKEN = "YOUR_BOT_TOKEN"
bot = Bot(token=BOT_TOKEN)
dp = Dispatcher()

def get_db():
    conn = sqlite3.connect("stars_bot.db")
    cur = conn.cursor()
    cur.execute("""
        CREATE TABLE IF NOT EXISTS users (
            user_id INTEGER PRIMARY KEY,
            balance_stars INTEGER DEFAULT 0,
            free_prompts INTEGER DEFAULT 3
        )
    """)
    conn.commit()
    return conn

@dp.message(Command("start"))
async def cmd_start(msg: types.Message):
    conn = get_db()
    cur = conn.cursor()
    cur.execute("INSERT OR IGNORE INTO users (user_id) VALUES (?)", (msg.from_user.id,))
    conn.commit()
    conn.close()

    await msg.answer(
        "✨ <b>Добро пожаловать в AI Stars Bot!</b>

"
        "У вас есть 3 бесплатных запроса к нейросети.
"
        "Чтобы пополнить баланс через Telegram Stars, используйте команду /buy",
        parse_mode="HTML"
    )

@dp.message(Command("buy"))
async def cmd_buy(msg: types.Message):
    # Send native Telegram Stars invoice
    prices = [LabeledPrice(label="50 AI Stars", amount=50)] # 50 Stars
    await msg.answer_invoice(
        title="Пакет 50 AI Stars",
        description="Пополнение баланса для неограниченных запросов к Claude и GPT-4o",
        payload="stars_pack_50",
        currency="XTR",
        prices=prices
    )

@dp.pre_checkout_query()
async def process_pre_checkout(pre_checkout_query: PreCheckoutQuery):
    await pre_checkout_query.answer(ok=True)

@dp.message(F.successful_payment)
async def process_successful_payment(msg: types.Message):
    stars_amount = msg.successful_payment.total_amount
    conn = get_db()
    cur = conn.cursor()
    cur.execute("UPDATE users SET balance_stars = balance_stars + ? WHERE user_id = ?", (stars_amount, msg.from_user.id))
    conn.commit()
    conn.close()
    await msg.answer(f"🎉 Оплата прошла успешно! Ваш баланс пополнен на {stars_amount} Stars ⭐️")

async def main():
    await dp.start_polling(bot)

if __name__ == "__main__":
    asyncio.run(main())
