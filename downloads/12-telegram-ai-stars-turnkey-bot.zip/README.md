# Готовый Telegram AI Бот с оплатой Telegram Stars ⭐️
Поддержка ChatGPT, Claude 3.5, Gemini и DeepSeek под ключ.

## Установка за 3 шага:
1. `pip install -r requirements.txt`
2. Скопируйте `.env.example` в `.env` и укажите токен бота из @BotFather
3. Запустите: `python3 bot.py`
