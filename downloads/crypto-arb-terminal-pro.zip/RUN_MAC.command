#!/bin/bash
cd "$(dirname "$0")"
open "ЗАПУСТИТЬ_В_1_КЛИК.html"
