@echo off
chcp 65001 >nul
start "" "ЗАПУСТИТЬ_В_1_КЛИК.html"
