#!/usr/bin/env python3
"""Self-check for crypto-arb-terminal-pro.

Runs offline. No API keys, no exchange calls, no internet. Every assertion is
either exact arithmetic on the engine, a parser fed a canned payload, or an
HTTP request against a server this script starts on a random localhost port.

    python3 verify.py            # human output
    python3 verify.py --quiet    # exit code only
    python3 verify.py --json     # machine-readable

Exit code 0 means every check passed. A single failure exits 1 and prints the
traceback, because a verifier that hides why it failed is worse than none.
"""

from __future__ import annotations

import json
import os
import socket
import struct
import sys
import tempfile
import threading
import traceback
import urllib.error
import urllib.request
from decimal import Decimal
from pathlib import Path

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))

import engine  # noqa: E402
import exchanges  # noqa: E402
import telegram  # noqa: E402

D = Decimal
RESULTS: list[tuple[str, bool, str]] = []


def check(name: str):
    def wrap(fn):
        try:
            detail = fn()
            RESULTS.append((name, True, "" if detail is None else str(detail)))
        except Exception:
            RESULTS.append((name, False, traceback.format_exc(limit=3).strip().splitlines()[-1]))
        return fn

    return wrap


def eq(actual, expected, label=""):
    if actual != expected:
        raise AssertionError(f"{label or 'value'}: got {actual!r}, want {expected!r}")
    return actual


def near(actual, expected, tol=1e-9, label=""):
    a, b = float(actual), float(expected)
    if abs(a - b) > tol:
        raise AssertionError(f"{label or 'value'}: got {a!r}, want {b!r} (±{tol})")
    return a


# ---------------------------------------------------------------------------
# files
# ---------------------------------------------------------------------------

REQUIRED = [
    "engine.py", "exchanges.py", "server.py", "telegram.py", "terminal.html",
    "config.example.json", "README.md", "QUICKSTART.md", "verify.py",
    "assets/cover.png", "assets/make_cover.py", "docs/desk.png",
    "tests/fixtures/quotes.json", "tests/test_engine.py", "tests/test_exchanges.py",
]


@check("layout: every shipped file exists")
def _layout():
    missing = [p for p in REQUIRED if not (ROOT / p).exists()]
    if missing:
        raise AssertionError("missing: " + ", ".join(missing))
    return f"{len(REQUIRED)} files"


@check("layout: no file is empty")
def _nonempty():
    empty = [p for p in REQUIRED if (ROOT / p).exists() and (ROOT / p).stat().st_size == 0]
    if empty:
        raise AssertionError("empty: " + ", ".join(empty))
    return "ok"


@check("layout: terminal.html has no external asset references")
def _selfcontained():
    page = (ROOT / "terminal.html").read_text()
    for bad in ("http://", "https://", "//cdn", "integrity="):
        if bad in page:
            raise AssertionError(f"external reference: {bad}")
    if "<style>" not in page or "<script>" not in page:
        raise AssertionError("inline style/script missing")
    return f"{len(page)} bytes"


@check("layout: cover is a 2400x1600 PNG")
def _cover():
    raw = (ROOT / "assets/cover.png").read_bytes()
    if raw[:8] != b"\x89PNG\r\n\x1a\n":
        raise AssertionError("not a PNG")
    width, height = struct.unpack(">II", raw[16:24])
    eq((width, height), (2400, 1600), "dimensions")
    if len(raw) < 40_000:
        raise AssertionError(f"cover looks empty: {len(raw)} bytes")
    return f"{width}x{height}, {len(raw)//1024} KiB"


# ---------------------------------------------------------------------------
# engine arithmetic
# ---------------------------------------------------------------------------


@check("engine: funding_apr converts 8h rate to annual percent")
def _apr8():
    # 0.01% per 8h -> 3 intervals/day -> 1095 intervals/yr -> 10.95%
    eq(engine.funding_apr("0.0001", 8), D("10.9500"))
    return "10.95%"


@check("engine: funding_apr is interval-aware (1h rate != 8h rate)")
def _apr1():
    hourly = engine.funding_apr("0.0000125", 1)
    eight = engine.funding_apr("0.0000125", 8)
    eq(hourly, D("10.950000"))
    near(eight, 1.36875)
    if hourly != eight * 8:
        raise AssertionError("hourly annualisation is not 8x the 8h one")
    return "8x"


@check("engine: funding_apr is zero-safe")
def _apr_zero():
    eq(engine.funding_apr("0.0001", 0), D(0))
    eq(engine.funding_apr("0", 8), D(0))
    return "ok"


@check("engine: basis_bps signs the perp premium")
def _basis():
    eq(engine.basis_bps("101", "100"), D("100.00"))
    eq(engine.basis_bps("99", "100"), D("-100.00"))
    eq(engine.basis_bps("100", "0"), D(0))
    return "ok"


@check("engine: breakeven_days divides cost by daily carry")
def _be():
    # 20% APR -> 20*100/365 = 5.479 bps/day; 15 bps cost -> 2.7375 days
    near(engine.breakeven_days(D("20"), D("15")), 2.7375)
    eq(engine.breakeven_days(D("0"), D("15")), None)
    eq(engine.breakeven_days(D("20"), D("0")), D(0))
    return "ok"


@check("engine: round-trip cost sums both taker fees and two slippages")
def _cost():
    cfg = {**engine.DEFAULT_CONFIG, "slippage_bps": 2}
    q1 = engine.Quote("binance", "spot", "BTC", D("100"))
    q2 = engine.Quote("bybit", "perp", "BTC", D("100"))
    eq(engine._cost_bps(q1, q2, cfg), D("14.5"))
    return "14.5 bps"


@check("engine: config can override a venue fee")
def _cost_override():
    cfg = {**engine.DEFAULT_CONFIG, "venue_fees_bps": {"binance": 1.0}}
    q1 = engine.Quote("binance", "spot", "BTC", D("100"))
    q2 = engine.Quote("binance", "perp", "BTC", D("100"))
    eq(engine._cost_bps(q1, q2, cfg), D("6.0"))  # 1 + 1 + 2*2 slippage
    return "6.0 bps"


@check("engine: cash_and_carry nets the annualised cost")
def _carry():
    perp = engine.Quote("binance", "perp", "BTC", D("68100"), D("0.0001"), D(8))
    spot = engine.Quote("binance", "spot", "BTC", D("68000"))
    op = engine.cash_and_carry(perp, spot, engine.DEFAULT_CONFIG)
    near(float(op.gross_apr), 10.95)
    near(float(op.cost_bps), 14.0)
    # cost 14 bps spread over 30 days -> 1.7033 APR points
    near(float(op.net_apr), 10.95 - 14 / 100 * 365 / 30, tol=1e-6)
    near(float(op.daily_usd), 10000 * 10.95 / 100 / 365, tol=1e-6)
    eq(op.signal, "CARRY")
    return f"net {float(op.net_apr):.2f}%"


@check("engine: negative funding is flagged, not silently shown as carry")
def _carry_neg():
    perp = engine.Quote("bybit", "perp", "ETH", D("3195"), D("-0.00002"), D(8))
    spot = engine.Quote("bybit", "spot", "ETH", D("3205"))
    op = engine.cash_and_carry(perp, spot, engine.DEFAULT_CONFIG)
    if op.gross_apr >= 0:
        raise AssertionError("negative funding became positive")
    if not any("negative funding" in n for n in op.notes):
        raise AssertionError("no negative-funding note")
    return f"{float(op.gross_apr):.2f}%"


@check("engine: cross_spread reports net bps and per-turn dollars")
def _spread():
    lo = engine.Quote("bybit", "perp", "ETH", D("3195"))
    hi = engine.Quote("binance", "perp", "ETH", D("3212"))
    op = engine.cross_spread(lo, hi, engine.DEFAULT_CONFIG)
    near(float(op.gross_bps), (3212 / 3195 - 1) * 10000, tol=1e-6)
    near(float(op.net_bps), float(op.gross_bps) - 14.5, tol=1e-6)
    near(float(op.daily_usd), 10000 * float(op.net_bps) / 10000, tol=1e-6)
    eq(op.signal, "SPREAD")
    return f"{float(op.net_bps):.2f} bps"


@check("engine: crossed prices are called out")
def _crossed():
    lo = engine.Quote("binance", "perp", "BTC", D("100"))
    hi = engine.Quote("bybit", "perp", "BTC", D("99"))
    op = engine.cross_spread(lo, hi, engine.DEFAULT_CONFIG)
    if op.gross_bps >= 0:
        raise AssertionError("negative gross should stay negative")
    if not any("prices crossed" in n for n in op.notes):
        raise AssertionError("missing crossed note")
    return "ok"


@check("engine: fixture loads every quote")
def _fixture():
    quotes = engine.load_fixture(ROOT / "tests/fixtures/quotes.json")
    eq(len(quotes), 24)
    kinds = {q.kind for q in quotes}
    eq(kinds, {"spot", "perp", "dex"})
    eq({q.venue for q in quotes}, {"binance", "bybit", "hyperliquid", "dex"})
    return "24 quotes"


@check("engine: scan dedupes and sorts by score")
def _scan():
    quotes = engine.load_fixture(ROOT / "tests/fixtures/quotes.json")
    ops = engine.scan(quotes)
    keys = [(o.kind, o.symbol, o.long_venue, o.short_venue) for o in ops]
    eq(len(keys), len(set(keys)), "duplicate venue pairs")
    scores = [o.score for o in ops]
    if scores != sorted(scores, reverse=True):
        raise AssertionError("not sorted descending")
    if len(ops) < 30:
        raise AssertionError(f"only {len(ops)} rows")
    return f"{len(ops)} rows"


@check("engine: a year of carry < cost is labelled WATCH")
def _watch():
    perp = engine.Quote("binance", "perp", "BTC", D("100"), D("0.0000001"), D(8))
    spot = engine.Quote("binance", "spot", "BTC", D("100"))
    op = engine.cash_and_carry(perp, spot, engine.DEFAULT_CONFIG)
    eq(op.signal, "WATCH")
    if not any("exceeds" in n for n in op.notes):
        raise AssertionError("missing cost warning")
    return "ok"


@check("engine: a symbol with only spot quotes produces no row")
def _scan_spot_only():
    quotes = [engine.Quote("binance", "spot", "XRP", D("1"))]
    eq(engine.scan(quotes), [])
    return "0 rows"


@check("engine: summary totals reconcile with the row list")
def _summary():
    quotes = engine.load_fixture(ROOT / "tests/fixtures/quotes.json")
    ops = engine.scan(quotes)
    s = engine.summary(ops, quotes, "fixture", "2026-10-28T00:00:00Z")
    eq(s["stats"]["count"], len(ops))
    eq(s["stats"]["carry"] + s["stats"]["spread"], len(ops))
    eq(s["quoteCount"], 24)
    eq(len(s["venues"]), 4)
    if s["stats"]["signals"] > len(ops):
        raise AssertionError("more signals than rows")
    return f"{s['stats']['count']} rows"


# ---------------------------------------------------------------------------
# exchange parsers (canned payloads, no network)
# ---------------------------------------------------------------------------


@check("binance: parser builds spot and perp quotes, ignores other symbols")
def _p_binance():
    prices = [
        {"symbol": "BTCUSDT", "price": "68000.0"},
        {"symbol": "ETHUSDT", "price": "3200.0"},
        {"symbol": "DOGEUSDT", "price": "0.1"},
        {"symbol": "BTCBUSD", "price": "1"},
    ]
    premium = [
        {"symbol": "BTCUSDT", "markPrice": "68100.0", "lastFundingRate": "0.0001"},
        {"symbol": "DOGEUSDT", "markPrice": "0.1", "lastFundingRate": "0.001"},
    ]
    quotes = exchanges.parse_binance(prices, premium, ["BTC"])
    eq(len(quotes), 2)
    eq({q.kind for q in quotes}, {"spot", "perp"})
    eq([q for q in quotes if q.is_perp][0].price, D("68100.0"))
    return "2 quotes"


@check("binance: missing mark price is dropped, not zeroed")
def _p_binance_zero():
    quotes = exchanges.parse_binance([], [{"symbol": "BTCUSDT", "markPrice": "0", "lastFundingRate": "0"}], ["BTC"])
    eq(quotes, [])
    return "ok"


@check("bybit: parser reads result.list for both categories")
def _p_bybit():
    spot = {"result": {"list": [{"symbol": "BTCUSDT", "lastPrice": "68050"}]}}
    linear = {"result": {"list": [{"symbol": "BTCUSDT", "lastPrice": "67980", "fundingRate": "0.00005",
                                   "turnover24h": "3100000000"}]}}
    quotes = exchanges.parse_bybit(spot, linear, ["BTC"])
    eq(len(quotes), 2)
    perp = [q for q in quotes if q.is_perp][0]
    eq(perp.funding_rate, D("0.00005"))
    eq(perp.volume_usd, D("3100000000"))
    return "2 quotes"


@check("bybit: malformed envelope raises VenueError")
def _p_bybit_bad():
    try:
        exchanges.parse_bybit({}, {}, ["BTC"])
    except exchanges.VenueError:
        return "raised"
    raise AssertionError("no error raised")


@check("hyperliquid: hourly funding is labelled 1h, not 8h")
def _p_hl():
    meta = {"universe": [{"name": "BTC"}, {"name": "ETH"}]}
    ctxs = [
        {"markPx": "68120", "funding": "0.0000125", "dayNtlVlm": "1400000000"},
        {"markPx": "3215", "funding": "0.000015"},
    ]
    quotes = exchanges.parse_hyperliquid(meta, ctxs, ["btc"])
    eq(len(quotes), 1)
    eq(quotes[0].symbol, "BTC")
    eq(quotes[0].interval_hours, D(1))
    near(engine.funding_apr(quotes[0].funding_rate, quotes[0].interval_hours), 10.95)
    return "1h interval"


@check("hyperliquid: length mismatch is rejected")
def _p_hl_bad():
    try:
        exchanges.parse_hyperliquid({"universe": [{"name": "BTC"}]}, [], ["BTC"])
    except exchanges.VenueError:
        return "raised"
    raise AssertionError("no error raised")


@check("dexscreener: picks the deepest pair on the requested chain")
def _p_dex():
    payload = {"pairs": [
        {"chainId": "ethereum", "priceUsd": "1", "liquidity": {"usd": "10"},
         "volume": {"h24": "1"}, "baseToken": {"symbol": "HYPE"}},
        {"chainId": "ethereum", "priceUsd": "25.2", "liquidity": {"usd": "19000000"},
         "volume": {"h24": "5"}, "baseToken": {"symbol": "HYPE"}},
        {"chainId": "bsc", "priceUsd": "99", "liquidity": {"usd": "99999999"},
         "baseToken": {"symbol": "HYPE"}},
    ]}
    quotes = exchanges.parse_dexscreener(payload, "hype")
    eq(len(quotes), 1)
    eq(quotes[0].price, D("25.2"))
    eq(quotes[0].symbol, "HYPE")
    return "deepest"


@check("dexscreener: a deeper pair for another token is rejected")
def _p_dex_wrong_token():
    payload = {"pairs": [
        {"chainId": "ethereum", "priceUsd": "0.000047", "liquidity": {"usd": "99999999"},
         "baseToken": {"symbol": "SCAM"}},
        {"chainId": "ethereum", "priceUsd": "25.2", "liquidity": {"usd": "10"},
         "baseToken": {"symbol": "HYPE"}},
    ]}
    eq(exchanges.parse_dexscreener(payload, "HYPE")[0].price, D("25.2"))
    return "correct token"


@check("dexscreener: WBTC is accepted as BTC")
def _p_dex_alias():
    payload = {"pairs": [{"chainId": "ethereum", "priceUsd": "81000",
                          "liquidity": {"usd": "1"}, "baseToken": {"symbol": "WBTC"}}]}
    eq(exchanges.parse_dexscreener(payload, "BTC")[0].price, D("81000"))
    return "alias"


@check("dexscreener: unroutable symbols have no DEX leg and no error")
def _p_dex_unroutable():
    eq(exchanges.fetch_dexscreener("HYPE", chain="ethereum", timeout=0.01), [])
    return "skipped"


@check("dexscreener: no matching chain raises VenueError")
def _p_dex_bad():
    try:
        exchanges.parse_dexscreener({"pairs": []}, "BTC")
    except exchanges.VenueError:
        return "raised"
    raise AssertionError("no error raised")


@check("collect: one dead venue does not abort the scan")
def _collect():
    original = exchanges.VENUES["binance"]

    def boom(symbols, timeout=8.0):
        raise exchanges.VenueError("binance -> HTTP 451")

    exchanges.VENUES["binance"] = boom
    try:
        result = exchanges.collect(["BTC"], venues=["binance"], include_dex=False)
    finally:
        exchanges.VENUES["binance"] = original
    eq(result.quotes, [])
    if not any("451" in e for e in result.errors):
        raise AssertionError("error was swallowed")
    return "degraded"


@check("collect: unknown venue is an explicit error")
def _collect_unknown():
    result = exchanges.collect(["BTC"], venues=["ftx"], include_dex=False)
    if not any("unknown venue" in e for e in result.errors):
        raise AssertionError("unknown venue accepted")
    return "ok"


# ---------------------------------------------------------------------------
# telegram
# ---------------------------------------------------------------------------


def _sample_summary():
    quotes = engine.load_fixture(ROOT / "tests/fixtures/quotes.json")
    ops = engine.scan(quotes)
    return engine.summary(ops, quotes, "fixture", "2026-10-28T00:00:00Z")


@check("telegram: render contains header, rows and footer")
def _tg():
    text = telegram.render(_sample_summary(), limit=3)
    for needle in ("<b>", "opportunities", "source: fixture", "Not financial advice"):
        if needle not in text:
            raise AssertionError(f"missing {needle!r}")
    eq(text.count("<b>"), 1 + 3)  # header bold + 3 row titles
    return f"{len(text)} chars"


@check("telegram: render respects the row limit")
def _tg_limit():
    text = telegram.render(_sample_summary(), limit=0)
    if "1. " in text:
        raise AssertionError("limit 0 still printed rows")
    return "ok"


@check("telegram: untrusted venue names are HTML-escaped")
def _tg_escape():
    evil = {
        "at": "2026-01-01T00:00:00Z",
        "source": "<script>alert(1)</script>",
        "venues": ["<img onerror=x>"],
        "quoteCount": 1,
        "opportunities": [{
            "kind": "CARRY", "symbol": "<b>X</b>", "longVenue": "a&b", "shortVenue": "<i>",
            "signal": "CARRY", "longPrice": 1, "shortPrice": 2, "netApr": 1, "netBps": 1,
            "dailyUsd": 1, "breakevenDays": 1, "costBps": 1, "notes": ["<script>"],
        }],
        "errors": [],
        "stats": {"count": 1, "signals": 1, "bestNetApr": 1, "bestNetBps": 1},
    }
    text = telegram.render(evil)
    if "<script>" in text or "<img" in text:
        raise AssertionError("raw HTML survived escaping")
    for escaped in ("&lt;script&gt;", "&lt;img", "a&amp;b"):
        if escaped not in text:
            raise AssertionError(f"missing {escaped}")
    return "escaped"


@check("telegram: render never exceeds the 4096-char API limit")
def _tg_len():
    big = _sample_summary()
    big["opportunities"] = big["opportunities"] * 12
    text = telegram.render(big, limit=200)
    if len(text) > 4000:
        raise AssertionError(f"{len(text)} chars")
    return f"{len(text)} chars"


@check("telegram: bad token is rejected before the network")
def _tg_token():
    try:
        telegram.send("nope", "1", "x")
    except ValueError:
        return "raised"
    raise AssertionError("accepted a malformed token")


# ---------------------------------------------------------------------------
# server over a real socket
# ---------------------------------------------------------------------------


class ServerFixture:
    def __init__(self):
        import server

        self.server_mod = server
        self.tmp = tempfile.TemporaryDirectory()
        server.CONFIG_PATH = Path(self.tmp.name) / "config.json"
        self.httpd = server.ThreadingHTTPServer(("127.0.0.1", 0), server.Handler)
        self.port = self.httpd.server_address[1]
        self.thread = threading.Thread(target=self.httpd.serve_forever, daemon=True)
        self.thread.start()

    def url(self, path):
        return f"http://127.0.0.1:{self.port}{path}"

    def get(self, path):
        with urllib.request.urlopen(self.url(path), timeout=10) as r:
            return r.status, r.read()

    def post(self, path, payload):
        data = json.dumps(payload).encode()
        req = urllib.request.Request(
            self.url(path), data=data, headers={"Content-Type": "application/json"}, method="POST"
        )
        with urllib.request.urlopen(req, timeout=10) as r:
            return r.status, r.read()

    def post_raw(self, path, raw: bytes):
        req = urllib.request.Request(
            self.url(path), data=raw, headers={"Content-Type": "application/json"}, method="POST"
        )
        try:
            with urllib.request.urlopen(req, timeout=10) as r:
                return r.status, r.read()
        except urllib.error.HTTPError as exc:
            return exc.code, exc.read()

    def close(self):
        self.httpd.shutdown()
        self.httpd.server_close()
        self.tmp.cleanup()


_SERVER: ServerFixture | None = None


def server_fixture() -> ServerFixture:
    global _SERVER
    if _SERVER is None:
        _SERVER = ServerFixture()
    return _SERVER


@check("server: / serves the terminal HTML")
def _s_root():
    status, body = server_fixture().get("/")
    eq(status, 200)
    if b"Arb Terminal" not in body:
        raise AssertionError("page title missing")
    return f"{len(body)} bytes"


@check("server: /api/health reports version and liveness")
def _s_health():
    status, body = server_fixture().get("/api/health")
    eq(status, 200)
    data = json.loads(body)
    eq(data["ok"], True)
    if not data["version"].count(".") == 2:
        raise AssertionError("version not semver-ish")
    return data["version"]


@check("server: /api/scan returns a fixture scan without network")
def _s_scan():
    status, body = server_fixture().get("/api/scan")
    eq(status, 200)
    data = json.loads(body)
    eq(data["source"], "fixture")
    eq(data["quoteCount"], 24)
    if len(data["opportunities"]) < 30:
        raise AssertionError("too few rows")
    eq(data["stats"]["count"], len(data["opportunities"]))
    return f"{len(data['opportunities'])} rows"


@check("server: /api/scan honours ?force=1")
def _s_force():
    _, first = server_fixture().get("/api/scan")
    _, second = server_fixture().get("/api/scan?force=1")
    a, b = json.loads(first), json.loads(second)
    eq(a["quoteCount"], b["quoteCount"])
    return "ok"


@check("server: /api/quotes matches the scan quote count")
def _s_quotes():
    _, body = server_fixture().get("/api/quotes")
    data = json.loads(body)
    eq(len(data["quotes"]), 24)
    q = data["quotes"][0]
    for key in ("venue", "kind", "symbol", "price", "fundingApr"):
        if key not in q:
            raise AssertionError(f"quote missing {key}")
    return "24 quotes"


@check("server: /api/export.csv has the documented header")
def _s_csv():
    _, body = server_fixture().get("/api/export.csv")
    text = body.decode()
    lines = text.strip().splitlines()
    header = lines[0].split(",")
    for col in ("kind", "symbol", "netApr", "netBps", "signal"):
        if col not in header:
            raise AssertionError(f"missing column {col}")
    if len(lines) < 30:
        raise AssertionError("csv has no rows")
    return f"{len(lines)-1} rows"


@check("server: /api/config redacts secret-ish keys")
def _s_config():
    server_fixture().post("/api/config", {"telegram_token": "123:abc", "capital_usd": 25000})
    _, body = server_fixture().get("/api/config")
    data = json.loads(body)
    eq(data["telegram_token"], "***")
    eq(data["capital_usd"], 25000)
    return "redacted"


@check("server: unknown config keys are ignored")
def _s_config_unknown():
    server_fixture().post("/api/config", {"wibble": 1, "include_dex": False})
    _, body = server_fixture().get("/api/config")
    data = json.loads(body)
    if "wibble" in data:
        raise AssertionError("unknown key persisted")
    eq(data["include_dex"], False)
    server_fixture().post("/api/config", {"include_dex": True})
    return "ok"


@check("server: malformed JSON body is a 400")
def _s_bad_json():
    status, body = server_fixture().post_raw("/api/config", b"{not json")
    eq(status, 400)
    if b"error" not in body:
        raise AssertionError("no error message")
    return "400"


@check("server: config changes reach the next scan")
def _s_config_effect():
    server_fixture().post("/api/config", {"min_spread_bps": 50})
    _, body = server_fixture().get("/api/scan?force=1")
    data = json.loads(body)
    spreads = [o for o in data["opportunities"] if o["kind"] == "SPREAD" and o["signal"] == "SPREAD"]
    if any(o["netBps"] < 50 for o in spreads):
        raise AssertionError("a SPREAD row is below the new threshold")
    server_fixture().post("/api/config", {"min_spread_bps": 6})
    return "applied"


@check("server: POST /api/telegram returns escaped text")
def _s_tg():
    status, body = server_fixture().post("/api/telegram", {"limit": 2})
    eq(status, 200)
    data = json.loads(body)
    if data["chars"] != len(data["text"]):
        raise AssertionError("char count wrong")
    if "<b>" not in data["text"]:
        raise AssertionError("no formatting")
    return f"{data['chars']} chars"


@check("server: unknown route is a JSON 404")
def _s_404():
    try:
        server_fixture().get("/api/nope")
    except urllib.error.HTTPError as exc:
        eq(exc.code, 404)
        data = json.loads(exc.read())
        eq(data["error"], "not found")
        return "404"
    raise AssertionError("no 404")


@check("server: path traversal is not served")
def _s_traversal():
    try:
        server_fixture().get("/../../etc/passwd")
    except urllib.error.HTTPError as exc:
        eq(exc.code, 404)
        return "404"
    raise AssertionError("traversal returned 200")


@check("server: HEAD returns headers and no body")
def _s_head():
    req = urllib.request.Request(server_fixture().url("/api/health"), method="HEAD")
    with urllib.request.urlopen(req, timeout=10) as r:
        eq(r.status, 200)
        eq(r.read(), b"")
    return "ok"


# ---------------------------------------------------------------------------
# runner
# ---------------------------------------------------------------------------


def main(argv: list[str] | None = None) -> int:
    argv = argv if argv is not None else sys.argv[1:]
    quiet = "--quiet" in argv
    as_json = "--json" in argv

    # checks registered by decorator run in definition order, at import time
    if _SERVER is not None:
        _SERVER.close()

    passed = sum(1 for _, ok, _ in RESULTS if ok)
    failed = [r for r in RESULTS if not r[1]]

    if as_json:
        print(json.dumps({
            "total": len(RESULTS),
            "passed": passed,
            "failed": len(failed),
            "checks": [{"name": n, "ok": ok, "detail": d} for n, ok, d in RESULTS],
        }, indent=2))
    elif not quiet:
        width = max(len(n) for n, _, _ in RESULTS) + 2
        for name, ok, detail in RESULTS:
            mark = "PASS" if ok else "FAIL"
            print(f"  [{mark}] {name.ljust(width)} {detail}")
        print()
        print(f"  {passed}/{len(RESULTS)} checks passed")

    if failed:
        if not as_json:
            print("\n  Failures:")
            for name, _, detail in failed:
                print(f"    - {name}: {detail}")
        return 1
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
