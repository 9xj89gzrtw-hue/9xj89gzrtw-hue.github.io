"""Local HTTP server for the terminal.

stdlib only: `ThreadingHTTPServer` plus a tiny router. It binds to 127.0.0.1
by default because this tool holds a config with position sizes and a Telegram
token; there is no authentication layer and there should never need to be one.

Routes
------
GET  /                     the terminal (terminal.html)
GET  /api/health           liveness + version + whether live data is enabled
GET  /api/config           effective config (secrets redacted)
POST /api/config           merge a partial config, returns the new config
GET  /api/scan             opportunities; `?live=1` hits the exchanges
GET  /api/quotes           the raw quotes behind the last scan
GET  /api/export.csv       the last scan as CSV
POST /api/telegram         render the alert text for the top signal
"""

from __future__ import annotations

import csv
import io
import json
import os
import sys
import threading
import time
from datetime import datetime, timezone
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from typing import Any
from urllib.parse import parse_qs, urlparse

import engine
import exchanges
import telegram

VERSION = "1.0.0"
ROOT = Path(__file__).resolve().parent
DEFAULT_FIXTURE = ROOT / "tests" / "fixtures" / "quotes.json"
CONFIG_PATH = Path(os.environ.get("ARB_CONFIG", ROOT / "config.json"))

_lock = threading.Lock()
_cache: dict[str, Any] = {"summary": None, "quotes": [], "at": 0.0, "live": False}
CACHE_TTL = 20.0


def load_config() -> dict:
    merged = dict(engine.DEFAULT_CONFIG)
    if CONFIG_PATH.exists():
        try:
            merged.update(json.loads(CONFIG_PATH.read_text()))
        except (OSError, ValueError):
            pass
    return merged


SECRET_KEYS = {"telegram_token", "telegram_chat_id"}
SERVER_KEYS = {"include_dex", "dex_chain", "venues", "fixture"}
WRITABLE = set(engine.DEFAULT_CONFIG) | {"venue_fees_bps"} | SECRET_KEYS | SERVER_KEYS


def save_config(patch: dict) -> dict:
    """Merge a partial config. Unknown keys are ignored, not echoed back.

    The file is chmod 600 because it may hold a Telegram token. The GET
    handler redacts those keys, so a browser tab left open does not leak them.
    """
    cfg = load_config()
    cfg.update({k: v for k, v in patch.items() if k in WRITABLE})
    CONFIG_PATH.write_text(json.dumps(cfg, indent=2) + "\n")
    try:
        os.chmod(CONFIG_PATH, 0o600)
    except OSError:
        pass
    return cfg


def redact(cfg: dict) -> dict:
    out = json.loads(json.dumps(cfg))
    for key in list(out):
        if key in SECRET_KEYS or any(word in key.lower() for word in ("token", "secret", "key", "password")):
            value = out[key]
            out[key] = "***" if value else ""
    return out


def build_summary(live: bool = False, force: bool = False) -> dict:
    """Scan once, cache for CACHE_TTL. Live failures fall back to the fixture."""
    now = time.time()
    with _lock:
        if not force and _cache["summary"] and now - _cache["at"] < CACHE_TTL:
            return _cache["summary"]

    cfg = load_config()
    source = "fixture"
    errors: list[str] = []
    if live:
        result = exchanges.collect(
            cfg.get("symbols") or engine.DEFAULT_CONFIG["symbols"],
            venues=cfg.get("venues"),
            include_dex=bool(cfg.get("include_dex", True)),
            dex_chain=cfg.get("dex_chain", "ethereum"),
        )
        quotes, errors, source = result.quotes, result.errors, "live"
        if not quotes:
            quotes = engine.load_fixture(cfg.get("fixture") or DEFAULT_FIXTURE)
            source = "fixture (live failed)"
    else:
        quotes = engine.load_fixture(cfg.get("fixture") or DEFAULT_FIXTURE)

    ops = engine.scan(quotes, cfg)
    at = datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
    data = engine.summary(ops, quotes, source=source, at=at, errors=errors)
    data["config"] = redact(cfg)

    with _lock:
        _cache.update(summary=data, quotes=quotes, at=now, live=live)
    return data


def to_csv(data: dict) -> str:
    buf = io.StringIO()
    fields = [
        "kind", "symbol", "longVenue", "shortVenue", "longPrice", "shortPrice",
        "grossBps", "costBps", "netBps", "grossApr", "netApr", "dailyUsd",
        "breakevenDays", "score", "signal",
    ]
    writer = csv.DictWriter(buf, fieldnames=fields, extrasaction="ignore")
    writer.writeheader()
    for row in data.get("opportunities", []):
        writer.writerow({k: row.get(k) for k in fields})
    return buf.getvalue()


class Handler(BaseHTTPRequestHandler):
    server_version = f"ArbTerminal/{VERSION}"
    protocol_version = "HTTP/1.1"

    # -- helpers ----------------------------------------------------------
    def _send(self, status: int, body: bytes, content_type: str) -> None:
        self.send_response(status)
        self.send_header("Content-Type", content_type)
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.send_header("X-Content-Type-Options", "nosniff")
        self.send_header("Referrer-Policy", "no-referrer")
        self.end_headers()
        if self.command != "HEAD":
            self.wfile.write(body)

    def _json(self, payload: Any, status: int = 200) -> None:
        self._send(status, json.dumps(payload, indent=2).encode(), "application/json; charset=utf-8")

    def _html(self, text: str) -> None:
        self._send(200, text.encode(), "text/html; charset=utf-8")

    def _read_json(self) -> dict:
        length = int(self.headers.get("Content-Length") or 0)
        if length <= 0:
            return {}
        if length > 1_000_000:
            raise ValueError("body too large")
        return json.loads(self.rfile.read(length).decode("utf-8") or "{}")

    def log_message(self, fmt: str, *args: Any) -> None:
        # Default logs every asset request; one line per API call is enough.
        if "/api/" in (args[0] if args else ""):
            sys.stderr.write("[%s] %s\n" % (time.strftime("%H:%M:%S"), fmt % args))

    # -- routes -----------------------------------------------------------
    def do_HEAD(self) -> None:
        self.do_GET()

    def do_GET(self) -> None:
        parsed = urlparse(self.path)
        path = parsed.path
        query = parse_qs(parsed.query)

        try:
            if path in ("/", "/index.html", "/terminal"):
                page = ROOT / "terminal.html"
                if not page.exists():
                    return self._html("<h1>terminal.html missing</h1>")
                return self._html(page.read_text())

            if path == "/api/health":
                return self._json({
                    "ok": True,
                    "version": VERSION,
                    "python": sys.version.split()[0],
                    "liveEnabled": os.environ.get("ARB_LIVE", "0") == "1",
                    "cacheAgeSec": round(time.time() - _cache["at"], 1) if _cache["at"] else None,
                    "fixture": DEFAULT_FIXTURE.exists(),
                })

            if path == "/api/config":
                return self._json(redact(load_config()))

            if path == "/api/scan":
                live = query.get("live", ["0"])[0] in ("1", "true", "yes")
                force = query.get("force", ["0"])[0] in ("1", "true", "yes")
                return self._json(build_summary(live=live, force=force))

            if path == "/api/quotes":
                data = build_summary(live=query.get("live", ["0"])[0] in ("1", "true"))
                return self._json({
                    "source": data["source"],
                    "quotes": [q.as_dict() for q in _cache["quotes"]],
                })

            if path == "/api/export.csv":
                data = build_summary(live=query.get("live", ["0"])[0] in ("1", "true"))
                body = to_csv(data).encode()
                self.send_response(200)
                self.send_header("Content-Type", "text/csv; charset=utf-8")
                self.send_header("Content-Disposition", 'attachment; filename="opportunities.csv"')
                self.send_header("Content-Length", str(len(body)))
                self.end_headers()
                return self.wfile.write(body)

            return self._json({"error": "not found", "path": path}, 404)
        except Exception as exc:
            return self._json({"error": f"{type(exc).__name__}: {exc}"}, 500)

    def do_POST(self) -> None:
        path = urlparse(self.path).path
        try:
            body = self._read_json()
        except ValueError as exc:
            return self._json({"error": str(exc)}, 400)

        try:
            if path == "/api/config":
                return self._json(redact(save_config(body)))
            if path == "/api/telegram":
                data = build_summary(live=bool(body.get("live")))
                limit = int(body.get("limit") or 5)
                text = telegram.render(data, limit=limit, bot_name=body.get("bot_name", "Arb Terminal"))
                return self._json({"text": text, "chars": len(text)})
            return self._json({"error": "not found", "path": path}, 404)
        except Exception as exc:
            return self._json({"error": f"{type(exc).__name__}: {exc}"}, 500)


def serve(host: str = "127.0.0.1", port: int = 8787, live: bool = False) -> None:
    if live:
        os.environ["ARB_LIVE"] = "1"
        build_summary(live=True)
    httpd = ThreadingHTTPServer((host, port), Handler)
    httpd.daemon_threads = True
    print(f"crypto-arb-terminal-pro {VERSION}")
    print(f"  http://{host}:{port}/")
    print(f"  live data: {'on' if live else 'off (fixture)'}")
    print("  Ctrl-C to stop")
    try:
        httpd.serve_forever()
    except KeyboardInterrupt:
        print("\nstopped")
    finally:
        httpd.server_close()


def main(argv: list[str] | None = None) -> int:
    import argparse

    parser = argparse.ArgumentParser(description="crypto-arb-terminal-pro local server")
    parser.add_argument("--host", default="127.0.0.1")
    parser.add_argument("--port", type=int, default=8787)
    parser.add_argument("--live", action="store_true", help="scan real exchanges on startup")
    args = parser.parse_args(argv)
    serve(args.host, args.port, args.live)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
