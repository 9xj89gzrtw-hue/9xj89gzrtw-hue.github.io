# crypto-arb-terminal-pro

A local desk for two trades that are easy to describe and easy to get wrong:

- **Carry** — long spot (or a DEX pool), short the perpetual, collect funding while delta-neutral.
- **Spread** — long the cheaper venue, short the richer one, keep the basis.

Both are shown **net of taker fees and slippage**, with the break-even holding
period and the dollar value per day. No API keys, no order placement, no
telemetry, no cloud. One folder, stdlib Python, and a browser tab.

```
python3 server.py            # http://127.0.0.1:8787  (bundled snapshot)
python3 server.py --live     # scan Binance / Bybit / Hyperliquid / DexScreener
```

---

## Why another scanner

Most "arbitrage finders" show gross spreads. A 40 bps spread between two perps
looks like free money until you pay 5 bps twice, cross two order books, and
discover the funding you were going to collect is negative on the leg you
needed. This tool refuses to hide that:

| The question | Where the answer is |
|---|---|
| Is the edge real after fees? | `netBps`, `netApr` — cost is subtracted, never grossed up |
| How long until the cost is paid? | `breakevenDays` from funding alone |
| What is that in dollars? | `dailyUsd` on your configured capital |
| Is one leg on-chain? | a note on every DEX leg, plus MEV/bridge risk |
| Is funding actually positive? | negative rates are flagged, not shown as carry |
| Which venues failed? | `errors[]` in every scan payload |

And one deliberate omission: **cross-venue spread is not annualised as if you
could repeat it every day.** The UI shows net bps and per-turn dollars. `netApr`
exists for sorting and is labelled "if repeated" because a basis trade is a
one-shot, not a yield.

## What is in the box

```
crypto-arb-terminal-pro/
├── engine.py              pure math: funding APR, basis, cost, break-even, scan
├── exchanges.py           public API clients + pure parsers (no keys)
├── server.py              local HTTP server + JSON/CSV API
├── telegram.py            alert renderer (HTML-escaped) + optional sender
├── terminal.html          the desk: table, filters, detail rows, no CDN
├── config.example.json    copy to config.json and edit
├── verify.py              52 offline checks: math, parsers, HTTP routes
├── tests/
│   ├── test_engine.py     26 unittest cases
│   ├── test_exchanges.py  21 unittest cases
│   └── fixtures/quotes.json
├── assets/
│   ├── cover.png          2400x1600 product cover
│   └── make_cover.py      reproducible cover generator (Pillow, build-time only)
├── docs/desk.png          screenshot of the running desk (fixture data)
├── README.md
├── QUICKSTART.md
└── LICENSE               MIT, with an explicit "not financial advice" note
```

## Install

Python **3.9+**. Nothing to install for the product itself.

```bash
cd crypto-arb-terminal-pro
cp config.example.json config.json     # optional, defaults work
python3 verify.py                      # 52 checks, offline
python3 server.py
```

Open <http://127.0.0.1:8787>. The default view is the bundled snapshot, so the
UI works with no network at all. Flip **Live data** to call the exchanges.

If you want the cover generator: `python3 -m pip install pillow` and
`python3 assets/make_cover.py`. The cover is already in `assets/`; you do not
need Pillow to run the desk.

## Live data

| Venue | Endpoint | Kind | Funding interval |
|---|---|---|---|
| Binance | `api.binance.com/api/v3/ticker/price` + `fapi.binance.com/fapi/v1/premiumIndex` | spot + perp | 8h |
| Bybit | `api.bybit.com/v5/market/tickers` (`spot`, `linear`) | spot + perp | 8h |
| Hyperliquid | `api.hyperliquid.xyz/info` (`metaAndAssetCtxs`) | perp | **1h** |
| DexScreener | `api.dexscreener.com/token-pairs/v1/{chain}/{address}` | DEX | n/a |

All public, all read-only. Hyperliquid publishes an **hourly** funding rate;
treating it as 8-hourly overstates the APR by 8x. That is the single most common
bug in Hyperliquid carry calculators, and there is a test pinning it.

If a venue is down, blocked by your region, or rate-limits you, the scan keeps
going and lists the failure in `errors[]`. A partial comparison with a visible
error beats a blank screen.

DEX legs are priced by **token contract**, not by name: a search for "BTC" can
return a token that merely calls itself BTC, and a leg priced off the wrong
asset is worse than no leg. SOL and HYPE have no canonical Ethereum pool, so
they simply have no DEX leg — that is a fact about the asset, not an error.

### Region note

Some venues return HTTP 451 from some countries. That is a legal block, not a
bug. The scanner reports it and continues with the venues it can reach. Nothing
in this product circumvents geo-restrictions.

## Configuration

`config.json` is merged over the defaults in `engine.DEFAULT_CONFIG`:

```json
{
  "capital_usd": 10000,
  "min_net_apr": 8.0,
  "min_spread_bps": 6.0,
  "holding_days": 30,
  "taker_fee_bps": 5.5,
  "slippage_bps": 2.0,
  "symbols": ["BTC", "ETH", "SOL", "HYPE"],
  "venues": ["binance", "bybit", "hyperliquid"],
  "include_dex": true,
  "dex_chain": "ethereum",
  "venue_fees_bps": {"binance": 5.0, "bybit": 5.5, "hyperliquid": 4.5, "dex": 5.0}
}
```

| Key | Meaning |
|---|---|
| `capital_usd` | notional per leg; drives `dailyUsd` |
| `min_net_apr` | carry below this is `WATCH` |
| `min_spread_bps` | spread below this is `WATCH` |
| `holding_days` | amortisation window for the round-trip cost |
| `slippage_bps` | **per leg**, applied twice per round trip |
| `venue_fees_bps` | override any venue's taker fee |

Set your real fee tier. A VIP-0 taker on Bybit is 5.5 bps; a market maker is
not. The defaults are a starting point, not a promise.

## HTTP API

The server binds to `127.0.0.1` by default. There is no auth layer because
there is nothing to protect beyond your own config; do not expose it.

| Method | Path | Purpose |
|---|---|---|
| GET | `/` | the terminal |
| GET | `/api/health` | version, liveness, cache age |
| GET | `/api/config` | effective config, secrets redacted |
| POST | `/api/config` | merge a partial config |
| GET | `/api/scan?live=0\|1&force=0\|1` | opportunities + stats |
| GET | `/api/quotes` | raw quotes behind the last scan |
| GET | `/api/export.csv` | the last scan as CSV |
| POST | `/api/telegram` | render the alert text (`{live, limit, bot_name}`) |

```bash
curl -s localhost:8787/api/scan | jq '.stats'
curl -s 'localhost:8787/api/scan?live=1' | jq '.opportunities[0]'
curl -s localhost:8787/api/export.csv > opportunities.csv
```

Example payload:

```json
{
  "at": "2026-10-28T09:00:00Z",
  "source": "live",
  "venues": ["binance", "bybit", "dex", "hyperliquid"],
  "quoteCount": 24,
  "stats": {"count": 60, "carry": 36, "spread": 24, "bestNetApr": 25.67,
            "bestNetBps": 186.0, "signals": 41},
  "opportunities": [{
    "kind": "SPREAD", "symbol": "HYPE",
    "longVenue": "bybit", "shortVenue": "hyperliquid",
    "longPrice": 25.0, "shortPrice": 25.5,
    "grossBps": 200.0, "costBps": 14.0, "netBps": 186.0,
    "netApr": 22.63, "dailyUsd": 186.0, "breakevenDays": 0.0,
    "signal": "SPREAD", "notes": ["one leg is on-chain: add bridge and MEV risk"],
    "legs": [{"side": "LONG", "venue": "bybit", "kind": "perp", "price": 25.0},
             {"side": "SHORT", "venue": "hyperliquid", "kind": "perp", "price": 25.5}]
  }],
  "errors": []
}
```

## The math, spelled out

**Funding APR** — published rate is per interval, not per day:

```
APR% = rate × (24 / interval_hours) × 365 × 100
```

**Round-trip cost** — both taker fees, slippage on both legs:

```
cost_bps = fee(long) + fee(short) + 2 × slippage_bps
```

**Net carry APR** — the one-time cost is spread over the holding window:

```
cost_apr  = cost_bps / 100 × (365 / holding_days)
net_apr   = funding_apr − cost_apr
daily_usd = capital × funding_apr / 100 / 365
```

**Break-even** — days of funding needed to pay the entry and exit:

```
daily_bps = funding_apr × 100 / 365
breakeven_days = cost_bps / daily_bps
```

**Basis** — signed premium of perp over spot:

```
basis_bps = (perp / spot − 1) × 10 000
net_bps   = basis_bps − cost_bps
```

**Spread dollars** — a basis trade is one turn, so:

```
daily_usd = capital × net_bps / 10 000
```

**Edge (the sortable `score`)** — one number, in bps of capital over the
holding window, so carry and spread rows can share a column without ranking
percent against basis points:

```
CARRY   edge = (basis_bps − cost_bps) + net_apr × holding_days / 365 × 100
SPREAD  edge = net_bps
```

The table labels it **Edge 30d** and the footer repeats the window. Change
`holding_days` and the label follows.

Decimal arithmetic throughout the engine. No floats until JSON serialisation.

## Signals

| Signal | Meaning |
|---|---|
| `CARRY` | net carry APR ≥ `min_net_apr` |
| `SPREAD` | net bps ≥ `min_spread_bps` |
| `WATCH` | real prices, but the edge does not clear your threshold |

`WATCH` rows are kept on purpose. Seeing that the best spread today is 3 bps is
information: it tells you not to trade.

## Telegram alerts

```bash
python3 telegram.py --preview                       # print, send nothing
python3 telegram.py --token 123:ABC --chat-id 42    # send
```

The renderer escapes every dynamic string with `html.escape`, because venue and
symbol names come from third-party APIs. A message that breaks on an `&` is
embarrassing; one that renders injected HTML is worse. There are tests for both
the escaping and the 4096-character limit.

The web desk has **Telegram preview** in the header: it calls `/api/telegram`
and shows exactly what would be sent.

## What this is not

- **Not a bot.** It never signs, never holds keys, never places an order.
- **Not a backtest.** It scores *now*, from quotes collected seconds ago.
- **Not a guarantee.** Funding flips, spreads close, depth vanishes, bridges
  get drained. Every row is a candidate, not a trade.
- **Not financial advice.** You are responsible for your own risk, jurisdiction
  and tax treatment.

## Verification

```bash
python3 verify.py            # 52 checks, readable output
python3 verify.py --json     # machine-readable
python3 -m unittest discover -s tests -v
```

`verify.py` starts a real HTTP server on a random localhost port and exercises
every route, checks the CSV header, confirms secrets are redacted, verifies the
PNG dimensions, and re-derives the engine's arithmetic from first principles.
It makes no network calls, so it passes on a plane.

A note on the numbers in the bundled snapshot: the fixture is synthetic but
shaped exactly like live data. It exists so the UI and tests work offline; it is
not a claim about today's market.

## Troubleshooting

| Symptom | Cause | Fix |
|---|---|---|
| `Address already in use` | port 8787 taken | `python3 server.py --port 8790` |
| every venue errors | VPN/DNS/firewall | check `curl https://api.binance.com/api/v3/ping` |
| HTTP 451 from a venue | regional block | use the venues you can reach; the scan continues |
| all rows `WATCH` | thresholds stricter than the market | lower `min_net_apr`, or accept the answer |
| Hyperliquid APR looks huge | you compared a 1h rate to an 8h one | the engine already normalises; check your own math |
| `config.json` ignored | wrong cwd | set `ARB_CONFIG=/path/to/config.json` |

## Provenance

Written as a standalone product: pure stdlib for the runtime, Pillow only for
the build-time cover. The engine has no imports outside the standard library
and no clock, which is why its tests are deterministic. The fixture is
synthetic. The API shapes were taken from public documentation and pinned in
tests so a schema change fails loudly instead of silently mispricing a trade.

MIT licence (see `LICENSE`): run it, modify it, ship it inside your own desk.
Attribution appreciated, not required.
