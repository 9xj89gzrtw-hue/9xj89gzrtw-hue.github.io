"""Parser tests. Every payload here is a trimmed copy of a real API response
shape, captured once and frozen so the suite never touches the network.
"""

from __future__ import annotations

import sys
import unittest
from decimal import Decimal
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

import engine  # noqa: E402
import exchanges  # noqa: E402

D = Decimal


class BinanceTests(unittest.TestCase):
    def test_spot_and_perp(self):
        prices = [
            {"symbol": "BTCUSDT", "price": "68000.0"},
            {"symbol": "ETHUSDT", "price": "3200.0"},
            {"symbol": "DOGEUSDT", "price": "0.1"},
        ]
        premium = [{"symbol": "BTCUSDT", "markPrice": "68100.0", "lastFundingRate": "0.0001"}]
        quotes = exchanges.parse_binance(prices, premium, ["BTC"])
        self.assertEqual(len(quotes), 2)
        self.assertEqual({q.kind for q in quotes}, {"spot", "perp"})

    def test_filters_other_symbols(self):
        quotes = exchanges.parse_binance(
            [{"symbol": "DOGEUSDT", "price": "0.1"}], [], ["BTC"]
        )
        self.assertEqual(quotes, [])

    def test_non_usdt_pairs_ignored(self):
        quotes = exchanges.parse_binance([{"symbol": "BTCBUSD", "price": "1"}], [], ["BTC"])
        self.assertEqual(quotes, [])

    def test_zero_mark_dropped(self):
        quotes = exchanges.parse_binance(
            [], [{"symbol": "BTCUSDT", "markPrice": "0", "lastFundingRate": "0"}], ["BTC"]
        )
        self.assertEqual(quotes, [])


class BybitTests(unittest.TestCase):
    def test_both_categories(self):
        spot = {"result": {"list": [{"symbol": "BTCUSDT", "lastPrice": "68050"}]}}
        linear = {"result": {"list": [{
            "symbol": "BTCUSDT", "lastPrice": "67980", "fundingRate": "0.00005",
            "turnover24h": "3100000000",
        }]}}
        quotes = exchanges.parse_bybit(spot, linear, ["BTC"])
        self.assertEqual(len(quotes), 2)
        perp = [q for q in quotes if q.is_perp][0]
        self.assertEqual(perp.funding_rate, D("0.00005"))
        self.assertEqual(perp.volume_usd, D("3100000000"))

    def test_missing_envelope(self):
        with self.assertRaises(exchanges.VenueError):
            exchanges.parse_bybit({}, {}, ["BTC"])

    def test_list_not_a_list(self):
        with self.assertRaises(exchanges.VenueError):
            exchanges.parse_bybit({"result": {"list": "nope"}}, {"result": {"list": []}}, ["BTC"])


class HyperliquidTests(unittest.TestCase):
    def test_hourly_interval(self):
        meta = {"universe": [{"name": "BTC"}, {"name": "ETH"}]}
        ctxs = [
            {"markPx": "68120", "funding": "0.0000125", "dayNtlVlm": "1400000000"},
            {"markPx": "3215", "funding": "0.000015"},
        ]
        quotes = exchanges.parse_hyperliquid(meta, ctxs, ["BTC"])
        self.assertEqual(len(quotes), 1)
        self.assertEqual(quotes[0].interval_hours, D(1))
        self.assertAlmostEqual(
            float(engine.funding_apr(quotes[0].funding_rate, quotes[0].interval_hours)),
            10.95,
            places=4,
        )

    def test_case_insensitive_symbol(self):
        meta = {"universe": [{"name": "BTC"}]}
        quotes = exchanges.parse_hyperliquid(meta, [{"markPx": "1", "funding": "0"}], ["btc"])
        self.assertEqual(len(quotes), 1)

    def test_length_mismatch(self):
        with self.assertRaises(exchanges.VenueError):
            exchanges.parse_hyperliquid({"universe": [{"name": "BTC"}]}, [], ["BTC"])

    def test_missing_universe(self):
        with self.assertRaises(exchanges.VenueError):
            exchanges.parse_hyperliquid({}, [], ["BTC"])


class DexScreenerTests(unittest.TestCase):
    def test_deepest_pair_wins(self):
        payload = {"pairs": [
            {"chainId": "ethereum", "priceUsd": "1", "liquidity": {"usd": "10"},
             "baseToken": {"symbol": "HYPE"}},
            {"chainId": "ethereum", "priceUsd": "25.2", "liquidity": {"usd": "19000000"},
             "baseToken": {"symbol": "HYPE"}},
            {"chainId": "bsc", "priceUsd": "99", "liquidity": {"usd": "99999999"},
             "baseToken": {"symbol": "HYPE"}},
        ]}
        quotes = exchanges.parse_dexscreener(payload, "hype")
        self.assertEqual(len(quotes), 1)
        self.assertEqual(quotes[0].price, D("25.2"))
        self.assertEqual(quotes[0].symbol, "HYPE")

    def test_no_pairs(self):
        with self.assertRaises(exchanges.VenueError):
            exchanges.parse_dexscreener({"pairs": []}, "BTC")

    def test_wrong_base_token_is_ignored(self):
        payload = {"pairs": [
            {"chainId": "ethereum", "priceUsd": "0.000047", "liquidity": {"usd": "99999999"},
             "baseToken": {"symbol": "SCAM"}},
            {"chainId": "ethereum", "priceUsd": "25.2", "liquidity": {"usd": "10"},
             "baseToken": {"symbol": "HYPE"}},
        ]}
        self.assertEqual(exchanges.parse_dexscreener(payload, "HYPE")[0].price, D("25.2"))

    def test_bare_list_payload(self):
        payload = [{"chainId": "ethereum", "priceUsd": "2362.38",
                    "liquidity": {"usd": "1"}, "baseToken": {"symbol": "WETH"}}]
        self.assertEqual(exchanges.parse_dexscreener(payload, "ETH")[0].price, D("2362.38"))

    def test_wbtc_answers_as_btc(self):
        payload = {"pairs": [
            {"chainId": "ethereum", "priceUsd": "81000", "liquidity": {"usd": "1"},
             "baseToken": {"symbol": "WBTC"}},
        ]}
        self.assertEqual(exchanges.parse_dexscreener(payload, "BTC")[0].price, D("81000"))

    def test_wrong_chain_only(self):
        payload = {"pairs": [{"chainId": "bsc", "priceUsd": "1", "liquidity": {"usd": "1"},
                              "baseToken": {"symbol": "BTC"}}]}
        with self.assertRaises(exchanges.VenueError):
            exchanges.parse_dexscreener(payload, "BTC", chain="ethereum")

    def test_zero_price_skipped(self):
        payload = {"pairs": [
            {"chainId": "ethereum", "priceUsd": "0", "liquidity": {"usd": "999"},
             "baseToken": {"symbol": "BTC"}},
            {"chainId": "ethereum", "priceUsd": "2", "liquidity": {"usd": "1"},
             "baseToken": {"symbol": "BTC"}},
        ]}
        self.assertEqual(exchanges.parse_dexscreener(payload, "BTC")[0].price, D("2"))


class CollectTests(unittest.TestCase):
    def test_dead_venue_degrades(self):
        original = exchanges.VENUES["binance"]

        def boom(symbols, timeout=8.0):
            raise exchanges.VenueError("binance -> HTTP 451")

        exchanges.VENUES["binance"] = boom
        try:
            result = exchanges.collect(["BTC"], venues=["binance"], include_dex=False)
        finally:
            exchanges.VENUES["binance"] = original
        self.assertEqual(result.quotes, [])
        self.assertTrue(any("451" in e for e in result.errors))

    def test_unknown_venue_is_error(self):
        result = exchanges.collect(["BTC"], venues=["ftx"], include_dex=False)
        self.assertTrue(any("unknown venue" in e for e in result.errors))

    def test_empty_result_is_an_error(self):
        original = exchanges.VENUES["binance"]
        exchanges.VENUES["binance"] = lambda symbols, timeout=8.0: []
        try:
            result = exchanges.collect(["BTC"], venues=["binance"], include_dex=False)
        finally:
            exchanges.VENUES["binance"] = original
        self.assertTrue(any("no matching symbols" in e for e in result.errors))


if __name__ == "__main__":
    unittest.main()
