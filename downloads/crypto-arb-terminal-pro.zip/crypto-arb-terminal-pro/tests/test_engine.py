"""Engine arithmetic. Plain unittest so `python -m unittest discover` works
without installing anything; pytest collects these too.
"""

from __future__ import annotations

import sys
import unittest
from decimal import Decimal
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

import engine  # noqa: E402

D = Decimal


class FundingTests(unittest.TestCase):
    def test_eight_hour_rate(self):
        self.assertEqual(engine.funding_apr("0.0001", 8), D("10.9500"))

    def test_one_hour_rate_is_eight_times_larger(self):
        hourly = engine.funding_apr("0.0000125", 1)
        eight = engine.funding_apr("0.0000125", 8)
        self.assertEqual(hourly, eight * 8)

    def test_zero_interval_is_zero_not_crash(self):
        self.assertEqual(engine.funding_apr("0.001", 0), D(0))

    def test_negative_rate_stays_negative(self):
        self.assertLess(engine.funding_apr("-0.00002", 8), 0)


class BasisTests(unittest.TestCase):
    def test_premium(self):
        self.assertEqual(engine.basis_bps("101", "100"), D("100.00"))

    def test_discount(self):
        self.assertEqual(engine.basis_bps("99", "100"), D("-100.00"))

    def test_zero_spot_is_zero_not_division_error(self):
        self.assertEqual(engine.basis_bps("100", "0"), D(0))


class BreakevenTests(unittest.TestCase):
    def test_days(self):
        self.assertAlmostEqual(float(engine.breakeven_days(D("20"), D("15"))), 2.7375, places=6)

    def test_no_carry_is_none(self):
        self.assertIsNone(engine.breakeven_days(D("0"), D("15")))

    def test_no_cost_is_zero(self):
        self.assertEqual(engine.breakeven_days(D("20"), D("0")), D(0))


class CostTests(unittest.TestCase):
    def setUp(self):
        self.cfg = dict(engine.DEFAULT_CONFIG)

    def test_round_trip_includes_two_slippages(self):
        a = engine.Quote("binance", "spot", "BTC", D("100"))
        b = engine.Quote("bybit", "perp", "BTC", D("100"))
        self.assertEqual(engine._cost_bps(a, b, self.cfg), D("14.5"))

    def test_override_beats_default(self):
        self.cfg["venue_fees_bps"] = {"binance": 1}
        a = engine.Quote("binance", "spot", "BTC", D("100"))
        b = engine.Quote("binance", "perp", "BTC", D("100"))
        self.assertEqual(engine._cost_bps(a, b, self.cfg), D("6.0"))


class CarryTests(unittest.TestCase):
    def _op(self, funding="0.0001", perp_price="68100"):
        perp = engine.Quote("binance", "perp", "BTC", D(perp_price), D(funding), D(8))
        spot = engine.Quote("binance", "spot", "BTC", D("68000"))
        return engine.cash_and_carry(perp, spot, engine.DEFAULT_CONFIG)

    def test_net_apr_subtracts_annualised_cost(self):
        op = self._op()
        expected = 10.95 - 14 / 100 * 365 / 30
        self.assertAlmostEqual(float(op.net_apr), expected, places=6)

    def test_daily_usd_is_capital_times_apr_over_365(self):
        op = self._op()
        self.assertAlmostEqual(float(op.daily_usd), 10000 * 10.95 / 100 / 365, places=6)

    def test_signal(self):
        self.assertEqual(self._op().signal, "CARRY")

    def test_negative_funding_flagged(self):
        op = self._op(funding="-0.00002")
        self.assertTrue(any("negative funding" in n for n in op.notes))

    def test_dex_leg_flagged(self):
        perp = engine.Quote("binance", "perp", "BTC", D("68100"), D("0.0001"), D(8))
        dex = engine.Quote("dex", "dex", "BTC", D("68000"))
        op = engine.cash_and_carry(perp, dex, engine.DEFAULT_CONFIG)
        self.assertTrue(any("smart-contract" in n for n in op.notes))


class SpreadTests(unittest.TestCase):
    def test_net_bps(self):
        lo = engine.Quote("bybit", "perp", "ETH", D("3195"))
        hi = engine.Quote("binance", "perp", "ETH", D("3212"))
        op = engine.cross_spread(lo, hi, engine.DEFAULT_CONFIG)
        self.assertAlmostEqual(float(op.net_bps), (3212 / 3195 - 1) * 10000 - 14.5, places=6)

    def test_signal(self):
        lo = engine.Quote("bybit", "perp", "ETH", D("3195"))
        hi = engine.Quote("binance", "perp", "ETH", D("3212"))
        self.assertEqual(engine.cross_spread(lo, hi, engine.DEFAULT_CONFIG).signal, "SPREAD")

    def test_identical_prices_are_not_offered(self):
        lo = engine.Quote("bybit", "perp", "ETH", D("3200"))
        hi = engine.Quote("binance", "perp", "ETH", D("3200"))
        self.assertLessEqual(engine.cross_spread(lo, hi, engine.DEFAULT_CONFIG).gross_bps, 0)


class ScanTests(unittest.TestCase):
    def setUp(self):
        self.quotes = engine.load_fixture(ROOT / "tests/fixtures/quotes.json")
        self.ops = engine.scan(self.quotes)

    def test_fixture_shape(self):
        self.assertEqual(len(self.quotes), 24)

    def test_no_duplicate_venue_pairs(self):
        keys = [(o.kind, o.symbol, o.long_venue, o.short_venue) for o in self.ops]
        self.assertEqual(len(keys), len(set(keys)))

    def test_sorted_descending(self):
        scores = [o.score for o in self.ops]
        self.assertEqual(scores, sorted(scores, reverse=True))

    def test_has_both_kinds(self):
        self.assertEqual({o.kind for o in self.ops}, {"CARRY", "SPREAD"})

    def test_empty_input(self):
        self.assertEqual(engine.scan([]), [])

    def test_summary_reconciles(self):
        s = engine.summary(self.ops, self.quotes, "fixture", "2026-10-28T00:00:00Z")
        self.assertEqual(s["stats"]["count"], len(self.ops))
        self.assertEqual(s["stats"]["carry"] + s["stats"]["spread"], len(self.ops))
        self.assertEqual(s["quoteCount"], 24)


if __name__ == "__main__":
    unittest.main()
