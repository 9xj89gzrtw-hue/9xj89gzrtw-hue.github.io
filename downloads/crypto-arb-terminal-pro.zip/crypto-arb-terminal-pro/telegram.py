"""Telegram alert rendering and delivery.

Two halves again: `render` is a pure function from a scan payload to a message,
`send` is the one call that touches the network. You can preview exactly what
the bot will say (`python telegram.py --preview`) before giving it a token.

The message is HTML-parse-mode, so every dynamic string is escaped. Opportunity
symbols and venue names come from exchange APIs — untrusted input — and an
unescaped `<` there would simply break the message.
"""

from __future__ import annotations

import argparse
import html
import json
import sys
import urllib.error
import urllib.request
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

import engine

API = "https://api.telegram.org/bot{token}/sendMessage"
MAX_LEN = 3800  # Telegram hard limit is 4096; leave room for the footer.


def _money(value: float) -> str:
    if abs(value) >= 1000:
        return f"${value:,.0f}"
    if abs(value) >= 1:
        return f"${value:,.2f}"
    return f"${value:.4f}"


def render(data: dict, limit: int = 5, bot_name: str = "Arb Terminal") -> str:
    """HTML message: header, top N rows, footer with source and errors."""
    stats = data.get("stats") or {}
    rows = (data.get("opportunities") or [])[: max(0, limit)]
    at = data.get("at") or datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")

    lines = [
        f"<b>{html.escape(bot_name)}</b> · {html.escape(str(at))}",
        (
            f"{stats.get('count', 0)} opportunities · "
            f"{stats.get('signals', 0)} actionable · "
            f"best carry APR {stats.get('bestNetApr', 0):.2f}% · "
            f"best spread {stats.get('bestNetBps', 0):.2f} bps"
        ),
        "",
    ]

    if not rows:
        lines.append("<i>Nothing clears the filters. That is a valid result.</i>")
    for i, row in enumerate(rows, 1):
        kind = html.escape(str(row.get("kind", "?")))
        symbol = html.escape(str(row.get("symbol", "?")))
        long_v = html.escape(str(row.get("longVenue", "?")))
        short_v = html.escape(str(row.get("shortVenue", "?")))
        lines.append(f"<b>{i}. {kind} {symbol}</b> — {html.escape(str(row.get('signal', '')))}")
        long_k = html.escape(str((row.get("legs") or [{}])[0].get("kind", "")))
        short_k = html.escape(str((row.get("legs") or [{}, {}])[1].get("kind", "")))
        lines.append(f"   long {long_v} ({long_k}) @ {_money(float(row.get('longPrice', 0)))}")
        lines.append(f"   short {short_v} ({short_k}) @ {_money(float(row.get('shortPrice', 0)))}")
        if kind == "CARRY":
            lines.append(
                f"   net APR {float(row.get('netApr', 0)):.2f}% · "
                f"{_money(float(row.get('dailyUsd', 0)))}/day · "
                f"breakeven {row.get('breakevenDays')}d"
            )
        else:
            lines.append(
                f"   net {float(row.get('netBps', 0)):.2f} bps · "
                f"{_money(float(row.get('dailyUsd', 0)))} on one turn · "
                f"cost {float(row.get('costBps', 0)):.1f} bps"
            )
        for note in (row.get("notes") or [])[:2]:
            lines.append(f"   <i>{html.escape(str(note))}</i>")
        lines.append("")

    source = html.escape(str(data.get("source", "fixture")))
    venues = ", ".join(html.escape(str(v)) for v in (data.get("venues") or []))
    lines.append(f"source: {source} · venues: {venues or 'none'} · {data.get('quoteCount', 0)} quotes")
    errors = data.get("errors") or []
    if errors:
        lines.append(f"⚠ {len(errors)} venue error(s): {html.escape('; '.join(map(str, errors))[:300])}")
    lines.append("<i>Read-only market data. Not financial advice.</i>")

    text = "\n".join(lines)
    return text[:MAX_LEN]


def send(token: str, chat_id: str, text: str, timeout: float = 10.0) -> dict:
    """POST to the Bot API. Returns Telegram's JSON; raises on transport failure."""
    if not token or ":" not in token:
        raise ValueError("bot token looks wrong (expected 123456:ABC...)")
    payload = json.dumps({
        "chat_id": chat_id,
        "text": text,
        "parse_mode": "HTML",
        "disable_web_page_preview": True,
    }).encode()
    request = urllib.request.Request(
        API.format(token=token),
        data=payload,
        headers={"Content-Type": "application/json", "User-Agent": "crypto-arb-terminal-pro/1.0"},
        method="POST",
    )
    with urllib.request.urlopen(request, timeout=timeout) as response:
        body = json.loads(response.read().decode())
    if not body.get("ok"):
        raise RuntimeError(f"telegram: {body.get('description', 'unknown error')}")
    return body


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="Render or send a Telegram alert")
    parser.add_argument("--fixture", default="tests/fixtures/quotes.json")
    parser.add_argument("--config", default=None)
    parser.add_argument("--limit", type=int, default=5)
    parser.add_argument("--preview", action="store_true", help="print the message, send nothing")
    parser.add_argument("--token", default=None)
    parser.add_argument("--chat-id", default=None)
    args = parser.parse_args(argv)

    config = dict(engine.DEFAULT_CONFIG)
    if args.config:
        config.update(json.loads(Path(args.config).read_text()))
    quotes = engine.load_fixture(args.fixture)
    ops = engine.scan(quotes, config)
    data = engine.summary(
        ops, quotes, source="fixture", at=datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
    )
    text = render(data, limit=args.limit)
    print(text)
    if not args.preview:
        if not args.token or not args.chat_id:
            print("\n(no --token/--chat-id: preview only)", file=sys.stderr)
            return 0
        send(args.token, args.chat_id, text)
        print("\nsent", file=sys.stderr)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
