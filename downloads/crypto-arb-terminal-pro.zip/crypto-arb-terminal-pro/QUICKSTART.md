# Quick start

Python 3.9+. No dependencies. No keys.

```bash
cd crypto-arb-terminal-pro
python3 verify.py        # 52 offline checks, should end "52/52"
python3 server.py        # open http://127.0.0.1:8787
```

You will see 60 scored pairs from the bundled snapshot. Everything works with
the network off.

## Two-minute tour

1. **Sort by Net APR** (click the header twice for descending). The green rows
   are carry trades that clear 8% after fees; blue are cross-venue spreads.
2. **Click a row.** It expands into the two legs, the gross/cost/net breakdown,
   and the risk notes (DEX leg, negative funding, cost above a year of carry).
3. **Type `SOL` in the filter.** The table narrows to one symbol across venues.
4. **Press Telegram preview.** You get the exact alert text, HTML-escaped.
5. **Press CSV.** `opportunities.csv` lands in your downloads folder.

## Go live

```bash
python3 server.py --live
```

or tick **Live data** in the header. The footer shows the source and every venue
warning; a dead venue degrades the scan instead of killing it.

## Make it yours

```bash
cp config.example.json config.json
```

Set `capital_usd` to your real per-leg notional, and `venue_fees_bps` to your
actual taker tier. If you are on VIP-0, the defaults are already close. If you
have a rebate, put the real number in — the point of the tool is that the net
column matches your account.

## Five rules the desk enforces

1. Cost is subtracted, never annualised away.
2. A basis trade is one turn; `netApr` is display-only and labelled as such.
3. Negative funding is a warning, not a carry.
4. A DEX leg adds bridge, MEV and smart-contract risk to the note.
5. Nothing is sent anywhere. The server binds to `127.0.0.1`.

## When nothing is green

That is the normal state. A desk that shows an opportunity every minute is
showing you gross spreads. Lower `min_spread_bps` if you want to see near-misses
labelled `WATCH` — but the default is deliberately honest.
