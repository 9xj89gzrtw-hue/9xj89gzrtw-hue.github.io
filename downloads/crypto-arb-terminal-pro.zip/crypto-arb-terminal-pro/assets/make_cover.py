#!/usr/bin/env python3
"""Generate assets/cover.png — the 2400x1600 product cover.

Reproducible: same input, same pixels. Only Pillow is required, and only to
build the cover; the product itself is stdlib-only.

    python3 assets/make_cover.py

The numbers drawn on the card are read from the fixture through the engine, so
the cover cannot drift away from what the software actually reports.
"""

from __future__ import annotations

import sys
from pathlib import Path

from PIL import Image, ImageDraw, ImageFilter, ImageFont

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))
import engine  # noqa: E402

W, H = 2400, 1600
OUT = ROOT / "assets" / "cover.png"

BG_TOP = (7, 10, 15)
BG_BOT = (11, 19, 29)
INK = (230, 237, 246)
DIM = (124, 139, 161)
FAINT = (72, 86, 105)
LINE = (30, 40, 54)
GREEN = (46, 230, 168)
BLUE = (90, 169, 255)
AMBER = (255, 179, 71)

FONT_DIRS = [
    Path("/System/Library/Fonts/Supplemental"),
    Path("/System/Library/Fonts"),
    Path("/Library/Fonts"),
]


def font(names: list[str], size: int) -> ImageFont.FreeTypeFont:
    for directory in FONT_DIRS:
        for name in names:
            path = directory / name
            if path.exists():
                try:
                    return ImageFont.truetype(str(path), size)
                except OSError:
                    continue
    return ImageFont.load_default(size)


def sans(size: int, bold: bool = False) -> ImageFont.FreeTypeFont:
    names = ["Arial Bold.ttf", "Arial.ttf"] if bold else ["Arial.ttf"]
    return font(names, size)


def mono(size: int) -> ImageFont.FreeTypeFont:
    return font(["Menlo.ttc", "SFNSMono.ttf", "Courier New.ttf"], size)


def gradient() -> Image.Image:
    """Vertical gradient built from a 1px column, then stretched.

    A per-pixel Python loop over 3.8M pixels takes seconds; resizing a 1×H
    strip is instant and produces the same result.
    """
    base = Image.new("RGB", (1, H))
    px = base.load()
    top, bottom = BG_TOP, BG_BOT
    for y in range(H):
        t = (y / (H - 1)) ** 0.85
        px[0, y] = tuple(int(top[i] + (bottom[i] - top[i]) * t) for i in range(3))
    return base.resize((W, H), Image.BILINEAR)


def glow(canvas: Image.Image, center: tuple[int, int], radius: int, color: tuple[int, int, int], alpha: int) -> None:
    layer = Image.new("RGBA", (W, H), (0, 0, 0, 0))
    d = ImageDraw.Draw(layer)
    steps = 26
    for i in range(steps, 0, -1):
        r = int(radius * i / steps)
        a = int(alpha * (1 - i / steps) ** 1.6)
        d.ellipse((center[0] - r, center[1] - r, center[0] + r, center[1] + r), fill=color + (a,))
    layer = layer.filter(ImageFilter.GaussianBlur(60))
    canvas.alpha_composite(layer)


def grid(draw: ImageDraw.ImageDraw) -> None:
    step = 80
    for x in range(0, W, step):
        draw.line([(x, 0), (x, H)], fill=(255, 255, 255, 7), width=1)
    for y in range(0, H, step):
        draw.line([(0, y), (W, y)], fill=(255, 255, 255, 7), width=1)


def text(draw, x, y, s, f, fill, anchor=None):
    draw.text((x, y), s, font=f, fill=fill, anchor=anchor)


def rounded(draw, box, radius, fill=None, outline=None, width=1):
    draw.rounded_rectangle(box, radius=radius, fill=fill, outline=outline, width=width)


def logo(draw, x, y, scale=1.0) -> None:
    s = scale
    rounded(draw, (x, y, x + int(76 * s), y + int(76 * s)), int(20 * s), fill=(17, 25, 36), outline=(42, 58, 78), width=2)
    pts = [
        (x + int(16 * s), y + int(52 * s)),
        (x + int(30 * s), y + int(22 * s)),
        (x + int(42 * s), y + int(44 * s)),
        (x + int(51 * s), y + int(34 * s)),
        (x + int(61 * s), y + int(56 * s)),
    ]
    draw.line(pts, fill=GREEN, width=int(4 * s), joint="curve")
    r = int(5 * s)
    cx, cy = x + int(60 * s), y + int(18 * s)
    draw.ellipse((cx - r, cy - r, cx + r, cy + r), fill=BLUE)


def chip(draw, x, y, label, fg, bg, f) -> int:
    w = draw.textlength(label, font=f)
    pad_x, h = 22, 46
    rounded(draw, (x, y, x + w + pad_x * 2, y + h), 23, fill=bg, outline=fg + (70,) if len(fg) == 3 else fg, width=1)
    text(draw, x + pad_x, y + h // 2, label, f, fg, anchor="lm")
    return int(w + pad_x * 2)


def main() -> int:
    quotes = engine.load_fixture(ROOT / "tests" / "fixtures" / "quotes.json")
    ops = engine.scan(quotes)
    rows = [o for o in ops if o.kind == "SPREAD"][:6]

    canvas = gradient().convert("RGBA")
    glow(canvas, (1850, 240), 700, (28, 78, 122), 120)
    glow(canvas, (300, 1350), 620, (18, 92, 74), 90)

    overlay = Image.new("RGBA", (W, H), (0, 0, 0, 0))
    d = ImageDraw.Draw(overlay)
    grid(d)
    canvas.alpha_composite(overlay)
    draw = ImageDraw.Draw(canvas)

    # ---- header -----------------------------------------------------------
    logo(draw, 120, 108, 1.0)
    text(draw, 218, 118, "ARB TERMINAL", sans(34, bold=True), INK)
    text(draw, 219, 160, "FUNDING  ·  BASIS  ·  CARRY", mono(19), DIM)

    pill_f = mono(20)
    chip(draw, W - 120 - 330, 118, "v1.0.0  ·  READ-ONLY", GREEN, (17, 40, 34), pill_f)

    # ---- headline ---------------------------------------------------------
    text(draw, 120, 318, "Two prices.", sans(104, bold=True), INK)
    text(draw, 120, 434, "One honest number.", sans(100, bold=True), (150, 178, 208))
    text(
        draw, 124, 606,
        "Funding carry and cross-venue basis, net of fees and slippage —",
        sans(35), DIM,
    )
    text(draw, 124, 654, "in a local terminal with no keys and no orders.", sans(35), DIM)

    # ---- feature list -----------------------------------------------------
    feats = [
        ("CARRY", "long spot / DEX, short the perp, collect funding"),
        ("SPREAD", "long the cheap venue, short the rich one"),
        ("HONEST", "cost, break-even days and per-turn dollars, shown"),
        ("LOCAL", "stdlib Python, binds to 127.0.0.1, zero telemetry"),
    ]
    y = 800
    for tag, desc in feats:
        color = GREEN if tag in ("CARRY", "SPREAD") else BLUE
        draw.ellipse((124, y + 10, 140, y + 26), fill=color + (255,))
        text(draw, 160, y, tag, mono(25), color)
        text(draw, 300, y - 2, desc, sans(29), (196, 210, 226))
        y += 62

    # ---- metrics ----------------------------------------------------------
    stats = [
        (str(len(ops)), "pairs scored"),
        (f"{max(float(o.net_apr) for o in ops if o.kind == 'CARRY'):.1f}%", "best net carry"),
        (str(len(quotes)), "quotes compared"),
    ]
    for x, (value, label) in zip((122, 360, 740), stats):
        text(draw, x, 1086, value, sans(70, bold=True), INK)
        text(draw, x, 1172, label.upper(), mono(18), FAINT)

    # ---- card -------------------------------------------------------------
    card = (1180, 300, 2280, 1360)
    rounded(draw, card, 26, fill=(13, 19, 27, 235), outline=LINE, width=2)

    # card header
    draw.ellipse((1218, 336, 1232, 350), fill=GREEN)
    text(draw, 1244, 330, "opportunities", mono(22), DIM)
    text(draw, 2240, 330, "sorted by net edge", mono(20), FAINT, anchor="ra")
    draw.line([(1208, 378), (2252, 378)], fill=LINE, width=1)

    headers = [("TYPE", 1218), ("PAIR", 1380), ("LONG", 1520), ("SHORT", 1700), ("NET BPS", 2240)]
    for label, hx in headers:
        anchor = "ra" if label == "NET BPS" else "la"
        text(draw, hx, 404, label, mono(19), FAINT, anchor=anchor)
    draw.line([(1208, 442), (2252, 442)], fill=(24, 33, 45), width=1)

    row_y = 474
    for i, op in enumerate(rows):
        if i % 2 == 1:
            rounded(draw, (1200, row_y - 16, 2260, row_y + 66), 10, fill=(16, 23, 32))
        tag_bg = (16, 38, 33) if op.kind == "CARRY" else (16, 30, 48)
        tag_fg = GREEN if op.kind == "CARRY" else BLUE
        rounded(draw, (1218, row_y - 4, 1322, row_y + 34), 7, fill=tag_bg)
        text(draw, 1232, row_y + 1, op.kind, mono(19), tag_fg)

        text(draw, 1380, row_y, op.symbol, sans(30, bold=True), INK)
        text(draw, 1520, row_y + 2, op.long_venue, mono(22), (170, 188, 208))
        text(draw, 1700, row_y + 2, op.short_venue, mono(22), (170, 188, 208))

        net = float(op.net_bps)
        text(draw, 2240, row_y + 1, f"{net:+.1f}", mono(27), GREEN if net > 0 else (255, 93, 108), anchor="ra")

        # edge bar, right-aligned and capped so it never touches a venue name
        width = int(min(1.0, abs(net) / 190.0) * 96)
        bar_x = 2085 - width
        rounded(draw, (bar_x, row_y + 20, 2085, row_y + 26), 3, fill=(34, 48, 66))
        rounded(draw, (bar_x, row_y + 20, bar_x + max(6, width), row_y + 26), 3, fill=tag_fg)
        row_y += 108

    # card footer summary
    draw.line([(1208, 1190), (2252, 1190)], fill=LINE, width=1)
    text(draw, 1218, 1216, "cost model", mono(20), FAINT)
    text(draw, 2240, 1216, "taker fees + 2 bps slippage / leg", mono(20), (150, 168, 188), anchor="ra")

    text(draw, 1218, 1262, "fixture scan", sans(31, bold=True), INK)
    text(draw, 2240, 1268, "python3 server.py --live", mono(21), GREEN, anchor="ra")

    # ---- footer -----------------------------------------------------------
    draw.line([(120, 1452), (2280, 1452)], fill=(26, 35, 47), width=1)
    text(draw, 120, 1492, "crypto-arb-terminal-pro", sans(27, bold=True), (168, 186, 206))
    text(
        draw, 120, 1532,
        "2400 × 1600  ·  Python 3.9+  ·  no dependencies  ·  no API keys  ·  not financial advice",
        mono(19), FAINT,
    )
    text(draw, 2280, 1500, "40+ self-checks", mono(21), DIM, anchor="ra")
    text(draw, 2280, 1536, "verify.py --json", mono(19), FAINT, anchor="ra")

    canvas.convert("RGB").save(OUT, "PNG", optimize=True)
    print(f"wrote {OUT} ({OUT.stat().st_size // 1024} KiB)")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
