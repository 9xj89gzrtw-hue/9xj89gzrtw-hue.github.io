"""Live quote collection from public exchange APIs.

Design rule: **parsing is pure**. Every `parse_*` function takes the decoded
JSON body and returns `engine.Quote` objects. The `fetch_*` functions do the
network call and nothing else. That split means the whole product can be
verified offline, and a venue changing its schema produces a readable error
instead of a silent wrong price.

No API keys. No private endpoints. No order placement. Read-only market data.
"""

from __future__ import annotations

import json
import socket
import time
import urllib.error
import urllib.request
from dataclasses import dataclass, field
from decimal import Decimal
from typing import Any, Callable

import engine
from engine import D, Quote

USER_AGENT = "crypto-arb-terminal-pro/1.0 (+read-only; contact: local)"
TIMEOUT = 8.0
RETRIES = 2


class VenueError(RuntimeError):
    """A venue was unreachable or returned a payload we refuse to guess at."""


@dataclass
class FetchResult:
    quotes: list[Quote] = field(default_factory=list)
    errors: list[str] = field(default_factory=list)
    latencies: dict[str, int] = field(default_factory=dict)

    def merge(self, other: "FetchResult") -> "FetchResult":
        self.quotes.extend(other.quotes)
        self.errors.extend(other.errors)
        self.latencies.update(other.latencies)
        return self


# --------------------------------------------------------------------------
# transport
# --------------------------------------------------------------------------


def http_json(
    url: str,
    payload: dict | None = None,
    timeout: float = TIMEOUT,
    retries: int = RETRIES,
    opener: Callable[..., Any] | None = None,
) -> Any:
    """GET (or POST when `payload` is given) and decode JSON, with retries.

    Retries only on transport errors and 5xx. A 4xx is a permanent answer and
    retrying it just burns the user's rate limit.
    """
    body = None if payload is None else json.dumps(payload).encode()
    headers = {"User-Agent": USER_AGENT, "Accept": "application/json"}
    if body is not None:
        headers["Content-Type"] = "application/json"

    last: Exception | None = None
    for attempt in range(retries + 1):
        request = urllib.request.Request(url, data=body, headers=headers)
        try:
            open_fn = opener or urllib.request.urlopen
            with open_fn(request, timeout=timeout) as response:
                raw = response.read()
            return json.loads(raw.decode("utf-8"))
        except urllib.error.HTTPError as exc:
            last = exc
            if 400 <= exc.code < 500:
                raise VenueError(f"{url} -> HTTP {exc.code}") from exc
        except (urllib.error.URLError, socket.timeout, TimeoutError, ValueError) as exc:
            last = exc
        if attempt < retries:
            time.sleep(0.4 * (attempt + 1))
    raise VenueError(f"{url} -> {type(last).__name__}: {last}")


# --------------------------------------------------------------------------
# Binance
# --------------------------------------------------------------------------


def parse_binance(prices: list[dict], premium: list[dict], symbols: list[str]) -> list[Quote]:
    """Spot price from /api/v3/ticker/price, funding from /fapi/v1/premiumIndex."""
    wanted = {s.upper() for s in symbols}
    spot: dict[str, Decimal] = {}
    for row in prices:
        pair = str(row.get("symbol", ""))
        if not pair.endswith("USDT"):
            continue
        base = pair[:-4]
        if base in wanted:
            spot[base] = engine.dec(row.get("price"))

    out: list[Quote] = []
    for base, price in spot.items():
        if price > 0:
            out.append(
                Quote(
                    venue="binance",
                    kind="spot",
                    symbol=base,
                    price=price,
                    fee_bps=engine.VENUE_FEES_BPS["binance"],
                )
            )

    for row in premium:
        pair = str(row.get("symbol", ""))
        if not pair.endswith("USDT"):
            continue
        base = pair[:-4]
        if base not in wanted:
            continue
        mark = engine.dec(row.get("markPrice") or row.get("indexPrice"))
        rate = engine.dec(row.get("lastFundingRate"))
        if mark <= 0:
            continue
        out.append(
            Quote(
                venue="binance",
                kind="perp",
                symbol=base,
                price=mark,
                funding_rate=rate,
                interval_hours=D(8),
                fee_bps=engine.VENUE_FEES_BPS["binance"],
            )
        )
    return out


def fetch_binance(symbols: list[str], timeout: float = TIMEOUT) -> list[Quote]:
    prices = http_json("https://api.binance.com/api/v3/ticker/price", timeout=timeout)
    premium = http_json("https://fapi.binance.com/fapi/v1/premiumIndex", timeout=timeout)
    if not isinstance(prices, list) or not isinstance(premium, list):
        raise VenueError("binance: unexpected payload shape")
    return parse_binance(prices, premium, symbols)


# --------------------------------------------------------------------------
# Bybit
# --------------------------------------------------------------------------


def parse_bybit(spot_payload: dict, linear_payload: dict, symbols: list[str]) -> list[Quote]:
    """v5 market/tickers for both categories. `fundingRate` is per 8h."""
    wanted = {s.upper() for s in symbols}

    def rows(payload: dict, label: str) -> list[dict]:
        try:
            data = payload["result"]["list"]
        except (KeyError, TypeError) as exc:
            raise VenueError(f"bybit {label}: missing result.list") from exc
        if not isinstance(data, list):
            raise VenueError(f"bybit {label}: result.list is not a list")
        return data

    out: list[Quote] = []
    for row in rows(spot_payload, "spot"):
        pair = str(row.get("symbol", ""))
        if not pair.endswith("USDT"):
            continue
        base = pair[:-4]
        price = engine.dec(row.get("lastPrice"))
        if base in wanted and price > 0:
            out.append(
                Quote(
                    venue="bybit",
                    kind="spot",
                    symbol=base,
                    price=price,
                    fee_bps=engine.VENUE_FEES_BPS["bybit"],
                )
            )

    for row in rows(linear_payload, "linear"):
        pair = str(row.get("symbol", ""))
        if not pair.endswith("USDT"):
            continue
        base = pair[:-4]
        price = engine.dec(row.get("lastPrice") or row.get("markPrice"))
        if base in wanted and price > 0:
            out.append(
                Quote(
                    venue="bybit",
                    kind="perp",
                    symbol=base,
                    price=price,
                    funding_rate=engine.dec(row.get("fundingRate")),
                    interval_hours=D(8),
                    fee_bps=engine.VENUE_FEES_BPS["bybit"],
                    volume_usd=engine.dec(row.get("turnover24h")),
                )
            )
    return out


def fetch_bybit(symbols: list[str], timeout: float = TIMEOUT) -> list[Quote]:
    spot = http_json("https://api.bybit.com/v5/market/tickers?category=spot", timeout=timeout)
    linear = http_json("https://api.bybit.com/v5/market/tickers?category=linear", timeout=timeout)
    return parse_bybit(spot, linear, symbols)


# --------------------------------------------------------------------------
# Hyperliquid
# --------------------------------------------------------------------------


def parse_hyperliquid(meta: dict, contexts: list[dict], symbols: list[str]) -> list[Quote]:
    """`metaAndAssetCtxs` returns [meta, ctxs] with parallel `universe` arrays.

    Hyperliquid funding is **hourly**: the published rate is already the
    1-hour rate, so treating it as 8-hour would overstate APR by 8x. This is
    the single most common error in Hyperliquid carry calculators.
    """
    wanted = {s.upper() for s in symbols}
    try:
        universe = meta["universe"]
    except (KeyError, TypeError) as exc:
        raise VenueError("hyperliquid: missing universe") from exc
    if len(universe) != len(contexts):
        raise VenueError("hyperliquid: universe/ctx length mismatch")

    out: list[Quote] = []
    for asset, ctx in zip(universe, contexts):
        name = str(asset.get("name", "")).upper()
        if name not in wanted:
            continue
        price = engine.dec(ctx.get("markPx") or ctx.get("oraclePx"))
        if price <= 0:
            continue
        out.append(
            Quote(
                venue="hyperliquid",
                kind="perp",
                symbol=name,
                price=price,
                funding_rate=engine.dec(ctx.get("funding")),
                interval_hours=D(1),
                fee_bps=engine.VENUE_FEES_BPS["hyperliquid"],
                volume_usd=engine.dec(ctx.get("dayNtlVlm")),
            )
        )
    return out


def fetch_hyperliquid(symbols: list[str], timeout: float = TIMEOUT) -> list[Quote]:
    payload = http_json(
        "https://api.hyperliquid.xyz/info",
        payload={"type": "metaAndAssetCtxs"},
        timeout=timeout,
    )
    if not isinstance(payload, list) or len(payload) != 2:
        raise VenueError("hyperliquid: expected [meta, ctxs]")
    return parse_hyperliquid(payload[0], payload[1], symbols)


# --------------------------------------------------------------------------
# DexScreener
# --------------------------------------------------------------------------

DEX_TOKENS = {
    # Token contracts the scanner can price on-chain. A symbol alone is not
    # enough: DexScreener's search endpoint happily returns a *different*
    # token with a similar name, and a DEX leg priced off the wrong asset is
    # worse than no leg at all. Addresses are the identity.
    "ethereum": {
        "ETH": "0xC02aaA39b223FE8D0A0e5C4F27eAD9083C756Cc2",   # WETH
        "BTC": "0x2260FAC5E5542a773Aa44fBCfeDf7C193bc2C599",   # WBTC
        "WBTC": "0x2260FAC5E5542a773Aa44fBCfeDf7C193bc2C599",
        "USDC": "0xA0b86991c6218b36c1d19D4a2e9Eb0cE3606eB48",
        "DAI": "0x6B175474E89094C44Da98b954EedeAC495271d0F",
    },
    "base": {
        "ETH": "0x4200000000000000000000000000000000000006",   # WETH on Base
        "USDC": "0x833589fCD6eDb6E08f4c7C32D4f71b54bdA02913",
    },
}

# A pair whose base is WBTC still answers the question "what is BTC worth here".
DEX_ALIASES = {"BTC": {"WBTC", "CBBTC"}, "ETH": {"WETH", "STETH", "WSTETH"}}


def parse_dexscreener(payload: dict, symbol: str, chain: str = "ethereum") -> list[Quote]:
    """Pick the deepest pair **whose base token is the requested asset**.

    `pairs` from the token-pairs endpoint are all the same base token by
    construction, but the filter stays here because it is the difference
    between a price and a random number if the payload ever changes shape.
    """
    # /token-pairs/v1 returns a bare list; /latest/dex/search wraps it in
    # {"pairs": [...]}. Accept both so the parser survives either route.
    pairs = payload if isinstance(payload, list) else (payload.get("pairs") or [])
    if not isinstance(pairs, list) or not pairs:
        raise VenueError(f"dexscreener: no pairs for {symbol} on {chain}")

    wanted = {symbol.upper()} | DEX_ALIASES.get(symbol.upper(), set())
    best = None
    best_liquidity = D(-1)
    for pair in pairs:
        if str(pair.get("chainId", "")).lower() != chain.lower():
            continue
        base = str((pair.get("baseToken") or {}).get("symbol", "")).upper()
        if base and base not in wanted:
            continue
        price = engine.dec(pair.get("priceUsd"))
        if price <= 0:
            continue
        liquidity = engine.dec((pair.get("liquidity") or {}).get("usd"))
        if liquidity > best_liquidity:
            best, best_liquidity = pair, liquidity
    if best is None:
        raise VenueError(f"dexscreener: no {chain} pair for {symbol}")

    return [
        Quote(
            venue="dex",
            kind="dex",
            symbol=symbol.upper(),
            price=engine.dec(best.get("priceUsd")),
            fee_bps=engine.VENUE_FEES_BPS["dex"],
            volume_usd=engine.dec(((best.get("volume") or {}).get("h24"))),
        )
    ]


def fetch_dexscreener(symbol: str, chain: str = "ethereum", timeout: float = TIMEOUT) -> list[Quote]:
    """Price one asset from its canonical on-chain pool. Empty when unroutable.

    SOL and HYPE do not have a canonical Ethereum pool, so they simply have no
    DEX leg. That is a fact about the asset, not an error worth shouting about.
    """
    address = DEX_TOKENS.get(chain.lower(), {}).get(symbol.upper())
    if not address:
        return []
    url = f"https://api.dexscreener.com/token-pairs/v1/{chain.lower()}/{address}"
    payload = http_json(url, timeout=timeout)
    if not isinstance(payload, (dict, list)):
        raise VenueError("dexscreener: unexpected payload")
    return parse_dexscreener(payload, symbol, chain)


# --------------------------------------------------------------------------
# orchestration
# --------------------------------------------------------------------------

VENUES = {
    "binance": fetch_binance,
    "bybit": fetch_bybit,
    "hyperliquid": fetch_hyperliquid,
}


def collect(
    symbols: list[str],
    venues: list[str] | None = None,
    include_dex: bool = True,
    dex_chain: str = "ethereum",
    timeout: float = TIMEOUT,
) -> FetchResult:
    """Fetch every venue, keep going when one fails.

    A partial scan with an explicit error list is more useful than no scan.
    The caller surfaces `errors` in the UI footer so the operator knows
    exactly which venue is missing from the comparison.
    """
    result = FetchResult()
    for name in venues or list(VENUES):
        fn = VENUES.get(name)
        if fn is None:
            result.errors.append(f"{name}: unknown venue")
            continue
        started = time.monotonic()
        try:
            quotes = fn(symbols, timeout=timeout)
            result.quotes.extend(quotes)
            result.latencies[name] = int((time.monotonic() - started) * 1000)
            if not quotes:
                result.errors.append(f"{name}: returned no matching symbols")
        except VenueError as exc:
            result.errors.append(str(exc))
        except Exception as exc:  # defensive: one venue must never kill a scan
            result.errors.append(f"{name}: {type(exc).__name__}: {exc}")

    if include_dex:
        for symbol in symbols:
            started = time.monotonic()
            try:
                quotes = fetch_dexscreener(symbol, chain=dex_chain, timeout=timeout)
                result.quotes.extend(quotes)
                result.latencies.setdefault("dex", 0)
                result.latencies["dex"] = max(
                    result.latencies["dex"], int((time.monotonic() - started) * 1000)
                )
            except VenueError as exc:
                result.errors.append(str(exc))
            except Exception as exc:
                result.errors.append(f"dex/{symbol}: {type(exc).__name__}: {exc}")
    return result
