"""Arbitrage and funding analytics. Pure stdlib, no network, no clock.

Every number the terminal shows is produced here, from quotes that `exchanges.py`
collected. Keeping the math separate is what makes the product testable: the
fixtures in `tests/fixtures/` are the same shape as live data, and `verify.py`
asserts the arithmetic without touching an exchange.

Two strategies:

  CARRY   long spot / DEX, short the perp. You earn the perp's funding while the
          position is delta-neutral. Net APR subtracts the round-trip cost,
          annualised over the holding period.
  SPREAD  long the cheaper venue, short the richer one. The edge is the price
          difference, not funding. Reported as net basis points and net dollars,
          because annualising a one-shot basis trade is how bad products lie.

Both kinds expose one comparable `score`: net basis points on capital if the
trade is opened now and held for `holding_days`. For CARRY that is the entry
basis plus the funding earned over the window; for SPREAD it is the converged
basis. Mixing percent APR and basis points in one sortable column would rank
apples against oranges, which is exactly the dishonesty this tool avoids.

Sign conventions: funding is the rate per interval, as published. A positive
rate means longs pay shorts, so the short perp leg receives it.
"""

from __future__ import annotations

import json
from dataclasses import dataclass, field
from decimal import Decimal, InvalidOperation
from pathlib import Path

D = Decimal
ZERO = D(0)
BPS = D(10_000)


DEFAULT_CONFIG = {
    "capital_usd": 10_000,
    "min_net_apr": 8.0,
    "min_spread_bps": 6.0,
    "holding_days": 30,
    "taker_fee_bps": 5.5,
    "slippage_bps": 2.0,
    "symbols": ["BTC", "ETH", "SOL", "HYPE"],
}

VENUE_FEES_BPS = {
    # Public taker schedules, rounded up. The user can override every one of
    # these in config.json; the defaults are a starting point, not a promise.
    "binance": D("5.0"),
    "bybit": D("5.5"),
    "hyperliquid": D("4.5"),
    "uniswap-v3": D("5.0"),
    "dex": D("5.0"),
}


def dec(value, default: str = "0") -> Decimal:
    try:
        if value is None:
            return D(default)
        return D(str(value))
    except (InvalidOperation, ValueError):
        return D(default)


def funding_apr(rate, interval_hours) -> Decimal:
    """Percent per year. `rate` is per interval, not per day."""
    per_interval = dec(rate)
    hours = dec(interval_hours)
    if hours <= 0:
        return ZERO
    return per_interval * (D(24) / hours) * D(365) * D(100)


def basis_bps(perp_price, spot_price) -> Decimal:
    perp, spot = dec(perp_price), dec(spot_price)
    if spot <= 0:
        return ZERO
    return (perp / spot - 1) * BPS


def breakeven_days(gross_apr: Decimal, cost_bps: Decimal) -> Decimal | None:
    """Days of carry needed to pay the one-time cost. None when there is no carry."""
    if gross_apr <= 0 or cost_bps <= 0:
        return D(0) if cost_bps <= 0 else None
    daily_bps = gross_apr * D(100) / D(365)
    if daily_bps <= 0:
        return None
    return cost_bps / daily_bps


@dataclass(frozen=True)
class Quote:
    venue: str
    kind: str  # spot | perp | dex
    symbol: str
    price: Decimal
    funding_rate: Decimal = ZERO
    interval_hours: Decimal = D(8)
    fee_bps: Decimal = D("5")
    volume_usd: Decimal = ZERO

    @property
    def is_perp(self) -> bool:
        return self.kind == "perp"

    def as_dict(self) -> dict:
        return {
            "venue": self.venue,
            "kind": self.kind,
            "symbol": self.symbol,
            "price": float(self.price),
            "fundingRate": float(self.funding_rate),
            "intervalHours": float(self.interval_hours),
            "feeBps": float(self.fee_bps),
            "volumeUsd": float(self.volume_usd),
            "fundingApr": float(funding_apr(self.funding_rate, self.interval_hours)),
        }


@dataclass
class Opportunity:
    kind: str
    symbol: str
    long_venue: str
    short_venue: str
    long_price: Decimal
    short_price: Decimal
    gross_bps: Decimal
    cost_bps: Decimal
    net_bps: Decimal
    gross_apr: Decimal
    net_apr: Decimal
    daily_usd: Decimal
    breakeven_days: Decimal | None
    score: Decimal
    signal: str
    long_kind: str = "spot"
    short_kind: str = "perp"
    notes: list[str] = field(default_factory=list)

    def as_dict(self) -> dict:
        return {
            "kind": self.kind,
            "symbol": self.symbol,
            "longVenue": self.long_venue,
            "shortVenue": self.short_venue,
            "longPrice": float(self.long_price),
            "shortPrice": float(self.short_price),
            "grossBps": round(float(self.gross_bps), 3),
            "costBps": round(float(self.cost_bps), 3),
            "netBps": round(float(self.net_bps), 3),
            "grossApr": round(float(self.gross_apr), 3),
            "netApr": round(float(self.net_apr), 3),
            "dailyUsd": round(float(self.daily_usd), 2),
            "breakevenDays": None if self.breakeven_days is None else round(float(self.breakeven_days), 2),
            "score": round(float(self.score), 3),
            "signal": self.signal,
            "notes": self.notes,
            "legs": [
                {"side": "LONG", "venue": self.long_venue, "kind": self.long_kind,
                 "price": float(self.long_price)},
                {"side": "SHORT", "venue": self.short_venue, "kind": self.short_kind,
                 "price": float(self.short_price)},
            ],
        }


def fee_for(venue: str, config: dict) -> Decimal:
    override = (config.get("venue_fees_bps") or {}).get(venue)
    return dec(override) if override is not None else VENUE_FEES_BPS.get(venue, dec(config.get("taker_fee_bps", 5.5)))


def _cost_bps(long_q: Quote, short_q: Quote, config: dict) -> Decimal:
    slip = dec(config.get("slippage_bps", 2))
    return fee_for(long_q.venue, config) + fee_for(short_q.venue, config) + slip * 2


def cash_and_carry(perp: Quote, spot: Quote, config: dict) -> Opportunity:
    capital = dec(config.get("capital_usd", 10_000))
    holding = max(dec(config.get("holding_days", 30)), D(1))
    gross_apr = funding_apr(perp.funding_rate, perp.interval_hours)
    basis = basis_bps(perp.price, spot.price)
    cost = _cost_bps(spot, perp, config)
    # A one-time cost spread over the holding period, in APR points.
    cost_apr = cost / D(100) * (D(365) / holding)
    net_apr = gross_apr - cost_apr
    daily = capital * gross_apr / D(100) / D(365)
    be = breakeven_days(gross_apr, cost)
    # Comparable across kinds: entry basis + funding over the holding window.
    score = (basis - cost) + net_apr * holding / D(365) * D(100)
    signal = "CARRY" if net_apr >= dec(config.get("min_net_apr", 8)) else "WATCH"
    notes = []
    if gross_apr <= 0:
        notes.append("negative funding: the short perp pays, not receives")
    if perp.funding_rate > 0 and spot.kind == "dex":
        notes.append("DEX leg adds smart-contract and MEV risk")
    if cost > gross_apr:
        notes.append("round-trip cost exceeds a full year of carry")
    return Opportunity(
        kind="CARRY",
        symbol=perp.symbol,
        long_venue=spot.venue,
        short_venue=perp.venue,
        long_price=spot.price,
        short_price=perp.price,
        gross_bps=basis,
        cost_bps=cost,
        net_bps=basis - cost,
        gross_apr=gross_apr,
        net_apr=net_apr,
        daily_usd=daily,
        breakeven_days=be,
        score=score,
        signal=signal,
        long_kind=spot.kind,
        short_kind=perp.kind,
        notes=notes,
    )


def cross_spread(long_q: Quote, short_q: Quote, config: dict) -> Opportunity:
    capital = dec(config.get("capital_usd", 10_000))
    gross = (dec(short_q.price) / dec(long_q.price) - 1) * BPS if long_q.price > 0 else ZERO
    cost = _cost_bps(long_q, short_q, config)
    net = gross - cost
    holding = max(dec(config.get("holding_days", 30)), D(1))
    # Display-only annualisation, clearly labelled in the UI as "if repeated".
    net_apr = net / D(100) * (D(365) / holding)
    signal = "SPREAD" if net >= dec(config.get("min_spread_bps", 6)) else "WATCH"
    notes = []
    if long_q.kind == "dex" or short_q.kind == "dex":
        notes.append("one leg is on-chain: add bridge and MEV risk")
    if gross <= 0:
        notes.append("prices crossed: the 'long' venue is not cheaper")
    return Opportunity(
        kind="SPREAD",
        symbol=long_q.symbol,
        long_venue=long_q.venue,
        short_venue=short_q.venue,
        long_price=long_q.price,
        short_price=short_q.price,
        gross_bps=gross,
        cost_bps=cost,
        net_bps=net,
        gross_apr=ZERO,
        net_apr=net_apr,
        daily_usd=capital * net / BPS,
        breakeven_days=D(0),
        score=net,
        signal=signal,
        long_kind=long_q.kind,
        short_kind=short_q.kind,
        notes=notes,
    )


def scan(quotes: list[Quote], config: dict | None = None) -> list[Opportunity]:
    """Every pair worth looking at, best first.

    CARRY is perp-vs-spot/DEX for the same symbol. SPREAD is perp-vs-perp across
    venues (and perp-vs-DEX, which is the same trade with a longer settlement).
    """
    cfg = {**DEFAULT_CONFIG, **(config or {})}
    by_symbol: dict[str, list[Quote]] = {}
    for q in quotes:
        by_symbol.setdefault(q.symbol.upper(), []).append(q)

    out: list[Opportunity] = []
    for symbol, rows in by_symbol.items():
        perps = [q for q in rows if q.kind == "perp"]
        spots = [q for q in rows if q.kind in ("spot", "dex")]
        if len(perps) < 1:
            continue
        for perp in perps:
            for spot in spots:
                out.append(cash_and_carry(perp, spot, cfg))
        for i, a in enumerate(perps):
            for b in perps[i + 1 :]:
                if a.price == b.price:
                    continue
                lo, hi = (a, b) if a.price < b.price else (b, a)
                out.append(cross_spread(lo, hi, cfg))
        # perp vs DEX is a spread with a settlement leg, not a funding carry
        for perp in perps:
            for dex in [q for q in rows if q.kind == "dex"]:
                lo, hi = (dex, perp) if dex.price < perp.price else (perp, dex)
                out.append(cross_spread(lo, hi, cfg))

    # Best row per (kind, symbol, venue pair); the UI does not need duplicates.
    best: dict[tuple, Opportunity] = {}
    for op in out:
        key = (op.kind, op.symbol, op.long_venue, op.short_venue)
        if key not in best or op.score > best[key].score:
            best[key] = op
    return sorted(best.values(), key=lambda o: -o.score)


def load_fixture(path: str | Path) -> list[Quote]:
    payload = json.loads(Path(path).read_text())
    quotes = []
    for raw in payload["quotes"]:
        quotes.append(
            Quote(
                venue=raw["venue"],
                kind=raw["kind"],
                symbol=raw["symbol"].upper(),
                price=dec(raw["price"]),
                funding_rate=dec(raw.get("funding_rate", 0)),
                interval_hours=dec(raw.get("interval_hours", 8)),
                fee_bps=dec(raw.get("fee_bps", VENUE_FEES_BPS.get(raw["venue"], 5))),
                volume_usd=dec(raw.get("volume_usd", 0)),
            )
        )
    return quotes


def summary(ops: list[Opportunity], quotes: list[Quote], source: str, at: str, errors: list[str] | None = None) -> dict:
    carry = [o for o in ops if o.kind == "CARRY"]
    spread = [o for o in ops if o.kind == "SPREAD"]
    venues = sorted({q.venue for q in quotes})
    return {
        "at": at,
        "source": source,
        "venues": venues,
        "quoteCount": len(quotes),
        "opportunities": [o.as_dict() for o in ops],
        "stats": {
            "count": len(ops),
            "carry": len(carry),
            "spread": len(spread),
            "bestNetApr": round(max((float(o.net_apr) for o in carry), default=0.0), 2),
            "bestNetBps": round(max((float(o.net_bps) for o in spread), default=0.0), 2),
            "signals": len([o for o in ops if o.signal in ("CARRY", "SPREAD")]),
        },
        "errors": errors or [],
    }
