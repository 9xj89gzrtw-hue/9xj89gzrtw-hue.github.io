#!/usr/bin/env python3
"""Exporters for Scraper data: CSV, Excel (XLSX), JSON, and Telegram Notification."""
from __future__ import annotations

import csv
import json
import logging
import os
from pathlib import Path
from typing import Any, Dict, List, Optional
import urllib.request
import urllib.parse

logger = logging.getLogger("scraper.exporters")

def export_csv(rows: List[Dict[str, Any]], filepath: Path | str) -> None:
    path = Path(filepath)
    path.parent.mkdir(parents=True, exist_ok=True)
    if not rows:
        logger.warning("No rows to export to CSV.")
        return

    keys = list(rows[0].keys())
    with open(path, "w", encoding="utf-8-sig", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=keys)
        writer.writeheader()
        writer.writerows(rows)
    logger.info(f"Successfully exported {len(rows)} rows to CSV: {path}")

def export_json(rows: List[Dict[str, Any]], filepath: Path | str, indent: int = 2) -> None:
    path = Path(filepath)
    path.parent.mkdir(parents=True, exist_ok=True)
    with open(path, "w", encoding="utf-8") as f:
        json.dump(rows, f, ensure_ascii=False, indent=indent)
    logger.info(f"Successfully exported {len(rows)} rows to JSON: {path}")

def export_excel(rows: List[Dict[str, Any]], filepath: Path | str) -> None:
    path = Path(filepath)
    path.parent.mkdir(parents=True, exist_ok=True)
    if not rows:
        logger.warning("No rows to export to Excel.")
        return

    try:
        import openpyxl
        wb = openpyxl.Workbook()
        ws = wb.active
        ws.title = "Scraped Data"

        keys = list(rows[0].keys())
        ws.append(keys)
        for r in rows:
            ws.append([str(r.get(k, "")) for k in keys])
        wb.save(path)
        logger.info(f"Successfully exported {len(rows)} rows to Excel: {path}")
    except ImportError:
        logger.warning("openpyxl not installed. Falling back to CSV export with .csv suffix.")
        csv_fallback = path.with_suffix(".csv")
        export_csv(rows, csv_fallback)

def send_telegram_alert(bot_token: str, chat_id: str | int, message: str) -> bool:
    if not bot_token or not chat_id:
        logger.warning("Telegram bot token or chat ID missing. Alert skipped.")
        return False
    url = f"https://api.telegram.org/bot{bot_token}/sendMessage"
    payload = {
        "chat_id": chat_id,
        "text": message,
        "parse_mode": "HTML",
        "disable_web_page_preview": True
    }
    data = json.dumps(payload).encode("utf-8")
    req = urllib.request.Request(url, data=data, headers={"Content-Type": "application/json"})
    try:
        with urllib.request.urlopen(req, timeout=10) as resp:
            return resp.status == 200
    except Exception as e:
        logger.error(f"Failed to send Telegram alert: {e}")
        return False
