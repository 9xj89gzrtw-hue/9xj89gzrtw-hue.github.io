#!/usr/bin/env python3
"""Unit tests for Universal Scraper Pro."""
import sys
import unittest
from pathlib import Path
import tempfile

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from engine import ScraperEngine, ProxyManager
from exporters import export_csv, export_json

class TestScraper(unittest.TestCase):
    def test_proxy_manager(self):
        proxies = ["http://1.1.1.1:8080", "http://2.2.2.2:8080"]
        mgr = ProxyManager(proxies)
        p1 = mgr.get_proxy()
        self.assertIn(p1, proxies)

        mgr.mark_dead(p1)
        p2 = mgr.get_proxy()
        self.assertNotEqual(p1, p2)

    def test_exporters(self):
        sample_data = [
            {"name": "Product A", "price": 100},
            {"name": "Product B", "price": 250}
        ]
        with tempfile.TemporaryDirectory() as tmpdir:
            csv_file = Path(tmpdir) / "test.csv"
            export_csv(sample_data, csv_file)
            self.assertTrue(csv_file.exists())
            content = csv_file.read_text(encoding="utf-8-sig")
            self.assertIn("Product A", content)
            self.assertIn("250", content)

            json_file = Path(tmpdir) / "test.json"
            export_json(sample_data, json_file)
            self.assertTrue(json_file.exists())
            self.assertIn("Product B", json_file.read_text())

if __name__ == "__main__":
    unittest.main()
