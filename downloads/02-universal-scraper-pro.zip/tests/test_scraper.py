"""Unit tests for Scraper engine."""
import unittest
from scraper.core import UniversalScraper

class TestScraper(unittest.TestCase):
    def setUp(self):
        self.scraper = UniversalScraper()

    def test_parse_items(self):
        sample_html = """
        <div class="product"><h3 class="title">Товар 1</h3><span class="price">100 ₽</span><a href="/item1">Ссылка</a></div>
        <div class="product"><h3 class="title">Товар 2</h3><span class="price">250 ₽</span><a href="/item2">Ссылка</a></div>
        """
        items = self.scraper.parse_items(sample_html, ".product", {"title": ".title", "price": ".price", "link": "a"})
        self.assertEqual(len(items), 2)
        self.assertEqual(items[0]["title"], "Товар 1")
        self.assertEqual(items[0]["price"], "100 ₽")

if __name__ == "__main__":
    unittest.main()
