# Universal Resilient Scraper Pro

Профессиональный движок для парсинга и скрапинга веб-сайтов на Python с защитой от блокировок, обходом Cloudflare / Anti-Bot систем, ротацией прокси и автоматическим экспортом в Excel (XLSX), CSV и Telegram.

## Ключевые возможности
- **Обход Cloudflare и WAF:**
  - Генерация реалистичных TLS-отпечатков (Sec-CH-UA, Accept-Language, Sec-Fetch-*).
  - Ротация User-Agent (актуальные десктопные браузеры macOS, Windows, Linux).
  - Автоматическое распознавание страниц Cloudflare Challenge (503/403) и умная экспоненциальная пауза.
- **Интеллектуальный Proxy-менеджер:**
  - Поддержка HTTP, HTTPS и SOCKS5 (включая Tor `socks5h://127.0.0.1:40000`).
  - Автоматическое исключение «умерших» или заблокированных прокси без падения скрипта.
  - Рандомизированные задержки (human-like jitter).
- **Экспорт в любые форматы:**
  - **Excel (`.xlsx`)**: нативное форматирование для отчетов.
  - **CSV**: кодировка UTF-8 с BOM (`utf-8-sig`) — открывается в русском Excel без кракозябр.
  - **JSON**: для интеграции в другие сервисы и базы данных.
  - **Telegram Alert**: мгновенные уведомления в канал или чат об изменении цен или новых товарах.
- **Готовые тесты и CLI:**
  - Включает модульные тесты и CLI с поддержкой пагинации.

## Быстрый запуск

### 1. Установка
```bash
pip install -r requirements.txt
```

### 2. Запуск скрапинга в CSV
```bash
python cli.py --pages 3 --out results.csv
```

### 3. Экспорт в Excel с ротацией прокси
```bash
python cli.py --pages 5 --proxies proxies.txt --out catalog.xlsx
```

### 4. Уведомление в Telegram по окончании
```bash
python cli.py --pages 2 --out data.csv --tg-token "YOUR_BOT_TOKEN" --tg-chat "YOUR_CHAT_ID"
```

## Структура файлов
```
├── cli.py             # Консольная утилита скрапинга
├── engine.py          # Ядро с обходом Cloudflare и ротацией прокси
├── exporters.py       # Экспорт в Excel, CSV, JSON и Telegram
├── proxies.txt.sample # Пример файла со списком прокси
├── requirements.txt   # Зависимости
└── tests/             # Модульные тесты
```

## Тестирование
```bash
python tests/test_scraper.py
```
