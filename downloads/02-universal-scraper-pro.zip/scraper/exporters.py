"""Data export modules (JSON, CSV, SQLite)."""
import json
import csv
import sqlite3
from pathlib import Path
from typing import List, Dict, Any

class DataExporter:
    @staticmethod
    def to_json(data: List[Dict[str, Any]], filepath: str):
        with open(filepath, "w", encoding="utf-8") as f:
            json.dump(data, f, ensure_ascii=False, indent=2)

    @staticmethod
    def to_csv(data: List[Dict[str, Any]], filepath: str):
        if not data:
            return
        fields = list(data[0].keys())
        with open(filepath, "w", encoding="utf-8", newline="") as f:
            writer = csv.DictWriter(f, fieldnames=fields)
            writer.writeheader()
            writer.writerows(data)

    @staticmethod
    def to_sqlite(data: List[Dict[str, Any]], db_path: str, table_name: str = "scraped_items"):
        if not data:
            return
        conn = sqlite3.connect(db_path)
        cur = conn.cursor()
        fields = list(data[0].keys())
        cols = ", ".join([f'"{f}" TEXT' for f in fields])
        cur.execute(f'CREATE TABLE IF NOT EXISTS "{table_name}" ({cols})')
        placeholders = ", ".join(["?"] * len(fields))
        for row in data:
            cur.execute(f'INSERT INTO "{table_name}" VALUES ({placeholders})', [str(row.get(f, "")) for f in fields])
        conn.commit()
        conn.close()
