"""Command Line Interface for running scrapers."""
import argparse
import asyncio
from scraper.core import UniversalScraper
from scraper.exporters import DataExporter

async def main():
    parser = argparse.ArgumentParser(description="Universal Scraper Pro CLI")
    parser.add_argument("--url", required=True, help="Target URL to scrape")
    parser.add_argument("--item-selector", default=".item", help="CSS selector for list items")
    parser.add_argument("--output", default="output.json", help="Output file path (.json, .csv, .db)")
    args = parser.parse_args()

    scraper = UniversalScraper()
    print(f"[*] Scraping {args.url}...")
    html = await scraper.fetch_page(args.url)
    if not html:
        print("[-] Failed to fetch page content.")
        return

    items = scraper.parse_items(html, args.item_selector, {"title": "h2, h3, a", "price": ".price, .cost", "link": "a"})
    print(f"[+] Found {len(items)} items.")

    if args.output.endswith(".csv"):
        DataExporter.to_csv(items, args.output)
    elif args.output.endswith(".db"):
        DataExporter.to_sqlite(items, args.output)
    else:
        DataExporter.to_json(items, args.output)
    print(f"[+] Results saved to {args.output}")

if __name__ == "__main__":
    asyncio.run(main())
