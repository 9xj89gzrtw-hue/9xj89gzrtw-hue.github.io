"""Universal Scraper Engine with retry logic and async workers."""
import asyncio
import logging
from typing import List, Dict, Any, Optional
import httpx
from bs4 import BeautifulSoup

logger = logging.getLogger("ScraperCore")

class UniversalScraper:
    def __init__(self, user_agent: Optional[str] = None, timeout: float = 15.0, max_retries: int = 3):
        self.user_agent = user_agent or "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36"
        self.timeout = timeout
        self.max_retries = max_retries
        self.headers = {
            "User-Agent": self.user_agent,
            "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8",
            "Accept-Language": "ru-RU,ru;q=0.9,en-US;q=0.8,en;q=0.7",
            "Cache-Control": "no-cache",
        }

    async def fetch_page(self, url: str) -> Optional[str]:
        async with httpx.AsyncClient(headers=self.headers, timeout=self.timeout, follow_redirects=True) as client:
            for attempt in range(1, self.max_retries + 1):
                try:
                    resp = await client.get(url)
                    if resp.status_code == 200:
                        return resp.text
                    logger.warning(f"Attempt {attempt}: HTTP {resp.status_code} for {url}")
                except Exception as e:
                    logger.error(f"Attempt {attempt} failed for {url}: {e}")
                await asyncio.sleep(1.0 * attempt)
        return None

    def parse_items(self, html: str, selector: str, fields: Dict[str, str]) -> List[Dict[str, Any]]:
        soup = BeautifulSoup(html, "html.parser")
        items = []
        for elem in soup.select(selector):
            item = {}
            for field, sel in fields.items():
                found = elem.select_one(sel)
                item[field] = found.get_text(strip=True) if found else ""
            items.append(item)
        return items
