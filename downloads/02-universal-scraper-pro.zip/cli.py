#!/usr/bin/env python3
"""Universal Scraper Pro CLI.
Scrape websites with anti-detect headers, proxy rotation, and export to CSV/Excel/Telegram.
"""
from __future__ import annotations

import argparse
import logging
import sys
from pathlib import Path
from bs4 import BeautifulSoup

from engine import ScraperEngine, ProxyManager
from exporters import export_csv, export_excel, export_json, send_telegram_alert

logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(message)s")
logger = logging.getLogger("scraper.cli")

def parse_demo_books(html: str) -> list[dict]:
    soup = BeautifulSoup(html, "html.parser")
    items = []
    articles = soup.find_all("article", class_="product_pod")
    for art in articles:
        h3 = art.find("h3")
        title = h3.find("a")["title"] if h3 and h3.find("a") else "Unknown"
        price_p = art.find("p", class_="price_color")
        price = price_p.get_text(strip=True) if price_p else "$0.00"
        instock = bool(art.find("p", class_="instock"))
        items.append({
            "title": title,
            "price": price,
            "in_stock": instock
        })
    return items

def main():
    parser = argparse.ArgumentParser(description="Universal Resilient Scraper Pro")
    parser.add_argument("--url", default="https://books.toscrape.com/", help="Target URL to scrape")
    parser.add_argument("--pages", type=int, default=1, help="Number of pages to scrape")
    parser.add_argument("--out", default="output.csv", help="Output file path (.csv, .xlsx, or .json)")
    parser.add_argument("--proxies", default="", help="Path to text file with proxies (one per line)")
    parser.add_argument("--tg-token", default="", help="Telegram Bot Token for alerts")
    parser.add_argument("--tg-chat", default="", help="Telegram Chat ID for alerts")
    args = parser.parse_args()

    proxy_list = []
    if args.proxies and Path(args.proxies).exists():
        proxy_list = Path(args.proxies).read_text().splitlines()
        logger.info(f"Loaded {len(proxy_list)} proxies from {args.proxies}")

    proxy_mgr = ProxyManager(proxy_list)
    engine = ScraperEngine(proxy_manager=proxy_mgr)

    all_data = []
    base_url = args.url

    for p in range(1, args.pages + 1):
        target = base_url if p == 1 else f"{base_url.rstrip('/')}/catalogue/page-{p}.html"
        logger.info(f"Scraping page {p}/{args.pages}: {target}")
        resp = engine.fetch(target)
        if not resp:
            logger.warning(f"Could not fetch page {p}. Stopping.")
            break

        rows = parse_demo_books(resp.text)
        logger.info(f"Extracted {len(rows)} items from page {p}")
        all_data.extend(rows)

    if not all_data:
        logger.error("No data collected.")
        sys.exit(1)

    out_path = Path(args.out)
    if out_path.suffix == ".xlsx":
        export_excel(all_data, out_path)
    elif out_path.suffix == ".json":
        export_json(all_data, out_path)
    else:
        export_csv(all_data, out_path)

    if args.tg_token and args.tg_chat:
        msg = f"🚀 <b>Scraper Finished!</b>\nExtracted: <b>{len(all_data)}</b> items.\nSaved to: <code>{args.out}</code>"
        send_telegram_alert(args.tg_token, args.tg_chat, msg)

    logger.info("Done!")

if __name__ == "__main__":
    main()
