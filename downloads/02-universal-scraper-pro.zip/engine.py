#!/usr/bin/env python3
"""Universal Resilient Scraper Engine with Cloudflare & Anti-Bot Evasion.
Supports proxy rotation, realistic TLS browser fingerprints, retry backoff, and ban mitigation.
"""
from __future__ import annotations

import logging
import random
import re
import time
from typing import Any, Dict, List, Optional
from urllib.parse import urlparse

import requests
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry

logger = logging.getLogger("scraper.engine")

USER_AGENTS = [
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/129.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 14_6_1) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.5 Safari/605.1.15",
    "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/127.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:130.0) Gecko/20100101 Firefox/130.0"
]

CLOUDFLARE_MARKERS = [
    "cf-browser-verification",
    "cf-challenge-running",
    "Attention Required! | Cloudflare",
    "Just a moment...",
    "challenge-platform",
    "Checking your browser before accessing",
    "ray ID:"
]

class ProxyManager:
    def __init__(self, proxy_list: Optional[List[str]] = None):
        self.proxies: List[str] = [p.strip() for p in (proxy_list or []) if p.strip()]
        self.dead_proxies: set[str] = set()

    def get_proxy(self) -> Optional[str]:
        available = [p for p in self.proxies if p not in self.dead_proxies]
        if not available:
            if self.proxies:
                logger.warning("All proxies marked dead. Resetting pool.")
                self.dead_proxies.clear()
                return random.choice(self.proxies)
            return None
        return random.choice(available)

    def mark_dead(self, proxy: str) -> None:
        self.dead_proxies.add(proxy)
        logger.info(f"Marked proxy {proxy} as dead. Remaining alive: {len(self.proxies) - len(self.dead_proxies)}")


class ScraperEngine:
    def __init__(
        self,
        proxy_manager: Optional[ProxyManager] = None,
        max_retries: int = 4,
        timeout: int = 15,
        min_delay: float = 1.0,
        max_delay: float = 3.0
    ):
        self.proxy_manager = proxy_manager or ProxyManager()
        self.max_retries = max_retries
        self.timeout = timeout
        self.min_delay = min_delay
        self.max_delay = max_delay
        self.session = self._create_session()

    def _create_session(self) -> requests.Session:
        s = requests.Session()
        retries = Retry(
            total=self.max_retries,
            backoff_factor=1.5,
            status_forcelist=[500, 502, 503, 504],
            raise_on_status=False
        )
        adapter = HTTPAdapter(max_retries=retries)
        s.mount("http://", adapter)
        s.mount("https://", adapter)
        return s

    def _get_stealth_headers(self, referer: Optional[str] = None) -> Dict[str, str]:
        ua = random.choice(USER_AGENTS)
        is_chrome = "Chrome" in ua
        headers = {
            "User-Agent": ua,
            "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8",
            "Accept-Language": "en-US,en;q=0.9,ru;q=0.8",
            "Accept-Encoding": "gzip, deflate, br",
            "Cache-Control": "max-age=0",
            "Upgrade-Insecure-Requests": "1"
        }
        if is_chrome:
            headers["Sec-Ch-Ua"] = '"Chromium";v="128", "Not;A=Brand";v="24", "Google Chrome";v="128"'
            headers["Sec-Ch-Ua-Mobile"] = "?0"
            headers["Sec-Ch-Ua-Platform"] = '"macOS"'
            headers["Sec-Fetch-Dest"] = "document"
            headers["Sec-Fetch-Mode"] = "navigate"
            headers["Sec-Fetch-Site"] = "none" if not referer else "same-origin"
            headers["Sec-Fetch-User"] = "?1"
        if referer:
            headers["Referer"] = referer
        return headers

    def is_cloudflare_blocked(self, response: requests.Response) -> bool:
        if response.status_code in (403, 503):
            text_lower = response.text.lower()
            return any(marker.lower() in text_lower for marker in CLOUDFLARE_MARKERS)
        return False

    def fetch(self, url: str, referer: Optional[str] = None) -> Optional[requests.Response]:
        """Fetch URL with automatic stealth headers, proxy rotation, and CF evasion."""
        for attempt in range(1, self.max_retries + 1):
            proxy = self.proxy_manager.get_proxy()
            proxies_dict = {"http": proxy, "https": proxy} if proxy else None
            headers = self._get_stealth_headers(referer)

            delay = random.uniform(self.min_delay, self.max_delay)
            time.sleep(delay)

            try:
                logger.info(f"[{attempt}/{self.max_retries}] Fetching {url} (proxy: {proxy or 'direct'})...")
                resp = self.session.get(url, headers=headers, proxies=proxies_dict, timeout=self.timeout)

                if self.is_cloudflare_blocked(resp):
                    logger.warning(f"Cloudflare challenge detected on {url}! Status: {resp.status_code}")
                    if proxy:
                        self.proxy_manager.mark_dead(proxy)
                    time.sleep(attempt * 2.0)
                    continue

                if resp.status_code == 200:
                    return resp
                elif resp.status_code == 429:
                    logger.warning("Rate limit hit (429). Backing off...")
                    time.sleep(attempt * 3.0)
                else:
                    logger.warning(f"Unexpected status code {resp.status_code} on {url}")

            except (requests.RequestException, Exception) as exc:
                logger.warning(f"Request failed: {exc}")
                if proxy:
                    self.proxy_manager.mark_dead(proxy)
                time.sleep(attempt * 1.5)

        logger.error(f"Failed to fetch {url} after {self.max_retries} attempts.")
        return None
