#!/usr/bin/env python3
"""Production-grade Telegram Shop Bot with CryptoBot (USDT/TON) & Telegram Stars (XTR)
Auto-delivery for digital files, templates, and license keys.
"""
from __future__ import annotations

import asyncio
import logging
import os
import uuid
from pathlib import Path

from aiogram import Bot, Dispatcher, F, types
from aiogram.filters import Command, CommandStart
from aiogram.types import (
    FSInputFile,
    InlineKeyboardButton,
    InlineKeyboardMarkup,
    LabeledPrice,
    PreCheckoutQuery,
)

import config
import database
import cryptopay

logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(message)s")
logger = logging.getLogger(__name__)

bot = Bot(token=config.BOT_TOKEN) if config.BOT_TOKEN else None
dp = Dispatcher()

def main_keyboard() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="🛒 Каталог товаров / Products", callback_data="catalog")],
        [InlineKeyboardButton(text="📦 Мои покупки / My Orders", callback_data="my_orders")],
        [InlineKeyboardButton(text="ℹ️ О магазине / About", callback_data="about")]
    ])

def admin_keyboard() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="📊 Статистика / Stats", callback_data="admin_stats")],
        [InlineKeyboardButton(text="📢 Рассылка / Broadcast", callback_data="admin_broadcast")],
        [InlineKeyboardButton(text="🔄 Обновить базу", callback_data="admin_refresh")]
    ])

@dp.message(CommandStart())
async def cmd_start(message: types.Message):
    if not message.from_user:
        return
    database.record_user(
        user_id=message.from_user.id,
        username=message.from_user.username,
        first_name=message.from_user.first_name
    )
    welcome_text = (
        f"👋 Добро пожаловать в <b>{config.SHOP_NAME}</b>!\n\n"
        f"Здесь вы можете приобрести готовые скрипты, ботов, парсеры и UI-киты "
        f"с мгновенной автовыдачей сразу после оплаты.\n\n"
        f"💳 <b>Способы оплаты:</b>\n"
        f"• <b>CryptoBot</b>: USDT, TON, BTC, ETH\n"
        f"• <b>Telegram Stars</b>: оплата картой через Telegram\n\n"
        f"Выберите раздел в меню ниже:"
    )
    await message.answer(welcome_text, parse_mode="HTML", reply_markup=main_keyboard())

@dp.callback_query(F.data == "catalog")
async def show_catalog(callback: types.CallbackQuery):
    products = database.get_all_products()
    if not products:
        await callback.message.edit_text("Каталог в данный момент пуст.", reply_markup=main_keyboard())
        return

    buttons = []
    for p in products:
        btn_text = f"{p['title']} — ${p['price_usdt']:.0f} / ⭐{p['price_stars']}"
        buttons.append([InlineKeyboardButton(text=btn_text, callback_data=f"prod_{p['id']}")])
    buttons.append([InlineKeyboardButton(text="« Назад в меню", callback_data="menu")])

    await callback.message.edit_text(
        "📦 <b>Выберите товар для просмотра описания и покупки:</b>",
        parse_mode="HTML",
        reply_markup=InlineKeyboardMarkup(inline_keyboard=buttons)
    )

@dp.callback_query(F.data.startswith("prod_"))
async def show_product(callback: types.CallbackQuery):
    prod_id = int(callback.data.split("_")[1])
    p = database.get_product_by_id(prod_id)
    if not p:
        await callback.answer("Товар не найден", show_alert=True)
        return

    text = (
        f"💎 <b>{p['title']}</b>\n\n"
        f"{p['description']}\n\n"
        f"💰 <b>Цена:</b>\n"
        f"• <b>CryptoBot (USDT/TON):</b> <code>${p['price_usdt']:.2f}</code>\n"
        f"• <b>Telegram Stars:</b> <code>⭐ {p['price_stars']} Stars</code>\n\n"
        f"⚡ <i>Автовыдача архива и ключа сразу после подтверждения платежа!</i>"
    )

    buttons = []
    if config.CRYPTOBOT_TOKEN:
        buttons.append([InlineKeyboardButton(text=f"💳 Купить за CryptoBot (${p['price_usdt']:.0f})", callback_data=f"buy_crypto_{p['id']}")])
    buttons.append([InlineKeyboardButton(text=f"⭐ Купить за Stars (⭐{p['price_stars']})", callback_data=f"buy_stars_{p['id']}")])
    buttons.append([InlineKeyboardButton(text="« Назад в каталог", callback_data="catalog")])

    await callback.message.edit_text(text, parse_mode="HTML", reply_markup=InlineKeyboardMarkup(inline_keyboard=buttons))

@dp.callback_query(F.data.startswith("buy_crypto_"))
async def buy_via_cryptobot(callback: types.CallbackQuery):
    prod_id = int(callback.data.split("_")[2])
    p = database.get_product_by_id(prod_id)
    if not p:
        await callback.answer("Товар не найден", show_alert=True)
        return

    order_uuid = str(uuid.uuid4())[:8]
    invoice = await cryptopay.create_cryptobot_invoice(
        amount=p["price_usdt"],
        currency="USDT",
        description=f"Purchase: {p['title']}",
        payload=order_uuid
    )

    if not invoice:
        await callback.answer("Ошибка связи с CryptoBot. Попробуйте Stars или повторите позже.", show_alert=True)
        return

    invoice_id = str(invoice["invoice_id"])
    pay_url = invoice["bot_invoice_url"]

    database.create_order(
        order_uuid=order_uuid,
        user_id=callback.from_user.id,
        product_id=p["id"],
        payment_method="CRYPTOBOT",
        amount=p["price_usdt"],
        currency="USDT",
        invoice_id=invoice_id
    )

    text = (
        f"🧾 <b>Счет на оплату #{order_uuid}</b>\n\n"
        f"Товар: <b>{p['title']}</b>\n"
        f"Сумма: <b>${p['price_usdt']:.2f} USDT</b>\n\n"
        f"1. Нажмите кнопку ниже и оплатите через CryptoBot.\n"
        f"2. После оплаты нажмите «Проверить оплату»."
    )

    kb = InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="🔗 Оплатить в CryptoBot", url=pay_url)],
        [InlineKeyboardButton(text="✅ Проверить оплату", callback_data=f"check_{order_uuid}")],
        [InlineKeyboardButton(text="« Отмена", callback_data="catalog")]
    ])
    await callback.message.edit_text(text, parse_mode="HTML", reply_markup=kb)

@dp.callback_query(F.data.startswith("check_"))
async def check_payment(callback: types.CallbackQuery):
    order_uuid = callback.data.split("_")[1]
    order = database.get_order_by_uuid(order_uuid)
    if not order:
        await callback.answer("Заказ не найден", show_alert=True)
        return

    if order["status"] == "PAID":
        await callback.answer("Этот заказ уже оплачен и выдан!", show_alert=True)
        return

    is_paid = await cryptopay.check_cryptobot_invoice(order["invoice_id"])
    if not is_paid:
        await callback.answer("⏳ Платеж пока не поступил в CryptoBot. Пожалуйста, завершите оплату и нажмите снова.", show_alert=True)
        return

    # Deliver digital goods
    delivered = database.mark_order_paid(order_uuid)
    await deliver_goods(callback.from_user.id, delivered)
    await callback.message.edit_text(f"🎉 <b>Оплата #{order_uuid} успешно получена!</b>\nТовар отправлен вам личным сообщением.", parse_mode="HTML")

@dp.callback_query(F.data.startswith("buy_stars_"))
async def buy_via_stars(callback: types.CallbackQuery):
    prod_id = int(callback.data.split("_")[2])
    p = database.get_product_by_id(prod_id)
    if not p:
        await callback.answer("Товар не найден", show_alert=True)
        return

    order_uuid = str(uuid.uuid4())[:8]
    database.create_order(
        order_uuid=order_uuid,
        user_id=callback.from_user.id,
        product_id=p["id"],
        payment_method="STARS",
        amount=p["price_stars"],
        currency="XTR",
        invoice_id=order_uuid
    )

    prices = [LabeledPrice(label=p["title"][:30], amount=int(p["price_stars"]))]
    await callback.message.delete()
    await bot.send_invoice(
        chat_id=callback.from_user.id,
        title=p["title"],
        description=p["description"][:255],
        payload=order_uuid,
        currency="XTR",
        prices=prices,
        provider_token=""  # Empty for Telegram Stars
    )

@dp.pre_checkout_query()
async def pre_checkout_handler(pre_checkout_query: PreCheckoutQuery):
    await bot.answer_pre_checkout_query(pre_checkout_query.id, ok=True)

@dp.message(F.successful_payment)
async def successful_payment_handler(message: types.Message):
    if not message.successful_payment:
        return
    order_uuid = message.successful_payment.invoice_payload
    delivered = database.mark_order_paid(order_uuid)
    if delivered:
        await message.answer(f"🎉 <b>Оплата через Telegram Stars прошла успешно!</b>\nВыдаем ваш товар...")
        await deliver_goods(message.from_user.id, delivered)

async def deliver_goods(user_id: int, order_data: dict):
    if not order_data:
        return

    msg = f"📦 <b>Ваш заказ: {order_data['product_title']}</b>\n\n"
    if order_data.get("license_key"):
        msg += f"🔑 <b>Лицензионный ключ / Доступ:</b>\n<code>{order_data['license_key']}</code>\n\n"
    msg += "Спасибо за покупку! Если возникли вопросы, обратитесь в поддержку."

    await bot.send_message(chat_id=user_id, text=msg, parse_mode="HTML")

    if order_data.get("file_name"):
        file_path = config.DELIVERABLES_DIR / order_data["file_name"]
        if file_path.exists():
            doc = FSInputFile(file_path)
            await bot.send_document(chat_id=user_id, document=doc, caption="Ваш цифровой архив")
        else:
            await bot.send_message(
                chat_id=user_id,
                text=f"<i>Архив {order_data['file_name']} готовится к отправке. Администратор уведомлен.</i>",
                parse_mode="HTML"
            )

@dp.callback_query(F.data == "about")
async def show_about(callback: types.CallbackQuery):
    text = (
        f"ℹ️ <b>О сервисе {config.SHOP_NAME}</b>\n\n"
        f"Мы разрабатываем и продаем проверенный софт для разработчиков, крипто-энтузиастов и бизнеса:\n"
        f"• Telegram-боты любой сложности\n"
        f"• Высокоскоростные скрейперы и мониторинги\n"
        f"• Ончейн-аналитика и Web3-инструменты\n\n"
        f"⚡ <b>Гарантии:</b> 100% рабочий код с тестами и инструкциями.\n"
        f"🌐 Web-витрина: <code>https://9xj89gzrtw-hue.github.io/</code>"
    )
    await callback.message.edit_text(text, parse_mode="HTML", reply_markup=main_keyboard())

@dp.callback_query(F.data == "menu")
async def back_to_menu(callback: types.CallbackQuery):
    await callback.message.edit_text("Главное меню магазина:", reply_markup=main_keyboard())

@dp.message(Command("admin"))
async def cmd_admin(message: types.Message):
    if message.from_user.id != config.ADMIN_ID and config.ADMIN_ID != 0:
        await message.answer("⛔ Доступ только для администратора.")
        return
    stats = database.get_stats()
    text = (
        f"👑 <b>Панель управления магазином</b>\n\n"
        f"👥 Всего пользователей: <b>{stats['users']}</b>\n"
        f"📦 Успешных заказов: <b>{stats['orders']}</b>\n"
        f"💵 Оборот USDT: <b>${stats['usdt_volume']:.2f}</b>\n"
        f"⭐ Оборот Stars: <b>{stats['stars_volume']} XTR</b>"
    )
    await message.answer(text, parse_mode="HTML", reply_markup=admin_keyboard())

async def main():
    database.init_db()
    logger.info("Database initialized successfully.")
    if not config.BOT_TOKEN:
        logger.error("BOT_TOKEN is not set in .env! Please set it before running the bot.")
        return
    logger.info("Starting Telegram Bot polling...")
    await dp.start_polling(bot)

if __name__ == "__main__":
    asyncio.run(main())
