from __future__ import annotations
import os
from pathlib import Path
from dotenv import load_dotenv

BASE_DIR = Path(__file__).resolve().parent
load_dotenv(BASE_DIR / ".env")

BOT_TOKEN: str = os.getenv("BOT_TOKEN", "").strip()
CRYPTOBOT_TOKEN: str = os.getenv("CRYPTOBOT_TOKEN", "").strip()
ADMIN_ID: int = int(os.getenv("ADMIN_ID", "0"))
SHOP_NAME: str = os.getenv("SHOP_NAME", "Digital Code Store")
DATABASE_PATH: Path = BASE_DIR / os.getenv("DATABASE_PATH", "shop.db")
DELIVERABLES_DIR: Path = BASE_DIR / "deliverables"

DELIVERABLES_DIR.mkdir(parents=True, exist_ok=True)
