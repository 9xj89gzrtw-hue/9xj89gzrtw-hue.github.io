from __future__ import annotations
import aiohttp
from typing import Any, Dict, Optional
from config import CRYPTOBOT_TOKEN

CRYPTOBOT_API_BASE = "https://pay.crypt.bot/api"

def _get_headers() -> Dict[str, str]:
    return {
        "Crypto-Pay-API-Token": CRYPTOBOT_TOKEN,
        "User-Agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) Shop010-CryptoBot/1.0"
    }

async def create_cryptobot_invoice(amount: float, currency: str = "USDT", description: str = "Order Payment", payload: str = "") -> Optional[Dict[str, Any]]:
    if not CRYPTOBOT_TOKEN:
        return None
    url = f"{CRYPTOBOT_API_BASE}/createInvoice"
    headers = _get_headers()
    data = {
        "asset": currency,
        "amount": str(amount),
        "description": description,
        "payload": payload,
        "paid_btn_name": "callback",
        "paid_btn_url": "https://t.me/Shop010_bot"
    }
    try:
        async with aiohttp.ClientSession() as session:
            async with session.post(url, json=data, headers=headers, timeout=10) as resp:
                res = await resp.json()
                if res.get("ok"):
                    return res["result"]
                print(f"[CryptoBot] Response not ok: {res}")
                return None
    except Exception as e:
        print(f"[CryptoBot] Error creating invoice: {e}")
        return None

async def check_cryptobot_invoice(invoice_id: str) -> bool:
    if not CRYPTOBOT_TOKEN:
        return False
    url = f"{CRYPTOBOT_API_BASE}/getInvoices"
    headers = _get_headers()
    params = {"invoice_ids": str(invoice_id)}
    try:
        async with aiohttp.ClientSession() as session:
            async with session.get(url, params=params, headers=headers, timeout=10) as resp:
                res = await resp.json()
                if res.get("ok") and res.get("result", {}).get("items"):
                    item = res["result"]["items"][0]
                    return item.get("status") == "paid"
                return False
    except Exception as e:
        print(f"[CryptoBot] Error checking invoice: {e}")
        return False
