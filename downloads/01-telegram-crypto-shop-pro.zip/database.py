from __future__ import annotations
import sqlite3
from typing import Any, Dict, List, Optional
from config import DATABASE_PATH

def get_connection() -> sqlite3.Connection:
    conn = sqlite3.connect(DATABASE_PATH)
    conn.row_factory = sqlite3.Row
    return conn

def init_db() -> None:
    with get_connection() as conn:
        cursor = conn.cursor()
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS users (
                user_id INTEGER PRIMARY KEY,
                username TEXT,
                first_name TEXT,
                joined_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        """)
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS products (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                title TEXT NOT NULL,
                description TEXT NOT NULL,
                price_usdt REAL NOT NULL,
                price_stars INTEGER NOT NULL,
                file_name TEXT,
                license_key TEXT,
                is_active INTEGER DEFAULT 1
            )
        """)
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS orders (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                order_uuid TEXT UNIQUE NOT NULL,
                user_id INTEGER NOT NULL,
                product_id INTEGER NOT NULL,
                payment_method TEXT NOT NULL,
                amount REAL NOT NULL,
                currency TEXT NOT NULL,
                status TEXT DEFAULT 'PENDING',
                invoice_id TEXT,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (user_id) REFERENCES users(user_id),
                FOREIGN KEY (product_id) REFERENCES products(id)
            )
        """)
        conn.commit()

        # Seed sample products if empty
        cursor.execute("SELECT COUNT(*) as cnt FROM products")
        if cursor.fetchone()["cnt"] == 0:
            sample_products = [
                (
                    "1. Telegram Crypto Shop Bot (aiogram 3)",
                    "Готовый интернет-магазин цифровых товаров для Telegram. Два шлюза: CryptoBot (USDT, TON, BTC) и Telegram Stars (карты). Автовыдача файлов и лицензий, SQLite, админ-панель.",
                    29.0,
                    700,
                    "01-telegram-crypto-shop-pro.zip",
                    None,
                    1
                ),
                (
                    "2. Universal Scraper Pro (Cloudflare Bypass)",
                    "Профессиональный скрапер на Python с обходом Cloudflare/WAF, ротацией TLS-отпечатков (JA3/JA4), пулом SOCKS5/Tor прокси и экспортом в Excel, CSV и Telegram.",
                    39.0,
                    950,
                    "02-universal-scraper-pro.zip",
                    None,
                    1
                ),
                (
                    "3. 10 Premium Landing UI Components & SVG Kit",
                    "Комплект из 10 премиальных интерактивных веб-компонентов в темном Web3/SaaS-стиле: 3D Tilt карта, крипто-чекаут, бегущая строка, терминал, бенто-сетка и генератор SVG.",
                    25.0,
                    600,
                    "03-landing-ui-svg-kit.zip",
                    None,
                    1
                ),
                (
                    "4. Crypto Bounty Hunter & Onchain Analytics",
                    "Набор инструментов для поиска крипто-задач без KYC на GitHub и Gibwork (Solana) + ончейн-трекер выплат USDC через публичные RPC Base и Arbitrum.",
                    49.0,
                    1200,
                    "04-crypto-bounty-hunter-toolkit.zip",
                    None,
                    1
                ),
                (
                    "5. Static Base USDC Storefront Template",
                    "Готовый шаблон статического интернет-магазина для GitHub Pages / Vercel с приемом нативного USDC на Base без бэкенда и клиентской расшифровкой AES-256.",
                    29.0,
                    700,
                    "05-base-usdc-storefront-template.zip",
                    None,
                    1
                ),
            ]
            cursor.executemany("""
                INSERT INTO products (title, description, price_usdt, price_stars, file_name, license_key, is_active)
                VALUES (?, ?, ?, ?, ?, ?, ?)
            """, sample_products)
            conn.commit()

def record_user(user_id: int, username: Optional[str], first_name: Optional[str]) -> None:
    with get_connection() as conn:
        conn.execute("""
            INSERT INTO users (user_id, username, first_name)
            VALUES (?, ?, ?)
            ON CONFLICT(user_id) DO UPDATE SET
                username=excluded.username,
                first_name=excluded.first_name
        """, (user_id, username, first_name))
        conn.commit()

def get_all_products() -> List[Dict[str, Any]]:
    with get_connection() as conn:
        rows = conn.execute("SELECT * FROM products WHERE is_active = 1").fetchall()
        return [dict(r) for r in rows]

def get_product_by_id(product_id: int) -> Optional[Dict[str, Any]]:
    with get_connection() as conn:
        row = conn.execute("SELECT * FROM products WHERE id = ?", (product_id,)).fetchone()
        return dict(row) if row else None

def create_order(order_uuid: str, user_id: int, product_id: int, payment_method: str, amount: float, currency: str, invoice_id: Optional[str] = None) -> None:
    with get_connection() as conn:
        conn.execute("""
            INSERT INTO orders (order_uuid, user_id, product_id, payment_method, amount, currency, status, invoice_id)
            VALUES (?, ?, ?, ?, ?, ?, 'PENDING', ?)
        """, (order_uuid, user_id, product_id, payment_method, amount, currency, invoice_id))
        conn.commit()

def get_order_by_uuid(order_uuid: str) -> Optional[Dict[str, Any]]:
    with get_connection() as conn:
        row = conn.execute("SELECT * FROM orders WHERE order_uuid = ?", (order_uuid,)).fetchone()
        return dict(row) if row else None

def get_order_by_invoice(invoice_id: str) -> Optional[Dict[str, Any]]:
    with get_connection() as conn:
        row = conn.execute("SELECT * FROM orders WHERE invoice_id = ?", (str(invoice_id),)).fetchone()
        return dict(row) if row else None

def mark_order_paid(order_uuid: str) -> Optional[Dict[str, Any]]:
    with get_connection() as conn:
        conn.execute("UPDATE orders SET status = 'PAID' WHERE order_uuid = ?", (order_uuid,))
        conn.commit()
        row = conn.execute("""
            SELECT o.*, p.title as product_title, p.file_name, p.license_key
            FROM orders o
            JOIN products p ON o.product_id = p.id
            WHERE o.order_uuid = ?
        """, (order_uuid,)).fetchone()
        return dict(row) if row else None

def get_stats() -> Dict[str, Any]:
    with get_connection() as conn:
        total_users = conn.execute("SELECT COUNT(*) as c FROM users").fetchone()["c"]
        total_orders = conn.execute("SELECT COUNT(*) as c FROM orders WHERE status = 'PAID'").fetchone()["c"]
        usdt_volume = conn.execute("SELECT COALESCE(SUM(amount), 0) as s FROM orders WHERE status = 'PAID' AND currency = 'USDT'").fetchone()["s"]
        stars_volume = conn.execute("SELECT COALESCE(SUM(amount), 0) as s FROM orders WHERE status = 'PAID' AND currency = 'XTR'").fetchone()["s"]
        return {
            "users": total_users,
            "orders": total_orders,
            "usdt_volume": usdt_volume,
            "stars_volume": int(stars_volume)
        }
