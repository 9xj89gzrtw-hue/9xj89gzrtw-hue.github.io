#!/usr/bin/env python3
"""Automated tests for Telegram Crypto Shop Bot database & order logic."""
import os
from pathlib import Path
import unittest
import database

TEST_DB = Path(__file__).parent / "test_shop.db"

class TestShopLogic(unittest.TestCase):
    def setUp(self):
        if TEST_DB.exists():
            TEST_DB.unlink()
        database.DATABASE_PATH = TEST_DB
        database.init_db()

    def tearDown(self):
        if TEST_DB.exists():
            TEST_DB.unlink()

    def test_products_seeded(self):
        products = database.get_all_products()
        self.assertGreaterEqual(len(products), 3)
        self.assertEqual(products[0]["title"], "Python Scraper Starter Kit")

    def test_order_creation_and_delivery(self):
        database.record_user(12345, "testuser", "Test")
        order_uuid = "order-test-001"
        database.create_order(
            order_uuid=order_uuid,
            user_id=12345,
            product_id=1,
            payment_method="CRYPTOBOT",
            amount=9.0,
            currency="USDT",
            invoice_id="inv-12345"
        )
        order = database.get_order_by_uuid(order_uuid)
        self.assertIsNotNone(order)
        self.assertEqual(order["status"], "PENDING")

        # Mark paid
        delivered = database.mark_order_paid(order_uuid)
        self.assertIsNotNone(delivered)
        self.assertEqual(delivered["status"], "PAID")
        self.assertEqual(delivered["product_title"], "Python Scraper Starter Kit")

        # Check stats
        stats = database.get_stats()
        self.assertEqual(stats["orders"], 1)
        self.assertEqual(stats["usdt_volume"], 9.0)

if __name__ == "__main__":
    unittest.main()
