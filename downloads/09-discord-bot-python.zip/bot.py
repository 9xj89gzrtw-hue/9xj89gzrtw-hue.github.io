"""Discord Server Moderator & Automation Bot (discord.py)."""
import discord
from discord.ext import commands
import logging

logging.basicConfig(level=logging.INFO)
intents = discord.Intents.default()
intents.message_content = True
intents.members = True

bot = commands.Bot(command_prefix="!", intents=intents)

@bot.event
async def on_ready():
    print(f"[+] Bot logged in as {bot.user.name} (ID: {bot.user.id})")

@bot.command()
@commands.has_permissions(kick_members=True)
async def kick(ctx, member: discord.Member, *, reason="Нарушение правил"):
    await member.kick(reason=reason)
    await ctx.send(f"👢 {member.mention} был исключен. Причина: {reason}")

@bot.command()
@commands.has_permissions(ban_members=True)
async def ban(ctx, member: discord.Member, *, reason="Нарушение правил"):
    await member.ban(reason=reason)
    await ctx.send(f"🔨 {member.mention} был забанен. Причина: {reason}")

@bot.command()
async def serverinfo(ctx):
    guild = ctx.guild
    embed = discord.Embed(title=f"Информация о сервере {guild.name}", color=0x38bdf8)
    embed.add_field(name="Участников", value=str(guild.member_count))
    embed.add_field(name="Создан", value=guild.created_at.strftime("%d.%m.%Y"))
    await ctx.send(embed=embed)

if __name__ == "__main__":
    bot.run("YOUR_DISCORD_BOT_TOKEN")
