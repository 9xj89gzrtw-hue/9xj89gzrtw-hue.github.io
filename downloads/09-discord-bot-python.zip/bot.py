#!/usr/bin/env python3
"""Discord Moderation & Auto-Role Bot with Slash Commands.
Built on discord.py 2.3+ with full Audit Logging.
"""
from __future__ import annotations

import datetime
import logging
import os
import discord
from discord import app_commands
from discord.ext import commands

logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(message)s")
logger = logging.getLogger(__name__)

TOKEN = os.getenv("DISCORD_BOT_TOKEN", "YOUR_DISCORD_TOKEN")
LOG_CHANNEL_ID = int(os.getenv("LOG_CHANNEL_ID", "0"))
AUTO_ROLE_NAME = os.getenv("AUTO_ROLE_NAME", "Member")

intents = discord.Intents.default()
intents.members = True
intents.message_content = True

bot = commands.Bot(command_prefix="!", intents=intents)

@bot.event
async def on_ready():
    logger.info(f"Bot logged in as {bot.user} (ID: {bot.user.id})")
    try:
        synced = await bot.tree.sync()
        logger.info(f"Synced {len(synced)} application slash commands.")
    except Exception as e:
        logger.error(f"Failed to sync slash commands: {e}")

@bot.event
async def on_member_join(member: discord.Member):
    logger.info(f"New member joined: {member.name}#{member.discriminator}")
    # Auto-role
    if AUTO_ROLE_NAME:
        role = discord.utils.get(member.guild.roles, name=AUTO_ROLE_NAME)
        if role:
            try:
                await member.add_roles(role)
                logger.info(f"Assigned {AUTO_ROLE_NAME} to {member.name}")
            except discord.Forbidden:
                logger.warning(f"Missing permissions to assign role {AUTO_ROLE_NAME}")

    # Audit log
    if LOG_CHANNEL_ID:
        channel = bot.get_channel(LOG_CHANNEL_ID)
        if channel:
            embed = discord.Embed(
                title="📥 Новый участник",
                description=f"{member.mention} ({member.name}) присоединился к серверу.",
                color=discord.Color.green(),
                timestamp=datetime.datetime.utcnow()
            )
            embed.set_thumbnail(url=member.display_avatar.url)
            await channel.send(embed=embed)

@bot.event
async def on_message_delete(message: discord.Message):
    if message.author.bot or not LOG_CHANNEL_ID:
        return
    channel = bot.get_channel(LOG_CHANNEL_ID)
    if channel and message.guild:
        embed = discord.Embed(
            title="🗑️ Сообщение удалено",
            description=f"**Автор:** {message.author.mention}\n**Канал:** {message.channel.mention}\n**Содержимое:**\n{message.content or '[Вложение/Embed]'}",
            color=discord.Color.red(),
            timestamp=datetime.datetime.utcnow()
        )
        await channel.send(embed=embed)

# Slash Commands
@bot.tree.command(name="clear", description="Очистить N последних сообщений в канале")
@app_commands.describe(amount="Количество сообщений для удаления (1-100)")
@app_commands.checks.has_permissions(manage_messages=True)
async def clear_cmd(interaction: discord.Interaction, amount: int):
    if amount < 1 or amount > 100:
        await interaction.response.send_message("Укажите число от 1 до 100.", ephemeral=True)
        return
    await interaction.response.defer(ephemeral=True)
    deleted = await interaction.channel.purge(limit=amount)
    await interaction.followup.send(f"✅ Удалено {len(deleted)} сообщений.", ephemeral=True)

@bot.tree.command(name="kick", description="Выгнать участника с сервера")
@app_commands.describe(member="Участник", reason="Причина")
@app_commands.checks.has_permissions(kick_members=True)
async def kick_cmd(interaction: discord.Interaction, member: discord.Member, reason: str = "Нарушение правил"):
    await member.kick(reason=reason)
    await interaction.response.send_message(f"👢 {member.mention} был исключен. Причина: {reason}")

@bot.tree.command(name="ban", description="Заблокировать участника на сервере")
@app_commands.describe(member="Участник", reason="Причина")
@app_commands.checks.has_permissions(ban_members=True)
async def ban_cmd(interaction: discord.Interaction, member: discord.Member, reason: str = "Грубое нарушение"):
    await member.ban(reason=reason)
    await interaction.response.send_message(f"🔨 {member.mention} был забанен. Причина: {reason}")

@bot.tree.command(name="serverinfo", description="Информация о сервере")
async def serverinfo_cmd(interaction: discord.Interaction):
    guild = interaction.guild
    embed = discord.Embed(title=guild.name, color=discord.Color.blue())
    if guild.icon:
        embed.set_thumbnail(url=guild.icon.url)
    embed.add_field(name="Участников", value=str(guild.member_count), inline=True)
    embed.add_field(name="Каналов", value=str(len(guild.channels)), inline=True)
    embed.add_field(name="Ролей", value=str(len(guild.roles)), inline=True)
    embed.set_footer(text=f"ID сервера: {guild.id}")
    await interaction.response.send_message(embed=embed)

if __name__ == "__main__":
    if not TOKEN or TOKEN == "YOUR_DISCORD_TOKEN":
        print("[-] Set DISCORD_BOT_TOKEN in .env or environment!")
    else:
        bot.run(TOKEN)
