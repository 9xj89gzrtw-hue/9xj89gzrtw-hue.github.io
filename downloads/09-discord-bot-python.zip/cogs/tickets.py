"""Support Ticket System Cog."""
import discord
from discord.ext import commands

class TicketSystem(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @commands.command()
    async def ticket(self, ctx):
        guild = ctx.guild
        overwrites = {
            guild.default_role: discord.PermissionOverwrite(read_messages=False),
            ctx.author: discord.PermissionOverwrite(read_messages=True, send_messages=True),
        }
        channel = await guild.create_text_channel(f"тикет-{ctx.author.name}", overwrites=overwrites)
        await channel.send(f"Здравствуйте, {ctx.author.mention}! Опишите вашу проблему, модератор скоро ответит.")
        await ctx.send(f"Тикет создан: {channel.mention}")

async def setup(bot):
    await bot.add_cog(TicketSystem(bot))
