"""bot/qr.py — PNG QR code generation for the vless:// key link.

The `qrcode` package is imported lazily so that the rest of the bot (and the
test-suite) runs without optional dependencies installed.
"""
from __future__ import annotations

import io
from typing import Optional

def qr_png_bytes(text: str) -> bytes:
    """Render `text` as a PNG image; raises if the qrcode lib is missing."""
    import qrcode  # lazy: keeps import graph light
    img = qrcode.make(text)
    buf = io.BytesIO()
    img.save(buf, format="PNG")
    return buf.getvalue()


def qr_to_file(text: str, path: str) -> Optional[str]:
    """Save a QR PNG to `path`; returns the path on success, None on failure."""
    try:
        data = qr_png_bytes(text)
    except ImportError:
        return None
    with open(path, "wb") as fh:
        fh.write(data)
    return path
