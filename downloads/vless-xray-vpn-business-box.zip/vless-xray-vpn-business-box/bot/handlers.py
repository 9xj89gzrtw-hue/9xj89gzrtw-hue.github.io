"""bot/handlers.py — aiogram 3 routers: buyer flow + admin commands.

Buyer flow:
    /start -> choose plan -> payment panel with three rails:
        (a) RUB manual transfer  -> buyer presses "I paid" -> admin /approve
        (b) Telegram Stars (XTR) -> invoice -> auto-issue after payment
        (c) USDT TRC20           -> buyer presses "I paid" -> admin /approve
    After payment the key is issued automatically: a UUID client is appended
    to the local Xray config (via the vshop CLI) and a vless:// URL + QR PNG
    is sent to the buyer.

Admin commands: /stats /orders /pending /approve /grant /revoke /issue.
"""
from __future__ import annotations

import html
import logging

from aiogram import Bot, F, Router
from aiogram.exceptions import TelegramBadRequest, TelegramForbiddenError
from aiogram.filters import BaseFilter, Command, CommandObject, CommandStart
from aiogram.types import (
    BufferedInputFile,
    CallbackQuery,
    InlineKeyboardButton,
    InlineKeyboardMarkup,
    LabeledPrice,
    Message,
    PreCheckoutQuery,
    TelegramObject,
)

from . import config as cfg
from . import db, keygen
from . import qr as qrmod

log = logging.getLogger(__name__)

router = Router()
admin = Router()

# ------------------------------------------------------------------ filters
class IsAdmin(BaseFilter):
    """Passes only for users listed in cfg.ADMIN_IDS."""

    async def __call__(self, obj: TelegramObject) -> bool:
        user = getattr(obj, "from_user", None)
        return bool(user) and user.id in cfg.ADMIN_IDS


admin.message.filter(IsAdmin())


# -------------------------------------------------------------------- texts
def _fmt_plan(pid: str) -> str:
    p = cfg.PLANS[pid]
    return (
        f"<b>{html.escape(p['title'])}</b>\n"
        f"Цена: {p['rub']:.0f} ₽ / {p['stars']} ⭐ / {p['usdt']:.1f} USDT\n"
        f"Срок: {p['days']} дн."
    )


def _plans_kb() -> InlineKeyboardMarkup:
    rows = []
    for pid, p in cfg.PLANS.items():
        rows.append(
            [
                InlineKeyboardButton(
                    text=f"{p['title']} — {p['rub']:.0f}₽",
                    callback_data=f"plan:{pid}",
                )
            ]
        )
    rows.append([InlineKeyboardButton(text="🔑 Мои ключи", callback_data="mykeys")])
    rows.append([InlineKeyboardButton(text="🆘 Поддержка", callback_data="support")])
    return InlineKeyboardMarkup(inline_keyboard=rows)


def _pay_kb(oid: int) -> InlineKeyboardMarkup:
    stars_btn = (
        InlineKeyboardButton(text="⭐ Оплатить звёздами", callback_data=f"stars:{oid}")
        if (cfg.STARS_ENABLED and _star_price_ok(oid))
        else None
    )
    row1 = [
        InlineKeyboardButton(text="💳 RUB перевод", callback_data=f"how:{oid}:rub"),
        stars_btn or InlineKeyboardButton(text="₮ USDT TRC20", callback_data=f"how:{oid}:usdt"),
    ]
    row2 = [InlineKeyboardButton(text="₮ USDT TRC20", callback_data=f"how:{oid}:usdt")]
    row3 = [
        InlineKeyboardButton(text="✅ Я оплатил", callback_data=f"ok:{oid}"),
        InlineKeyboardButton(text="✖ Отмена", callback_data=f"cancel:{oid}"),
    ]
    return InlineKeyboardMarkup(inline_keyboard=[row1, row2, row3])


def _star_price_ok(oid: int) -> bool:
    # Stars button is shown only for orders whose plan has a star price.
    o = db.get_order(cfg.DB_PATH, oid)
    return bool(o and (o.get("amount_stars") or 0) > 0)


def _panel_text(oid: int, plan_title: str) -> str:
    return (
        f"<b>Заказ №{oid} — {html.escape(plan_title)}</b>\n\n"
        "Выберите способ оплаты:\n"
        "💳 <b>RUB</b> — ручной перевод, подтверждает администратор\n"
        "⭐ <b>Telegram Stars</b> — мгновенно, ключ приходит автоматически\n"
        "₮ <b>USDT TRC20</b> — перевод в USDT, подтверждает администратор"
    )


def _rub_text(o: dict) -> str:
    return (
        f"<b>Заказ №{o['id']}</b> — {o['amount_rub']:.0f} ₽\n\n"
        f"Реквизиты:\n<code>{html.escape(cfg.PAY_RUB_INFO)}</code>\n\n"
        f"В комментарии к переводу укажите номер заказа <b>№{o['id']}</b>.\n"
        "После перевода нажмите «Я оплатил» — администратор подтвердит и вы:"
        " пришлёт вам `vless://` ключ (обычно до 15 минут)."
    )


def _usdt_text(o: dict) -> str:
    wallet = html.escape(cfg.USDT_WALLET_TRC20 or "USDT_WALLET_TRC20 не задан!")
    return (
        f"<b>Заказ №{o['id']}</b> — {o['amount_usdt']:.2f} USDT\n"
        f"Сеть: <b>TRC20</b> (Tron)\n\n"
        f"Кошелёк:\n<code>{wallet}</code>\n\n"
        "⚠️ Отправляйте строго в сети TRC20 и точную сумму.\n"
        "После перевода нажмите «Я оплатил» — администратор сверит транзакцию "
        "и выдаст ключ."
    )


def _paid_text(o: dict) -> str:
    return (
        f"<b>Заказ №{o['id']}</b> выставлен как «ожидает подтверждения».\n"
        "Мы уведомили администратора. Ключ придёт сюда этим же сообщением."
    )


def _key_message_text(o: dict, url: str, expires: str) -> str:
    expired = (
        f"\nКлюч активен до: <b>{expires}</b>\n" if expires else "\nКлюч бессрочный.\n"
    )
    return (
        f"✅ <b>Оплата получена — ваш VPN готов!</b> (заказ №{o['id']})\n"
        f"{expired}"
        "\n1. Установите клиент:\n"
        " • Android: v2rayNG\n"
        " • iOS: Streisand / Foxray\n"
        " • Windows: Hiddify / v2rayN\n"
        " • macOS: Hiddify\n\n"
        "2. Нажмите «+» → «Сканировать QR» на картинке ниже,\n"
        "   или скопируйте ссылку вручную:\n"
        f"<code>{html.escape(url)}</code>\n\n"
        "Не передавайте ключ третьим лицам: он выдаётся вам одному."
    )


SUPPORT_TEXT = (
    "🆘 Поддержка:\n"
    "• опишите проблему (что нажимали, что видите);\n"
    "• приложите скриншот ошибки и номер заказа;"
)


def user_commands():
    from aiogram.types import BotCommand
    return [
        BotCommand(command="start", description="Купить VPN / начать"),
        BotCommand(command="my_keys", description="Мои ключи"),
        BotCommand(command="help", description="Поддержка"),
    ]


# ------------------------------------------------------------- issue helpers
def _admin_ids() -> list:
    return sorted(cfg.ADMIN_IDS)


async def _notify_admins(bot: Bot, text: str) -> None:
    for aid in _admin_ids():
        try:
            await bot.send_message(aid, text)
        except (TelegramForbiddenError, TelegramBadRequest):
            continue


async def issue_and_deliver(bot: Bot, o: dict) -> tuple[bool, str]:
    """Create a server-side client, register the key and deliver it.

    Returns (ok, detail) — used for retry via /issue when something fails.
    """
    days = int((cfg.PLANS.get(o["plan"]) or {}).get("days", 30))
    label = keygen.sanitize_username(f"u{o['tg_id']}o{o['id']}")
    try:
        info = keygen.issue_client(label)
    except Exception as exc:  # noqa: BLE001 — report precise failure to admin
        log.warning("issue failed for order %s: %s", o["id"], exc)
        return False, (
            f"Не удалось выдать ключ для заказа №{o['id']}: {exc}. "
            "Проверьте vshop CLI и повторите: /issue " + str(o["id"])
        )
    expires = db.iso_in_days(days)
    key_id = db.add_key(
        path=cfg.DB_PATH,
        tg_id=o["tg_id"],
        order_id=o["id"],
        label=label,
        vless_url=info["url"],
        days=days,
        source="order",
    )
    db.set_order_status(cfg.DB_PATH, o["id"], "issued")
    text = _key_message_text(o, info["url"], expires)
    try:
        try:
            photo = BufferedInputFile(qrmod.qr_png_bytes(info["url"]), filename="vpn-key.png")
            await bot.send_photo(o["tg_id"], photo=photo, caption=text)
        except ImportError:
            await bot.send_message(o["tg_id"], text)
    except (TelegramForbiddenError, TelegramBadRequest) as exc:
        return False, f"Выдал ключ №{key_id}, но не смог написать покупателю: {exc}"
    await _notify_admins(
        bot,
        f"✅ Заказ №{o['id']} выдан: ключ №{key_id} для uid{o['tg_id']} (срок {days} дн.).",
    )
    return True, f"Выдано: ключ №{key_id} (заказ №{o['id']})."


# --------------------------------------------------------------- buyer flow
@router.message(CommandStart())
async def cmd_start(message: Message) -> None:
    db.upsert_user(cfg.DB_PATH, message.from_user.id,
                   message.from_user.username or "", message.from_user.first_name or "")
    await message.answer(
        "👋 Привет! Здесь можно купить доступ к VPN (VLESS+Reality).\n"
        "Выберите тариф:",
        reply_markup=_plans_kb(),
    )


@router.callback_query(F.data == "mykeys")
async def cb_mykeys(cb: CallbackQuery) -> None:
    await cb.answer()
    keys = [k for k in db.list_keys(cfg.DB_PATH, cb.from_user.id, active_only=True)]
    await cb.message.answer(_my_keys_text(keys))


@router.callback_query(F.data == "support")
async def cb_support(cb: CallbackQuery) -> None:
    await cb.answer()
    tail = f"Или напишите: {html.escape(cfg.SUPPORT_USERNAME)}" if cfg.SUPPORT_USERNAME else ""
    await cb.message.answer(SUPPORT_TEXT + "\n" + tail)


@router.message(Command("my_keys"))
async def cmd_my_keys(message: Message) -> None:
    keys = db.list_keys(cfg.DB_PATH, message.from_user.id, active_only=True)
    await message.answer(_my_keys_text(keys))


@router.message(Command("help"))
async def cmd_help(message: Message) -> None:
    tail = f"\nПоддержка: {html.escape(cfg.SUPPORT_USERNAME)}" if cfg.SUPPORT_USERNAME else ""
    await message.answer(SUPPORT_TEXT + tail)


def _my_keys_text(keys) -> str:
    if not keys:
        return "У вас нет активных ключей. Нажмите /start, чтобы купить."
    lines = ["🔑 <b>Ваши ключи</b>"]
    for k in keys[:5]:
        exp = f"до {k['expires_at']}" if k["expires_at"] else "бессрочно"
        lines.append(f"• №{k['id']} — {exp}\n<code>{html.escape(k['vless_url'])}</code>")
    lines.append("\nПродление: выберите тариф командой /start.")
    return "\n".join(lines)


@router.callback_query(F.data.startswith("plan:"))
async def cb_plan(cb: CallbackQuery) -> None:
    pid = cb.data.split(":", 1)[1]
    if pid not in cfg.PLANS:
        await cb.answer("Тариф не найден", show_alert=True)
        return
    p = cfg.PLANS[pid]
    db.upsert_user(cfg.DB_PATH, cb.from_user.id,
                   cb.from_user.username or "", cb.from_user.first_name or "")
    oid = db.create_order(
        path=cfg.DB_PATH,
        tg_id=cb.from_user.id,
        plan=pid,
        amount_rub=p["rub"],
        amount_stars=p["stars"],
        amount_usdt=p["usdt"],
    )
    await cb.answer()
    await cb.message.answer(
        _panel_text(oid, p["title"]),
        reply_markup=_pay_kb(oid),
    )


@router.callback_query(F.data.startswith("how:"))
async def cb_how(cb: CallbackQuery) -> None:
    _, oid_s, rail = cb.data.split(":", 2)
    oid = int(oid_s)
    o = db.get_order(cfg.DB_PATH, oid)
    if not o or o["tg_id"] != cb.from_user.id:  # only the buyer sees his order
        await cb.answer("Заказ не найден", show_alert=True)
        return
    await cb.answer()
    if rail == "rub":
        await cb.message.answer(_rub_text(o))
    elif rail == "usdt":
        await cb.message.answer(_usdt_text(o))


@router.callback_query(F.data.startswith("ok:"))
async def cb_declared(cb: CallbackQuery) -> None:
    oid = int(cb.data.split(":", 1)[1])
    o = db.get_order(cfg.DB_PATH, oid)
    if not o or o["tg_id"] != cb.from_user.id:
        await cb.answer("Заказ не найден", show_alert=True)
        return
    if o["status"] in ("paid", "issued"):
        await cb.answer("Заказ уже оплачен ✓")
        return
    if o["status"] == "awaiting_approval":
        await cb.answer("Уже в очереди на подтверждение")
        return
    db.set_order_status(cfg.DB_PATH, oid, "awaiting_approval")
    await cb.answer("Уведомление оправлено ✓")
    await cb.message.answer(_paid_text(o))
    await _notify_admins(
        cb.bot,
        f"⏳ Заказ №{oid} ожидает подтверждения ({o['plan']}, "
        f"uid{o['tg_id']}). Подтвердить: /approve {oid}",
    )


@router.callback_query(F.data.startswith("cancel:"))
async def cb_cancel(cb: CallbackQuery) -> None:
    oid = int(cb.data.split(":", 1)[1])
    o = db.get_order(cfg.DB_PATH, oid)
    if not o or o["tg_id"] != cb.from_user.id:
        await cb.answer("Заказ не найден", show_alert=True)
        return
    if o["status"] in ("paid", "issued"):
        await cb.answer("Оплаченный заказ отменить нельзя")
        return
    db.set_order_status(cfg.DB_PATH, oid, "cancelled")
    await cb.answer("Заказ отменён")
    await cb.message.answer(f"Заказ №{oid} отменён. Создайте новый через /start.")


# ------------------------------------------------------------- stars (XTR)
@router.callback_query(F.data.startswith("stars:"))
async def cb_stars(cb: CallbackQuery) -> None:
    oid = int(cb.data.split(":", 1)[1])
    o = db.get_order(cfg.DB_PATH, oid)
    if not o or o["tg_id"] != cb.from_user.id:
        await cb.answer("Заказ не найден", show_alert=True)
        return
    if o["status"] in ("paid", "issued"):
        await cb.answer("Заказ уже оплачен ✓")
        return
    p = cfg.PLANS.get(o["plan"], {})
    try:
        await cb.bot.send_invoice(
            chat_id=cb.from_user.id,
            title=f"VPN: {p.get('title', 'тариф')}",
            description=f"Доступ к VPN на {p.get('days', 30)} дней (заказ №{oid})",
            payload=f"order:{oid}",
            currency="XTR",
            prices=[LabeledPrice(label="VPN доступ", amount=o["amount_stars"])],
        )
        await cb.answer("Счёт отправлен ⭐")
    except Exception as exc:  # noqa: BLE001 — Stars may be temporarily unavailable
        log.warning("stars invoice failed: %s", exc)
        await cb.answer("Звёзды временно недоступны — оплатите RUB/USDT", show_alert=True)


@router.pre_checkout_query()
async def pre_checkout(q: PreCheckoutQuery) -> None:
    # Accept everything: the bot fails closed on delivery errors and the
    # admin can re-issue with /issue.
    await q.answer(ok=True)


@router.message(F.successful_payment)
async def on_successful_payment(message: Message) -> None:
    sp = message.successful_payment
    oid = -1
    if sp.invoice_payload.startswith("order:"):
        try:
            oid = int(sp.invoice_payload.split(":", 1)[1])
        except ValueError:
            oid = -1
    o = db.get_order(cfg.DB_PATH, oid) if oid > 0 else None
    if not o:
        await message.answer(
            "Спасибо! Оплата получена, но заказ не найден по payload — "
            "напишите в поддержку."
        )
        return
    db.record_payment(
        cfg.DB_PATH, o["id"], o["tg_id"], "stars", sp.telegram_payment_charge_id,
        f"{sp.total_amount} XTR",
    )
    if o["status"] in ("paid", "issued"):
        await message.answer("Этот заказ уже оплачен и выдан ✓")
        return
    db.set_order_status(cfg.DB_PATH, o["id"], "paid")
    ok, detail = await issue_and_deliver(message.bot, o)
    if not ok:
        await message.answer(detail)


# ------------------------------------------------------------ admin: helpers
def _order_short(o: dict) -> str:
    amts = " / ".join(
        x for x in (f"{o['amount_rub']:.0f}₽" if o["amount_rub"] else "",
                    f"{o['amount_stars']}⭐" if o["amount_stars"] else "",
                    f"{o['amount_usdt']:.1f}₮" if o["amount_usdt"] else "") if x
    )
    return (
        f"№{o['id']} [{o['status']}] план {o['plan']} – {amts} – "
        f"uid{o['tg_id']} – {o['created_at']}"
    )


def _admin_stats_text() -> str:
    path = cfg.DB_PATH
    from collections import Counter
    orders = db.list_orders(path, limit=1000)
    by_status = Counter(x["status"] for x in orders)
    rev = {}
    for o in orders:
        if o["status"] in ("paid", "issued"):
            rev[o["plan"]] = rev.get(o["plan"], 0.0) + float(o["amount_rub"] or 0)
    lines = [
        "📊 <b>Статистика магазина</b>",
        f"Пользователей: {db.count_users(path)}",
        f"Активных ключей: {db.count_active_keys(path)}",
        "Заказы: " + ", ".join(f"{k}={v}" for k, v in sorted(by_status.items())) or "нет",
        "Выручка по тарифам (₽): " + (
            ", ".join(f"{k}={v:.0f}" for k, v in sorted(rev.items())) or "0"
        ),
        f"Всего заказов: {len(orders)}",
    ]
    return "\n".join(lines)


# ---------------------------------------------------------- admin: commands
@admin.message(Command("stats"))
async def adm_stats(message: Message) -> None:
    await message.answer(_admin_stats_text())


@admin.message(Command("orders"))
async def adm_orders(message: Message, command: CommandObject) -> None:
    try:
        limit = int(command.args or 10) if command.args else 10
    except ValueError:
        limit = 10
    orders = db.list_orders(cfg.DB_PATH, limit=min(limit, 50))
    if not orders:
        await message.answer("Заказов пока нет.")
        return
    await message.answer("🧾 Последние заказы:\n" + "\n".join(_order_short(o) for o in orders))


@admin.message(Command("pending"))
async def adm_pending(message: Message) -> None:
    pending = db.list_pending(cfg.DB_PATH)
    if not pending:
        await message.answer("Нет заказов в ожидании.")
        return
    await message.answer(
        "⏳ Ожидают:\n" + "\n".join(_order_short(o) for o in pending)
        + "\n\nПодтвердить: /approve <номер>"
    )


@admin.message(Command("approve"))
async def adm_approve(message: Message, command: CommandObject) -> None:
    if not (command.args or "").strip().split():
        await message.answer("Формат: /approve <номер заказа>")
        return
    try:
        oid = int(command.args.split()[0])
    except ValueError:
        await message.answer("Номер заказа — целое число: /approve 42")
        return
    o = db.get_order(cfg.DB_PATH, oid)
    if not o:
        await message.answer(f"Заказ №{oid} не найден.")
        return
    if o["status"] == "issued":
        await message.answer(f"Заказ №{oid} уже выдан.")
        return
    if o["status"] == "paid":
        ok, detail = await issue_and_deliver(message.bot, o)
        await message.answer(detail)
        return
    db.set_order_status(cfg.DB_PATH, oid, "paid")
    ok, detail = await issue_and_deliver(message.bot, o)
    await message.answer((f"Оплата подтверждена. {detail}") if ok else detail)


@admin.message(Command("issue"))
async def adm_issue(message: Message, command: CommandObject) -> None:
    """Retry key issuance for an order stuck in `paid`."""
    if not (command.args or "").strip():
        await message.answer("Формат: /issue <номер заказа>")
        return
    try:
        oid = int(command.args.split()[0])
    except ValueError:
        await message.answer("Номер заказа — целое число: /issue 42")
        return
    o = db.get_order(cfg.DB_PATH, oid)
    if not o or o["status"] != "paid":
        await message.answer("Выдавать ключ можно только для заказа в статусе paid.")
        return
    ok, detail = await issue_and_deliver(message.bot, o)
    await message.answer(detail)


@admin.message(Command("grant"))
async def adm_grant(message: Message, command: CommandObject) -> None:
    """/grant 123456 [days] — выдать доступ без оплаты."""
    parts = (command.args or "").split()
    if not parts:
        await message.answer("Формат: /grant <tg_id> [дней=30]")
        return
    try:
        uid = int(parts[0])
        days = int(parts[1]) if len(parts) > 1 else 30
    except ValueError:
        await message.answer("Аргументы — целые числа: /grant 123456 30")
        return
    label = keygen.sanitize_username(f"g{uid}j{days}")
    try:
        info = keygen.issue_client(label)
    except Exception as exc:  # noqa: BLE001
        await message.answer(f"Не удалось создать ключ: {exc}")
        return
    key_id = db.add_key(
        cfg.DB_PATH, uid, None, label, info["url"], days=days, source="grant"
    )
    db.upsert_user(cfg.DB_PATH, uid)
    await message.answer(f"✅ Выдан ключ №{key_id} uid{uid} ({days} дн.):\n{info['url']}")


@admin.message(Command("revoke"))
async def adm_revoke(message: Message, command: CommandObject) -> None:
    ids = db.list_keys(cfg.DB_PATH, active_only=True)
    if not (command.args or "").strip():
        await message.answer("Формат: /revoke <tg_id> или <ключ №id>")
        return
    arg = command.args.split()[0]
    try:
        target = int(arg)
    except ValueError:
        await message.answer("Аргумент — целое число (tg_id или № ключа)")
        return
    # Try key id first, then treat the number as a Telegram id.
    keys = [k for k in ids if k["id"] == target] or [k for k in ids if k["tg_id"] == target]
    if not keys:
        await message.answer("Активных ключей не найдено для этого номера.")
        return
    revoked = 0
    for k in keys:
        try:
            keygen.revoke_client(k["label"])
        except Exception as exc:  # noqa: BLE001
            await message.answer(f"vshop revoke для '{k['label']}' не сработал: {exc}")
        db.revoke_key(cfg.DB_PATH, k["id"])
        revoked += 1
    await message.answer(f"Отозвано ключей: {revoked}.")
