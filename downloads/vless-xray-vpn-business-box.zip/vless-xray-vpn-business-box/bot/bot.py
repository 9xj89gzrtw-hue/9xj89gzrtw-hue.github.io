#!/usr/bin/env python3
"""bot/bot.py — entry point of the Telegram VPN sales bot.

Wire-up only: DB init, dispatchers, background key-expiry worker, the admin
web dashboard (stdlib) and long polling. Run with:

    python3 -m bot.bot           (from the box root, with .env loaded)
or via the systemd unit in bot/telegram-vpn-bot.service.
"""
from __future__ import annotations

import asyncio
import logging
import os
import sys
import threading
import time
from pathlib import Path

# Make "python3 bot/bot.py" work from the box root and from any cwd.
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from bot import config as cfg  # noqa: E402
from bot import db  # noqa: E402


def load_dotenv(path: str = ".env") -> int:
    """Tiny KEY=VALUE loader (no python-dotenv dependency). Shell wins."""
    n = 0
    try:
        with open(path, "r", encoding="utf-8") as fh:
            for raw in fh:
                line = raw.strip()
                if not line or line.startswith("#") or "=" not in line:
                    continue
                key, _, value = line.partition("=")
                key = key.strip()
                value = value.strip().strip('"').strip("'")
                os.environ.setdefault(key, value)
                n += 1
    except FileNotFoundError:
        pass
    return n


def _cleanup_worker(db_path: str):
    """Mark expired keys revoked (DB + Xray config via the CLI template)."""
    from bot import keygen

    while True:
        try:
            for k in db.expired_keys(db_path):
                db.revoke_key(db_path, k["id"])
                try:
                    keygen.revoke_client(k["label"])
                except Exception:  # pragma: no cover - vshop may be absent
                    pass
                logging.info("cleaned expired key id=%s label=%s", k["id"], k["label"])
        except Exception:  # pragma: no cover - sqlite restarts etc.
            logging.exception("cleanup workeriteration failed")
        time.sleep(600)


def _start_dashboard(db_path: str):
    """Start the stdlib admin dashboard in a daemon thread (best-effort)."""
    try:
        from web.app import serve_forever

        t = threading.Thread(
            target=serve_forever,
            kwargs={"db_path": db_path, "host": cfg.WEB_HOST, "port": cfg.WEB_PORT},
            daemon=True,
        )
        t.start()
        logging.info("dashboard on http://%s:%s/?token=<ADMIN_TOKEN>", cfg.WEB_HOST, cfg.WEB_PORT)
        return t
    except Exception:  # pragma: no cover
        logging.exception("dashboard start failed — continuing without web UI")
        return None


async def main() -> int:
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s %(levelname)s %(name)s: %(message)s",
    )
    log = logging.getLogger("vpn-bot")

    if not cfg.BOT_TOKEN:
        print("BOT_TOKEN is empty. Copy .env.example to .env and set your token.", file=sys.stderr)
        return 2
    if not cfg.ADMIN_IDS:
        print("ADMIN_IDS is empty — admin commands will not work.", file=sys.stderr)

    db.init_db(cfg.DB_PATH)
    log.info("db ready: %s", cfg.DB_PATH)

    _start_dashboard(cfg.DB_PATH)
    threading.Thread(target=_cleanup_worker, args=(cfg.DB_PATH,), daemon=True).start()

    # aiogram machinery is imported lazily so that config/db/web stay testable
    from aiogram import Bot, Dispatcher
    from bot import handlers

    bot = Bot(token=cfg.BOT_TOKEN)
    dp = Dispatcher()
    dp.include_router(handlers.router)   # buyer flow
    dp.include_router(handlers.admin)    # admin commands (IsAdmin-filtered)

    log.info("polling started — sending /start to the bot from your admin account")
    try:
        await dp.start_polling(bot, allowed_updates=dp.resolve_used_update_types())
    finally:
        await bot.session.close()
    return 0


if __name__ == "__main__":
    load_dotenv()
    raise SystemExit(asyncio.run(main()))
