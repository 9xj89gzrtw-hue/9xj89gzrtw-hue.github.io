"""bot/keygen.py — vless:// key building, validation and issuance helpers.

Pure stdlib. Three jobs:
  1. build_vless_url() — assemble a correct VLESS-Reality share URL;
  2. validate_vless_url() — assert the URL is well-formed (used in tests);
  3. issue_client() / revoke_client() — drive the local management CLI
     (vshop.sh) through a configurable command template, e.g.:
         KEY_ISSUE_COMMAND="/usr/local/bin/vshop.sh add-user {name}"
     For remote servers the template can be anything executable,
     e.g. "ssh root@vps /usr/local/bin/vshop.sh add-user {name}".

The CLI contract: a successful command prints a line `VLESS_URL=vless://...`.
"""
from __future__ import annotations

import os
import re
import shlex
import subprocess
import uuid as _uuid
from typing import Any, Dict, Optional
from urllib.parse import parse_qs, urlparse

VPN_SCHEME = "vless"
UUID_RE = re.compile(
    r"^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$", re.I
)
DEFAULT_FP = "chrome"
DEFAULT_FLOW = "xtls-rprx-vision"
NAME_RE = re.compile(r"^[A-Za-z0-9_.-]{1,32}$")

VLESS_URL_LINE = re.compile(r"^VLESS_URL=(vless://\S+)\s*$", re.M)

# ------------------------------------------------------------------ validators
def new_uuid() -> str:
    return str(_uuid.uuid4())


def sanitize_username(raw: str) -> str:
    """Make a Telegram id / arbitrary string safe as a client label."""
    cleaned = re.sub(r"[^A-Za-z0-9_.-]", "_", str(raw or "")).strip("._-")
    if not cleaned:
        cleaned = "user"
    return cleaned[:32]


def valid_name(name: str) -> bool:
    return bool(NAME_RE.match(name or ""))


def build_vless_url(
    uuid_: str,
    host: str,
    port: int,
    sni: str,
    pbk: str,
    sid: str,
    fp: str = DEFAULT_FP,
    flow: str = DEFAULT_FLOW,
    name: str = "user",
    net_type: str = "tcp",
) -> str:
    """Build a full VLESS + Reality share URL.

    Canonical shape (order of query keys is not significant to clients):
    vless://<uuid>@<host>:<port>?type=tcp&security=reality&encryption=none
      &pbk=<pubkey>&fp=chrome&sid=<short-id>&sni=<sni>&flow=xtls-rprx-vision#<name>
    """
    if not UUID_RE.match(uuid_ or ""):
        raise ValueError(f"bad client UUID: {uuid_!r}")
    if not host:
        raise ValueError("host is required")
    if not isinstance(port, int) or not (0 < port < 65536):
        raise ValueError(f"bad port: {port!r}")
    if not sni or not pbk or not sid:
        raise ValueError("sni, pbk and sid are required for reality")
    query = (
        f"type={net_type}"
        f"&security=reality"
        f"&encryption=none"
        f"&pbk={pbk}"
        f"&fp={fp}"
        f"&sid={sid}"
        f"&sni={sni}"
    )
    if flow:
        query += f"&flow={flow}"
    return f"vless://{uuid_}@{host}:{port}?{query}#{name}"


def validate_vless_url(url: str, strict: bool = True) -> Dict[str, Any]:
    """Parse and validate a VLESS-Reality URL; return the important parts.

    strict=True additionally requires type=tcp, fp, flow=xtls-rprx-vision —
    the exact shape our generator emits.
    Raises ValueError on any malformed component.
    """
    if not url or not url.startswith(VPN_SCHEME + "://"):
        raise ValueError(f"not a vless url: {url[:32]!r}")
    parsed = urlparse(url)
    if parsed.scheme != VPN_SCHEME:
        raise ValueError(f"unexpected scheme: {parsed.scheme}")
    if "@" not in (parsed.netloc or ""):
        raise ValueError("missing '@' (uuid@host:port expected)")
    user, _, hostport = parsed.netloc.rpartition("@")
    if not UUID_RE.match(user or ""):
        raise ValueError(f"bad uuid: {user!r}")
    host, sep, port = hostport.partition(":")
    if not host or not sep:
        raise ValueError(f"bad host:port: {hostport!r}")
    try:
        port_i = int(port)
    except ValueError:
        raise ValueError(f"non-numeric port: {port!r}") from None
    if not (0 < port_i < 65536):
        raise ValueError(f"port out of range: {port_i}")

    q = {k: v[0] for k, v in parse_qs(parsed.query, keep_blank_values=True).items()}
    for key in ("security", "pbk", "sid", "sni"):
        if not q.get(key):
            raise ValueError(f"missing query param: {key}")
    if q["security"] != "reality":
        raise ValueError(f"security must be 'reality', got {q['security']!r}")
    if strict:
        if q.get("type") != "tcp":
            raise ValueError(f"type must be 'tcp', got {q.get('type')!r}")
        if not q.get("fp"):
            raise ValueError("fp is required (chrome)")
        if q.get("flow") != DEFAULT_FLOW:
            raise ValueError(f"flow must be '{DEFAULT_FLOW}', got {q.get('flow')!r}")
    return {
        "uuid": user,
        "host": host,
        "port": port_i,
        "name": parsed.fragment,
        "params": q,
    }


# --------------------------------------------------------------------- state
def load_state(path: Optional[str] = None) -> Dict[str, str]:
    """Parse a flat KEY=VALUE shell state file (as written by server/install.sh)."""
    path = path or os.getenv("VSHOP_STATE", "/etc/vshop/state.env")
    out: Dict[str, str] = {}
    try:
        with open(path, "r", encoding="utf-8") as fh:
            for line in fh:
                line = line.strip()
                if not line or line.startswith("#") or "=" not in line:
                    continue
                key, _, value = line.partition("=")
                out[key.strip()] = value.strip().strip('"').strip("'")
    except FileNotFoundError:
        pass
    return out


def build_url_from_state(state: Dict[str, str], name: str, uuid_: Optional[str] = None) -> str:
    """Convenience: build a URL straight from the installer state file."""
    uuid_ = uuid_ or new_uuid()
    host = state.get("HOST", "127.0.0.1")
    port = int(state.get("PORT", "443"))
    return build_vless_url(
        uuid_=uuid_,
        host=host,
        port=port,
        sni=state.get("SNI_NAME", "www.microsoft.com"),
        pbk=state.get("PUB_KEY", ""),
        sid=state.get("SHORT_ID", ""),
        name=name,
    )


def is_expired(expires_at: str, now_iso: Optional[str] = None) -> bool:
    if not expires_at:
        return False  # lifetime key
    now_iso = now_iso or datetime_now_iso()
    return expires_at < now_iso  # ISO-8601 with same format sorts lexicographically


def datetime_now_iso() -> str:
    import datetime as _dt
    return _dt.datetime.now(_dt.timezone.utc).isoformat(timespec="seconds")


# ------------------------------------------------------------------- issuance
def _run_template(template: str, name: str, timeout: int = 30) -> str:
    """Expand {name} in the command template and execute it; return stdout."""
    if not template:
        raise RuntimeError("empty issuance command template")
    if not valid_name(name):
        raise RuntimeError(f"unsafe client name: {name!r}")
    cmd = template.format(name=shlex.quote(name)) if "{name}" in template else f"{template} {shlex.quote(name)}"
    argv = shlex.split(cmd)
    proc = subprocess.run(
        argv,
        capture_output=True,
        text=True,
        timeout=timeout,
        check=False,
    )
    tail = (proc.stderr or "").strip().splitlines()[-3:]
    if proc.returncode != 0:
        raise RuntimeError(
            f"command failed (rc={proc.returncode}): {' '.join(argv)} :: "
            + " | ".join(tail)
        )
    return proc.stdout or ""


def parse_vless_line(output: str) -> str:
    """Extract the VLESS_URL= line emitted by the CLI."""
    m = VLESS_URL_LINE.search(output or "")
    if not m:
        raise RuntimeError("CLI output has no VLESS_URL= line")
    return m.group(1)


def issue_client(name: str, template: Optional[str] = None) -> Dict[str, Any]:
    """Register a client on the Xray server and return {"url": ..., "uuid": ...}."""
    name = sanitize_username(name)
    template = template or os.getenv(
        "KEY_ISSUE_COMMAND", "/usr/local/bin/vshop.sh add-user {name}"
    )
    out = _run_template(template, name)
    url = parse_vless_line(out)
    info = validate_vless_url(url)
    return {"url": url, "uuid": info["uuid"], "host": info["host"], "port": info["port"]}


def revoke_client(name: str, template: Optional[str] = None) -> bool:
    """Remove a client from the Xray server via the revoke command template."""
    name = sanitize_username(name)
    template = template or os.getenv(
        "KEY_REVOKE_COMMAND", "/usr/local/bin/vshop.sh revoke-user {name}"
    )
    _run_template(template, name)
    return True
