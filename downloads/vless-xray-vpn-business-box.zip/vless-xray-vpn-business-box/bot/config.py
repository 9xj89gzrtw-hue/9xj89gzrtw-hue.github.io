"""bot/config.py — environment-driven configuration for the Telegram VPN bot.

All secrets and tunables come from the process environment (see .env.example).
Nothing here contains real credentials: defaults are placeholders only.
"""
from __future__ import annotations

import json
import os
from typing import Dict

# --------------------------------------------------------------------- util
def _get(name: str, default: str = "") -> str:
    """String env var with a default (whitespace-trimmed)."""
    return (os.getenv(name) or default).strip()


def _get_bool(name: str, default: bool = False) -> bool:
    raw = _get(name, "true" if default else "false").lower()
    return raw in ("1", "true", "yes", "on")


def _get_int(name: str, default: int = 0) -> int:
    raw = _get(name, "")
    try:
        return int(raw)
    except ValueError:
        return default


def parse_admin_ids(raw: str):
    """ADMIN_IDS="111,222" -> frozenset({111, 222})."""
    ids = set()
    for chunk in raw.replace(";", ",").split(","):
        chunk = chunk.strip()
        if not chunk:
            continue
        try:
            ids.add(int(chunk))
        except ValueError:
            continue
    return frozenset(ids)


# ------------------------------------------------------------------ identity
BOT_TOKEN = _get("BOT_TOKEN")
ADMIN_IDS = parse_admin_ids(_get("ADMIN_IDS"))
DB_PATH = _get("DB_PATH", "data/bot.sqlite3")
SUPPORT_USERNAME = _get("SUPPORT_USERNAME", "@your_support")

# --------------------------------------------------------------- payment rails
# Manual RUB transfer: free text shown to the buyer (card / SBP details).
PAY_RUB_INFO = _get(
    "PAY_RUB_INFO",
    "Реквизиты не настроены — задайте PAY_RUB_INFO в .env",
)
STARS_ENABLED = _get_bool("STARS_ENABLED", True)

# USDT TRC20 wallet shown to the buyer (the admin confirms transfers manually).
USDT_WALLET_TRC20 = _get("USDT_WALLET_TRC20")

# --------------------------------------------------------------- key issuance
# Template for the shell command that registers a VLESS client on the local
# Xray instance. {name} is replaced by a sanitized username like  u123456_42.
# Default works when the bot runs on the same VPS as server/install.sh and the
# CLI was installed to /usr/local/bin/vshop.sh.
KEY_ISSUE_COMMAND = _get("KEY_ISSUE_COMMAND", "/usr/local/bin/vshop.sh add-user {name}")
KEY_REVOKE_COMMAND = _get("KEY_REVOKE_COMMAND", "/usr/local/bin/vshop.sh revoke-user {name}")
VSHOP_STATE = _get("VSHOP_STATE", "/etc/vshop/state.env")

# ------------------------------------------------------------------- pricing
DEFAULT_PLANS: Dict[str, dict] = {
    "7": {"title": "VPN на 7 дней", "days": 7, "rub": 199, "stars": 99, "usdt": 2.5},
    "30": {"title": "VPN на 30 дней", "days": 30, "rub": 499, "stars": 249, "usdt": 5.9},
}


def load_plans(raw: str | None = None) -> Dict[str, dict]:
    """Load VPN_PLANS from env JSON; fall back to DEFAULT_PLANS on any error.

    Shape: {"7": {"title": "..", "days": 7, "rub": 199, "stars": 99, "usdt": 2.5}, ...}
    This is the "авторский" pricing hook: a seller redefines plans in .env
    without touching the code.
    """
    raw = raw if raw is not None else _get("VPN_PLANS")
    if not raw:
        return {k: dict(v) for k, v in DEFAULT_PLANS.items()}
    try:
        data = json.loads(raw)
        plans = {}
        for pid, p in data.items():
            plans[str(pid)] = {
                "title": str(p.get("title", f"VPN ({pid})")),
                "days": int(p.get("days", 30)),
                "rub": float(p.get("rub", 0)),
                "stars": int(p.get("stars", 0)),
                "usdt": float(p.get("usdt", 0)),
            }
        return plans or {k: dict(v) for k, v in DEFAULT_PLANS.items()}
    except (json.JSONDecodeError, TypeError, ValueError):
        return {k: dict(v) for k, v in DEFAULT_PLANS.items()}


PLANS = load_plans()

# ------------------------------------------------------------------ dashboard
ADMIN_TOKEN = _get("ADMIN_TOKEN")
WEB_HOST = _get("WEB_HOST", "127.0.0.1")
WEB_PORT = _get_int("WEB_PORT", 8080)
