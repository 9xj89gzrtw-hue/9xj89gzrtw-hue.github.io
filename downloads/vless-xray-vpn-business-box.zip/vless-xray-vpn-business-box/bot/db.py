"""bot/db.py — SQLite storage (stdlib sqlite3) for the VPN sales bot.

Tables: users, orders, payments, keys.
The order state machine is explicit and validated:

    new ──▶ awaiting_approval ──▶ paid ──▶ issued
      │            │              │
      └──────────▶ cancelled ◀─────┘
      (new ▶ paid is allowed for instant rails like Telegram Stars)

Connections are short-lived (open/commit/close per operation): cheap for
SQLite, zaps no locks across async turns and crashes safely.
"""
from __future__ import annotations

import os
import sqlite3
from contextlib import contextmanager
from datetime import datetime, timedelta, timezone
from typing import Any, Dict, List, Optional

# ---------------------------------------------------------------- state machine
STATUSES = ("new", "awaiting_approval", "paid", "issued", "cancelled")

ALLOWED_TRANSITIONS: Dict[str, set] = {
    "new": {"awaiting_approval", "paid", "cancelled"},
    "awaiting_approval": {"paid", "cancelled"},
    "paid": {"issued", "cancelled"},
    "issued": set(),
    "cancelled": set(),
}


def transition(current: str, target: str) -> str:
    """Validate a status change; raise ValueError on an illegal transition."""
    if current not in ALLOWED_TRANSITIONS:
        raise ValueError(f"unknown status: {current!r}")
    if target not in ALLOWED_TRANSITIONS:
        raise ValueError(f"unknown status: {target!r}")
    if target not in ALLOWED_TRANSITIONS[current]:
        raise ValueError(f"transition {current!r} -> {target!r} is not allowed")
    return target


# --------------------------------------------------------------------- helpers
def utcnow() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def iso_in_days(days: int) -> str:
    """Expiry timestamp `days` from now (or '' for a lifetime key when days<=0)."""
    if days is None or int(days) <= 0:
        return ""
    return (datetime.now(timezone.utc) + timedelta(days=int(days))).isoformat(timespec="seconds")


@contextmanager
def _db(path: str):
    """Yield a committed sqlite3 connection; always close; rollback on error."""
    c = sqlite3.connect(path, timeout=15)
    c.row_factory = sqlite3.Row
    try:
        c.execute("PRAGMA journal_mode=WAL")
        yield c
        c.commit()
    except Exception:
        c.rollback()
        raise
    finally:
        c.close()


def _rows(cursor: sqlite3.Cursor) -> List[Dict[str, Any]]:
    cols = [d[0] for d in cursor.description]
    return [dict(zip(cols, r)) for r in cursor.fetchall()]


def init_db(path: str) -> None:
    """Create tables/indexes; safe to call repeatedly."""
    parent = os.path.dirname(os.path.abspath(path))
    if parent:
        os.makedirs(parent, exist_ok=True)
    with _db(path) as c:
        c.executescript(
            """
            CREATE TABLE IF NOT EXISTS users (
                tg_id      INTEGER PRIMARY KEY,
                username   TEXT    NOT NULL DEFAULT '',
                first_name TEXT    NOT NULL DEFAULT '',
                created_at TEXT    NOT NULL,
                last_seen  TEXT    NOT NULL DEFAULT ''
            );
            CREATE TABLE IF NOT EXISTS orders (
                id           INTEGER PRIMARY KEY AUTOINCREMENT,
                tg_id        INTEGER NOT NULL,
                plan         TEXT    NOT NULL,
                amount_rub   REAL    NOT NULL DEFAULT 0,
                amount_stars INTEGER NOT NULL DEFAULT 0,
                amount_usdt  REAL    NOT NULL DEFAULT 0,
                method       TEXT    NOT NULL DEFAULT '',
                status       TEXT    NOT NULL DEFAULT 'new',
                created_at   TEXT    NOT NULL,
                paid_at      TEXT    NOT NULL DEFAULT '',
                issued_at    TEXT    NOT NULL DEFAULT ''
            );
            CREATE INDEX IF NOT EXISTS idx_orders_tg   ON orders(tg_id);
            CREATE INDEX IF NOT EXISTS idx_orders_stat ON orders(status);
            CREATE TABLE IF NOT EXISTS payments (
                id          INTEGER PRIMARY KEY AUTOINCREMENT,
                order_id    INTEGER NOT NULL,
                tg_id       INTEGER NOT NULL,
                method      TEXT    NOT NULL,
                external_id TEXT    NOT NULL DEFAULT '',
                amount      TEXT    NOT NULL DEFAULT '',
                created_at  TEXT    NOT NULL
            );
            CREATE TABLE IF NOT EXISTS keys (
                id         INTEGER PRIMARY KEY AUTOINCREMENT,
                tg_id      INTEGER NOT NULL,
                order_id   INTEGER,
                label      TEXT    NOT NULL,
                vless_url  TEXT    NOT NULL,
                created_at TEXT    NOT NULL,
                expires_at TEXT    NOT NULL DEFAULT '',
                revoked    INTEGER NOT NULL DEFAULT 0,
                source     TEXT    NOT NULL DEFAULT 'order'
            );
            CREATE INDEX IF NOT EXISTS idx_keys_tg ON keys(tg_id);
            """
        )


# ----------------------------------------------------------------------- users
def upsert_user(path: str, tg_id: int, username: str = "", first_name: str = "") -> None:
    now = utcnow()
    with _db(path) as c:
        c.execute(
            """
            INSERT INTO users (tg_id, username, first_name, created_at, last_seen)
            VALUES (?, ?, ?, ?, ?)
            ON CONFLICT(tg_id) DO UPDATE SET
                username=excluded.username,
                first_name=excluded.first_name,
                last_seen=excluded.last_seen
            """,
            (int(tg_id), username or "", first_name or "", now, now),
        )


def get_user(path: str, tg_id: int) -> Optional[Dict[str, Any]]:
    with _db(path) as c:
        rows = _rows(c.execute("SELECT * FROM users WHERE tg_id = ?", (int(tg_id),)))
    return rows[0] if rows else None


def count_users(path: str) -> int:
    with _db(path) as c:
        return int(c.execute("SELECT COUNT(*) FROM users").fetchone()[0])


# ---------------------------------------------------------------------- orders
def create_order(
    path: str,
    tg_id: int,
    plan: str,
    amount_rub: float = 0.0,
    amount_stars: int = 0,
    amount_usdt: float = 0.0,
    method: str = "",
) -> int:
    with _db(path) as c:
        cur = c.execute(
            """
            INSERT INTO orders
                (tg_id, plan, amount_rub, amount_stars, amount_usdt, method, status, created_at)
            VALUES (?, ?, ?, ?, ?, ?, 'new', ?)
            """,
            (int(tg_id), str(plan), float(amount_rub), int(amount_stars),
             float(amount_usdt), method, utcnow()),
        )
        return int(cur.lastrowid)


def get_order(path: str, order_id: int) -> Optional[Dict[str, Any]]:
    with _db(path) as c:
        rows = _rows(c.execute("SELECT * FROM orders WHERE id = ?", (int(order_id),)))
    return rows[0] if rows else None


def list_orders(path: str, limit: int = 20, status: Optional[str] = None) -> List[Dict[str, Any]]:
    q = "SELECT * FROM orders"
    args: List[Any] = []
    if status:
        q += " WHERE status = ?"
        args.append(status)
    q += " ORDER BY id DESC LIMIT ?"
    args.append(int(limit))
    with _db(path) as c:
        return _rows(c.execute(q, args))


def list_pending(path: str, limit: int = 50) -> List[Dict[str, Any]]:
    """Orders waiting for manual money confirmation (RUB transfer / USDT)."""
    with _db(path) as c:
        return _rows(
            c.execute(
                """
                SELECT * FROM orders
                WHERE status IN ('new', 'awaiting_approval')
                ORDER BY id ASC LIMIT ?
                """,
                (int(limit),),
            )
        )


def set_order_status(path: str, order_id: int, target: str) -> int:
    """Move order to `target` with transition validation; returns rows changed.

    Raises LookupError for missing orders and ValueError for illegal moves.
    """
    with _db(path) as c:
        rows = _rows(c.execute("SELECT status FROM orders WHERE id = ?", (int(order_id),)))
        if not rows:
            raise LookupError(f"order {order_id} not found")
        transition(rows[0]["status"], target)
        now = utcnow()
        if target == "paid":
            cur = c.execute(
                "UPDATE orders SET status='paid', paid_at=? WHERE id=?",
                (now, int(order_id)),
            )
        elif target == "issued":
            cur = c.execute(
                "UPDATE orders SET status='issued', issued_at=? WHERE id=?",
                (now, int(order_id)),
            )
        else:
            cur = c.execute(
                "UPDATE orders SET status=? WHERE id=?",
                (target, int(order_id)),
            )
        return int(cur.rowcount)


# -------------------------------------------------------------------- payments
def record_payment(
    path: str,
    order_id: int,
    tg_id: int,
    method: str,
    external_id: str = "",
    amount: str = "",
) -> int:
    with _db(path) as c:
        cur = c.execute(
            """
            INSERT INTO payments (order_id, tg_id, method, external_id, amount, created_at)
            VALUES (?, ?, ?, ?, ?, ?)
            """,
            (int(order_id), int(tg_id), method, external_id, amount, utcnow()),
        )
        return int(cur.lastrowid)


# ------------------------------------------------------------------------ keys
def add_key(
    path: str,
    tg_id: int,
    order_id: Optional[int],
    label: str,
    vless_url: str,
    days: int = 0,
    source: str = "order",
) -> int:
    """Register a key row; days<=0 means lifetime key."""
    expires = iso_in_days(int(days))
    with _db(path) as c:
        cur = c.execute(
            """
            INSERT INTO keys (tg_id, order_id, label, vless_url, created_at, expires_at, source)
            VALUES (?, ?, ?, ?, ?, ?, ?)
            """,
            (int(tg_id), None if order_id is None else int(order_id),
             label, vless_url, utcnow(), expires, source),
        )
        return int(cur.lastrowid)


def get_key(path: str, key_id: int) -> Optional[Dict[str, Any]]:
    with _db(path) as c:
        rows = _rows(c.execute("SELECT * FROM keys WHERE id = ?", (int(key_id),)))
    return rows[0] if rows else None


def list_keys(path: str, tg_id: Optional[int] = None, active_only: bool = True) -> List[Dict[str, Any]]:
    q = "SELECT * FROM keys"
    args: List[Any] = []
    where: List[str] = []
    if tg_id is not None:
        where.append("tg_id = ?")
        args.append(int(tg_id))
    if active_only:
        where.append("revoked = 0")
    if where:
        q += " WHERE " + " AND ".join(where)
    q += " ORDER BY id DESC"
    with _db(path) as c:
        return _rows(c.execute(q, args))


def revoke_key(path: str, key_id: int) -> bool:
    with _db(path) as c:
        cur = c.execute(
            "UPDATE keys SET revoked = 1 WHERE id = ? AND revoked = 0", (int(key_id),)
        )
        return int(cur.rowcount) > 0


def revoke_keys_by_tg(path: str, tg_id: int) -> List[Dict[str, Any]]:
    """Mark all active keys of a user revoked; returns the affected rows."""
    with _db(path) as c:
        rows = _rows(
            c.execute("SELECT * FROM keys WHERE tg_id = ? AND revoked = 0", (int(tg_id),))
        )
        if rows:
            c.execute("UPDATE keys SET revoked = 1 WHERE tg_id = ?", (int(tg_id),))
    return rows


def count_active_keys(path: str) -> int:
    with _db(path) as c:
        return int(
            c.execute(
                """
                SELECT COUNT(*) FROM keys
                WHERE revoked = 0 AND (expires_at = '' OR expires_at > ?)
                """,
                (utcnow(),),
            ).fetchone()[0]
        )


def expired_keys(path: str, now_iso: Optional[str] = None) -> List[Dict[str, Any]]:
    """Active keys whose expiry has passed (consumed by the cleanup worker)."""
    with _db(path) as c:
        return _rows(
            c.execute(
                """
                SELECT * FROM keys
                WHERE revoked = 0 AND expires_at != '' AND expires_at < ?
                """,
                (now_iso or utcnow(),),
            )
        )
