"""web/app.py — admin web dashboard for the VPN business box.

Pure stdlib (http.server + sqlite3): zero extra dependencies, runs in a
daemon thread started by bot/bot.py or standalone:

    python3 -m web.app --db data/bot.sqlite3 --port 8080

Auth: every request must carry the ADMIN token, either as
`?token=<ADMIN_TOKEN>` or header `X-Admin-Token: <ADMIN_TOKEN>`.
Routes:
    GET /                -> web/index.html (dashboard, single file, dark)
    GET /api/summary     -> JSON: users, active keys, orders by state, revenue
    GET /health          -> {"ok": true} (auth-free, for watchdogs)
"""
from __future__ import annotations

import argparse
import json
import sqlite3
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import parse_qs, urlparse

ROOT = Path(__file__).resolve().parent.parent

# --------------------------------------------------------------------- model
def summary(db_path: str) -> dict:
    """The numbers the dashboard shows; a pure function of the sqlite DB."""
    out = {
        "users": 0,
        "keys_active": 0,
        "orders": {"new": 0, "awaiting_approval": 0, "paid": 0, "issued": 0, "cancelled": 0},
        "revenue": {"rub": 0.0, "stars": 0, "usdt": 0.0},
        "latest_orders": [],
    }
    c = sqlite3.connect(f"file:{db_path}?mode=ro", uri=True, timeout=5)
    c.row_factory = sqlite3.Row
    try:
        out["users"] = int(c.execute("SELECT COUNT(*) FROM users").fetchone()[0])
        import datetime as _dt
        now_iso = _dt.datetime.now(_dt.timezone.utc).isoformat(timespec="seconds")
        row = c.execute(
            """
            SELECT COUNT(*) AS n FROM keys
            WHERE revoked = 0 AND (expires_at = '' OR expires_at > ?)
            """,
            (now_iso,),
        ).fetchone()
        out["keys_active"] = int(row["n"])

        for r in c.execute("SELECT status, COUNT(*) AS n FROM orders GROUP BY status"):
            if r["status"] in out["orders"]:
                out["orders"][r["status"]] = int(r["n"])

        # revenue from paid-or-further orders
        rev = c.execute(
            """
            SELECT COALESCE(SUM(amount_rub), 0)   AS rub,
                   COALESCE(SUM(amount_stars), 0) AS stars,
                   COALESCE(SUM(amount_usdt), 0)  AS usdt
            FROM orders WHERE status IN ('paid', 'issued')
            """
        ).fetchone()
        out["revenue"] = {
            "rub": float(rev["rub"]),
            "stars": int(rev["stars"]),
            "usdt": float(rev["usdt"]),
        }

        rows = c.execute(
            """
            SELECT o.id, o.tg_id, o.plan, o.method, o.status, o.amount_rub,
                   o.amount_stars, o.amount_usdt, o.created_at
            FROM orders o ORDER BY o.id DESC LIMIT 10
            """
        ).fetchall()
        out["latest_orders"] = [dict(r) for r in rows]
    finally:
        c.close()
    return out


def _token_ok(handler: BaseHTTPRequestHandler, expected: str, query) -> bool:
    if not expected:
        return True  # no ADMIN_TOKEN configured -> open dashboard on localhost
    given = (query.get("token", [""])[0]
             or handler.headers.get("X-Admin-Token", "")
             or _bearer(handler.headers.get("Authorization", "")))
    return str(given) == str(expected)


def _bearer(value: str) -> str:
    return value[7:].strip() if value.lower().startswith("bearer ") else ""


# -------------------------------------------------------------------- server
def make_handler(db_path: str, admin_token: str):
    """Build a request factory bound to this DB path and token."""
    index = Path(__file__).resolve().parent / "index.html"
    index_bytes = index.read_bytes() if index.exists() else b"<!doctype html><h1>dashboard missing web/index.html</h1>"

    class Handler(BaseHTTPRequestHandler):
        def _send(self, code, body: bytes, ctype: str):
            self.send_response(code)
            self.send_header("Content-Type", ctype)
            self.send_header("Content-Length", str(len(body)))
            self.send_header("Cache-Control", "no-store")
            self.end_headers()
            self.wfile.write(body)

        def do_GET(self):
            u = urlparse(self.path)
            q = parse_qs(u.query)
            if u.path == "/health":
                self._send(200, b'{"ok": true}', "application/json")
                return
            if not _token_ok(self, admin_token, q):
                self._send(401, b'{"error":"unauthorized"}', "application/json")
                return
            if u.path == "/":
                self._send(200, index_bytes, "text/html; charset=utf-8")
                return
            if u.path == "/api/summary":
                try:
                    body = json.dumps(summary(db_path), ensure_ascii=False).encode()
                except Exception as exc:  # never crash the dashboard on bad DB
                    body = json.dumps({"error": f"{type(exc).__name__}: {exc}"}).encode()
                    self._send(500, body, "application/json")
                    return
                self._send(200, body, "application/json")
                return
            self._send(404, b'{"error":"not found"}', "application/json")

        def log_message(self, *args):  # quieter launchd-friendly logs
            pass

    return Handler


def serve_forever(db_path: str, host: str = "127.0.0.1", port: int = 8080,
                  admin_token: str = "") -> None:
    admin_token = admin_token or os_token()
    httpd = ThreadingHTTPServer((host, int(port)), make_handler(db_path, admin_token))
    httpd.serve_forever(poll_interval=0.25)


def os_token() -> str:
    from bot import config as cfg
    return cfg.ADMIN_TOKEN


def main() -> None:
    ap = argparse.ArgumentParser(description="VPN-box admin dashboard (stdlib only)")
    ap.add_argument("--db", default="data/bot.sqlite3")
    ap.add_argument("--host", default="127.0.0.1")
    ap.add_argument("--port", type=int, default=8080)
    ap.add_argument("--token", default="")
    a = ap.parse_args()
    print(f"dashboard on http://{a.host}:{a.port}/  (db = {a.db})")
    serve_forever(a.db, a.host, a.port, a.token)


if __name__ == "__main__":
    main()
