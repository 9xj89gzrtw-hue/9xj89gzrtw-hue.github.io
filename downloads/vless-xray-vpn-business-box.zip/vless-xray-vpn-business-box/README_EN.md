# Personal VPN Business in a Box — Xray VLESS Reality + Telegram Sales Bot + Admin Dashboard

> **Screenshots of the running UI:** folder [`screenshots/`](screenshots/) —
> `01-dashboard-day.png`, `02-dashboard-week.png`, `03-dashboard-month.png`
> (web admin panel in three demo states, 1280×800).

A complete turnkey package: turn **any VPS of yours** (Ubuntu 22.04/24.04, 1 vCPU/1 GB) into a
**VLESS + Reality (Xray-core) VPN server** in about 5 minutes, add a **Telegram sales bot** that
**sells VPN keys automatically** (RUB / Telegram Stars / USDT TRC20), issues the buyer a ready
**`vless://` link + QR code** right after payment, and monitor everything from a **local web
admin dashboard** (users, keys, orders, revenue).

> An honest note about "uncensorable": the Reality + VLESS stack mimics regular HTTPS/TLS against
> DPI and is the strongest mainstream option of 2026, but no vendor can guarantee a permanent
> future-proofness against new DPI engines. Keys are issued on a server with a masked SNI; from
> the wire's point of view the traffic looks like regular HTTPS.

## What's inside

| Folder | What it is |
|---|---|
| `server/` | `install.sh` (~2-minute Xray+Reality setup), `uninstall.sh`, CLI `vshop.sh` (add-user / list-users / revoke-user / show-config / status) |
| `bot/` | Telegram bot on **aiogram 3**: sales flow, RUB/Stars/USDT rails, automatic key issuance + QR admin commands, automatic expired-key cleaner |
| `web/` | Admin dashboard on **pure Python stdlib** (http.server): users, active keys, orders by state, revenue per payment rail |
| `docker/` | Alternative deployment of the Xray server (docker-compose + Dockerfile) |
| `tests/` | **31 offline tests** (unittest, stdlib): generator/validator of the URL, order state-machine, SQLite store, HTTP dashboard |

## Requirements

- Ubuntu 22.04/24.04 (or Debian), root, 1 vCPU/1 GB — no domain and no TLS certificate needed (Reality does not need one)
- Python 3.10+ for the bot (installed automatically)
- A VPS in a place where your customers' connections work

## 5-minute install (single script)

```bash
# on a fresh root VPS:
unzip vless-xray-vpn-business-box.zip && cd vless-xray-vpn-business-box
sudo bash install-all.sh
```

The script (1) installs Xray-core with a systemd service and generates a fresh Reality keypair,
(2) creates a bot venv and copies the code to `/opt/vpn-box`, (3) registers the systemd unit
`telegram-vpn-bot.service`. It prints a banner and the 4 remaining manual steps at the end.

## Manual installation by parts

```bash
# 1) VPN server only:
bash server/install.sh                  # asks for port (443) and SNI (www.microsoft.com)

# 2) issue a key manually (without the bot):
vshop.sh add-user demo                  # prints VLESS_URL=vless://... (import into the client app)
vshop.sh list-users

# 3) the sales bot:
python3 -m venv .venv && .venv/bin/pip install -r requirements.txt
cp .env.example .env && $EDITOR .env    # BOT_TOKEN, ADMIN_IDS, PAY_RUB_INFO, VPN_PLANS
.venv/bin/python -m bot.bot             # dashboard on http://127.0.0.1:8080/?token=ADMIN_TOKEN
```

Docker variant for the server only: `cd docker && docker compose up -d` (VLESS on host networking).

## How the sales flow works (best practice)

1. The buyer chooses a plan in the bot (`VPN_PLANS` is editable from `.env`, no code changes).
2. Payment: **RUB** — bank transfer instructions from `PAY_RUB_INFO` + "I paid" button → the admin
   confirms with `/approve <order>`; **Stars** — Telegram invoice, issues automatically;
   **USDT TRC20** — wallet address from `USDT_WALLET_TRC20`, confirmed with the same `/approve`.
3. After approval the bot **runs `vshop.sh add-user` itself** (the command template is
   configurable — the bot may live on the same VPS or drive a remote one through an `ssh` template),
   reads `VLESS_URL=...` and sends the buyer the **link text + PNG QR code**.
4. Every 10 minutes the bot marks expired keys `revoked` and removes those clients from the Xray
   config — access self-expires without manual work.

## Admin bot commands

| Command | What it does |
|---|---|
| `/stats` | users, active keys, revenue per rail |
| `/orders` | last 20 orders |
| `/pending` | orders awaiting money confirmation |
| `/approve <id>` | confirm payment → the key is issued to the client automatically |
| `/grant <tg_id> [plan]` | issue a free key (friends/testers) |
| `/revoke <key id or tg_id>` | revoke access |

## Web dashboard

`http://127.0.0.1:8080/?token=<ADMIN_TOKEN>` — a dark-themed dashboard: users, active keys,
orders by state with bars, revenue (RUB/Stars/USDT), recent orders. It runs **in a thread inside
the bot process** (nothing to start separately); it is protected by `ADMIN_TOKEN` and served on
`127.0.0.1` only — do not expose it, use an SSH tunnel.

## Security hygiene (read before selling)

- The bot **never** exposes the Xray server's private keys: every buyer gets their own UUID client
  appended to the local config.
- Store `data/bot.sqlite3` next to the bot with `chmod 600`.
- This package is meant for **your own personal VPN** for family / small circle / invited clients.
  Respect your jurisdiction's laws and the Telegram Bot API rules.

## FAQ

- **Port 443 busy with nginx?** Set `PORT=8443` (or let nginx keep 443 and Reality on 2053).
- **Custom SNI.** Set `SNI_NAME=www.microsoft.com` (or another big CDN domain) — Reality masks
  the TLS handshake against the domain you pick.
- **Keys fail on iPhone?** Make sure the client app supports `xtls-rprx-vision` (v2rayNG ≥ 1.9.10,
  Streisand, Hiddify ≥ 2.0 — all do).
- **Bot registration:** `@BotFather` → `/newbot` → token into `BOT_TOKEN`. Your tg_id: `@userinfobot`.

## For resellers (Digiseller / Plati.Market / FunPay)

- Listing title: "Personal VPN business in a box: VLESS+Reality server in 5 minutes + Telegram
  sales bot (RUB/Stars/USDT) + admin dashboard".
- Price benchmark: 1 490 ₽. Be explicit that the buyer needs **their own VPS** (Ubuntu, root) —
  otherwise refunds pile up from customers without a server.
- Show the "what's in the archive" section + dashboard screenshots + bot screenshots; conversion
  typically grows 3–5×.

## Tests (built-in regression)

```bash
python3 -m tests.run                                   # 31 offline tests (stdlib only)
python3 -m venv .venv && .venv/bin/pip install -r requirements.txt
.venv/bin/python -m tests.run                          # + aiogram handlers smoke
bash -n server/*.sh                                    # bash script lint
```

## License

MIT (see LICENSE). Xray-core remains under its own upstream license.
