#!/usr/bin/env bash
# ============================================================================
# server/install.sh — turnkey VLESS-Reality (Xray-core) VPN server installer
#
# What it does:
#   1. Installs apt dependencies (curl, unzip, ca-certificates).
#   2. Downloads the pinned Xray-core release binary from GitHub.
#   3. Generates a REALITY keypair (`xray x25519`) and a short-id.
#   4. Writes /usr/local/etc/xray/config.json with a VLESS inbound.
#   5. Installs a systemd unit (xray.service) and enables + starts it.
#   6. Installs the management CLI `vshop.sh` to /usr/local/bin/vshop.sh.
#
# Environment overrides (all optional):
#   PORT=443                  inbound VLESS port
#   SNI_DEST="example.com:443" camouflaging Reality destination (default www.microsoft.com:443)
#   XRAY_VERSION="v25.3.6"    pinned Xray-core release tag
#   FORCE=1                   re-generate keys/UUID and rewrite config
#   VSHOP_SKIP_APT=1          skip apt (used by the Docker variant)
#   VSHOP_SYSTEMD=0           skip systemd unit (used by the Docker variant)
#
# Idempotent: safe to re-run. Existing keys are reused via /etc/vshop/state.env.
# The script never phones home except to GitHub releases and a public IP echo service.
# ============================================================================
set -euo pipefail

# ----------------------------------------------------------------- constants
XRAY_VERSION="${XRAY_VERSION:-v25.3.6}"
XRAY_BIN="/usr/local/bin/xray"
XRAY_SHARE="/usr/local/share/xray"
XRAY_DIR="/usr/local/etc/xray"
CONFIG_PATH="${XRAY_DIR}/config.json"
STATE_DIR="/etc/vshop"
STATE_FILE="${STATE_DIR}/state.env"
SYSTEMD_UNIT="/etc/systemd/system/xray.service"
VSHOP_BIN="/usr/local/bin/vshop.sh"
SERVICE_NAME="xray"
DEFAULT_CLIENT="default"

IN_PORT="${PORT:-443}"
SNI_DEST="${SNI_DEST:-www.microsoft.com:443}"
FORCE="${FORCE:-0}"
SKIP_APT="${VSHOP_SKIP_APT:-0}"
USE_SYSTEMD="${VSHOP_SYSTEMD:-1}"

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

# ------------------------------------------------------------------ helpers
info()  { printf '\033[1;32m==> %s\033[0m\n' "$*"; }
warn()  { printf '\033[1;33m[!] %s\033[0m\n' "$*"; }
die()   { printf '\033[1;31mERROR: %s\033[0m\n' "$*" >&2; exit 1; }

require_root() {
  [ "$(id -u)" -eq 0 ] || die "Run as root: sudo bash $0"
}

is_true() { [ "$1" = "1" ] || [ "$1" = "true" ]; }

is_base64url_43() {
  case "$1" in
    [A-Za-z0-9_-]*) [ "${#1}" -eq 43 ] && return 0 ;; # x25519 key is 43 chars base64url
  esac
  return 1
}

is_uuid() {
  case "$1" in
    [0-9a-f][0-9a-f][0-9a-f][0-9a-f][0-9a-f][0-9a-f][0-9a-f][0-9a-f]-*) ;;
    *) return 1 ;;
  esac
  [ "${#1}" -eq 36 ] && return 0 || return 1
}

detect_ipv4() {
  local ip=""
  ip="$(curl -4 -fsSm8 https://api.ipify.org 2>/dev/null || true)"
  if [ -z "$ip" ]; then
    ip="$(curl -4 -fsSm8 https://ifconfig.me 2>/dev/null || true)"
  fi
  if [ -z "$ip" ]; then
    ip="$(hostname -I 2>/dev/null | awk '{print $1}')"
  fi
  [ -n "$ip" ] || ip="127.0.0.1"
  echo "$ip"
}

normalize_sni() {
  # Accepts "hostname[:port]" or "https://hostname[:port]"; echoes DEST and SNI name.
  local raw="$1" dest="" name=""
  raw="${raw#https://}"; raw="${raw#http://}"; raw="${raw#/}"
  case "$raw" in
    *:*) name="${raw%%:*}"; dest="$raw" ;;
    *)   name="$raw";      dest="${raw}:443" ;;
  esac
  [ -n "$name" ] || die "Invalid SNI_DEST='$1'"
  echo "$dest $name"
}

gen_uuid() {
  # Prefer kernel UUID, fall back to xray uuid, then python3.
  if [ -r /proc/sys/kernel/random/uuid ]; then
    cat /proc/sys/kernel/random/uuid
  elif [ -x "$XRAY_BIN" ]; then
    "$XRAY_BIN" uuid
  else
    python3 -c 'import uuid; print(uuid.uuid4())'
  fi
}

# =============================================================== start work
require_root
info "vshop VPN installer — Xray-core ${XRAY_VERSION}"

# --- 0. apt dependencies ----------------------------------------------------
if ! is_true "$SKIP_APT"; then
  info "Installing apt dependencies..."
  apt-get update -y
  DEBIAN_FRONTEND=noninteractive apt-get install -y --no-install-recommends \
    curl unzip ca-certificates openssl python3
fi

# --- 1. Xray-core binary ----------------------------------------------------
if [ -x "$XRAY_BIN" ] && ! is_true "$FORCE"; then
  info "Xray binary already present at $XRAY_BIN — skipping download."
else
  ARCH="$(uname -m)"
  case "$ARCH" in
    x86_64|amd64)        ARTEFACT="Xray-linux-64.zip" ;;
    aarch64|arm64)       ARTEFACT="Xray-linux-arm64-v8a.zip" ;;
    *) die "Unsupported architecture: $ARCH (x86_64/arm64 only)" ;;
  esac
  URL="https://github.com/XTLS/Xray-core/releases/download/${XRAY_VERSION}/${ARTEFACT}"
  info "Downloading Xray-core ${XRAY_VERSION} (${ARTEFACT})..."
  TMPZIP="$(mktemp /tmp/xray-XXXXXX.zip)"
  curl -fsSL -o "$TMPZIP" "$URL" || die "Download failed: $URL (check tag / network)"
  mkdir -p /tmp/xray-unpack
  unzip -oq "$TMPZIP" -d /tmp/xray-unpack
  [ -f /tmp/xray-unpack/xray ] || die "Archive did not contain an xray binary"
  install -m 0755 /tmp/xray-unpack/xray "$XRAY_BIN"
  mkdir -p "$XRAY_SHARE"
  install -m 0644 /tmp/xray-unpack/geoip.dat "$XRAY_SHARE/geoip.dat" 2>/dev/null || true
  install -m 0644 /tmp/xray-unpack/geosite.dat "$XRAY_SHARE/geosite.dat" 2>/dev/null || true
  rm -rf /tmp/xray-unpack "$TMPZIP"
  info "Installed: $("$XRAY_BIN" version | head -n1)"
fi

# --- 2. Key material (idempotent via state file) ----------------------------
mkdir -p "$XRAY_DIR" "$STATE_DIR"
chmod 700 "$STATE_DIR"

REUSE_STATE=0
if [ -s "$STATE_FILE" ] && [ -f "$CONFIG_PATH" ] && ! is_true "$FORCE"; then
  # shellcheck disable=SC1090
  . "$STATE_FILE"
  if is_base64url_43 "${PRIV_KEY:-}" && is_base64url_43 "${PUB_KEY:-}" \
     && is_uuid "${CLIENT_UUID:-}" && [ -n "${SHORT_ID:-}" ]; then
    REUSE_STATE=1
    info "Existing state found in $STATE_FILE — reusing keys (FORCE=1 to re-generate)."
  fi
fi

if [ "$REUSE_STATE" = "1" ]; then
  info "Reusing existing keys from $STATE_FILE."
else
  info "Generating REALITY keypair (xray x25519)..."
  XOUT="$("$XRAY_BIN" x25519 || die "xray x25519 failed")"
  # Version-tolerant parsing: "Private key:", "PrivateKey:", "Password:" variants.
  PRIV_KEY="$(printf '%s\n' "$XOUT" | grep -Eio '(private[[:space:]]*key|privatekey|password)[^:]*:[[:space:]]*[A-Za-z0-9_-]{43}' | head -n1 | sed -E 's/.*:[[:space:]]*//')"
  PUB_KEY="$(printf '%s\n' "$XOUT"  | grep -Eio '(public[[:space:]]*key|publickey)[^:]*:[[:space:]]*[A-Za-z0-9_-]{43}' | head -n1 | sed -E 's/.*:[[:space:]]*//')"
  is_base64url_43 "$PRIV_KEY" || { echo "$XOUT"; die "Could not parse private key (see raw output above)"; }
  is_base64url_43 "$PUB_KEY"  || { echo "$XOUT"; die "Could not parse public key (see raw output above)"; }

  CLIENT_UUID="$(gen_uuid)"
  SHORT_ID="$(openssl rand -hex 8)"

  # Normalize the camouflaging destination: "host[:port]" -> DEST + bare name.
  read -r SNI_DEST_HOST SNI_DEST_NAME <<EOF2
$(normalize_sni "$SNI_DEST")
EOF2
  [ -n "$SNI_DEST_NAME" ] || die "SNI normalization failed"

  STATE_HOST="$(detect_ipv4)"
  cat > "$STATE_FILE" <<STATE
# vshop state — generated by server/install.sh on $(date -u +%Y-%m-%dT%H:%M:%SZ)
# CHANGING THESE VALUES INVALIDATES ALL CLIENT KEY LINKS.
PRIV_KEY="$PRIV_KEY"
PUB_KEY="$PUB_KEY"
CLIENT_UUID="$CLIENT_UUID"
SHORT_ID="$SHORT_ID"
PORT="$IN_PORT"
SNI_DEST="$SNI_DEST_HOST"
SNI_NAME="$SNI_DEST_NAME"
HOST="$STATE_HOST"
STATE
  chmod 600 "$STATE_FILE"
  info "State written to $STATE_FILE (chmod 600)."
fi

# Reusable values must be valid no matter which branch produced them.
[ -n "${SNI_DEST_NAME:-}" ] || SNI_DEST_NAME="${SNI_NAME:-www.microsoft.com}"

# --- 3. Write config.json ---------------------------------------------------
if [ -f "$CONFIG_PATH" ] && ! is_true "$FORCE"; then
  info "Config already exists at $CONFIG_PATH — leaving it untouched."
else
  info "Writing $CONFIG_PATH..."
  cat > "$CONFIG_PATH" <<JSON
{
  "log": { "loglevel": "warning" },
  "inbounds": [
    {
      "listen": "0.0.0.0",
      "port": ${IN_PORT},
      "protocol": "vless",
      "settings": {
        "clients": [
          {
            "id": "${CLIENT_UUID}",
            "flow": "xtls-rprx-vision",
            "email": "${DEFAULT_CLIENT}"
          }
        ],
        "decryption": "none"
      },
      "streamSettings": {
        "network": "tcp",
        "security": "reality",
        "realitySettings": {
          "show": false,
          "dest": "${SNI_DEST_HOST}",
          "xver": 0,
          "serverNames": ["${SNI_DEST_NAME}"],
          "privateKey": "${PRIV_KEY}",
          "shortIds": [ "${SHORT_ID}" ]
        }
      },
      "sniffing": {
        "enabled": true,
        "destOverride": ["http", "tls"]
      }
    }
  ],
  "outbounds": [
    { "protocol": "freedom", "tag": "direct" },
    { "protocol": "blackhole", "tag": "blocked", "settings": { "response": { "type": "http" } } }
  ]
}
JSON
  chmod 640 "$CONFIG_PATH"
  info "Validating config with xray..."
  "$XRAY_BIN" run -test -c "$CONFIG_PATH" >/dev/null 2>&1 \
    || die "Config validation failed — inspect $CONFIG_PATH"
  info "Config OK."
fi

# --- 4. systemd unit --------------------------------------------------------
if is_true "$USE_SYSTEMD"; then
  info "Installing systemd unit $SYSTEMD_UNIT..."
  cat > "$SYSTEMD_UNIT" <<UNIT
# Managed by vshop install.sh — do not edit by hand; re-run the installer instead.
[Unit]
Description=Xray VLESS-Reality VPN (vshop)
Documentation=https://xtls.github.io
After=network-online.target nss-lookup.target
Wants=network-online.target

[Service]
Type=simple
ExecStart=${XRAY_BIN} run -config ${CONFIG_PATH}
Environment=XRAY_LOCATION=${XRAY_BIN%/*}
Environment=XRAY_ASSETS_LOCATION=${XRAY_SHARE}
Restart=on-failure
RestartSec=5s
LimitNOFILE=65535

[Install]
WantedBy=multi-user.target
UNIT
  systemctl daemon-reload
  systemctl enable "$SERVICE_NAME" >/dev/null 2>&1 || true
  systemctl restart "$SERVICE_NAME" 2>/dev/null || systemctl start "$SERVICE_NAME"
  sleep 1
  if systemctl is-active --quiet "$SERVICE_NAME"; then
    info "Service $SERVICE_NAME is ACTIVE."
  else
    warn "Service failed to start — logs: journalctl -u $SERVICE_NAME -n 50"
  fi
else
  info "VSHOP_SYSTEMD=0 — starting Xray in the foreground is up to the caller (Docker)."
fi

# --- 5. management CLI ------------------------------------------------------
if [ -f "$SCRIPT_DIR/vshop.sh" ]; then
  install -m 0755 "$SCRIPT_DIR/vshop.sh" "$VSHOP_BIN"
  info "Management CLI installed: $VSHOP_BIN"
else
  warn "vshop.sh not found next to install.sh — skipping CLI install."
fi

# --- 6. firewall nicety -----------------------------------------------------
if command -v ufw >/dev/null 2>&1 && ufw status 2>/dev/null | grep -q "Status: active"; then
  ufw allow "${PORT}/tcp" >/dev/null 2>&1 || true
  info "ufw: allowed tcp/${PORT}"
fi

# --- 7. final report --------------------------------------------------------
STATE_HOST="$(detect_ipv4)"
CLIENT_URL="vless://${CLIENT_UUID}@${STATE_HOST}:${PORT}?type=tcp&security=reality&encryption=none&pbk=${PUB_KEY}&fp=chrome&sid=${SHORT_ID}&sni=${SNI_DEST_NAME}&flow=xtls-rprx-vision#default"
cat <<REPORT

==============================================================
  vshop VPN server installed
==============================================================
  Version   : $("$XRAY_BIN" version | head -n1)
  Port      : ${PORT}
  SNI       : ${SNI_DEST_NAME}
  Server IP : ${STATE_HOST}
  State     : ${STATE_FILE}
  Config    : ${CONFIG_PATH}

  Your first key (client "${DEFAULT_CLIENT}"):
  ${CLIENT_URL}

  Management CLI:
    ${VSHOP_BIN} add-user NAME      create a new key (prints vless:// URL)
    ${VSHOP_BIN} list-users         list keys
    ${VSHOP_BIN} revoke-user NAME   remove a key
    ${VSHOP_BIN} status             service status
    ${VSHOP_BIN} show-config        show config (secrets masked)

  Telegram bot & dashboard: run install-all.sh from the bundle root.
==============================================================
REPORT
