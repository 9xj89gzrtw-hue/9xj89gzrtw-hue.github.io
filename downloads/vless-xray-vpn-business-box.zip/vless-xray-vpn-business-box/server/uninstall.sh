#!/usr/bin/env bash
# ============================================================================
# server/uninstall.sh — remove the VLESS-Reality VPN server installed by install.sh
#
# Usage:
#   sudo bash uninstall.sh            # interactive (asks for confirmation)
#   sudo bash uninstall.sh --yes      # no confirmation prompt
#   sudo bash uninstall.sh --yes --with-bot   # also remove the Telegram bot
# ============================================================================
set -euo pipefail

XRAY_BIN="/usr/local/bin/xray"
XRAY_SHARE="/usr/local/share/xray"
XRAY_DIR="/usr/local/etc/xray"
STATE_DIR="/etc/vshop"
STATE_FILE="${STATE_DIR}/state.env"
SYSTEMD_UNIT="/etc/systemd/system/xray.service"
VSHOP_BIN="/usr/local/bin/vshop.sh"
BOT_UNIT="/etc/systemd/system/telegram-vpn-bot.service"
BOT_DIR="/opt/vshop-bot"

ASSUME_YES=0
WITH_BOT=0
for arg in "${@:-}"; do
  case "$arg" in
    --yes) ASSUME_YES=1 ;;
    --with-bot) WITH_BOT=1 ;;
    *) echo "unknown arg: $arg" >&2; exit 1 ;;
  esac
done

info() { printf '\033[1;32m==> %s\033[0m\n' "$*"; }
warn() { printf '\033[1;33m[!] %s\033[0m\n' "$*"; }

[ "$(id -u)" -eq 0 ] || { warn "Run as root: sudo bash $0"; exit 1; }

if [ "$ASSUME_YES" != "1" ]; then
  warn "This will STOP and DELETE the VPN server: xray binary, config, keys, state,"
  warn "management CLI and the systemd unit. All issued keys will stop working."
  printf "Type 'yes' to continue, anything else to abort: "
  read -r ANSWER
  [ "$ANSWER" = "yes" ] || { info "Aborted. Nothing was changed."; exit 0; }
fi

info "Removing Xray service..."
if command -v systemctl >/dev/null 2>&1; then
  systemctl stop xray 2>/dev/null || true
  systemctl disable xray 2>/dev/null || true
  [ -f "$SYSTEMD_UNIT" ] && rm -f "$SYSTEMD_UNIT" && systemctl daemon-reload
fi

for p in "$XRAY_BIN" "$VSHOP_BIN"; do
  if [ -e "$p" ]; then rm -f "$p"; info "removed $p"; fi
done
if [ -d "$XRAY_DIR" ]; then rm -rf "$XRAY_DIR"; info "removed $XRAY_DIR"; fi
if [ -d "$XRAY_SHARE" ]; then rm -rf "$XRAY_SHARE"; info "removed $XRAY_SHARE"; fi
if [ -f "$STATE_FILE" ]; then rm -f "$STATE_FILE"; info "removed $STATE_FILE"; fi
rmdir "$STATE_DIR" 2>/dev/null || true

if [ "$WITH_BOT" = "1" ]; then
  if command -v systemctl >/dev/null 2>&1; then
    systemctl stop telegram-vpn-bot 2>/dev/null || true
    systemctl disable telegram-vpn-bot 2>/dev/null || true
    [ -f "$BOT_UNIT" ] && rm -f "$BOT_UNIT" && systemctl daemon-reload
  fi
  if [ -d "$BOT_DIR" ]; then rm -rf "$BOT_DIR"; info "removed $BOT_DIR"; fi
  info "Telegram bot removed."
fi

info "VPN server uninstall complete. (Bot database files outside these paths are untouched.)"
