#!/usr/bin/env bash
# ============================================================================
# server/vshop.sh — management CLI for the VLESS-Reality VPN server
#
# Usage:
#   vshop.sh add-user NAME       create a VLESS client, print its vless:// URL
#   vshop.sh list-users          list clients from config.json
#   vshop.sh revoke-user NAME    remove a client and restart xray
#   vshop.sh show-config         print config (private key masked)
#   vshop.sh status              service/version/port/users summary
#   vshop.sh url NAME            re-print the key URL for an existing client
#
# Machine-readable contract (used by the Telegram bot):
#   Successful add-user always ends with the line  VLESS_URL=vless://...
#   Exit code 3 means "user already exists".
# ============================================================================
set -euo pipefail

CONFIG="${VSHOP_CONFIG:-/usr/local/etc/xray/config.json}"
STATE_FILE="${VSHOP_STATE:-/etc/vshop/state.env}"
XRAY_BIN="${VSHOP_XRAY:-/usr/local/bin/xray}"
SERVICE_NAME="${VSHOP_SERVICE:-xray}"

info()   { printf '\033[1;32m==> %s\033[0m\n' "$*"; }
warn()   { printf '\033[1;33m[!] %s\033[0m\n' "$*"; }
die()    { printf '\033[1;31mERROR: %s\033[0m\n' "$*" >&2; exit 1; }

usage() {
  sed -n '3,15p' "$0" | sed 's/^# //'
  exit 0
}

load_state() {
  [ -s "$STATE_FILE" ] || die "State file $STATE_FILE missing — run server/install.sh first."
  # shellcheck disable=SC1090
  . "$STATE_FILE"
  [ -n "${PUB_KEY:-}" ]     || die "PUB_KEY missing in state"
  [ -n "${SHORT_ID:-}" ]    || die "SHORT_ID missing in state"
  [ -n "${SNI_NAME:-}" ]    || die "SNI_NAME missing in state"
  [ -n "${PORT:-}" ]        || die "PORT missing in state"
}

server_host() {
  if [ -n "${VSHOP_HOST:-}" ]; then echo "$VSHOP_HOST"; return; fi
  if [ -n "${HOST:-}" ]; then echo "$HOST"; return; fi
  local ip
  ip="$(curl -4 -fsSm8 https://api.ipify.org 2>/dev/null || true)"
  [ -n "$ip" ] || ip="$(hostname -I 2>/dev/null | awk '{print $1}')"
  [ -n "$ip" ] || die "Cannot detect server IP — set VSHOP_HOST env"
  echo "$ip"
}

validate_name() {
  case "$1" in
    [A-Za-z0-9_.-]*) ;;
    *) die "Invalid name '$1' (allowed: A-Z a-z 0-9 _ . - up to 32 chars)" ;;
  esac
  [ "${#1}" -le 32 ] || die "Name too long (max 32 chars)"
}

gen_uuid() {
  if [ -r /proc/sys/kernel/random/uuid ]; then
    cat /proc/sys/kernel/random/uuid
  elif [ -x "$XRAY_BIN" ]; then
    "$XRAY_BIN" uuid
  else
    python3 -c 'import uuid; print(uuid.uuid4())'
  fi
}

build_url() { # name uuid
  local name="$1" uuid="$2" host
  host="$(server_host)"
  printf 'VLESS_URL=vless://%s@%s:%s?type=tcp&security=reality&encryption=none&pbk=%s&fp=chrome&sid=%s&sni=%s&flow=xtls-rprx-vision#%s\n' \
    "$uuid" "$host" "$PORT" "$PUB_KEY" "$SHORT_ID" "$SNI_NAME" "$name"
}

json_add_client() { # config name uuid -> prints OK|EXISTS
  python3 - "$1" "$2" "$3" <<'PY'
import json, sys
path, name, uid = sys.argv[1], sys.argv[2], sys.argv[3]
cfg = json.load(open(path))
inbs = [i for i in cfg.get("inbounds", []) if i.get("protocol") == "vless"]
if not inbs:
    sys.exit("no vless inbound found in config")
inb = inbs[0]
clients = inb.setdefault("settings", {}).setdefault("clients", [])
if any(c.get("email") == name for c in clients):
    print("EXISTS"); sys.exit(0)
clients.append({"id": uid, "flow": "xtls-rprx-vision", "email": name})
json.dump(cfg, open(path, "w"), indent=2)
print("OK")
PY
}

json_get_client() { # config name -> prints uuid or empty
  python3 - "$1" "$2" <<'PY'
import json, sys
path, name = sys.argv[1], sys.argv[2]
cfg = json.load(open(path))
for i in cfg.get("inbounds", []):
    if i.get("protocol") == "vless":
        for c in i.get("settings", {}).get("clients", []):
            if c.get("email") == name:
                print(c["id"]); sys.exit(0)
PY
}

json_del_client() { # config name -> prints REMOVED|NOTFOUND
  python3 - "$1" "$2" <<'PY'
import json, sys
path, name = sys.argv[1], sys.argv[2]
cfg = json.load(open(path))
found = False
for i in cfg.get("inbounds", []):
    if i.get("protocol") != "vless":
        continue
    before = i.get("settings", {}).get("clients", [])
    after = [c for c in before if c.get("email") != name]
    if len(after) != len(before):
        i["settings"]["clients"] = after
        found = True
if found:
    json.dump(cfg, open(path, "w"), indent=2)
    print("REMOVED")
else:
    print("NOTFOUND")
PY
}

json_list_clients() { # config -> prints "name uuid" lines
  python3 - "$1" <<'PY'
import json, sys
cfg = json.load(open(sys.argv[1]))
for i in cfg.get("inbounds", []):
    if i.get("protocol") != "vless":
        continue
    for c in i.get("settings", {}).get("clients", []):
        print("%s %s" % (c.get("email", "?"), c.get("id", "?")))
PY
}

json_client_count() { # config
  python3 - "$1" <<'PY'
import json, sys
cfg = json.load(open(sys.argv[1]))
n = 0
for i in cfg.get("inbounds", []):
    if i.get("protocol") == "vless":
        n += len(i.get("settings", {}).get("clients", []))
print(n)
PY
}

restart_service() {
  if command -v systemctl >/dev/null 2>&1 && systemctl list-unit-files 2>/dev/null | grep -q "^${SERVICE_NAME}"; then
    systemctl restart "$SERVICE_NAME"
    systemctl is-active --quiet "$SERVICE_NAME" || die "service failed to restart — journalctl -u ${SERVICE_NAME}"
  else
    warn "systemd unit not found (Docker?) — restart the container manually."
  fi
}

# ------------------------------------------------------------------ commands
cmd_add_user() {
  local name="${1:-}"
  [ -n "$name" ] || die "usage: $0 add-user NAME"
  validate_name "$name"
  load_state
  [ -f "$CONFIG" ] || die "config $CONFIG missing — run server/install.sh first"
  local uuid
  uuid="$(json_get_client "$CONFIG" "$name" || true)"
  if [ -n "$uuid" ]; then
    warn "user '$name' already exists — printing existing key."
    printf '\n'
    build_url "$name" "$uuid"
    exit 0
  fi
  uuid="$(gen_uuid)"
  local result
  result="$(json_add_client "$CONFIG" "$name" "$uuid")"
  [ "$result" = "OK" ] || die "collision while adding '$name'"
  restart_service
  printf "Added client '%s' (%s)\n" "$name" "$uuid"
  printf '\n'
  build_url "$name" "$uuid"
  printf "\nScan the QR or copy the link into your VPN client (v2rayNG / Streisand / Foxray etc).\n"
}

cmd_url() {
  local name="${1:-}"
  [ -n "$name" ] || die "usage: $0 url NAME"
  validate_name "$name"
  load_state
  local uuid
  uuid="$(json_get_client "$CONFIG" "$name")"
  [ -n "$uuid" ] || die "no user named '$name'"
  build_url "$name" "$uuid"
}

cmd_list_users() {
  [ -f "$CONFIG" ] || die "config $CONFIG missing"
  printf "%-24s %s\n" "NAME" "UUID"
  printf "%-24s %s\n" "----" "----"
  json_list_clients "$CONFIG"
  printf "\n%d client(s)\n" "$(json_client_count "$CONFIG")"
}

cmd_revoke_user() {
  local name="${1:-}"
  [ -n "$name" ] || die "usage: $0 revoke-user NAME"
  validate_name "$name"
  load_state
  local result
  result="$(json_del_client "$CONFIG" "$name")"
  case "$result" in
    REMOVED)  restart_service; info "user '$name' revoked, service restarted." ;;
    NOTFOUND) die "no user named '$name'" ;;
  esac
}

cmd_show_config() {
  [ -f "$CONFIG" ] || die "config $CONFIG missing"
  CONFIG_PATH="$CONFIG" python3 <<'PY'
import json
cfg = json.load(open("/usr/local/etc/xray/config.json"))
for i in cfg.get("inbounds", []):
    rs = i.get("streamSettings", {}).get("realitySettings", {})
    if "privateKey" in rs:
        rs["privateKey"] = "***MASKED***"
    for c in i.get("settings", {}).get("clients", []):
        if len(c.get("id", "")) == 36:
            c["id"] = c["id"][:8] + "***"
print(json.dumps(cfg, indent=2))
PY
}

cmd_status() {
  local ver="n/a" state="unknown" port_ok="no"
  [ -x "$XRAY_BIN" ] && ver="$($XRAY_BIN version | head -n1)"
  if command -v systemctl >/dev/null 2>&1; then
    state="$(systemctl is-active "$SERVICE_NAME" 2>/dev/null || echo unknown)"
  fi
  local port="${PORT:-$(load_state && echo "$PORT")}"
  if command -v ss >/dev/null 2>&1; then
    ss -ltn 2>/dev/null | grep -q "[[:space:]]:${port}[[:space:]]" && port_ok="listening"
  elif command -v netstat >/dev/null 2>&1; then
    netstat -ltn 2>/dev/null | grep -q "[[:space:]]:${port}[[:space:]]" && port_ok="listening"
  fi
  local users="0"
  [ -f "$CONFIG" ] && users="$(json_client_count "$CONFIG")"
  printf "version : %s\nservice : %s\nport    : %s (%s)\nclients : %s\n" \
    "$ver" "$state" "$port" "$port_ok" "$users"
}

# ------------------------------------------------------------------- dispatch
case "${1:-help}" in
  add-user)    shift; cmd_add_user "${1:-}" ;;
  list-users)  cmd_list_users ;;
  ls)          cmd_list_users ;;
  revoke-user) shift; cmd_revoke_user "${1:-}" ;;
  show-config) cmd_show_config ;;
  status)      cmd_status ;;
  url)         shift; cmd_url "${1:-}" ;;
  help|-h|--help) usage ;;
  *) die "unknown command '${1}'. Try: $0 help" ;;
esac
