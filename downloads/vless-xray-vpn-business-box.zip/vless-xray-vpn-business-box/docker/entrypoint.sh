# docker/entrypoint.sh — generate config.json on first start, then exec Xray.
#!/usr/bin/env bash
set -euo pipefail

CONFIG_PATH="/usr/local/etc/xray/config.json"
export XRAY_BIN_PATH="/usr/local/bin/xray"

# Reuse the config between restarts; generate it on first start.
if [ ! -f "$CONFIG_PATH" ]; then
  echo "[entrypoint] no config found — generating via install.sh (one-time)..."
  # Skip apt (already in the image) and systemd (not present in a container).
  VSHOP_SKIP_APT=1 VSHOP_SYSTEMD=0 /server/install.sh
fi

echo "[entrypoint] starting xray..."
exec /usr/local/bin/xray run -config "$CONFIG_PATH"
