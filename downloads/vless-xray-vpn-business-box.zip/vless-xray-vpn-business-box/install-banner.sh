#!/usr/bin/env bash
# install-banner.sh — prints what is installed and where to go next
PORT="$(grep -m1 '^PORT=' /etc/vshop/state.env 2>/dev/null | cut -d= -f2- || true)"
HOST="$(grep -m1 '^HOST=' /etc/vshop/state.env 2>/dev/null | cut -d= -f2- || true)"
cat <<'ART'
   _   _                ___ _   _        _____
  | \ | | _____   ____ _/ __\ \ / /      |___ /
  |  \| |/ _ \ \ / / _` \__ \\ V /  _____   |_ \
  | |\  |  __/\ V / (_| |___/| |  |_____| ___) |
  |_| \_|\___| \_/ \__,_|____/|_|       |____/
ART
echo "VLESS + Reality (Xray-core) installed."
echo "  state:  /etc/vshop/state.env"
echo "  CLI:    vshop.sh add-user NAME | revoke-user NAME | list-users | status"
if [ -n "${HOST}" ]; then echo "  server: ${HOST}:${PORT:-443}"; fi
echo
echo "Try: vshop.sh add-user demo  -> prints VLESS_URL=... (import into client app)"
