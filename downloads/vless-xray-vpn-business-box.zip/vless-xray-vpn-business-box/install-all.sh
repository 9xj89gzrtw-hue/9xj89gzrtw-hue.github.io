#!/usr/bin/env bash
# install-all.sh — one-shot setup of the whole business box:
#   1) Xray VLESS-Reality server (server/install.sh)
#   2) Telegram sales bot venv + .env + systemd unit
# Safe to re-run. Designed for a fresh Ubuntu 22.04/24.04 VPS as root.
set -euo pipefail

HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
VBOX="${VBOX_DIR:-/opt/vpn-box}"
VENT="${VBOX}/.venv"

echo "== [1/3] Xray VLESS-Reality server =="
bash "${HERE}/server/install.sh"

echo "== [2/3] Bot venv + code =="
mkdir -p "${VBOX}"
cp -R "${HERE}/bot" "${HERE}/web" "${HERE}/.env.example" "${HERE}/requirements.txt" "${HERE}/LICENSE" "${HERE}/README_RU.md" "${HERE}/README_EN.md" "${VBOX}/"
command -v python3 >/dev/null || { apt-get update -y && apt-get install -y python3 python3-venv python3-pip; }
[ -d "${VENT}" ] || python3 -m venv "${VENT}"
"${VENT}/bin/pip" -q install --disable-pip-version-check -r "${VBOX}/requirements.txt"
[ -f "${VBOX}/.env" ] || cp "${VBOX}/.env.example" "${VBOX}/.env"

echo "== [3/3] systemd unit =="
cp "${VBOX}/bot/telegram-vpn-bot.service" /etc/systemd/system/telegram-vpn-bot.service
systemctl daemon-reload

bash "${HERE}/install-banner.sh"
echo
echo "Educate next steps:"
echo "  1) chmod 600 ${VBOX}/.env && ${EDITOR:-nano} ${VBOX}/.env   # BOT_TOKEN, ADMIN_IDS, PAY_RUB_INFO..."
echo "  2) ${VENT}/bin/python -m bot.bot          # first run in the foreground"
echo "  3) systemctl enable --now telegram-vpn-bot  # then as daemon"
echo "  4) dashboard: http://127.0.0.1:8080/?token=<ADMIN_TOKEN  from .env>"
