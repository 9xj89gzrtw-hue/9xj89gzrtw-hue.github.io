"""tests/test_db.py — sqlite storage: state machine, orders, payments, keys."""
import os
import tempfile
import unittest

from bot import db


class TestTransitions(unittest.TestCase):
    def test_legal(self):
        for a, b in [("new", "awaiting_approval"), ("new", "paid"), ("new", "cancelled"),
                     ("awaiting_approval", "paid"), ("paid", "issued"), ("paid", "cancelled")]:
            self.assertEqual(db.transition(a, b), b)

    def test_illegal(self):
        for a, b in [("new", "issued"), ("issued", "paid"), ("cancelled", "paid"),
                     ("paid", "new"), ("bogus", "paid")]:
            with self.assertRaises(ValueError):
                db.transition(a, b)


class TestOrders(unittest.TestCase):
    def setUp(self):
        self.path = os.path.join(tempfile.mkdtemp(prefix="vpnbox-test-"), "bot.sqlite3")
        db.init_db(self.path)
        self.path = os.path.abspath(self.path)

    def test_order_lifecycle(self):
        oid = db.create_order(self.path, 42, "30", amount_rub=499.0, method="rub")
        self.assertEqual(db.get_order(self.path, oid)["status"], "new")
        self.assertEqual(db.set_order_status(self.path, oid, "awaiting_approval"), 1)
        self.assertEqual(db.set_order_status(self.path, oid, "paid"), 1)
        self.assertEqual(db.set_order_status(self.path, oid, "issued"), 1)
        o = db.get_order(self.path, oid)
        self.assertEqual(o["status"], "issued")
        self.assertTrue(o["paid_at"] and o["issued_at"])

    def test_new_to_paid_allowed(self):
        oid = db.create_order(self.path, 42, "7", amount_stars=99, method="stars")
        self.assertEqual(db.set_order_status(self.path, oid, "paid"), 1)

    def test_illegal_move_raises(self):
        oid = db.create_order(self.path, 42, "7", method="rub")
        with self.assertRaises(ValueError):
            db.set_order_status(self.path, oid, "issued")

    def test_missing_order_raises(self):
        with self.assertRaises(LookupError):
            db.set_order_status(self.path, 999999, "paid")

    def test_list_pending_and_limit(self):
        for _ in range(3):
            oid = db.create_order(self.path, 42, "7", method="rub")
            db.set_order_status(self.path, oid, "awaiting_approval")
        db.create_order(self.path, 42, "7", method="stars")  # stays 'new'
        pending = db.list_pending(self.path)
        self.assertEqual(len(pending), 4)
        self.assertEqual(list_orders_status(self.path, "issued"), [])
        self.assertEqual(len(db.list_orders(self.path, limit=2)), 2)


def list_orders_status(p, status):
    import bot.db as d
    return d.list_orders(p, status=status)


class TestPaymentsAndKeys(unittest.TestCase):
    def setUp(self):
        self.path = os.path.abspath(os.path.join(tempfile.mkdtemp(prefix="vpnbox-test-"), "b.sqlite3"))
        db.init_db(self.path)

    def test_payment_roundtrip(self):
        oid = db.create_order(self.path, 7, "30", amount_usdt=5.9, method="usdt")
        pid = db.record_payment(self.path, oid, 7, "usdt", external_id="TX1", amount="5.9")
        import sqlite3
        c = sqlite3.connect(self.path)
        row = c.execute("SELECT order_id, method, external_id FROM payments WHERE id=?", (pid,)).fetchone()
        c.close()
        self.assertEqual(row, (oid, "usdt", "TX1"))

    def test_keys_roundtrip_and_expiry(self):
        db.add_key(self.path, 7, None, "u7_1", "vless://x", days=7)
        db.add_key(self.path, 7, None, "u7_2", "vless://y", days=0)  # lifetime
        self.assertEqual(db.count_active_keys(self.path), 2)
        ks = db.list_keys(self.path, tg_id=7)
        self.assertEqual(len(ks), 2)
        # lifetime row has empty expires_at
        self.assertEqual(ks[0]["expires_at"] == "", True)
        # manual revoke
        self.assertTrue(db.revoke_key(self.path, ks[0]["id"]))
        self.assertFalse(db.revoke_key(self.path, ks[0]["id"]))  # second revoke no-op
        self.assertEqual(db.count_active_keys(self.path), 1)
        # expired cleanup view
        old = db.expired_keys(self.path)  # nothing expired yet (7 days future)
        self.assertEqual(len(old), 0)
        # fake an expired key (direct insert to bypass lifetime behaviour)
        import sqlite3
        c = sqlite3.connect(self.path)
        c.execute(
            "INSERT INTO keys (tg_id, order_id, label, vless_url, created_at, expires_at, source)"
            " VALUES (8, NULL, 'u8', 'vless://z', '2024-01-01T00:00:00+00:00',"
            " '2000-01-01T00:00:00+00:00', 'order')"
        )
        c.commit()
        c.close()
        expired = db.expired_keys(self.path)
        self.assertEqual([k["label"] for k in expired], ["u8"])

if __name__ == "__main__":
    unittest.main()
