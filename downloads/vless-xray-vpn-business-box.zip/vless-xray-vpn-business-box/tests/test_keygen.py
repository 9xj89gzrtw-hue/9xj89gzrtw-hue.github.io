"""tests/test_keygen.py — vless:// URL building, validation, CLI parsing."""
import os
import tempfile
import unittest

from bot import keygen

STATE = {
    "HOST": "vps.example.com",
    "PORT": "443",
    "SNI_NAME": "www.microsoft.com",
    "PUB_KEY": "AbCdEf1234567890AbCdEf1234567890AbCdEf1234567",
    "SHORT_ID": "0a1b2c3d4e5f6a7b",
}


class TestBuildValidate(unittest.TestCase):
    def test_roundtrip(self):
        url = keygen.build_vless_url(
            uuid_=keygen.new_uuid(), host=STATE["HOST"], port=443,
            sni=STATE["SNI_NAME"], pbk=STATE["PUB_KEY"], sid=STATE["SHORT_ID"],
            name=" buyer 1 ")
        info = keygen.validate_vless_url(url)
        self.assertEqual(info["host"], "vps.example.com")
        self.assertEqual(info["port"], 443)
        self.assertEqual(info["params"]["security"], "reality")
        self.assertEqual(info["params"]["type"], "tcp")
        self.assertEqual(info["params"]["flow"], "xtls-rprx-vision")
        self.assertEqual(info["params"]["sni"], STATE["SNI_NAME"])
        self.assertEqual(info["params"]["sid"], STATE["SHORT_ID"])
        self.assertEqual(info["params"]["pbk"], STATE["PUB_KEY"])
        self.assertIn("fp=chrome", url)

    def test_bad_uuid(self):
        with self.assertRaises(ValueError):
            keygen.build_vless_url(uuid_="not-a-uuid", host="h", port=443,
                                   sni="s", pbk="p", sid="s")

    def test_bad_port(self):
        for bad in (0, -1, 65536, "443"):
            with self.assertRaises(ValueError):
                keygen.build_vless_url(uuid_=keygen.new_uuid(), host="h", port=bad,
                                       sni="s", pbk="p", sid="s")

    def test_missing_reality_params(self):
        with self.assertRaises(ValueError):
            keygen.build_vless_url(uuid_=keygen.new_uuid(), host="h", port=443,
                                   sni="", pbk="p", sid="s")

    def test_validate_rejects_non_vless(self):
        with self.assertRaises(ValueError):
            keygen.validate_vless_url("https://example.com")

    def test_parse_vless_line(self):
        out = "some noise\nVLESS_URL=vless://00000000-0000-4000-8000-000000000001@1.1.1.1:443?x\n"
        parsed = keygen.parse_vless_line(out)
        self.assertTrue(parsed.startswith("vless://"))

    def test_parse_vless_line_missing(self):
        with self.assertRaises(RuntimeError):
            keygen.parse_vless_line("nothing here")


class TestSanitizeAndState(unittest.TestCase):
    def test_sanitize_username(self):
        self.assertEqual(keygen.sanitize_username("u 123456_42"), "u_123456_42")
        self.assertEqual(keygen.sanitize_username(""), "user")
        self.assertLessEqual(len(keygen.sanitize_username("x" * 100)), 32)
        self.assertEqual(keygen.sanitize_username("a/b@c"), "a_b_c")

    def test_load_state_and_build_url(self):
        with tempfile.TemporaryDirectory() as d:
            p = os.path.join(d, "state.env")
            with open(p, "w", encoding="utf-8") as fh:
                fh.write("# installer state\n")
                fh.write('HOST="vps.example.com"\n')
                for k, v in STATE.items():
                    fh.write(f"{k}={v}\n")
            st = keygen.load_state(p)
            self.assertEqual(st["SNI_NAME"], STATE["SNI_NAME"])
            url = keygen.build_url_from_state(st, "buyer1")
            info = keygen.validate_vless_url(url)
            self.assertEqual(info["name"], "buyer1")
            self.assertEqual(info["port"], 443)
            # missing file -> empty state, default host/port still buildable
            st2 = keygen.load_state(os.path.join(d, "nope.env"))
            self.assertEqual(st2, {})

    def test_issue_rejects_unsafe_name(self):
        with self.assertRaises(RuntimeError):
            keygen._run_template("echo {name}", "bad name with spaces")


if __name__ == "__main__":
    unittest.main()
