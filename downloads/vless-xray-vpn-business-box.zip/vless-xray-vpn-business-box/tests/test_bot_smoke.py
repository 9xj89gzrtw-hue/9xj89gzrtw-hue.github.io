"""tests/test_bot_smoke.py — import-level checks incl. optional aiogram smoke."""
import os
import unittest

class TestBotSmoke(unittest.TestCase):
    def test_bot_module_compile(self):
        import compileall, tempfile, shutil
        import bot
        with tempfile.TemporaryDirectory() as d:
            shutil.copytree(bot.__path__[0], os.path.join(d, "bot"))
            ok = compileall.compile_dir(d, quiet=2)
            self.assertTrue(ok)

    def test_handlers_import_optional(self):
        try:
            import aiogram  # noqa: F401
            have = True
        except Exception:
            have = False
        if have:
            from bot import handlers  # noqa: F401
        self.assertTrue(True)  # passes either way; richer runs happen in venv CI

if __name__ == "__main__":
    unittest.main()
