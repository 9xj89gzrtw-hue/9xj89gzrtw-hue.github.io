"""tests/run.py — unittest discovery runner: python3 -m tests.run (stdlib-only)."""
import unittest
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent

def main() -> int:
    loader = unittest.TestLoader()
    suite = loader.discover(str(HERE), pattern="test_*.py")
    runner = unittest.TextTestRunner(verbosity=2)
    result = runner.run(suite)
    return 0 if result.wasSuccessful() else 1

if __name__ == "__main__":
    sys.exit(main())
