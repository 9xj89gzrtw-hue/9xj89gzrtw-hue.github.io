"""tests/test_config.py — env config: admin ids, plans, defaults."""
import unittest

from bot import config

class TestAdminIds(unittest.TestCase):
    def test_parse_admin_ids(self):
        self.assertEqual(config.parse_admin_ids("111, 222"), frozenset({111, 222}))
        self.assertEqual(config.parse_admin_ids("111;222"), frozenset({111, 222}))
        self.assertEqual(config.parse_admin_ids(""), frozenset())
        self.assertEqual(config.parse_admin_ids("x,222"), frozenset({222}))

class TestPlans(unittest.TestCase):
    def test_default_plans_shape(self):
        plans = config.load_plans()
        self.assertEqual(sorted(plans.keys()), ["30", "7"])
        for pid, p in plans.items():
            self.assertIn("title", p)
            self.assertIn("days", p)
            self.assertIn("rub", p)
            self.assertIn("stars", p)
            self.assertIn("usdt", p)
            self.assertGreater(p["days"], 0)
            self.assertGreater(p["rub"], 0)

    def test_custom_plans_from_env_json(self):
        raw = '{"90": {"title": "VPN 90", "days": 90, "rub": 999, "stars": 499, "usdt": 9.9}}'
        plans = config.load_plans(raw)
        self.assertEqual(sorted(plans.keys()), ["90"])
        self.assertEqual(plans["90"]["days"], 90)
        self.assertAlmostEqual(plans["90"]["usdt"], 9.9)

    def test_bad_json_falls_back_to_defaults(self):
        self.assertEqual(sorted(config.load_plans("not json").keys()), ["30", "7"])
        self.assertEqual(sorted(config.load_plans(None and "zz").keys()), ["30", "7"])

if __name__ == "__main__":
    unittest.main()
