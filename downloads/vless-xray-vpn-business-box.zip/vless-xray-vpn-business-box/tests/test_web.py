"""tests/test_web.py — stdlib dashboard: routes, auth, summary JSON."""
import json
import os
import tempfile
import threading
import unittest
import urllib.request

from bot import db
from web.app import make_handler, summary


class TestSummary(unittest.TestCase):
    def setUp(self):
        self.path = os.path.abspath(os.path.join(tempfile.mkdtemp(prefix="vpnbox-web-"), "b.sqlite3"))
        db.init_db(self.path)

    def test_empty_summary_shape(self):
        s = summary(self.path)
        self.assertEqual(s["users"], 0)
        self.assertEqual(s["keys_active"], 0)
        self.assertEqual(s["revenue"], {"rub": 0.0, "stars": 0, "usdt": 0.0})
        self.assertEqual(sorted(s["orders"].keys()), ["awaiting_approval", "cancelled", "issued", "new", "paid"])

    def test_summary_counts(self):
        db.upsert_user(self.path, 1, "buyer", "Vasya")
        oid = db.create_order(self.path, 1, "30", amount_rub=499.0, method="rub")
        db.set_order_status(self.path, oid, "paid")
        s = summary(self.path)
        self.assertEqual(s["users"], 1)
        self.assertEqual(s["orders"]["paid"], 1)
        self.assertEqual(s["revenue"]["rub"], 499.0)


class TestHttp(unittest.TestCase):
    def setUp(self):
        from http.server import ThreadingHTTPServer
        self.path = os.path.abspath(os.path.join(tempfile.mkdtemp(prefix="vpnbox-web-"), "b.sqlite3"))
        db.init_db(self.path)
        self.httpd = ThreadingHTTPServer(("127.0.0.1", 0), make_handler(self.path, "SECRET1"))
        self.port = self.httpd.server_address[1]
        self.t = threading.Thread(target=self.httpd.serve_forever, daemon=True)
        self.t.start()

    def tearDown(self):
        self.httpd.shutdown()
        self.httpd.server_close()

    def _get(self, path, headers=None):
        req = urllib.request.Request(f"http://127.0.0.1:{self.port}{path}", headers=headers or {})
        try:
            with urllib.request.urlopen(req, timeout=5) as r:
                return r.status, r.read()
        except urllib.error.HTTPError as e:
            return e.code, e.read()

    def test_health_open(self):
        st, body = self._get("/health")
        self.assertEqual(st, 200)
        self.assertEqual(json.loads(body)["ok"], True)

    def test_summary_requires_token(self):
        st, _ = self._get("/api/summary")
        self.assertEqual(st, 401)
        st, body = self._get("/api/summary?token=SECRET1")
        self.assertEqual(st, 200)
        self.assertIn("orders", json.loads(body))
        st, _ = self._get("/api/summary", headers={"X-Admin-Token": "SECRET1"})
        self.assertEqual(st, 200)

    def test_index_served(self):
        st, body = self._get("/?token=SECRET1")
        self.assertEqual(st, 200)
        self.assertIn(b"VPN-", body)

    def test_unknown_404(self):
        st, _ = self._get("/nope?token=SECRET1")
        self.assertEqual(st, 404)

if __name__ == "__main__":
    unittest.main()
