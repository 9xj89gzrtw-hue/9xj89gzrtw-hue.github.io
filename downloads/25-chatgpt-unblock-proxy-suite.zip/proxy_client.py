"""Python client demonstrating requests through proxy worker."""
import httpx
import asyncio

async def query_model(prompt: str, worker_url: str, api_key: str):
    headers = {"Authorization": f"Bearer {api_key}"}
    async with httpx.AsyncClient() as client:
        resp = await client.post(
            f"{worker_url}/v1/chat/completions",
            headers=headers,
            json={"model": "gpt-4o", "messages": [{"role": "user", "content": prompt}]}
        )
        return resp.json()
