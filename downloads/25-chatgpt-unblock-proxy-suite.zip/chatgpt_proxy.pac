function FindProxyForURL(url, host) {
    // Сайты OpenAI и ChatGPT
    if (dnsDomainIs(host, ".openai.com") ||
        dnsDomainIs(host, ".chatgpt.com") ||
        dnsDomainIs(host, ".oaistatic.com") ||
        dnsDomainIs(host, ".oaiusercontent.com") ||
        dnsDomainIs(host, ".anthropic.com") ||
        dnsDomainIs(host, ".claude.ai")) {
        // Направляем через надежный публичный HTTPS прокси
        return "HTTPS proxy.antizapret.prostovpn.org:443; PROXY proxy.antizapret.prostovpn.org:3128; DIRECT";
    }
    // Все остальные сайты (Сбер, Госуслуги, YouTube, VK, Яндекс) идут НАПРЯМУЮ на полной скорости!
    return "DIRECT";
}
