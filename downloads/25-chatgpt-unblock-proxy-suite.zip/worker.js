/**
 * Cloudflare Worker Reverse Proxy for OpenAI & Claude APIs.
 */
export default {
  async fetch(request, env) {
    const url = new URL(request.url);
    url.hostname = "api.openai.com"; // Или api.anthropic.com

    const newRequest = new Request(url, {
      method: request.method,
      headers: request.headers,
      body: request.body
    });

    return fetch(newRequest);
  }
};
