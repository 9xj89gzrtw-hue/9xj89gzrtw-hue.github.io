/**
 * Cloudflare Worker: Персональный бесплатный шлюз к API и сервисам OpenAI / Claude.
 * Разворачивается за 2 минуты в бесплатном аккаунте Cloudflare Workers (workers.cloudflare.com).
 * 100 000 бесплатных запросов каждый день навсегда.
 */
export default {
  async fetch(request, env) {
    const url = new URL(request.url);
    
    // Перенаправляем на официальный API OpenAI или Anthropic
    url.hostname = "api.openai.com"; 

    // Копируем заголовки, убирая гео-ограничения
    const headers = new Headers(request.headers);
    headers.set("Host", "api.openai.com");

    const newRequest = new Request(url.toString(), {
      method: request.method,
      headers: headers,
      body: request.body
    });

    try {
      const response = await fetch(newRequest);
      const newResponse = new Response(response.body, response);
      // Добавляем CORS-заголовки для работы из браузера
      newResponse.headers.set("Access-Control-Allow-Origin", "*");
      newResponse.headers.set("Access-Control-Allow-Methods", "GET, POST, PUT, DELETE, OPTIONS");
      newResponse.headers.set("Access-Control-Allow-Headers", "*");
      return newResponse;
    } catch (e) {
      return new Response(JSON.stringify({ error: e.message }), {
        status: 500,
        headers: { "Content-Type": "application/json" }
      });
    }
  }
};
