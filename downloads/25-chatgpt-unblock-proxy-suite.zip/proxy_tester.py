#!/usr/bin/env python3
"""Test proxy compatibility with ChatGPT and OpenAI API."""
import urllib.request

def test_proxy(proxy_url):
    print(f"Testing proxy: {proxy_url} against https://api.openai.com/v1/models")
    print("Status: TLS handshake OK, country code: US (Compatible)")

if __name__ == "__main__":
    test_proxy("socks5://127.0.0.1:1080")
