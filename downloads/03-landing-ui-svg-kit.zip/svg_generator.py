#!/usr/bin/env python3
"""Procedural SVG Generator for Landing UI Components.
Generates Roman Numeral Cards, Holler Brandmarks, Sparkline Charts, and Vector Badges.
"""
from __future__ import annotations
import math
from pathlib import Path

OUT_DIR = Path(__file__).resolve().parent / "svg"
OUT_DIR.mkdir(parents=True, exist_ok=True)

def generate_roman_numeral_card(numeral: str = "MMXXVI", subtitle: str = "ESTABLISHED ON-CHAIN"):
    """Two-sided high-resolution vector card with ornamental Roman typography & guilloche border."""
    svg = f"""<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 600 350" width="100%" height="100%">
  <defs>
    <linearGradient id="cardGrad" x1="0%" y1="0%" x2="100%" y2="100%">
      <stop offset="0%" stop-color="#0f172a"/>
      <stop offset="50%" stop-color="#1e293b"/>
      <stop offset="100%" stop-color="#020617"/>
    </linearGradient>
    <linearGradient id="goldGrad" x1="0%" y1="0%" x2="100%" y2="100%">
      <stop offset="0%" stop-color="#fbbf24"/>
      <stop offset="50%" stop-color="#f59e0b"/>
      <stop offset="100%" stop-color="#d97706"/>
    </linearGradient>
    <pattern id="guilloche" width="40" height="40" patternUnits="userSpaceOnUse">
      <circle cx="20" cy="20" r="18" fill="none" stroke="#334155" stroke-width="0.5" opacity="0.3"/>
      <circle cx="20" cy="20" r="12" fill="none" stroke="#f59e0b" stroke-width="0.3" opacity="0.2"/>
    </pattern>
  </defs>
  
  <!-- Background Card -->
  <rect width="600" height="350" rx="16" fill="url(#cardGrad)" stroke="#334155" stroke-width="2"/>
  <rect x="12" y="12" width="576" height="326" rx="12" fill="url(#guilloche)"/>
  
  <!-- Outer Frame -->
  <rect x="20" y="20" width="560" height="310" rx="8" fill="none" stroke="url(#goldGrad)" stroke-width="1.5" opacity="0.75"/>
  <rect x="26" y="26" width="548" height="298" rx="6" fill="none" stroke="#475569" stroke-width="0.5"/>

  <!-- Corner Ornaments -->
  <g fill="url(#goldGrad)">
    <polygon points="26,26 40,26 26,40"/>
    <polygon points="574,26 560,26 574,40"/>
    <polygon points="26,324 40,324 26,310"/>
    <polygon points="574,324 560,324 574,310"/>
  </g>

  <!-- Central Watermark -->
  <text x="300" y="200" font-family="'Cinzel', 'Times New Roman', serif" font-size="78" font-weight="900" fill="url(#goldGrad)" text-anchor="middle" letter-spacing="8" opacity="0.95">
    {numeral}
  </text>
  
  <text x="300" y="235" font-family="'Courier New', monospace" font-size="13" font-weight="700" fill="#94a3b8" text-anchor="middle" letter-spacing="4">
    {subtitle}
  </text>

  <!-- Chip Icon & Hologram -->
  <rect x="52" y="52" width="52" height="40" rx="6" fill="#38bdf8" opacity="0.15" stroke="#38bdf8" stroke-width="1.5"/>
  <path d="M52,72 L104,72 M78,52 L78,92" stroke="#38bdf8" stroke-width="1" opacity="0.5"/>
  
  <!-- Serial & Base ID -->
  <text x="548" y="76" font-family="monospace" font-size="11" fill="#64748b" text-anchor="end">NETWORK: BASE MAINNET</text>
  <text x="52" y="300" font-family="monospace" font-size="12" fill="#cbd5e1" letter-spacing="2">0x72Aa ···· 74d1a</text>
  <text x="548" y="300" font-family="monospace" font-size="12" fill="#10b981" font-weight="700" text-anchor="end">VERIFIED PRO</text>
</svg>"""
    (OUT_DIR / "roman_numeral_card.svg").write_text(svg, encoding="utf-8")
    print("Generated roman_numeral_card.svg")

def generate_sparklines():
    """Generate high-tech SVG sparkline charts."""
    points = [32, 45, 38, 55, 62, 58, 75, 82, 79, 94, 110, 105, 128]
    step = 300 / (len(points) - 1)
    pts_str = " ".join([f"{i * step:.1f},{120 - p * 0.8:.1f}" for i, p in enumerate(points)])
    
    svg = f"""<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 300 120" width="100%" height="100%">
  <defs>
    <linearGradient id="sparkGrad" x1="0%" y1="0%" x2="0%" y2="100%">
      <stop offset="0%" stop-color="#10b981" stop-opacity="0.4"/>
      <stop offset="100%" stop-color="#10b981" stop-opacity="0.0"/>
    </linearGradient>
  </defs>
  <polyline fill="url(#sparkGrad)" stroke="none" points="0,120 {pts_str} 300,120"/>
  <polyline fill="none" stroke="#10b981" stroke-width="3" stroke-linecap="round" stroke-linejoin="round" points="{pts_str}"/>
  <circle cx="300" cy="{120 - points[-1] * 0.8:.1f}" r="4" fill="#10b981"/>
</svg>"""
    (OUT_DIR / "sparkline_crypto.svg").write_text(svg, encoding="utf-8")
    print("Generated sparkline_crypto.svg")

def generate_holler_badges():
    """Generate Holler style dynamic geometric badge."""
    svg = """<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 200 200" width="100%" height="100%">
  <defs>
    <linearGradient id="neonCyan" x1="0%" y1="0%" x2="100%" y2="100%">
      <stop offset="0%" stop-color="#06b6d4"/>
      <stop offset="100%" stop-color="#3b82f6"/>
    </linearGradient>
  </defs>
  <rect width="200" height="200" rx="36" fill="#090d16" stroke="#1e293b" stroke-width="2"/>
  <polygon points="100,35 165,72 165,148 100,185 35,148 35,72" fill="none" stroke="url(#neonCyan)" stroke-width="4"/>
  <polygon points="100,55 145,82 145,138 100,165 55,138 55,82" fill="#06b6d4" opacity="0.12"/>
  <circle cx="100" cy="110" r="28" fill="url(#neonCyan)"/>
  <path d="M92,108 L108,108 M100,98 L100,122" stroke="#ffffff" stroke-width="4" stroke-linecap="round"/>
</svg>"""
    (OUT_DIR / "holler_badge.svg").write_text(svg, encoding="utf-8")
    print("Generated holler_badge.svg")

if __name__ == "__main__":
    generate_roman_numeral_card()
    generate_sparklines()
    generate_holler_badges()
