# DPI Unblock Suite Pro 1.0

A self-hosted diagnostics and routing panel for Discord, YouTube, Steam and Twitch.
It measures direct and proxied reachability, tracks node latency and uptime, and generates
a PAC file that tunnels only blocked domains while games and Steam stay direct.

**Honest scope:** the product ships no servers and does not "break" DPI by itself. It shows
what fails and automates routing through **your** SOCKS5/HTTP proxy. You need your own VPS
or a proxy you are allowed to use.

**No pip dependencies.** Python 3.9+, standard library only.

![Dashboard](screenshots/01-dashboard.png)

## Features

- **Service diagnostics** — Discord, YouTube, Steam, Twitch: DNS over HTTPS (Cloudflare),
  direct HTTPS request and request through a selected node. Shows HTTP status, latency,
  IP and error.
- **Node checks** — TCP ping for SOCKS5/HTTP proxies, 24-hour history, uptime, average
  latency, online/offline state.
- **Route verdict** — direct, proxy faster, proxy only, unreachable. Based on real
  requests, not guesses.
- **PAC generator** — tunnels Discord/YouTube/Twitch only; Steam and games stay `DIRECT`.
  Supports SOCKS5, HTTP and HTTPS proxies.
- **Monitoring** — background node pings with configurable interval and state-change log.
- **DoH tool** — resolve any domain via Cloudflare or Google.
- **Panel** — dark responsive UI, latency chart, password login, HMAC sessions,
  one-click PAC download.

## Quick start

```bash
cd dpi-unblock-suite-pro
python3 run.py --demo          # demo data
# open http://127.0.0.1:8090
# login: admin / admin123
```

Production:

```bash
python3 run.py
python3 run.py --port 9000
python3 run.py --no-monitor
```

### Docker

```bash
docker compose up -d --build
```

## Usage

1. Add a node (host, port, SOCKS5/HTTP) on the **Nodes** tab.
2. Press **Check** to verify TCP reachability.
3. Run **Diagnostics** for a service and node; compare direct vs proxied results.
4. Download `unblock.pac` from the **PAC** tab.
5. Point your OS or browser automatic proxy configuration to the file.
6. Verify Discord works and Steam still connects directly.

The PAC endpoint always reflects the current settings (`/api/pac`). Re-download after
changing domains or the proxy address.

## Verdicts

| Verdict | Meaning |
|---|---|
| Direct | Service works without a proxy |
| Proxy faster | Both work, proxy latency is 20%+ lower |
| Proxy only | Direct fails, proxy works |
| Unreachable | Both fail — check node and network |
| No data | No probe has run yet |

Latency is HTTP request time, not video throughput. The panel does not measure bandwidth
or 4K playback quality.

## Tests

```bash
python3 -m unittest discover -s tests -v
```

17 offline tests: PAC generation, domain normalisation/matching, DoH parsing, a real
SOCKS5 handshake against a local test server, verdict logic, SQLite, API auth, node CRUD,
PAC endpoint, settings, probe history. No external network.

## Limitations

- No built-in VPN/proxy servers: bring your own node.
- Measures reachability and request latency, not bandwidth or 4K quality.
- DPI may filter by SNI or IP; the panel reports failures but does not fix the node.
- PAC works in PAC-aware apps (browsers, macOS, Windows). Games with custom networking
  may ignore the system proxy and need an OS-level tunnel.
- Demo data is synthetic and labelled in the UI. Real checks require network access.
- The panel binds to `127.0.0.1` by default. Do not expose it without HTTPS and a strong
  password.

## License

Commercial single-buyer license, see `LICENSE.txt`.
