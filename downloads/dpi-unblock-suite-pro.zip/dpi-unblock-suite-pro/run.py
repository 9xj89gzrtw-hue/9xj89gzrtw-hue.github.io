#!/usr/bin/env python3
"""DPI Unblock Suite Pro — панель диагностики и маршрутизации.

    python3 run.py                 # http://127.0.0.1:8090
    python3 run.py --demo          # демонстрационные данные
    python3 run.py --no-monitor    # без фонового пинга узлов
"""
from __future__ import annotations

import argparse
import os
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))

from app.core import DB, seed_demo  # noqa: E402
from app.server import serve  # noqa: E402


def main() -> int:
    parser = argparse.ArgumentParser(description="DPI Unblock Suite Pro")
    parser.add_argument("--port", type=int, default=int(os.environ.get("PORT", 8090)))
    parser.add_argument("--host", default=os.environ.get("HOST", "127.0.0.1"))
    parser.add_argument("--demo", action="store_true")
    parser.add_argument("--no-demo", action="store_true")
    parser.add_argument("--no-monitor", action="store_true")
    args = parser.parse_args()

    db = DB()
    if args.demo or (not args.no_demo and db.get("demo_mode") == "1"):
        seed_demo(db)

    httpd = serve(port=args.port, host=args.host, with_monitor=not args.no_monitor)
    print(f"\n  DPI Unblock Suite Pro  ·  http://{args.host}:{args.port}")
    print("  Логин: admin / admin123 (смените в Настройках)\n")
    try:
        httpd.serve_forever()
    except KeyboardInterrupt:
        print("\n[server] остановлен")
    finally:
        httpd.monitor.stop()
        httpd.server_close()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
