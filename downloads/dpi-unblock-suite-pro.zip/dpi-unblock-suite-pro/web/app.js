/* DPI Unblock Suite Pro — панель */
const $ = (sel, root = document) => root.querySelector(sel);
const $$ = (sel, root = document) => [...root.querySelectorAll(sel)];

const state = {
  stats: null,
  nodes: [],
  settings: null,
  checks: [],
  view: 'dashboard',
  lastDiag: null,
};

const VERDICT = {
  proxy: ['Только через прокси', 'proxy'],
  proxy_faster: ['Прокси быстрее', 'proxy_faster'],
  direct: ['Напрямую', 'direct'],
  down: ['Недоступно', 'down'],
  unknown: ['Нет данных', 'unknown'],
};
const COLORS = ['#22d3ee', '#60a5fa', '#a78bfa', '#34d399', '#fbbf24', '#f472b6'];
const MODE_LABEL = { direct: 'Напрямую', proxy: 'Через прокси' };

async function api(path, opts = {}) {
  const res = await fetch(path, { headers: { 'Content-Type': 'application/json' }, ...opts });
  let data = {};
  try { data = await res.json(); } catch (e) { /* not json */ }
  if (!res.ok || data.ok === false) throw new Error(data.error || `HTTP ${res.status}`);
  return data;
}

function toast(message, kind = '') {
  const el = $('#toast');
  el.textContent = message;
  el.className = `toast ${kind}`;
  el.hidden = false;
  clearTimeout(toast._t);
  toast._t = setTimeout(() => { el.hidden = true; }, 4500);
}

function fmtTime(epoch) {
  if (!epoch) return '—';
  return new Date(epoch * 1000).toLocaleString('ru-RU',
    { day: '2-digit', month: '2-digit', hour: '2-digit', minute: '2-digit' });
}
function ago(epoch) {
  if (!epoch) return 'нет данных';
  const sec = Math.max(0, Math.floor(Date.now() / 1000 - epoch));
  if (sec < 60) return `${sec} сек назад`;
  if (sec < 3600) return `${Math.floor(sec / 60)} мин назад`;
  if (sec < 86400) return `${Math.floor(sec / 3600)} ч назад`;
  return `${Math.floor(sec / 86400)} дн назад`;
}
function escapeHtml(text) {
  return String(text ?? '').replace(/[&<>"']/g, (c) => ({
    '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;',
  }[c]));
}
function verdictBadge(v) {
  const [label, cls] = VERDICT[v] || VERDICT.unknown;
  return `<span class="badge ${cls}">${label}</span>`;
}
function ms(value) {
  return value ? `${Math.round(value)} мс` : '—';
}

/* ---------------- boot ---------------- */
async function boot() {
  const me = await api('/api/me');
  if (!me.authenticated) {
    $('#loginScreen').hidden = false;
    $('#app').hidden = true;
    $('#password').focus();
    return;
  }
  $('#loginScreen').hidden = true;
  $('#app').hidden = false;
  await loadAll();
  routeFromHash();
  setInterval(refreshQuiet, 30000);
}

async function loadAll() {
  const [stats, nodes, settings, checks] = await Promise.all([
    api('/api/stats'),
    api('/api/nodes'),
    api('/api/settings'),
    api('/api/checks?hours=24'),
  ]);
  state.stats = stats.data;
  state.nodes = nodes.data;
  state.settings = settings.data;
  state.checks = checks.data;
  renderAll();
}

async function refreshQuiet() {
  try {
    const [stats, nodes, checks] = await Promise.all([
      api('/api/stats'), api('/api/nodes'), api('/api/checks?hours=24'),
    ]);
    state.stats = stats.data;
    state.nodes = nodes.data;
    state.checks = checks.data;
    renderStats();
    renderNodes();
    renderChart();
  } catch (e) { /* silent */ }
}

$('#loginForm').addEventListener('submit', async (e) => {
  e.preventDefault();
  $('#loginErr').textContent = '';
  try {
    await api('/api/login', { method: 'POST', body: JSON.stringify({ password: $('#password').value }) });
    await boot();
  } catch (err) { $('#loginErr').textContent = err.message; }
});
$('#logoutBtn').addEventListener('click', async () => {
  await api('/api/logout', { method: 'POST' });
  location.reload();
});

/* ---------------- routing ---------------- */
const TITLES = {
  dashboard: ['Обзор', 'Доступность сервисов, задержки и маршруты'],
  nodes: ['Узлы', 'SOCKS5 и HTTP-прокси для туннеля'],
  diagnostics: ['Диагностика', 'Прямой маршрут, DoH и проверка через узел'],
  pac: ['PAC-файл', 'Автоматическая маршрутизация доменов'],
  settings: ['Настройки', 'Прокси, домены и доступ'],
  logs: ['Журнал', 'События мониторинга и проверок'],
};

function showView(name) {
  if (!TITLES[name]) name = 'dashboard';
  state.view = name;
  $$('.nav a').forEach((a) => a.classList.toggle('active', a.dataset.view === name));
  $$('.view').forEach((v) => v.classList.toggle('active', v.id === `view-${name}`));
  const [title, sub] = TITLES[name];
  $('#pageTitle').textContent = title;
  $('#pageSub').textContent = sub;
  if (location.hash !== `#${name}`) history.replaceState(null, '', `#${name}`);
  if (name === 'logs') loadLogs();
  if (name === 'settings') fillSettings();
  if (name === 'pac') loadPac();
  if (name === 'diagnostics') { fillDiagNodes(); loadDiagnostics(); }
}
function routeFromHash() { showView((location.hash || '#dashboard').slice(1)); }

$$('.nav a').forEach((a) => a.addEventListener('click', (e) => {
  e.preventDefault();
  showView(a.dataset.view);
}));
window.addEventListener('hashchange', routeFromHash);
$('#refreshBtn').addEventListener('click', async () => {
  await loadAll();
  if (state.view === 'pac') loadPac();
  toast('Данные обновлены', 'ok');
});
document.addEventListener('click', (e) => {
  const goto = e.target.closest('[data-goto]');
  if (goto) showView(goto.dataset.goto);
});

/* ---------------- dashboard ---------------- */
function renderStats() {
  const s = state.stats;
  if (!s) return;
  const services = s.services || {};
  const verdicts = Object.values(services).map((v) => v.verdict);
  const viaProxy = verdicts.filter((v) => v === 'proxy' || v === 'proxy_faster').length;
  const direct = verdicts.filter((v) => v === 'direct').length;

  $('#demoChip').hidden = !s.demo;
  $('#todayChip').textContent = new Date().toLocaleDateString('ru-RU', { day: 'numeric', month: 'long' });

  $('#kpis').innerHTML = `
    <div class="kpi"><div class="label">Узлы онлайн <span class="ic">⌁</span></div>
      <div class="value">${s.online}<span class="muted" style="font-size:18px">/${s.nodes}</span></div>
      <div class="sub">${s.nodes_enabled} включено · ${s.nodes - s.nodes_enabled} выключено</div></div>
    <div class="kpi"><div class="label">Средний пинг <span class="ic">◷</span></div>
      <div class="value">${s.avg_ms || 0}<span class="muted" style="font-size:16px"> мс</span></div>
      <div class="sub">по доступным узлам</div></div>
    <div class="kpi"><div class="label">Через прокси <span class="ic">⇄</span></div>
      <div class="value">${viaProxy}</div>
      <div class="sub">сервисов требуют туннель</div></div>
    <div class="kpi"><div class="label">Прямой маршрут <span class="ic">↯</span></div>
      <div class="value">${direct}</div>
      <div class="sub">игры и Steam напрямую</div></div>`;

  $('#probeChip').textContent = s.last_probe ? `Проверка ${ago(s.last_probe)}` : 'Проверок ещё не было';

  $('#services').innerHTML = Object.entries(services).map(([key, svc]) => {
    const d = svc.direct || {};
    const p = svc.proxy || {};
    const dText = d.ok ? `${d.status || 'ok'} · ${ms(d.ms)}` : (d.ts ? 'недоступно' : 'нет данных');
    const pText = p.ok ? `${p.status || 'ok'} · ${ms(p.ms)}` : (p.ts ? 'недоступно' : 'нет данных');
    return `<div class="svc">
      <div class="svc-top"><span class="svc-ic">${svc.icon}</span><b>${escapeHtml(svc.title)}</b>
        ${verdictBadge(svc.verdict)}</div>
      <div class="svc-row"><span class="lab">Напрямую</span>
        <span class="val ${d.ok ? 'ok' : (d.ts ? 'bad' : 'warn')}">${dText}</span></div>
      <div class="svc-row"><span class="lab">Через узел</span>
        <span class="val ${p.ok ? 'ok' : (p.ts ? 'bad' : 'warn')}">${pText}</span></div>
    </div>`;
  }).join('');

  $('#routing').innerHTML = Object.entries(services).map(([key, svc]) => {
    const [label, cls] = VERDICT[svc.verdict] || VERDICT.unknown;
    const icon = svc.verdict === 'direct' ? '↯' : (svc.verdict === 'down' ? '✕' : '⇄');
    return `<div class="route-row">
      <span>${svc.icon} ${escapeHtml(svc.title)}</span>
      <span class="badge ${cls}">${icon} ${label}</span>
    </div>`;
  }).join('');

  $('#sideProxy').textContent = `Прокси: ${s.proxy.host}:${s.proxy.port} · ${s.proxy.kind.toUpperCase()}`;
  $('#sideNodes').textContent = `Узлы: ${s.online}/${s.nodes} онлайн`;
  $('#sideStatus').textContent = s.demo ? 'Демо-режим' : (s.monitor ? 'Мониторинг активен' : 'Мониторинг выключен');
  $('#sidePulse').className = 'pulse' + (s.monitor && !s.demo ? '' : ' off');
  renderNodes();
}

function nodeStatus(n) {
  const last = n.last;
  if (!last) return `<span class="node-status"><i class="dot off"></i>нет проверок</span>`;
  if (last.ok) return `<span class="node-status"><i class="dot on"></i>онлайн</span>`;
  return `<span class="node-status"><i class="dot off"></i>недоступен</span>`;
}
function uptimeBar(value) {
  return `<div class="uptime"><div class="bar"><span style="width:${Math.min(100, value)}%"></span></div>
    <span class="muted small">${value}%</span></div>`;
}

function renderNodes() {
  const nodes = state.nodes;
  if (!nodes.length) {
    $('#nodesTable tbody').innerHTML = `<tr><td colspan="6" class="muted">Узлы не добавлены</td></tr>`;
    $('#nodesFull tbody').innerHTML = `<tr><td colspan="8" class="muted">Узлы не добавлены</td></tr>`;
    return;
  }
  $('#nodesTable tbody').innerHTML = nodes.map((n) => `
    <tr>
      <td><b>${escapeHtml(n.name)}</b></td>
      <td class="mono">${escapeHtml(n.host)}:${n.port}</td>
      <td class="muted">${n.kind.toUpperCase()}</td>
      <td>${nodeStatus(n)}</td>
      <td class="mono">${n.last && n.last.ok ? ms(n.last.tcp_ms) : '—'}</td>
      <td>${uptimeBar(n.uptime)}</td>
    </tr>`).join('');

  $('#nodesFull tbody').innerHTML = nodes.map((n) => `
    <tr data-id="${n.id}">
      <td><b>${escapeHtml(n.name)}</b></td>
      <td class="mono">${escapeHtml(n.host)}:${n.port}</td>
      <td class="muted">${n.kind.toUpperCase()}</td>
      <td class="muted">${escapeHtml(n.tag) || '—'}</td>
      <td>${nodeStatus(n)}</td>
      <td class="mono">${n.last && n.last.ok ? ms(n.last.tcp_ms) : '—'}</td>
      <td>${uptimeBar(n.uptime)}</td>
      <td>
        <div class="row" style="justify-content:flex-end;flex-wrap:nowrap">
          <button class="btn sm ghost" data-act="check" data-id="${n.id}">Проверить</button>
          <button class="btn sm ghost" data-act="edit" data-id="${n.id}">✎</button>
          <button class="btn sm danger" data-act="del" data-id="${n.id}">✕</button>
        </div>
      </td>
    </tr>`).join('');
}

function renderChart() {
  const svg = $('#latencyChart');
  const nodes = state.nodes.filter((n) => n.enabled);
  const width = 720, height = 230, left = 44, right = 14, top = 14, bottom = 26;
  const now = Date.now() / 1000;
  const from = now - 24 * 3600;
  const all = state.checks.filter((c) => c.ok && c.tcp_ms > 0);
  const maxMs = Math.max(50, ...all.map((c) => c.tcp_ms));
  const yMax = Math.ceil(maxMs / 25) * 25;
  const x = (ts) => left + (Math.min(now, Math.max(from, ts)) - from) / (now - from) * (width - left - right);
  const y = (value) => top + (1 - value / yMax) * (height - top - bottom);

  let parts = [`<rect x="0" y="0" width="${width}" height="${height}" fill="none"/>`];
  for (let i = 0; i <= 3; i++) {
    const value = (yMax / 3) * i;
    parts.push(`<line class="grid-line" x1="${left}" x2="${width - right}" y1="${y(value)}" y2="${y(value)}"/>`);
    parts.push(`<text x="${left - 8}" y="${y(value) + 3}" text-anchor="end">${Math.round(value)}</text>`);
  }
  parts.push(`<text x="${left}" y="${height - 6}">${new Date(from * 1000).toLocaleTimeString('ru-RU', { hour: '2-digit', minute: '2-digit' })}</text>`);
  parts.push(`<text x="${width - right}" y="${height - 6}" text-anchor="end">сейчас</text>`);

  const legend = [];
  nodes.forEach((node, idx) => {
    const color = COLORS[idx % COLORS.length];
    const points = state.checks
      .filter((c) => c.node_id === node.id && c.ok && c.tcp_ms > 0)
      .map((c) => `${x(c.ts).toFixed(1)},${y(c.tcp_ms).toFixed(1)}`);
    if (points.length > 1) {
      parts.push(`<polyline points="${points.join(' ')}" fill="none" stroke="${color}" stroke-width="2" stroke-linejoin="round" stroke-linecap="round"/>`);
    }
    legend.push(`<span><i style="background:${color}"></i>${escapeHtml(node.name)}</span>`);
  });

  if (!nodes.length) {
    parts.push(`<text x="${width / 2}" y="${height / 2}" text-anchor="middle">Нет узлов — добавьте первый</text>`);
  }
  svg.innerHTML = parts.join('');
  $('#chartLegend').innerHTML = legend.join('') || '<span>Нет данных за 24 часа</span>';
}

/* ---------------- nodes page ---------------- */
$('#nodesFull').addEventListener('click', async (e) => {
  const btn = e.target.closest('button[data-act]');
  if (!btn) return;
  const id = Number(btn.dataset.id);
  const node = state.nodes.find((n) => n.id === id);
  if (!node) return;
  if (btn.dataset.act === 'del') {
    if (!confirm(`Удалить узел «${node.name}»?`)) return;
    try {
      await api(`/api/nodes/${id}`, { method: 'DELETE' });
      toast('Узел удалён', 'ok');
      await loadAll();
    } catch (err) { toast(err.message, 'err'); }
  } else if (btn.dataset.act === 'check') {
    btn.disabled = true; btn.textContent = '…';
    try {
      const r = await api(`/api/nodes/${id}/check`, { method: 'POST', body: JSON.stringify({}) });
      toast(r.data.ok ? `Онлайн · ${ms(r.data.ms)}` : `Недоступен: ${r.data.error}`, r.data.ok ? 'ok' : 'err');
      await loadAll();
    } catch (err) { toast(err.message, 'err'); btn.disabled = false; btn.textContent = 'Проверить'; }
  } else if (btn.dataset.act === 'edit') {
    openNodeModal(node);
  }
});

function openNodeModal(node = null) {
  openModal(node ? 'Изменить узел' : 'Новый узел', `
    <div class="field"><label>Название</label><input class="input" id="nodeName" placeholder="Amsterdam · NL" value="${node ? escapeHtml(node.name) : ''}"></div>
    <div class="field"><label>Хост или IP</label><input class="input" id="nodeHost" placeholder="proxy.example.net" value="${node ? escapeHtml(node.host) : ''}"></div>
    <div class="field"><label>Порт</label><input class="input" id="nodePort" type="number" min="1" max="65535" value="${node ? node.port : 1080}"></div>
    <div class="field"><label>Тип</label>
      <select class="input" id="nodeKind">
        <option value="socks5">SOCKS5</option><option value="http">HTTP</option><option value="https">HTTPS</option>
      </select></div>
    <div class="field"><label>Тег</label><input class="input" id="nodeTag" placeholder="eu-west" value="${node ? escapeHtml(node.tag) : ''}"></div>
    <div class="note-card">Панель проверяет только TCP-доступность. Корректность логина/пароля прокси проверяется реальным запросом на вкладке «Диагностика».</div>`,
  `<button class="btn ghost" data-close>Отмена</button><button class="btn primary" id="nodeSave">Сохранить</button>`);
  if (node) $('#nodeKind').value = node.kind;
  $('#nodeSave').addEventListener('click', async () => {
    const payload = {
      name: $('#nodeName').value.trim(),
      host: $('#nodeHost').value.trim(),
      port: Number($('#nodePort').value),
      kind: $('#nodeKind').value,
      tag: $('#nodeTag').value.trim(),
    };
    try {
      if (node) await api(`/api/nodes/${node.id}`, { method: 'PUT', body: JSON.stringify(payload) });
      else await api('/api/nodes', { method: 'POST', body: JSON.stringify(payload) });
      closeModal();
      toast('Узел сохранён', 'ok');
      await loadAll();
    } catch (err) { toast(err.message, 'err'); }
  });
}
$('#addNodeBtn').addEventListener('click', () => openNodeModal());

/* ---------------- diagnostics ---------------- */
function fillDiagNodes() {
  const select = $('#diagNode');
  const prev = select.value;
  select.innerHTML = state.nodes.filter((n) => n.enabled)
    .map((n) => `<option value="${n.id}">${escapeHtml(n.name)} · ${n.kind.toUpperCase()}</option>`).join('');
  if (prev) select.value = prev;
}

async function loadDiagnostics() {
  try {
    const r = await api('/api/diagnostics');
    const probes = r.probes || [];
    $('#probeTable tbody').innerHTML = probes.length ? probes.map((p) => `
      <tr>
        <td class="mono muted">${fmtTime(p.ts)}</td>
        <td>${escapeHtml((state.stats?.services?.[p.service]?.title) || p.service)}</td>
        <td class="muted">${MODE_LABEL[p.mode] || p.mode}</td>
        <td><span class="badge ${p.ok ? 'published' : 'down'}">${p.ok ? 'ok' : 'fail'}</span></td>
        <td class="mono">${p.ok ? ms(p.ms) : '—'}</td>
        <td class="mono muted">${escapeHtml(p.ip) || '—'}</td>
      </tr>`).join('') : '<tr><td colspan="6" class="muted">Проверок ещё не было</td></tr>';
    if (!state.lastDiag) renderDiagResult(pickService(), state.stats?.services?.[pickService()]);
  } catch (err) { toast(err.message, 'err'); }
}

function pickService() { return $('#diagService').value || 'discord'; }

function diagCard(title, data, extra = '') {
  if (!data) data = {};
  const okClass = data.ok ? 'ok' : (data.ts || data.error ? 'bad' : 'warn');
  return `<div class="diag-card">
    <h4>${title} <span class="${okClass}">${data.ok ? 'доступен' : (data.error || data.ts ? 'недоступен' : 'нет данных')}</span></h4>
    <div class="diag-line"><span>HTTP-статус</span><b>${data.status || '—'}</b></div>
    <div class="diag-line"><span>Задержка</span><b>${data.ok ? ms(data.ms) : '—'}</b></div>
    <div class="diag-line"><span>IP из DoH</span><b>${escapeHtml(extra || data.ip || '—')}</b></div>
    <div class="diag-line"><span>Время проверки</span><b>${data.ts ? fmtTime(data.ts) : 'только что'}</b></div>
    ${data.error ? `<div class="diag-line"><span>Ошибка</span><b class="bad" style="max-width:60%;text-align:right">${escapeHtml(data.error)}</b></div>` : ''}
  </div>`;
}

function renderDiagResult(serviceKey, svc) {
  const key = serviceKey || 'discord';
  if (!svc) {
    $('#diagResult').innerHTML = `<div class="empty" style="grid-column:1/-1"><b>Нет данных</b>Запустите проверку — результат появится здесь.</div>`;
    return;
  }
  const nodeName = state.nodes.find((n) => n.enabled)?.name || 'узел';
  const [vlabel, vcls] = VERDICT[svc.verdict] || VERDICT.unknown;
  const explain = svc.verdict === 'proxy'
    ? 'Прямой маршрут не проходит, туннель работает — включайте PAC или прокси для этого сервиса.'
    : (svc.verdict === 'proxy_faster'
      ? 'Оба маршрута доступны, но через узел заметно быстрее.'
      : (svc.verdict === 'direct'
        ? 'Сервис доступен напрямую, прокси не обязателен.'
        : 'Нет успешных проверок — проверьте узел и настройки прокси.'));
  $('#diagResult').innerHTML = `
    <div class="diag-card">
      <h4>${svc.icon} ${escapeHtml(svc.title)} · прямой маршрут</h4>
      ${diagCard('Напрямую', svc.direct, svc.direct?.ip)}
    </div>
    <div class="diag-card">
      <h4>${svc.icon} через ${escapeHtml(nodeName)}</h4>
      ${diagCard('Через прокси', svc.proxy, svc.proxy?.ip)}
    </div>
    <div class="note-card" style="grid-column:1/-1">
      Вердикт: <span class="badge ${vcls}">${vlabel}</span> — ${explain}
    </div>`;
}

$('#runDiagBtn').addEventListener('click', async () => {
  const btn = $('#runDiagBtn');
  const service = pickService();
  const nodeId = Number($('#diagNode').value) || null;
  btn.disabled = true;
  btn.innerHTML = '<span class="spinner"></span>Проверяю…';
  try {
    const r = await api('/api/diagnostics/run', {
      method: 'POST', body: JSON.stringify({ service, node_id: nodeId }),
    });
    state.lastDiag = r.data;
    state.stats.services = r.services;
    renderStats();
    renderDiagResult(service, r.services[service]);
    await loadDiagnostics();
    toast('Проверка завершена', 'ok');
  } catch (err) {
    toast(err.message, 'err');
  } finally {
    btn.disabled = false;
    btn.textContent = 'Запустить проверку';
  }
});
$('#refreshProbesBtn').addEventListener('click', loadDiagnostics);
$('#diagService').addEventListener('change', () => {
  state.lastDiag = null;
  renderDiagResult(pickService(), state.stats?.services?.[pickService()]);
});

/* ---------------- PAC ---------------- */
async function loadPac() {
  try {
    const res = await fetch('/api/pac');
    const text = await res.text();
    $('#pacCode').textContent = text;
    const s = state.settings;
    if (s) {
      const blocked = (s.pac_blocked || '').split(/[\n,]+/).map((x) => x.trim()).filter(Boolean);
      const direct = (s.pac_direct || '').split(/[\n,]+/).map((x) => x.trim()).filter(Boolean);
      $('#blockedChips').innerHTML = blocked.map((d) => `<span class="domain-chip">${escapeHtml(d)}</span>`).join('');
      $('#directChips').innerHTML = direct.map((d) => `<span class="domain-chip">${escapeHtml(d)}</span>`).join('');
      $('#blockedCount').textContent = `· ${blocked.length}`;
      $('#directCount').textContent = `· ${direct.length}`;
      $('#pacProxy').textContent = `${s.proxy_kind.toUpperCase()} ${s.proxy_host}:${s.proxy_port}`;
    }
  } catch (err) { toast(err.message, 'err'); }
}

$('#copyPacBtn').addEventListener('click', async () => {
  const text = $('#pacCode').textContent;
  try {
    await navigator.clipboard.writeText(text);
    toast('PAC-файл скопирован', 'ok');
  } catch (e) {
    toast('Браузер запретил буфер обмена — скачайте файл', 'err');
  }
});

/* ---------------- settings ---------------- */
function fillSettings() {
  const s = state.settings;
  if (!s) return;
  $('#proxy_host').value = s.proxy_host || '';
  $('#proxy_port').value = s.proxy_port || 1080;
  $('#proxy_kind').value = s.proxy_kind || 'socks5';
  $('#timeout').value = s.timeout || 4;
  $('#ping_interval').value = s.ping_interval || 60;
  $('#pac_blocked').value = s.pac_blocked || '';
  $('#pac_direct').value = s.pac_direct || '';
  $('#new_password').value = '';
}

$('#saveSettingsBtn').addEventListener('click', async () => {
  const payload = {
    proxy_host: $('#proxy_host').value.trim(),
    proxy_port: $('#proxy_port').value,
    proxy_kind: $('#proxy_kind').value,
    timeout: $('#timeout').value,
    ping_interval: $('#ping_interval').value,
    pac_blocked: $('#pac_blocked').value,
    pac_direct: $('#pac_direct').value,
  };
  if ($('#new_password').value) payload.new_password = $('#new_password').value;
  try {
    await api('/api/settings', { method: 'PUT', body: JSON.stringify(payload) });
    toast('Настройки сохранены', 'ok');
    await loadAll();
    fillSettings();
  } catch (err) { toast(err.message, 'err'); }
});

$('#dnsTestBtn').addEventListener('click', async () => {
  const out = $('#dnsResult');
  const domain = $('#dnsDomain').value.trim();
  if (!domain) return toast('Укажите домен', 'err');
  out.hidden = false;
  out.textContent = 'Запрос…';
  try {
    const r = await api('/api/dns/test', { method: 'POST', body: JSON.stringify({ domain }) });
    const d = r.data;
    out.textContent = d.ok
      ? `${domain} → ${d.ip}\nDoH: ${d.provider} · ${ms(d.ms)}`
      : `Не удалось: ${d.error}`;
  } catch (err) { out.textContent = err.message; }
});

/* ---------------- logs ---------------- */
async function loadLogs() {
  try {
    const r = await api('/api/logs?limit=150');
    $('#logsTable tbody').innerHTML = r.data.length ? r.data.map((l) => `
      <tr><td class="mono muted">${fmtTime(l.ts)}</td>
      <td><span class="log-kind">${escapeHtml(l.kind)}</span></td>
      <td>${escapeHtml(l.message)}</td></tr>`).join('')
      : '<tr><td colspan="3" class="muted">Журнал пуст</td></tr>';
  } catch (err) { toast(err.message, 'err'); }
}
$('#refreshLogsBtn').addEventListener('click', loadLogs);

/* ---------------- modal ---------------- */
function openModal(title, body, foot = '') {
  $('#modalTitle').textContent = title;
  $('#modalBody').innerHTML = body;
  $('#modalFoot').innerHTML = foot;
  $('#overlay').hidden = false;
  $$('[data-close]', $('#modal')).forEach((b) => b.addEventListener('click', closeModal));
}
function closeModal() { $('#overlay').hidden = true; }
$('#modalClose').addEventListener('click', closeModal);
$('#overlay').addEventListener('click', (e) => { if (e.target === $('#overlay')) closeModal(); });
document.addEventListener('keydown', (e) => { if (e.key === 'Escape') closeModal(); });

/* ---------------- all ---------------- */
function renderAll() {
  renderStats();
  renderNodes();
  renderChart();
  fillSettings();
  fillDiagNodes();
}

boot().catch((err) => {
  console.error(err);
  $('#loginScreen').hidden = false;
  $('#loginErr').textContent = 'Сервер недоступен: ' + err.message;
});
