"""Тесты DPI Unblock Suite Pro (stdlib unittest)."""
from __future__ import annotations

import json
import os
import socket
import sys
import tempfile
import threading
import time
import unittest
import urllib.error
import urllib.request
from http.cookiejar import CookieJar
from http.server import ThreadingHTTPServer
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

from app.core import DB, SERVICES, seed_demo, verify_password  # noqa: E402
from app.net import (  # noqa: E402
    build_pac, matches, parse_doh_response, parse_domains, socks5_connect,
)
from app.scheduler import verdict  # noqa: E402


class PacTest(unittest.TestCase):
    def test_domains_normalised(self):
        raw = "Discord.com\n.discord.com\nhttps://youtube.com\n\nbad host\nyoutu.be"
        self.assertEqual(parse_domains(raw), ["discord.com", "youtube.com", "youtu.be"])

    def test_domain_matching(self):
        domains = ["discord.com", "youtube.com"]
        self.assertTrue(matches("discord.com", domains))
        self.assertTrue(matches("cdn.discord.com", domains))
        self.assertTrue(matches("www.youtube.com", domains))
        self.assertFalse(matches("notdiscord.com", domains))
        self.assertFalse(matches("example.org", domains))

    def test_pac_contents(self):
        pac = build_pac("127.0.0.1", 1080, "socks5",
                        ["discord.com", "youtube.com"], ["steampowered.com"])
        self.assertIn("FindProxyForURL", pac)
        self.assertIn("SOCKS5 127.0.0.1:1080", pac)
        self.assertIn('".discord.com"', pac)
        self.assertIn('".steampowered.com"', pac)
        self.assertIn("return \"DIRECT\"", pac)
        self.assertIn("dnsDomainIs", pac)

    def test_pac_http_kind(self):
        pac = build_pac("10.0.0.1", 3128, "http", ["discord.com"], [])
        self.assertIn("PROXY 10.0.0.1:3128", pac)
        self.assertNotIn("SOCKS5", pac)


class DnsTest(unittest.TestCase):
    def test_parse_doh_answer(self):
        data = {"Status": 0, "Answer": [
            {"name": "discord.com.", "type": 5, "data": "alias.discord.com."},
            {"name": "discord.com.", "type": 1, "data": "162.159.128.233"},
        ]}
        self.assertEqual(parse_doh_response(data), "162.159.128.233")

    def test_parse_doh_empty(self):
        self.assertIsNone(parse_doh_response({"Status": 3, "Answer": []}))
        self.assertIsNone(parse_doh_response({}))


class FakeSocks(threading.Thread):
    """Минимальный SOCKS5-сервер: приветствие + CONNECT + успешный ответ."""

    def __init__(self):
        super().__init__(daemon=True)
        self.ready = threading.Event()
        self.connected = threading.Event()
        self.sock = socket.socket()
        self.sock.bind(("127.0.0.1", 0))
        self.sock.listen(1)
        self.port = self.sock.getsockname()[1]
        self.error = ""

    def run(self):
        self.ready.set()
        try:
            conn, _ = self.sock.accept()
            conn.settimeout(3)
            greeting = conn.recv(3)
            if greeting != b"\x05\x01\x00":
                self.error = f"bad greeting {greeting!r}"
            conn.sendall(b"\x05\x00")
            head = conn.recv(4)
            if head[3] == 3:
                length = conn.recv(1)[0]
                host = conn.recv(length)
            elif head[3] == 1:
                host = conn.recv(4)
            else:
                host = b""
            conn.recv(2)
            self.connected.set()
            conn.sendall(b"\x05\x00\x00\x01\x7f\x00\x00\x01\x00\x50")
            time.sleep(0.3)
            conn.close()
        except OSError as e:
            self.error = str(e)
        finally:
            self.sock.close()


class SocksTest(unittest.TestCase):
    def test_handshake(self):
        server = FakeSocks()
        server.start()
        server.ready.wait(2)
        sock = socks5_connect("127.0.0.1", server.port, "discord.com", 443, timeout=3)
        self.assertTrue(server.connected.wait(2))
        self.assertEqual(server.error, "")
        sock.close()
        server.join(2)


class VerdictTest(unittest.TestCase):
    def test_verdicts(self):
        ok = {"ok": True, "ms": 40}
        slow = {"ok": True, "ms": 150}
        fail = {"ok": False, "ms": 0}
        self.assertEqual(verdict(fail, ok), "proxy")
        self.assertEqual(verdict(slow, ok), "proxy_faster")
        self.assertEqual(verdict(ok, slow), "direct")
        self.assertEqual(verdict(ok, fail), "direct")
        self.assertEqual(verdict(fail, fail), "down")
        self.assertEqual(verdict(None, None), "unknown")


class DBTest(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.NamedTemporaryFile(suffix=".db", delete=False).name
        self.db = DB(self.tmp)

    def tearDown(self):
        self.db.close()
        os.unlink(self.tmp)

    def test_password(self):
        self.assertTrue(verify_password("admin123", self.db.get("admin_password")))
        self.assertFalse(verify_password("nope", self.db.get("admin_password")))

    def test_seed_and_stats(self):
        seed_demo(self.db)
        stats = self.db.stats()
        self.assertEqual(stats["nodes"], 4)
        self.assertTrue(stats["demo"])
        self.assertGreater(stats["online"], 0)
        self.assertIn("discord:proxy", stats["probes"])
        self.assertGreaterEqual(len(self.db.checks()), 90)

    def test_node_crud(self):
        nid = self.db.add_node("Test", "127.0.0.1", 1080, "socks5", "local")
        self.db.update_node(nid, enabled=0)
        self.assertEqual(self.db.node(nid)["enabled"], 0)
        self.db.delete_node(nid)
        self.assertIsNone(self.db.node(nid))


class ApiTest(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.tmpdir = tempfile.mkdtemp()
        os.environ["DPI_DB"] = os.path.join(cls.tmpdir, "api.db")
        os.environ["DPI_DATA_DIR"] = cls.tmpdir
        os.environ["DPI_QUIET"] = "1"
        from app import server
        cls.db = DB(os.environ["DPI_DB"])
        seed_demo(cls.db)
        server.Handler.db = cls.db
        server.Handler.monitor = None
        cls.httpd = ThreadingHTTPServer(("127.0.0.1", 0), server.Handler)
        cls.port = cls.httpd.server_address[1]
        threading.Thread(target=cls.httpd.serve_forever, daemon=True).start()
        cls.jar = CookieJar()
        cls.opener = urllib.request.build_opener(urllib.request.HTTPCookieProcessor(cls.jar))

    @classmethod
    def tearDownClass(cls):
        cls.httpd.shutdown()
        cls.httpd.server_close()
        cls.db.close()

    def call(self, path, method="GET", payload=None):
        data = json.dumps(payload).encode() if payload is not None else None
        req = urllib.request.Request(
            f"http://127.0.0.1:{self.port}{path}", data=data, method=method,
            headers={"Content-Type": "application/json"},
        )
        with self.opener.open(req, timeout=10) as resp:
            return resp.status, json.loads(resp.read().decode())

    def test_01_auth_required(self):
        with self.assertRaises(urllib.error.HTTPError) as ctx:
            self.call("/api/stats")
        self.assertEqual(ctx.exception.code, 401)

    def test_02_login_stats(self):
        self.call("/api/login", "POST", {"password": "admin123"})
        status, data = self.call("/api/stats")
        self.assertEqual(status, 200)
        self.assertEqual(data["data"]["nodes"], 4)
        self.assertIn("discord", data["data"]["services"])
        self.assertEqual(data["data"]["services"]["discord"]["verdict"], "proxy")
        self.assertEqual(data["data"]["services"]["steam"]["verdict"], "direct")

    def test_03_nodes(self):
        status, data = self.call("/api/nodes")
        self.assertGreaterEqual(len(data["data"]), 4)
        status, data = self.call("/api/nodes", "POST",
                                 {"name": "Test", "host": "127.0.0.1", "port": 9999})
        self.assertEqual(status, 201)
        nid = data["id"]
        self.assertEqual(self.call(f"/api/nodes/{nid}", "DELETE")[1]["ok"], True)

    def test_04_pac(self):
        with self.opener.open(f"http://127.0.0.1:{self.port}/api/pac", timeout=10) as resp:
            body = resp.read().decode()
            ctype = resp.headers.get("Content-Type")
        self.assertIn("FindProxyForURL", body)
        self.assertIn("discord.com", body)
        self.assertIn("steampowered.com", body)
        self.assertIn("proxy-autoconfig", ctype)

    def test_05_settings(self):
        status, data = self.call("/api/settings")
        self.assertNotIn("admin_password", data["data"])
        self.call("/api/settings", "PUT", {"proxy_port": "1081"})
        self.assertEqual(self.call("/api/settings")[1]["data"]["proxy_port"], "1081")
        self.call("/api/settings", "PUT", {"proxy_port": "1080"})

    def test_06_checks_and_diagnostics(self):
        status, data = self.call("/api/checks?hours=24")
        self.assertGreaterEqual(len(data["data"]), 90)
        status, data = self.call("/api/diagnostics")
        self.assertIn("discord", data["data"])
        self.assertTrue(data["probes"])


if __name__ == "__main__":
    unittest.main()
