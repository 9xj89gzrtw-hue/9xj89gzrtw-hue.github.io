"""Сетевые проверки без внешних зависимостей: DoH, TCP, SOCKS5, HTTPS, PAC."""
from __future__ import annotations

import json
import socket
import ssl
import time
import urllib.error
import urllib.parse
import urllib.request

UA = "DPI-Unblock-Suite/1.0"
DOH_PROVIDERS = {
    "cloudflare": "https://cloudflare-dns.com/dns-query",
    "google": "https://dns.google/resolve",
}


def parse_domains(raw: str) -> list:
    out = []
    seen = set()
    for line in (raw or "").replace(",", "\n").splitlines():
        host = line.strip().lower()
        for prefix in ("https://", "http://"):
            if host.startswith(prefix):
                host = host[len(prefix):]
        host = host.split("/", 1)[0].split(":", 1)[0].lstrip(".")
        if not host or host in seen:
            continue
        if not all(part and all(c.isalnum() or c in "-_" for c in part)
                   for part in host.split(".")):
            continue
        seen.add(host)
        out.append(host)
    return out


def matches(host: str, domains: list) -> bool:
    host = (host or "").lower().strip(".")
    for domain in domains:
        domain = domain.lower().lstrip(".")
        if host == domain or host.endswith("." + domain):
            return True
    return False


def build_pac(proxy_host: str, proxy_port: int, kind: str,
              blocked: list, direct: list) -> str:
    if kind == "http":
        proxy = f"PROXY {proxy_host}:{proxy_port}; DIRECT"
    elif kind == "https":
        proxy = f"HTTPS {proxy_host}:{proxy_port}; PROXY {proxy_host}:{proxy_port}; DIRECT"
    else:
        proxy = (f"SOCKS5 {proxy_host}:{proxy_port}; "
                 f"SOCKS {proxy_host}:{proxy_port}; DIRECT")

    def js_list(items: list) -> str:
        return ",\n  ".join(json.dumps("." + d) for d in items) or ""

    return f"""// DPI Unblock Suite Pro — automatic proxy configuration
// Generated {time.strftime('%Y-%m-%d %H:%M:%S')}
// Tunnelled domains: {len(blocked)} · direct domains: {len(direct)}

var PROXY = "{proxy}";

var TUNNEL = [
  {js_list(blocked)}
];

var DIRECT_DOMAINS = [
  {js_list(direct)}
];

function _isDomain(host, domain) {{
  // domain stored with a leading dot: matches subdomains, apex checked separately
  return host === domain.substring(1) || dnsDomainIs(host, domain);
}}

function FindProxyForURL(url, host) {{
  host = host.toLowerCase();

  for (var i = 0; i < DIRECT_DOMAINS.length; i++) {{
    if (_isDomain(host, DIRECT_DOMAINS[i])) return "DIRECT";
  }}
  for (var j = 0; j < TUNNEL.length; j++) {{
    if (_isDomain(host, TUNNEL[j])) return PROXY;
  }}
  if (isPlainHostName(host)) return "DIRECT";
  if (shExpMatch(host, "*.local") || shExpMatch(host, "127.*") ||
      shExpMatch(host, "10.*") || shExpMatch(host, "192.168.*")) return "DIRECT";
  return "DIRECT";
}}
"""


# ---------------- DNS over HTTPS ----------------
def parse_doh_response(data: dict):
    for answer in data.get("Answer") or []:
        if answer.get("type") in (1, 28) and answer.get("data"):
            return str(answer["data"])
    return None


def doh_query(name: str, provider: str = "cloudflare", timeout: int = 6) -> dict:
    base = DOH_PROVIDERS.get(provider, DOH_PROVIDERS["cloudflare"])
    url = f"{base}?name={urllib.parse.quote(name)}&type=A"
    req = urllib.request.Request(url, headers={"Accept": "application/dns-json", "User-Agent": UA})
    started = time.monotonic()
    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            data = json.loads(resp.read().decode("utf-8", "replace"))
    except (urllib.error.URLError, socket.timeout, ValueError) as e:
        return {"ok": False, "ip": "", "ms": 0, "provider": provider, "error": str(e)}
    ms = round((time.monotonic() - started) * 1000, 1)
    ip = parse_doh_response(data)
    return {"ok": bool(ip), "ip": ip or "", "ms": ms, "provider": provider,
            "error": "" if ip else "no A/AAAA answer"}


# ---------------- TCP ----------------
def tcp_ping(host: str, port: int, timeout: float = 4.0) -> dict:
    started = time.monotonic()
    try:
        with socket.create_connection((host, int(port)), timeout=timeout):
            pass
    except (OSError, socket.timeout) as e:
        return {"ok": False, "ms": 0, "error": str(e)}
    return {"ok": True, "ms": round((time.monotonic() - started) * 1000, 1), "error": ""}


# ---------------- SOCKS5 ----------------
class SocksError(RuntimeError):
    pass


def socks5_connect(proxy_host: str, proxy_port: int, target_host: str,
                   target_port: int, timeout: float = 6.0) -> socket.socket:
    sock = socket.create_connection((proxy_host, int(proxy_port)), timeout=timeout)
    try:
        sock.sendall(b"\x05\x01\x00")
        if sock.recv(2) != b"\x05\x00":
            raise SocksError("SOCKS5: proxy requires authentication")
        try:
            ip = socket.inet_aton(target_host)
            addr = b"\x01" + ip
        except OSError:
            raw = target_host.encode("idna")[:255]
            addr = b"\x03" + bytes([len(raw)]) + raw
        sock.sendall(b"\x05\x01\x00" + addr + int(target_port).to_bytes(2, "big"))
        head = sock.recv(4)
        if len(head) < 4 or head[0] != 5:
            raise SocksError("SOCKS5: bad reply")
        if head[1] != 0:
            codes = {1: "general failure", 2: "connection not allowed", 3: "network unreachable",
                     4: "host unreachable", 5: "connection refused", 6: "TTL expired",
                     7: "command not supported", 8: "address type not supported"}
            raise SocksError("SOCKS5: " + codes.get(head[1], f"error {head[1]}"))
        atyp = head[3]
        if atyp == 1:
            sock.recv(4)
        elif atyp == 3:
            length = sock.recv(1)[0]
            sock.recv(length)
        elif atyp == 4:
            sock.recv(16)
        sock.recv(2)
        return sock
    except Exception:
        sock.close()
        raise


def http_via_socks(node: dict, host: str, path: str = "/", timeout: float = 8.0) -> dict:
    started = time.monotonic()
    sock = None
    try:
        sock = socks5_connect(node["host"], int(node["port"]), host, 443, timeout=timeout)
        ctx = ssl.create_default_context()
        tls = ctx.wrap_socket(sock, server_hostname=host)
        tls.sendall(
            f"GET {path} HTTP/1.1\r\nHost: {host}\r\nUser-Agent: {UA}\r\n"
            "Accept: */*\r\nConnection: close\r\n\r\n".encode()
        )
        line = tls.recv(64).split(b"\r\n", 1)[0].decode("latin-1", "replace")
        tls.close()
        parts = line.split()
        status = int(parts[1]) if len(parts) >= 2 and parts[1].isdigit() else 0
        ms = round((time.monotonic() - started) * 1000, 1)
        return {"ok": 100 <= status < 500, "ms": ms, "status": status, "error": ""}
    except (OSError, SocksError, ssl.SSLError, socket.timeout) as e:
        return {"ok": False, "ms": 0, "status": 0, "error": str(e)}
    finally:
        if sock is not None:
            try:
                sock.close()
            except OSError:
                pass


def http_direct(host: str, path: str = "/", timeout: float = 6.0) -> dict:
    started = time.monotonic()
    req = urllib.request.Request(f"https://{host}{path}", headers={
        "User-Agent": UA, "Accept": "*/*",
    })
    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            status = resp.status
    except urllib.error.HTTPError as e:
        status = e.code
    except (urllib.error.URLError, ssl.SSLError, socket.timeout) as e:
        return {"ok": False, "ms": 0, "status": 0, "error": str(e)}
    return {"ok": 100 <= status < 500, "ms": round((time.monotonic() - started) * 1000, 1),
            "status": status, "error": ""}


def probe_service(service: dict, node: dict | None, timeout: float = 6.0) -> dict:
    """Проверка сервиса напрямую и (если задан узел) через SOCKS5/HTTP-прокси."""
    host = service["host"]
    path = service.get("path", "/")
    dns = doh_query(host, timeout=timeout)
    direct = http_direct(host, path, timeout=timeout)
    result = {
        "service": service.get("key", ""),
        "host": host,
        "ip": dns.get("ip", ""),
        "dns_ms": dns.get("ms", 0),
        "direct": direct,
        "node_id": node["id"] if node else 0,
        "proxy": None,
    }
    if node:
        kind = (node.get("kind") or "socks5").lower()
        if kind == "socks5":
            result["proxy"] = http_via_socks(node, host, path, timeout=timeout)
        else:
            # HTTP-прокси: CONNECT через стандартный запрос urllib
            result["proxy"] = http_via_http_proxy(node, host, path, timeout=timeout)
    return result


def http_via_http_proxy(node: dict, host: str, path: str = "/", timeout: float = 8.0) -> dict:
    started = time.monotonic()
    proxy = f"http://{node['host']}:{int(node['port'])}"
    opener = urllib.request.build_opener(
        urllib.request.ProxyHandler({"http": proxy, "https": proxy})
    )
    req = urllib.request.Request(f"https://{host}{path}", headers={
        "User-Agent": UA, "Accept": "*/*",
    })
    try:
        with opener.open(req, timeout=timeout) as resp:
            status = resp.status
    except urllib.error.HTTPError as e:
        status = e.code
    except (urllib.error.URLError, ssl.SSLError, socket.timeout) as e:
        return {"ok": False, "ms": 0, "status": 0, "error": str(e)}
    return {"ok": 100 <= status < 500, "ms": round((time.monotonic() - started) * 1000, 1),
            "status": status, "error": ""}
