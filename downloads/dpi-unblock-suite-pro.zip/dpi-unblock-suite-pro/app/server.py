"""HTTP-сервер панели и API (stdlib)."""
from __future__ import annotations

import hmac
import json
import mimetypes
import os
import re
import secrets
import threading
import time
from http import cookies
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import parse_qs, urlparse

from .core import BASE_DIR, SERVICES, DB, hash_password, verify_password
from .net import build_pac, doh_query, parse_domains
from .scheduler import Monitor, run_diagnostics, verdict

WEB_DIR = BASE_DIR / "web"
DATA_DIR = Path(os.environ.get("DPI_DATA_DIR", BASE_DIR / "data"))
SECRET_FILE = DATA_DIR / "secret.key"
COOKIE = "dpi_session"
TTL = 60 * 60 * 12
KINDS = ("socks5", "http", "https")


def _secret() -> bytes:
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    if SECRET_FILE.exists():
        return SECRET_FILE.read_bytes()
    value = secrets.token_bytes(32)
    SECRET_FILE.write_bytes(value)
    try:
        SECRET_FILE.chmod(0o600)
    except OSError:
        pass
    return value


SECRET = _secret()


def make_session() -> str:
    ts = str(int(time.time()))
    sig = hmac.new(SECRET, ts.encode(), "sha256").hexdigest()[:40]
    return f"{ts}.{sig}"


def valid_session(token: str) -> bool:
    if not token or "." not in token:
        return False
    ts, sig = token.split(".", 1)
    expected = hmac.new(SECRET, ts.encode(), "sha256").hexdigest()[:40]
    if not hmac.compare_digest(sig, expected):
        return False
    try:
        return time.time() - int(ts) < TTL
    except ValueError:
        return False


class ApiError(Exception):
    def __init__(self, message: str, status: int = 400):
        super().__init__(message)
        self.message = message
        self.status = status


class Handler(BaseHTTPRequestHandler):
    db: DB
    monitor: Monitor | None = None
    server_version = "DPIUnblockSuitePro/1.0"

    def log_message(self, fmt, *args):
        if os.environ.get("DPI_QUIET") == "1":
            return
        print("[http] " + fmt % args)

    def _send(self, status: int, body: bytes, ctype="application/json; charset=utf-8",
              extra: dict | None = None):
        self.send_response(status)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(body)))
        self.send_header("X-Content-Type-Options", "nosniff")
        self.send_header("Cache-Control", "no-store")
        for k, v in (extra or {}).items():
            self.send_header(k, v)
        self.end_headers()
        if self.command != "HEAD":
            self.wfile.write(body)

    def json(self, data, status=200, extra=None):
        self._send(status, json.dumps(data, ensure_ascii=False).encode(), extra=extra)

    def error(self, message, status=400):
        self.json({"ok": False, "error": message}, status)

    def token(self) -> str:
        jar = cookies.SimpleCookie()
        try:
            jar.load(self.headers.get("Cookie", ""))
        except cookies.CookieError:
            return ""
        m = jar.get(COOKIE)
        return m.value if m else ""

    def require_auth(self):
        if not valid_session(self.token()):
            raise ApiError("Требуется вход в панель", 401)

    def body(self) -> dict:
        length = int(self.headers.get("Content-Length") or 0)
        if length > 1_000_000:
            raise ApiError("Слишком большой запрос", 413)
        raw = self.rfile.read(length) if length else b""
        if not raw:
            return {}
        try:
            data = json.loads(raw.decode("utf-8"))
        except (ValueError, UnicodeDecodeError):
            raise ApiError("Некорректный JSON")
        if not isinstance(data, dict):
            raise ApiError("Ожидался JSON-объект")
        return data

    def do_GET(self):
        parsed = urlparse(self.path)
        try:
            if parsed.path.startswith("/api/"):
                self.api("GET", parsed.path, parse_qs(parsed.query), None)
            else:
                self.static(parsed.path)
        except ApiError as e:
            self.error(e.message, e.status)
        except BrokenPipeError:
            pass
        except Exception as e:  # noqa: BLE001
            print("[error]", repr(e))
            self.error("Внутренняя ошибка сервера", 500)

    do_HEAD = do_GET

    def do_POST(self):
        self.mutate("POST")

    def do_PUT(self):
        self.mutate("PUT")

    def do_DELETE(self):
        self.mutate("DELETE")

    def mutate(self, method):
        parsed = urlparse(self.path)
        try:
            self.api(method, parsed.path, parse_qs(parsed.query), self.body())
        except ApiError as e:
            self.error(e.message, e.status)
        except BrokenPipeError:
            pass
        except Exception as e:  # noqa: BLE001
            print("[error]", repr(e))
            self.error("Внутренняя ошибка сервера", 500)

    def static(self, path: str):
        if path in ("/", ""):
            path = "/index.html"
        target = (WEB_DIR / path.lstrip("/")).resolve()
        if not str(target).startswith(str(WEB_DIR.resolve())) or not target.is_file():
            target = WEB_DIR / "index.html"
        if not target.is_file():
            return self.error("Не найдено", 404)
        ctype = mimetypes.guess_type(str(target))[0] or "application/octet-stream"
        if ctype.startswith("text/") or "javascript" in ctype:
            ctype += "; charset=utf-8"
        self._send(200, target.read_bytes(), ctype)

    # ---------- helpers ----------
    def pac_text(self) -> str:
        db = self.db
        blocked = parse_domains(db.get("pac_blocked"))
        direct = parse_domains(db.get("pac_direct"))
        return build_pac(db.get("proxy_host") or "127.0.0.1",
                         db.int_setting("proxy_port", 1080),
                         db.get("proxy_kind", "socks5"), blocked, direct)

    def nodes_payload(self) -> list:
        latest = self.db.latest_checks()
        out = []
        for node in self.db.nodes():
            item = dict(node)
            item["last"] = latest.get(node["id"])
            item["uptime"] = self.db.uptime(node["id"])
            out.append(item)
        return out

    def services_payload(self) -> dict:
        probes = self.db.latest_probes()
        out = {}
        for key, svc in SERVICES.items():
            direct = probes.get(f"{key}:direct")
            proxy = probes.get(f"{key}:proxy")
            out[key] = {
                "title": svc["title"],
                "icon": svc["icon"],
                "host": svc["host"],
                "domains": svc["domains"],
                "direct": direct,
                "proxy": proxy,
                "verdict": verdict(direct, proxy),
            }
        return out

    def stats_payload(self) -> dict:
        stats = self.db.stats()
        stats["services"] = self.services_payload()
        stats["proxy"] = {
            "host": self.db.get("proxy_host"),
            "port": self.db.int_setting("proxy_port", 1080),
            "kind": self.db.get("proxy_kind"),
        }
        stats["pac"] = {
            "blocked": len(parse_domains(self.db.get("pac_blocked"))),
            "direct": len(parse_domains(self.db.get("pac_direct"))),
        }
        stats["monitor"] = bool(self.monitor and self.monitor.is_alive())
        return stats

    # ---------- api ----------
    def api(self, method: str, path: str, query: dict, data: dict | None):
        db = self.db

        if path == "/api/health":
            return self.json({"ok": True, "service": "dpi-unblock-suite-pro", "version": "1.0.0"})

        if path == "/api/login" and method == "POST":
            if verify_password(str((data or {}).get("password", "")), db.get("admin_password")):
                return self.json({"ok": True}, extra={
                    "Set-Cookie": f"{COOKIE}={make_session()}; Path=/; HttpOnly; SameSite=Lax; Max-Age={TTL}"})
            db.log("auth", "Неудачная попытка входа")
            return self.error("Неверный пароль", 401)

        if path == "/api/logout" and method == "POST":
            return self.json({"ok": True}, extra={
                "Set-Cookie": f"{COOKIE}=; Path=/; HttpOnly; SameSite=Lax; Max-Age=0"})

        if path == "/api/me":
            return self.json({"ok": True, "authenticated": valid_session(self.token())})

        self.require_auth()

        if path == "/api/stats":
            return self.json({"ok": True, "data": self.stats_payload()})

        if path == "/api/nodes":
            if method == "GET":
                return self.json({"ok": True, "data": self.nodes_payload()})
            if method == "POST":
                payload = data or {}
                name = str(payload.get("name", "")).strip()
                host = str(payload.get("host", "")).strip()
                if not name or not host:
                    raise ApiError("Укажите название и хост узла")
                if not re.match(r"^[A-Za-z0-9_.:-]{2,253}$", host):
                    raise ApiError("Некорректный хост")
                port = int(payload.get("port") or 1080)
                if not 1 <= port <= 65535:
                    raise ApiError("Порт вне диапазона")
                kind = str(payload.get("kind") or "socks5")
                if kind not in KINDS:
                    raise ApiError("Тип прокси: socks5, http или https")
                nid = db.add_node(name, host, port, kind, str(payload.get("tag", "")),
                                  int(payload.get("enabled", 1)))
                db.log("node", f"Добавлен узел «{name}» ({kind} {host}:{port})")
                return self.json({"ok": True, "id": nid}, 201)

        m = re.match(r"^/api/nodes/(\d+)$", path)
        if m:
            nid = int(m.group(1))
            node = db.node(nid)
            if not node:
                raise ApiError("Узел не найден", 404)
            if method == "PUT":
                payload = data or {}
                if "kind" in payload and payload["kind"] not in KINDS:
                    raise ApiError("Неизвестный тип прокси")
                if "port" in payload:
                    payload["port"] = int(payload["port"])
                db.update_node(nid, **payload)
                return self.json({"ok": True, "data": db.node(nid)})
            if method == "DELETE":
                db.delete_node(nid)
                db.log("node", f"Узел #{nid} удалён")
                return self.json({"ok": True})

        m = re.match(r"^/api/nodes/(\d+)/check$", path)
        if m and method == "POST":
            node = db.node(int(m.group(1)))
            if not node:
                raise ApiError("Узел не найден", 404)
            from .net import tcp_ping
            result = tcp_ping(node["host"], node["port"],
                              timeout=max(1, db.int_setting("timeout", 4)))
            db.add_check(node["id"], result["ok"], result["ms"], result["error"])
            db.log("node", f"{node['name']}: {'ok' if result['ok'] else 'fail'} "
                           f"{result['ms'] or ''} ms")
            return self.json({"ok": True, "data": result})

        if path == "/api/diagnostics" and method == "GET":
            return self.json({"ok": True, "data": self.services_payload(),
                              "probes": db.probes(40)})

        if path == "/api/diagnostics/run" and method == "POST":
            payload = data or {}
            service = str(payload.get("service") or "")
            if service not in SERVICES:
                raise ApiError("Неизвестный сервис")
            node_id = payload.get("node_id")
            try:
                result = run_diagnostics(db, service, int(node_id) if node_id else None)
            except (OSError, ValueError) as e:
                raise ApiError(f"Проверка не удалась: {e}", 422)
            return self.json({"ok": True, "data": result,
                              "services": self.services_payload()})

        if path == "/api/checks":
            node_id = query.get("node", [None])[0]
            hours = int(query.get("hours", ["24"])[0])
            rows = db.checks(int(node_id) if node_id else None, hours=hours, limit=800)
            return self.json({"ok": True, "data": rows})

        if path == "/api/pac":
            body = self.pac_text().encode("utf-8")
            return self._send(200, body, "application/x-ns-proxy-autoconfig; charset=utf-8")
        if path == "/api/pac/download":
            body = self.pac_text().encode("utf-8")
            return self._send(200, body, "application/x-ns-proxy-autoconfig; charset=utf-8", {
                "Content-Disposition": 'attachment; filename="unblock.pac"'})

        if path == "/api/dns/test" and method == "POST":
            domain = str((data or {}).get("domain", "")).strip()
            if not domain:
                raise ApiError("Укажите домен")
            return self.json({"ok": True, "data": doh_query(domain)})

        if path == "/api/settings":
            if method == "GET":
                payload = db.settings()
                payload["kinds"] = list(KINDS)
                payload["services"] = {k: {"title": v["title"], "domains": v["domains"]}
                                       for k, v in SERVICES.items()}
                return self.json({"ok": True, "data": payload})
            if method == "PUT":
                payload = data or {}
                if payload.get("new_password"):
                    pwd = str(payload["new_password"])
                    if len(pwd) < 8:
                        raise ApiError("Пароль короче 8 символов")
                    db.set("admin_password", hash_password(pwd))
                if "proxy_kind" in payload and payload["proxy_kind"] not in KINDS:
                    raise ApiError("Неизвестный тип прокси")
                for key in ("proxy_host", "proxy_port", "proxy_kind", "ping_interval",
                            "probe_interval", "timeout", "pac_blocked", "pac_direct"):
                    if key in payload:
                        db.set(key, payload[key])
                db.log("settings", "Настройки обновлены")
                return self.json({"ok": True})

        if path == "/api/logs":
            return self.json({"ok": True, "data": db.logs(int(query.get("limit", ["120"])[0]))})

        raise ApiError("Метод API не найден", 404)


def serve(port: int = 8090, host: str = "127.0.0.1", with_monitor: bool = True):
    db = DB()
    Handler.db = db
    monitor = Monitor(db)
    Handler.monitor = monitor
    if with_monitor:
        monitor.start()
    httpd = ThreadingHTTPServer((host, port), Handler)
    httpd.daemon_threads = True
    httpd.monitor = monitor  # type: ignore[attr-defined]
    return httpd
