"""Фоновый мониторинг узлов и ручная диагностика сервисов."""
from __future__ import annotations

import threading
import time

from .core import SERVICES
from .net import probe_service, tcp_ping


class Monitor(threading.Thread):
    def __init__(self, db, interval: int = 30):
        super().__init__(name="dpi-monitor", daemon=True)
        self.db = db
        self.interval = interval
        self.stop_event = threading.Event()
        self._states: dict = {}

    def stop(self):
        self.stop_event.set()

    def run(self):
        if self.stop_event.wait(2):
            return
        while not self.stop_event.is_set():
            try:
                self.tick()
            except Exception as e:  # noqa: BLE001
                self.db.log("error", f"Мониторинг: {e}")
            timeout = max(10, self.db.int_setting("ping_interval", 60))
            if self.stop_event.wait(timeout):
                break

    def tick(self):
        # В демо-режиме сеть не опрашивается: показываем только сохранённые данные.
        if self.db.get("demo_mode") == "1":
            return
        timeout = max(1, self.db.int_setting("timeout", 4))
        for node in self.db.nodes():
            if not node["enabled"]:
                continue
            result = tcp_ping(node["host"], node["port"], timeout=timeout)
            self.db.add_check(node["id"], result["ok"], result["ms"], result["error"])
            prev = self._states.get(node["id"])
            if prev is not None and prev != result["ok"]:
                state = "доступен" if result["ok"] else "недоступен"
                self.db.log("node", f"{node['name']}: {state}")
            self._states[node["id"]] = result["ok"]


def run_diagnostics(db, service_key: str, node_id: int | None = None) -> dict:
    """Проверить сервис напрямую и через выбранный узел, сохранить результаты."""
    if service_key not in SERVICES:
        raise ValueError("Неизвестный сервис")
    service = dict(SERVICES[service_key])
    service["key"] = service_key
    node = db.node(node_id) if node_id else next(
        (n for n in db.nodes() if n["enabled"]), None
    )
    timeout = max(1, db.int_setting("timeout", 4))
    result = probe_service(service, node, timeout=timeout)
    direct = result["direct"]
    db.add_probe(service_key, "direct", direct["ok"], direct["ms"], direct["status"],
                 result.get("ip", ""), direct.get("error", ""))
    proxy = result.get("proxy")
    if proxy:
        db.add_probe(service_key, "proxy", proxy["ok"], proxy["ms"], proxy["status"],
                     result.get("ip", ""), proxy.get("error", ""))
    db.log("probe", f"{SERVICES[service_key]['title']}: "
                    f"напрямую {'ok' if direct['ok'] else 'fail'}, "
                    f"прокси {'ok' if proxy and proxy['ok'] else ('fail' if proxy else '—')}")
    result["node"] = {"id": node["id"], "name": node["name"]} if node else None
    return result


def verdict(direct: dict | None, proxy: dict | None) -> str:
    if not direct and not proxy:
        return "unknown"
    d_ok = bool(direct and direct.get("ok"))
    p_ok = bool(proxy and proxy.get("ok"))
    if p_ok and not d_ok:
        return "proxy"
    if d_ok and not p_ok:
        return "direct"
    if d_ok and p_ok:
        d_ms = float(direct.get("ms") or 0)
        p_ms = float(proxy.get("ms") or 0)
        if d_ms and p_ms and p_ms < d_ms * 0.8:
            return "proxy_faster"
        return "direct"
    return "down"
