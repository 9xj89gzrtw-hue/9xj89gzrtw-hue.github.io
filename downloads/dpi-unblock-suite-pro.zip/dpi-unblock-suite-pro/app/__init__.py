"""DPI Unblock Suite Pro."""
__version__ = "1.0.0"
