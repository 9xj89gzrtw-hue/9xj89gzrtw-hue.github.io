"""DPI Unblock Suite Pro — хранилище, узлы, проверки."""
from __future__ import annotations

import hashlib
import hmac
import json
import os
import secrets
import sqlite3
import threading
import time
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent.parent
DATA_DIR = Path(os.environ.get("DPI_DATA_DIR", BASE_DIR / "data"))
DATA_DIR.mkdir(parents=True, exist_ok=True)
DB_PATH = DATA_DIR / "app.db"

SERVICES = {
    "discord": {
        "title": "Discord",
        "host": "discord.com",
        "path": "/api/v9/gateway",
        "domains": ["discord.com", "discordapp.com", "discord.gg", "discordapp.net",
                    "discord.media", "discordstatus.com"],
        "icon": "🎧",
    },
    "youtube": {
        "title": "YouTube 4K",
        "host": "www.youtube.com",
        "path": "/",
        "domains": ["youtube.com", "youtu.be", "googlevideo.com", "ytimg.com",
                    "ggpht.com", "youtube-nocookie.com"],
        "icon": "▶",
    },
    "steam": {
        "title": "Steam",
        "host": "store.steampowered.com",
        "path": "/",
        "domains": ["steampowered.com", "steamcommunity.com", "steamstatic.com",
                    "steamcontent.com", "steamgames.com"],
        "icon": "🎮",
    },
    "twitch": {
        "title": "Twitch",
        "host": "www.twitch.tv",
        "path": "/",
        "domains": ["twitch.tv", "ttvnw.net", "jtvnw.net", "twitchcdn.net"],
        "icon": "📺",
    },
}

DEFAULT_BLOCKED = "\n".join(
    sorted({d for key in ("discord", "youtube", "twitch") for d in SERVICES[key]["domains"]})
)
DEFAULT_DIRECT = "\n".join(SERVICES["steam"]["domains"] + [
    "epicgames.com", "battle.net", "riotgames.com", "riotcdn.net",
])

DEFAULTS = {
    "proxy_host": "127.0.0.1",
    "proxy_port": "1080",
    "proxy_kind": "socks5",
    "ping_interval": "60",
    "probe_interval": "300",
    "timeout": "4",
    "pac_blocked": DEFAULT_BLOCKED,
    "pac_direct": DEFAULT_DIRECT,
    "demo_mode": "0",
}

STATUSES = ("online", "offline")


def now() -> float:
    return time.time()


def hash_password(password: str, salt: str | None = None) -> str:
    salt = salt or secrets.token_hex(8)
    digest = hashlib.pbkdf2_hmac("sha256", password.encode(), salt.encode(), 120_000).hex()
    return f"pbkdf2$120000${salt}${digest}"


def verify_password(password: str, stored: str) -> bool:
    try:
        algo, iterations, salt, digest = stored.split("$", 3)
        if algo != "pbkdf2":
            return False
        calc = hashlib.pbkdf2_hmac("sha256", password.encode(), salt.encode(), int(iterations)).hex()
        return hmac.compare_digest(calc, digest)
    except (ValueError, AttributeError):
        return False


class DB:
    def __init__(self, path: str | None = None):
        self.path = str(path or os.environ.get("DPI_DB", DB_PATH))
        self.lock = threading.RLock()
        self.conn = sqlite3.connect(self.path, check_same_thread=False)
        self.conn.row_factory = sqlite3.Row
        self.conn.execute("PRAGMA journal_mode=WAL")
        self._init()

    def _init(self):
        with self.lock:
            self.conn.executescript(
                """
                CREATE TABLE IF NOT EXISTS settings (
                    key TEXT PRIMARY KEY,
                    value TEXT NOT NULL
                );
                CREATE TABLE IF NOT EXISTS nodes (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    name TEXT NOT NULL,
                    host TEXT NOT NULL,
                    port INTEGER NOT NULL DEFAULT 1080,
                    kind TEXT NOT NULL DEFAULT 'socks5',
                    tag TEXT NOT NULL DEFAULT '',
                    enabled INTEGER NOT NULL DEFAULT 1,
                    created REAL NOT NULL
                );
                CREATE TABLE IF NOT EXISTS checks (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    node_id INTEGER NOT NULL,
                    ts REAL NOT NULL,
                    ok INTEGER NOT NULL DEFAULT 0,
                    tcp_ms REAL NOT NULL DEFAULT 0,
                    error TEXT NOT NULL DEFAULT ''
                );
                CREATE INDEX IF NOT EXISTS idx_checks_node ON checks(node_id, ts DESC);
                CREATE TABLE IF NOT EXISTS probes (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    service TEXT NOT NULL,
                    mode TEXT NOT NULL,
                    ts REAL NOT NULL,
                    ok INTEGER NOT NULL DEFAULT 0,
                    ms REAL NOT NULL DEFAULT 0,
                    status INTEGER NOT NULL DEFAULT 0,
                    ip TEXT NOT NULL DEFAULT '',
                    detail TEXT NOT NULL DEFAULT ''
                );
                CREATE INDEX IF NOT EXISTS idx_probes ON probes(service, mode, ts DESC);
                CREATE TABLE IF NOT EXISTS logs (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    ts REAL NOT NULL,
                    kind TEXT NOT NULL,
                    message TEXT NOT NULL
                );
                """
            )
            for key, value in DEFAULTS.items():
                self.conn.execute("INSERT OR IGNORE INTO settings(key, value) VALUES(?,?)",
                                  (key, value))
            if not self.get("admin_password"):
                self.set("admin_password", hash_password("admin123"))
            self.conn.commit()

    # ---------- settings ----------
    def get(self, key: str, default: str = "") -> str:
        with self.lock:
            row = self.conn.execute("SELECT value FROM settings WHERE key=?", (key,)).fetchone()
        return row["value"] if row else default

    def set(self, key: str, value) -> None:
        with self.lock:
            self.conn.execute(
                "INSERT INTO settings(key, value) VALUES(?,?) "
                "ON CONFLICT(key) DO UPDATE SET value=excluded.value",
                (key, str(value)),
            )
            self.conn.commit()

    def int_setting(self, key: str, default: int = 0) -> int:
        try:
            return int(float(self.get(key, str(default))))
        except (TypeError, ValueError):
            return default

    def settings(self) -> dict:
        with self.lock:
            rows = self.conn.execute("SELECT key, value FROM settings").fetchall()
        data = {r["key"]: r["value"] for r in rows}
        data.pop("admin_password", None)
        return data

    # ---------- nodes ----------
    def nodes(self) -> list:
        with self.lock:
            rows = self.conn.execute("SELECT * FROM nodes ORDER BY id").fetchall()
        return [dict(r) for r in rows]

    def node(self, nid: int):
        with self.lock:
            row = self.conn.execute("SELECT * FROM nodes WHERE id=?", (nid,)).fetchone()
        return dict(row) if row else None

    def add_node(self, name: str, host: str, port: int, kind: str = "socks5",
                 tag: str = "", enabled: int = 1) -> int:
        with self.lock:
            cur = self.conn.execute(
                "INSERT INTO nodes(name, host, port, kind, tag, enabled, created)"
                " VALUES(?,?,?,?,?,?,?)",
                (name.strip(), host.strip(), int(port), kind, tag.strip(),
                 int(enabled), now()),
            )
            self.conn.commit()
            return cur.lastrowid

    def update_node(self, nid: int, **fields) -> None:
        allowed = ("name", "host", "port", "kind", "tag", "enabled")
        pairs = [(k, fields[k]) for k in allowed if k in fields]
        if not pairs:
            return
        with self.lock:
            self.conn.execute(
                "UPDATE nodes SET " + ", ".join(f"{k}=?" for k, _ in pairs) + " WHERE id=?",
                [v for _, v in pairs] + [nid],
            )
            self.conn.commit()

    def delete_node(self, nid: int) -> None:
        with self.lock:
            self.conn.execute("DELETE FROM nodes WHERE id=?", (nid,))
            self.conn.execute("DELETE FROM checks WHERE node_id=?", (nid,))
            self.conn.commit()

    # ---------- checks ----------
    def add_check(self, node_id: int, ok: bool, tcp_ms: float = 0, error: str = "") -> None:
        with self.lock:
            self.conn.execute(
                "INSERT INTO checks(node_id, ts, ok, tcp_ms, error) VALUES(?,?,?,?,?)",
                (node_id, now(), int(bool(ok)), float(tcp_ms), error),
            )
            self.conn.commit()

    def latest_checks(self) -> dict:
        with self.lock:
            rows = self.conn.execute(
                "SELECT c.* FROM checks c JOIN ("
                " SELECT node_id, MAX(ts) AS ts FROM checks GROUP BY node_id"
                ") m ON c.node_id=m.node_id AND c.ts=m.ts"
            ).fetchall()
        return {r["node_id"]: dict(r) for r in rows}

    def checks(self, node_id: int | None = None, hours: int = 24, limit: int = 400) -> list:
        since = now() - hours * 3600
        sql = "SELECT * FROM checks WHERE ts>=?"
        params: list = [since]
        if node_id:
            sql += " AND node_id=?"
            params.append(node_id)
        sql += " ORDER BY ts DESC LIMIT ?"
        params.append(int(limit))
        with self.lock:
            rows = self.conn.execute(sql, params).fetchall()
        return [dict(r) for r in reversed(rows)]

    def uptime(self, node_id: int, hours: int = 24) -> float:
        since = now() - hours * 3600
        with self.lock:
            row = self.conn.execute(
                "SELECT COUNT(*) n, SUM(ok) ok FROM checks WHERE node_id=? AND ts>=?",
                (node_id, since),
            ).fetchone()
        if not row or not row["n"]:
            return 0.0
        return round(100.0 * (row["ok"] or 0) / row["n"], 1)

    # ---------- probes ----------
    def add_probe(self, service: str, mode: str, ok: bool, ms: float = 0,
                  status: int = 0, ip: str = "", detail: str = "") -> None:
        with self.lock:
            self.conn.execute(
                "INSERT INTO probes(service, mode, ts, ok, ms, status, ip, detail)"
                " VALUES(?,?,?,?,?,?,?,?)",
                (service, mode, now(), int(bool(ok)), float(ms), int(status), ip, detail),
            )
            self.conn.commit()

    def latest_probes(self) -> dict:
        out = {}
        with self.lock:
            rows = self.conn.execute(
                "SELECT p.* FROM probes p JOIN ("
                " SELECT service, mode, MAX(ts) AS ts FROM probes GROUP BY service, mode"
                ") m ON p.service=m.service AND p.mode=m.mode AND p.ts=m.ts"
            ).fetchall()
        for r in rows:
            out[f"{r['service']}:{r['mode']}"] = dict(r)
        return out

    def probes(self, limit: int = 100) -> list:
        with self.lock:
            rows = self.conn.execute(
                "SELECT * FROM probes ORDER BY id DESC LIMIT ?", (int(limit),)
            ).fetchall()
        return [dict(r) for r in rows]

    # ---------- stats ----------
    def stats(self) -> dict:
        nodes = self.nodes()
        latest = self.latest_checks()
        online = sum(1 for n in nodes if latest.get(n["id"], {}).get("ok"))
        latencies = [latest[n["id"]]["tcp_ms"] for n in nodes
                     if latest.get(n["id"], {}).get("ok")]
        probes = self.latest_probes()
        uptimes = {str(n["id"]): self.uptime(n["id"]) for n in nodes}
        with self.lock:
            last_probe = self.conn.execute("SELECT MAX(ts) t FROM probes").fetchone()["t"]
            last_check = self.conn.execute("SELECT MAX(ts) t FROM checks").fetchone()["t"]
        return {
            "nodes": len(nodes),
            "nodes_enabled": sum(1 for n in nodes if n["enabled"]),
            "online": online,
            "avg_ms": round(sum(latencies) / len(latencies), 1) if latencies else 0,
            "uptime": uptimes,
            "probes": probes,
            "last_probe": last_probe or 0,
            "last_check": last_check or 0,
            "demo": self.get("demo_mode") == "1",
        }

    # ---------- logs ----------
    def log(self, kind: str, message: str) -> None:
        with self.lock:
            self.conn.execute("INSERT INTO logs(ts, kind, message) VALUES(?,?,?)",
                              (now(), kind, message))
            self.conn.commit()

    def logs(self, limit: int = 120) -> list:
        with self.lock:
            rows = self.conn.execute("SELECT * FROM logs ORDER BY id DESC LIMIT ?",
                                     (int(limit),)).fetchall()
        return [dict(r) for r in rows]

    def close(self):
        with self.lock:
            self.conn.close()


def seed_demo(db: DB) -> None:
    """Синтетические данные для знакомства и скриншотов. Помечаются demo_mode."""
    if db.get("demo_mode") == "1" and db.nodes():
        return
    db.set("demo_mode", "1")
    if not db.nodes():
        db.add_node("Amsterdam · NL", "ams1.example.net", 1080, "socks5", "eu-west")
        db.add_node("Frankfurt · DE", "fra2.example.net", 1080, "socks5", "eu-central")
        db.add_node("Helsinki · FI", "hel1.example.net", 1080, "socks5", "eu-north")
        db.add_node("Local relay", "127.0.0.1", 10808, "http", "local")

    ts = now()
    bases = {1: 38.0, 2: 46.0, 3: 54.0, 4: 12.0}
    nodes = db.nodes()
    import random
    rnd = random.Random(42)
    with db.lock:
        for node in nodes:
            base = bases.get(node["id"], 45.0)
            for step in range(24, 0, -1):
                point = ts - step * 3600  # раз в час, 24 часа
                down = node["id"] == 3 and (step % 17 == 0 or step == 1)
                jitter = rnd.uniform(-7, 9)
                db.conn.execute(
                    "INSERT INTO checks(node_id, ts, ok, tcp_ms, error) VALUES(?,?,?,?,?)",
                    (node["id"], point, 0 if down else 1,
                     0 if down else max(5.0, base + jitter),
                     "timeout" if down else ""),
                )
        db.conn.commit()

    probes = [
        ("discord", "direct", False, 0, 0, "", "timeout / reset"),
        ("discord", "proxy", True, 44, 200, "162.159.128.233", "HTTP 200"),
        ("youtube", "direct", True, 148, 200, "142.250.74.142", "HTTP 200"),
        ("youtube", "proxy", True, 61, 200, "142.250.74.142", "HTTP 200"),
        ("steam", "direct", True, 34, 200, "23.48.14.10", "HTTP 200"),
        ("steam", "proxy", True, 58, 200, "23.48.14.10", "HTTP 200"),
        ("twitch", "direct", False, 0, 0, "", "timeout / reset"),
        ("twitch", "proxy", True, 72, 200, "151.101.2.167", "HTTP 200"),
    ]
    with db.lock:
        for service, mode, ok, ms, status, ip, detail in probes:
            db.conn.execute(
                "INSERT INTO probes(service, mode, ts, ok, ms, status, ip, detail)"
                " VALUES(?,?,?,?,?,?,?,?)",
                (service, mode, ts - 90, int(ok), ms, status, ip, detail),
            )
        db.conn.commit()
    db.log("demo", "Загружены демонстрационные данные (сеть не опрашивалась)")
