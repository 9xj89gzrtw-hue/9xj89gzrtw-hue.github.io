"""Telegram Channel Cloner & Auto-Forwarder (Telethon)."""
import asyncio
import logging
from telethon import TelegramClient, events

logging.basicConfig(level=logging.INFO)
API_ID = 1234567
API_HASH = "your_api_hash_here"
SOURCE_CHATS = [-1001234567890]
TARGET_CHAT = -1009876543210

client = TelegramClient("cloner_session", API_ID, API_HASH)

@client.on(events.NewMessage(chats=SOURCE_CHATS))
async def handler(event):
    message = event.message
    text = message.text or ""
    # Filter or replace signatures/links
    clean_text = text.replace("@old_channel", "@my_new_channel")
    
    if message.media:
        await client.send_file(TARGET_CHAT, file=message.media, caption=clean_text)
    else:
        await client.send_message(TARGET_CHAT, clean_text)
    logging.info(f"[+] Cloned post {message.id} to target channel.")

async def main():
    await client.start()
    logging.info("[*] Cloner bot active and listening for new messages...")
    await client.run_until_disconnected()

if __name__ == "__main__":
    asyncio.run(main())
