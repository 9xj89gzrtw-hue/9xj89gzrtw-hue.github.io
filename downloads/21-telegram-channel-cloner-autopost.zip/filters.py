"""Content transformation and regex cleaning rules."""
import re

def clean_post_text(text: str, custom_signature: str = "") -> str:
    # Remove external links
    text = re.sub(r"https?://\S+", "", text)
    # Remove @mentions
    text = re.sub(r"@[a-zA-Z0-9_]+", "", text)
    if custom_signature:
        text += f"\n\n{custom_signature}"
    return text.strip()
