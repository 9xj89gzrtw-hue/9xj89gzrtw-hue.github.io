# ⚡️ Telegram Channel Cloner & Autoposting Script
Автоматическое копирование постов, медиафайлов и настройка автопостинга на Python Telethon.