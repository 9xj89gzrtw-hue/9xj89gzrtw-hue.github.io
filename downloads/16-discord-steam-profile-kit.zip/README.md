# 🎮 Discord & Steam Profile Design & Utility Kit
Пак оформления профиля, анимированных шаблонов и скриптов полезных утилит.

### Содержимое:
1. `profile_templates.txt` — готовые шаблоны био, шрифтов и карточек для профилей Discord и Steam.
2. `steam_idle_helper.py` — утилита для мониторинга фарма карточек.

Запуск:
```bash
python3 steam_idle_helper.py
```
