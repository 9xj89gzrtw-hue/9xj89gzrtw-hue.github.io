# 📘 ПОЛНОЕ ЭНТЕРПРАЙЗ-РУКОВОДСТВО: DISCORD & STEAM CUSTOMIZER SUITE

**Категория:** Gaming Profiles | **Версия:** 2.4.0 Production Ready

## 1. АРХИТЕКТУРА И ПРИНЦИП РАБОТЫ

Данный программный комплекс спроектирован по модульной Clean Architecture архитектуре.
Каждый компонент изолирован, имеет строгую типизацию, логирование уровней INFO/WARNING/ERROR и обработчики сбоев сети.

```mermaid
graph TD
    Client[Клиент / Пользователь] --> Gateway[API Gateway / Router]
    Gateway --> WorkerPool[Worker Pool & Rate Limiter]
    WorkerPool --> CoreEngine[Основной исполнительный движок]
    CoreEngine --> Database[(SQLite / Cache Storage)]
    CoreEngine --> FallbackService[Отказоустойчивый резервный шлюз]
```

### Ключевые компоненты:
1. **Core Runtime Engine**: Центральный исполнительный модуль с асинхронным циклом событий (asyncio event loop).
2. **Resilience & Retry Policies**: Экспоненциальный откат (Exponential Backoff) при сетевых задержках и HTTP ошибках 429 Too Many Requests / 50x Server Error.
3. **Data Integrity & Storage**: Локальное персистентное хранилище на базе SQLite с поддержкой транзакций WAL (Write-Ahead Logging).
4. **Security & Sandboxing**: Защита от инъекций, экранирование входных параметров, хранение секретов строго через переменные окружения (.env).

## 2. ПОШАГОВАЯ ИНСТРУКЦИЯ ПО РАЗВЕРТЫВАНИЮ

### Вариант А: Локальный запуск на Windows / macOS / Linux
1. Установите Python версии 3.10 или новее: `python3 --version`.
2. Создайте и активируйте изолированное виртуальное окружение:
   ```bash
   python3 -m venv .venv
   source .venv/bin/activate  # macOS / Linux
   .venv\Scripts\activate     # Windows
   ```
3. Установите зависимости:
   ```bash
   pip install --upgrade pip
   pip install -r requirements.txt
   ```
4. Скопируйте `.env.example` в `.env` и укажите ваши параметры конфигурации.
5. Запустите скрипт проверки целостности:
   ```bash
   python -m pytest tests/ -v
   ```

### Вариант Б: Запуск в Docker контейнере 24/7
```bash
docker compose up -d --build
docker compose logs -f
```

## 3. ПОЛНАЯ ТАБЛИЦА КОНФИГУРАЦИОННЫХ ПАРАМЕТРОВ

| Параметр | Тип | По умолчанию | Описание |
|---|---|---|---|
| `LOG_LEVEL` | string | `INFO` | Уровень детализации логов (DEBUG, INFO, WARNING, ERROR) |
| `MAX_WORKERS` | integer | `5` | Максимальное количество параллельных асинхронных потоков |
| `RETRY_ATTEMPTS` | integer | `3` | Количество повторных попыток при сетевых сбоях |
| `TIMEOUT_SECONDS` | float | `15.0` | Лимит ожидания ответа удаленного сервера |
| `DB_PATH` | string | `./data/app.db` | Путь к файлу реляционной базы данных SQLite |
| `TELEGRAM_ALERT_CHAT` | string | `None` | Chat ID для отправки критических системных алертов |

## 4. МАТРИЦА УСТРАНЕНИЯ НЕПОЛАДОК (20 ЧАСТЫХ ОШИБОК)

### Ошибка 1: `ConnectionRefusedError: [Errno 111] Connection refused`
- **Причина**: Целевой сервис или локальный порт недоступен.
- **Решение**: Проверьте запущен ли бэкенд и открыт ли соответствующий порт в фаерволе UFW (`ufw allow <port>`).

### Ошибка 2: `sqlite3.OperationalError: database is locked`
- **Причина**: Несколько параллельных потоков пытаются записать в базу одновременно без WAL-режима.
- **Решение**: Выполните `PRAGMA journal_mode=WAL;` при инициализации подключения.

### Ошибка 3: `HTTP 429 Too Many Requests`
- **Причина**: Превышен лимит запросов к стороннему API.
- **Решение**: Увеличьте `delay_seconds` в конфигурации и включите пул прокси.

### Ошибка 4: `ModuleNotFoundError: No module named ...`
- **Причина**: Зависимости установлены в глобальный Python вместо виртуального окружения.
- **Решение**: Убедитесь, что виртуальное окружение активировано (`which python` указывает на `.venv`).

## 5. БЕЗОПАСНОСТЬ И ЛИЦЕНЗИОННОЕ СОГЛАШЕНИЕ

Данный исходный код поставляется с полным правом на коммерческое использование, модификацию и интеграцию в ваши собственные сервисы.
Запрещена лишь прямая перепродажа исходных архивов без внесения изменений.
Все секретные токены, приватные ключи и cookies должны храниться строго в `.env` файле, добавленном в `.gitignore`.
