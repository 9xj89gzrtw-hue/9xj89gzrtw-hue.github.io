@echo off
echo === 🧹 Очистка кэша Steam и ускорение загрузки страниц ===
taskkill /F /IM steam.exe 2>nul
timeout /t 2 /nobreak >nul
del /q /f /s "%localappdata%\Steam\htmlcache\*.*" 2>nul
del /q /f /s "%localappdata%\Steam\widevine\*.*" 2>nul
echo [+] Кэш успешно очищен! Запуск Steam...
start "" "C:\Program Files (x86)\Steam\steam.exe"
