# AI IDE Unlimited Router Pro — local AI router & load balancer

> **Screenshots of the live dashboard:** folder [`screenshots/`](screenshots/) —
> `01-dashboard-ru.png`, `02-interface-en.png`, `03-failover-analytics.png`
> (RU/EN UI, failover & 429 analytics, 1280×800).

**v1.0.0 · Node.js ≥ 18 · zero dependencies (Node stdlib only) · macOS + Linux**

A local proxy that sits between your AI IDE (Cursor, Claude Code, OpenCode,
VS Code, Continue…) and LLM providers (Gemini, DeepSeek, Groq, OpenRouter,
Anthropic) and does two jobs:

1. **No more broken sessions on 429.** When a key hits its rate limit, the
   router transparently fails over to the next key/provider and the IDE gets a
   normal response. The failing key enters a cooldown with exponential backoff
   (30s → 60s → 120s → … capped at 30 minutes).
2. **Weighted load balancing.** Multiple providers and multiple keys per
   provider rotate via smooth weighted round-robin — your free tiers
   (Gemini free, Groq free, OpenRouter `:free`) combine into one shared budget,
   paid models are used by `weight`.

Plus: per-request analytics in daily-rotated JSONL and a local web dashboard
at `http://localhost:8080/admin` with a "429 rescued" counter.

---

## 1. What this is — and what it is NOT

✅ It DOES:
- Proxy OpenAI-style `/v1/chat/completions` and Anthropic-style `/v1/messages`
  requests to **your own** key pool.
- Transliterate protocols both ways: Cursor (OpenAI) ↔ Gemini `generateContent`
  ↔ Anthropic `/v1/messages` ↔ DeepSeek/Groq/OpenRouter. Claude Code can talk
  to DeepSeek/Gemini through this router.
- Track 429/401/5xx, cool keys down, balance, retry (up to 4 attempts), log
  analytics, serve the dashboard, allow hot key management.

❌ It does NOT:
- **Ship or grant any third-party keys.** It works exclusively with keys YOU
  put into `.env`/config. No usable keys are included in the package.
- **Violate any provider's ToS.** You stay a normal client of each API and
  respect their limits; the router simply handles rate limits gracefully.
  Please review the current ToS/SLA of your providers (we are not lawyers).
- **Multiply your quotas.** If your account allows 30 requests/min, you get
  exactly 30 — just without ugly errors and with automatic hand-off.
- Send your code anywhere except the providers you explicitly configured.
  The server binds to `127.0.0.1` and exposes nothing to the network.

Legally this is a plain local reverse-proxy over your own credentials — same
category as Continue.dev, LiteLLM or OpenRouter, just local and self-hosted.

---

## 2. Install in 5 minutes

```bash
cd ai-ide-unlimited-router-pro
bash install/install.sh
```

The installer checks Node ≥ 18 (prints hints: `brew install node` /
`apt install nodejs npm`), copies the bundle to `~/.ai-router`, creates the
`aicmd` symlink, installs a launchd agent `com.user.ai-router.plist` (macOS)
or a systemd user unit `ai-router` (Linux), starts the service and prints IDE
setup snippets.

Then add your keys:

```bash
nano ~/.ai-router/.env
# GEMINI_API_KEY=AIza…        (https://aistudio.google.com/apikey)
# DEEPSEEK_API_KEY=sk-…       (https://platform.deepseek.com)
# GROQ_API_KEY=gsk_…          (https://console.groq.com/keys)
# OPENROUTER_API_KEY=sk-or-…  (https://openrouter.ai/keys)
```

Multiple keys per provider: a comma-separated `"apiKey": "k1,k2,k3"` in
`config/config.json`. Restart: `aicmd`, or see §8.

Verify:

```bash
curl http://127.0.0.1:8080/health
# {"ok":true,"uptime":12,"keys_total":4,"keys_hot":0,...}
```

---

## 3. IDE setup

| IDE | Where | Value |
|---|---|---|
| **Cursor** | Settings → Models → OpenAI API Key → **Override OpenAI Base URL** | `http://127.0.0.1:8080/v1`, API key: any non-empty string (`local`) |
| **VS Code** (Continue.dev etc.) | extension config | `"apiBase": "http://127.0.0.1:8080/v1"`, `"apiKey": "local"` |
| **Claude Code** | env var | `ANTHROPIC_BASE_URL=http://127.0.0.1:8080` (keep your existing `ANTHROPIC_API_KEY`) |
| **OpenCode** | `opencode.json` → provider (openai-compatible) | `baseURL: http://127.0.0.1:8080/v1` |

The model list your IDE sees is the union of `models` in the config
(`GET /v1/models`). **Model affinity:** if the requested model is listed for
some provider, requests go there; unknown models fall back to any provider.

---

## 4. Dashboard

Open **http://localhost:8080/admin** — requests/hour sparkline, totals,
"429 rescued" counter, hot keys, avg latency, provider bars, top models,
recent request table (IDE hint, provider, model, status, ms, tokens),
RU/EN toggle and live key management (admin token required:
`data/admin_token.txt`, or set `ADMIN_TOKEN`).

Raw data: `data/traffic-YYYY-MM-DD.jsonl`, one line per attempt:

```json
{"ts":1793186000000,"ide_hint":"Cursor","provider":"gemini","model":"gemini-2.0-flash","status":200,"dur_ms":480,"tokens_in":312,"tokens_out":144,"attempt":2,"stream":false,"saved":true}
```

---

## 5. When all quotas are burned

1. Check the dashboard: which keys are hot, how many consecutive 429s.
2. When **every** key is cooling, the IDE gets an honest 429 with
   `Retry-After` — nothing is silently dropped; just retry later.
3. Real fixes: add another free provider to the config, add an extra key to a
   provider (only if the provider's ToS allows multiple accounts), include one
   cheap paid model with a small `weight` (e.g. DeepSeek), or reduce token
   spend (lower `max_tokens`, shorter system prompts).
4. Use `maxPerMinute` per provider to pre-limit traffic and avoid 429s at all.

---

## 6. FAQ

- **Are my keys leaving the machine?** No. Local-only binding (127.0.0.1); keys
  live in `.env`/config; the dashboard shows masked keys only.
- **Is this legal?** It wraps YOUR keys — same as any API client/LiteLLM. You
  are not distributing keys; verify providers' ToS yourself.
- **Why `x-ai-router-*` response headers?** Debug info: which provider/key
  answered, how many attempts were made. IDEs ignore them.
- **Streaming?** Yes. Native pairs (OpenAI-compatible, Anthropic) are piped
  byte-for-byte. Cross-style streams (Cursor → Gemini with `stream:true`) are
  synthesized after the upstream finishes.
- **Provider outage (5xx)?** Also fails over to the next key/provider.
- **Windows?** Run `node src/server.js` manually; the packaged installers
  target macOS/ Linux (launchd/systemd).

---

## 7. Troubleshooting

| Symptom | Fix |
|---|---|
| `Config file not found` | `cp config/config.example.json config/config.json && cp .env.example .env` |
| `/health` shows `keys_total: 0` | `.env` vars not set/empty — check names & values |
| IDE gets 401 | The key is really invalid/expired; the router passed the upstream answer through |
| IDE gets 429 | All keys cooling; wait for `Retry-After` or add more keys |
| Port busy | `PORT=8081`, or `lsof -i :8080` |
| Config changes ignored | Restart the service (see §8) |
| Google 400 `API key not valid` | A placeholder key is in `.env` |

---

## 8. Operations

```bash
aicmd                                   # run in foreground
# macOS
launchctl kickstart -k gui/$(id -u)/com.user.ai-router   # restart
launchctl bootout gui/$(id -u)/com.user.ai-router        # stop
tail -20 ~/.ai-router/data/server.log
# Linux
systemctl --user restart ai-router
journalctl --user -u ai-router -f
bash install/uninstall.sh               # remove (--purge deletes data too)
```

---

## 9. LLM pricing logic (reference)

The router does not make models cheaper; it makes them last longer:

| Provider (tier) | Example model | Approx price | Note |
|---|---|---|---|
| Gemini (free) | gemini-2.0-flash | ~$0 (rpm limits) | pool 2 keys |
| Groq (free) | llama-3.3-70b-versatile | ~$0 | fastest latency |
| OpenRouter (free) | `deepseek-chat-v3.1:free` | ~$0 | may queue |
| DeepSeek (paid) | deepseek-chat | ≈ $0.3–0.5 / 1M in | smart & cheap |

Always check current prices/limits on provider pages.

---

## 10. Seller guide (Digiseller / FunPay marketplace)

- **Positioning (honest):** "A local AI router that makes YOUR Gemini/DeepSeek/
  Groq/OpenRouter keys bulletproof: automatic 429 failover, balancing,
  analytics, dashboard. No third-party keys included."
- **Price:** 1290 ₽ fixed price check. Value: sessions survive rate limits,
  free tiers combine, 100% local.
- **Slots to fill:** title (≤ marketplace limit), category "Software",
  delivery type **instant file**, description (copy §1–§3 + dashboard
  screenshots), supported OS (Node ≥ 18, macOS/Linux), support 24h chat,
  refund policy for non-working setups.
- **First-sale checklist:** upload ZIP as digital attachment → test the auto
  delivery with a self-purchase → pin FAQ into the listing ("Works with my
  keys? — yes, only yours").
- **Do not** market it as "free GPT" or "cracked keys" — it is a proxy for
  your own credentials, say exactly that.

---

## 11. Package layout

```
ai-ide-unlimited-router-pro/
├── bin/aicmd                    # launcher
├── config/config.example.json   # providers with ${ENV:VAR} keys
├── data/                        # JSONL + admin token (auto-created)
├── install/{install,uninstall}.sh, install-banner.sh
├── src/{router,server,analytics,config}.js
├── tests/{run,suite}.js         # 31 offline node:test tests — green
├── web/dashboard.html           # single-file dashboard (RU/EN)
├── README_RU.md / README_EN.md / QUICKSTART_RU.txt
├── package.json / .env.example / LICENSE (MIT)
```

MIT license. The product contains no API keys and never asks for anything
beyond your own credentials.
