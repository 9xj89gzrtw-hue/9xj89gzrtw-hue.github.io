#!/usr/bin/env bash
# uninstall.sh — removes AI IDE Unlimited Router Pro from this machine.
# Keeps ~/.ai-router (your data + analytics) unless --purge is passed.
set -uo pipefail

PURGE=0
[ "${1:-}" = "--purge" ] && PURGE=1
DEST="${AI_ROUTER_HOME:-$HOME/.ai-router}"

echo "[uninstall] Останавливаю сервисы..."

if [ "$(uname -s)" = "Darwin" ]; then
  PLIST="$HOME/Library/LaunchAgents/com.user.ai-router.plist"
  if [ -f "$PLIST" ]; then
    launchctl bootout "gui/$(id -u)/com.user.ai-router" 2>/dev/null || launchctl unload "$PLIST" 2>/dev/null || true
    rm -f "$PLIST"
    echo "  - launchd агент удалён"
  fi
else
  if command -v systemctl >/dev/null 2>&1; then
    systemctl --user disable --now ai-router.service 2>/dev/null || true
    rm -f "$HOME/.config/systemd/user/ai-router.service"
    systemctl --user daemon-reload 2>/dev/null || true
    echo "  - systemd unit удалён"
  fi
fi

if [ -n "${HOME:-}" ]; then
  for F in /usr/local/bin/aicmd "$HOME/.local/bin/aicmd"; do
    if [ -L "$F" ]; then rm -f "$F"; echo "  - удалён $F"; fi
  done
fi

if [ "$PURGE" = "1" ]; then
  read -r -p "Удалить $DEST с данными и аналитикой? [y/N] " ans
  case "$ans" in
    [Yy]*) rm -rf "$DEST"; echo "  - $DEST удалён полностью (purge)" ;;
    *) echo "  - отмена purge" ;;
  esac
else
  echo "  - $DEST сохранён (данные, статистика, конфиг)."
  echo "    Полное удаление: $0 --purge"
fi

echo "[uninstall] Готово."
