#!/usr/bin/env bash
# install.sh — installs AI IDE Unlimited Router Pro to ~/.ai-router
# macOS: launchd agent (starts on login, restarts on crash)
# Linux: systemd user unit
# Zero npm dependencies: only Node.js >= 18 is required.
set -euo pipefail

SRC="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
DEST="${AI_ROUTER_HOME:-$HOME/.ai-router}"
PORT="${PORT:-8080}"

# ---------------------------------------------------------------- banner
if [ -f "$SRC/install-banner.sh" ]; then
  bash "$SRC/install-banner.sh" "$([ -t 1 ] && echo on || echo --off)" || true
fi

# ---------------------------------------------------------------- node check
if ! command -v node >/dev/null 2>&1; then
  echo "[install] Node.js не найден / Node.js not found."
  case "$(uname -s)" in
    Darwin)
      echo "  Установите: brew install node      (Homebrew: https://brew.sh)"
      echo "  или скачивайте с https://nodejs.org";;
    Linux)
      echo "  Установите: sudo apt install -y nodejs npm   (нужна версия >= 18)"
      echo "  или NodeSource: curl -fsSL https://deb.nodesource.com/setup_20.x | sudo -E bash - && sudo apt install -y nodejs";;
  esac
  exit 1
fi
NODE_BIN="$(command -v node)"
NODE_MAJOR="$(node -p 'Number(process.versions.node.split(".")[0])')"
if [ "$NODE_MAJOR" -lt 18 ]; then
  echo "[install] Нужен Node.js >= 18, найден $(node --version)."
  case "$(uname -s)" in
    Darwin) echo "  Обновите: brew upgrade node" ;;
    Linux)  echo "  Обновите: sudo apt upgrade nodejs  или через nvm (https://github.com/nvm-sh/nvm)" ;;
  esac
  exit 1
fi
echo "[install] Node.js: $(node --version) -> ok"

# ---------------------------------------------------------------- copy bundle
echo "[install] Копирую пакет в $DEST ..."
if command -v rsync >/dev/null 2>&1; then
  mkdir -p "$DEST"
  rsync -a --delete --exclude 'data' --exclude 'node_modules' --exclude '.git' "$SRC/" "$DEST/"
else
  mkdir -p "$DEST"
  rm -rf "$DEST/src" "$DEST/web" "$DEST/install" "$DEST/config" "$DEST/tests" "$DEST/bin"
  cp -R "$SRC/." "$DEST/"
  rm -rf "$DEST/data"
fi
chmod +x "$DEST/bin/aicmd" "$DEST/install-banner.sh" "$DEST/install/install.sh" "$DEST/install/uninstall.sh" 2>/dev/null || true

# ---------------------------------------------------------------- config
if [ ! -f "$DEST/config/config.json" ]; then
  cp "$DEST/config/config.example.json" "$DEST/config/config.json"
  echo "[install] Создан $DEST/config/config.json (из config.example.json)"
fi
if [ ! -f "$DEST/.env" ] && [ -f "$DEST/.env.example" ]; then
  cp "$DEST/.env.example" "$DEST/.env"
  echo "[install] Создан $DEST/.env"
  echo "          >>> ВПИШИТЕ ТУДА СВОИ КЛЮЧИ: nano $DEST/.env"
fi

# ---------------------------------------------------------------- aicmd symlink
BIN_TARGET=""
for CAND in /usr/local/bin "$HOME/.local/bin"; do
  if mkdir -p "$CAND" 2>/dev/null && [ -w "$CAND" ]; then
    BIN_TARGET="$CAND"; break
  fi
  if sudo -n true 2>/dev/null; then
    sudo mkdir -p "$CAND" 2>/dev/null && BIN_TARGET="$CAND" && break
  fi
done
if [ -n "$BIN_TARGET" ]; then
  ln -sf "$DEST/bin/aicmd" "$BIN_TARGET/aicmd"
  echo "[install] Команда установлена: $BIN_TARGET/aicmd"
  case ":$PATH:" in
    *":$HOME/.local/bin:"*) : ;;
    *) if [ "$BIN_TARGET" = "$HOME/.local/bin" ]; then
         echo "  Добавьте в PATH: echo 'export PATH=\"\$HOME/.local/bin:\$PATH\"' >> ~/.zshrc"
       fi ;;
  esac
fi

# ---------------------------------------------------------------- services
if [ "$(uname -s)" = "Darwin" ]; then
  PLIST="$HOME/Library/LaunchAgents/com.user.ai-router.plist"
  mkdir -p "$DEST/data"
  if [ -f "$PLIST" ]; then
    launchctl bootout "gui/$(id -u)/com.user.ai-router" 2>/dev/null || launchctl unload "$PLIST" 2>/dev/null || true
  fi
  cat > "$PLIST" <<EOF
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
  <key>Label</key><string>com.user.ai-router</string>
  <key>ProgramArguments</key>
  <array>
    <string>$NODE_BIN</string>
    <string>$DEST/src/server.js</string>
  </array>
  <key>WorkingDirectory</key><string>$DEST</string>
  <key>EnvironmentVariables</key>
  <dict>
    <key>PORT</key><string>$PORT</string>
    <key>HOST</key><string>127.0.0.1</string>
  </dict>
  <key>RunAtLoad</key><true/>
  <key>KeepAlive</key><true/>
  <key>StandardOutPath</key><string>$DEST/data/server.log</string>
  <key>StandardErrorPath</key><string>$DEST/data/server.log</string>
</dict>
</plist>
EOF
  launchctl bootstrap "gui/$(id -u)" "$PLIST" 2>/dev/null || launchctl load "$PLIST"
  echo "[install] macOS: launchd агент установлен (старт при входе, автоперезапуск)"
  echo "          запуск вручную:  launchctl kickstart -k gui/$(id -u)/com.user.ai-router"
else
  UNIT_DIR="$HOME/.config/systemd/user"
  mkdir -p "$UNIT_DIR" "$DEST/data"
  cat > "$UNIT_DIR/ai-router.service" <<EOF
[Unit]
Description=AI IDE Unlimited Router Pro (local LLM proxy)
[Service]
ExecStart=$NODE_BIN $DEST/src/server.js
WorkingDirectory=$DEST
Environment=PORT=$PORT
Environment=HOST=127.0.0.1
Restart=on-failure
RestartSec=3
[Install]
WantedBy=default.target
EOF
  systemctl --user daemon-reload
  systemctl --user enable --now ai-router.service
  echo "[install] Linux: systemd user unit установлен (автостарт):"
  echo "          journalctl --user -u ai-router -f"
fi

# ---------------------------------------------------------------- verify
sleep 1
if command -v curl >/dev/null 2>&1; then
  echo "[install] Проверка (how to verify):"
  if curl -fsS "http://127.0.0.1:$PORT/health" 2>/dev/null; then
    echo ""
    echo "[install] ✅ Роутер работает!"
  else
    echo ""
    echo "[install] ⚠️ /health не отвечает — смотрите лог:"
    echo "          tail -40 $DEST/data/server.log"
  fi
fi

# ---------------------------------------------------------------- snippets
cat <<EOF

========================================================================
  ПОДКЛЮЧЕНИЕ IDE (IDE setup snippets):
------------------------------------------------------------------------
  1) Cursor:
     Settings → Models → OpenAI API Key → Override OpenAI Base URL
       Base URL: http://127.0.0.1:$PORT/v1
       API Key : любой не-пустой токен (например "local")

  2) Claude Code (Anthropic-style, passthrough):
       export ANTHROPIC_BASE_URL=http://127.0.0.1:$PORT
       (ключ можно оставить прежний — он пройдёт на upstream «как есть»)

  3) OpenCode (opencode.json):
       "provider": { "ai-router": { "npm": "@ai-sdk/openai-compatible",
         "options": { "baseURL": "http://127.0.0.1:$PORT/v1", "apiKey": "local" } } }

  4) VS Code / Continue и любые OpenAI-совместимые расширения:
       "apiBase": "http://127.0.0.1:$PORT/v1", "apiKey": "local"

  Дашборд: http://localhost:$PORT/admin
========================================================================
EOF
echo "[install] Готово. Ключи провайдеров в .env, конфиг в config/config.json."
