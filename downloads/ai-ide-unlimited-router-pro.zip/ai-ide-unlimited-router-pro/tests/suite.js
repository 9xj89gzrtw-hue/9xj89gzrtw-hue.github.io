'use strict';

/**
 * suite.js — offline test suite (node:test) for AI IDE Unlimited Router Pro.
 *
 * Pure logic + config + analytics + FULL server integration with in-test mock
 * upstreams (200 → 429 → 200 failover, cooldown assertion, streaming, etc.).
 * No network access beyond 127.0.0.1 ephemeral ports. No dependencies.
 */

const test = require('node:test');
const assert = require('node:assert/strict');
const http = require('node:http');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');

const ROOT = path.join(__dirname, '..');
const {
  classifyStatus, computeCooldownMs, chooseNextKey, createKeyState, createRouter,
  buildUpstreamRequest, openAiToGemini, anthropicToOpenAi, openAiToAnthropic,
  openAiStreamFromCompletion, anthropicStreamFromMessage, extractUsage,
  openAiToAnthropicResponse, geminiToOpenAiResponse, maskKey
} = require(path.join(ROOT, 'src', 'router.js'));
const { Analytics, aggregateEntries, readJsonl } = require(path.join(ROOT, 'src', 'analytics.js'));
const { substituteEnv, deepSubstitute, loadEnvFile } = require(path.join(ROOT, 'src', 'config.js'));
const { createServer, detectIde } = require(path.join(ROOT, 'src', 'server.js'));

/* ------------------------------------------------------------------ */
/* helpers                                                             */
/* ------------------------------------------------------------------ */

function tmpDir(prefix) {
  return fs.mkdtempSync(path.join(os.tmpdir(), prefix));
}

/** Boot a mock upstream HTTP server. handler(hit, i) -> {status, body, ctype?, headers?} */
function startMock(handler) {
  const hits = [];
  const server = http.createServer((req, res) => {
    const chunks = [];
    req.on('data', (c) => chunks.push(c));
    req.on('end', () => {
      const hit = {
        path: req.url,
        headers: req.headers,
        body: Buffer.concat(chunks).toString('utf8')
      };
      hits.push(hit);
      const out = handler(hit, hits.length - 1) || {};
      let body = out.body == null ? '' : out.body;
      if (!Buffer.isBuffer(body) && typeof body !== 'string') body = JSON.stringify(body);
      res.writeHead(out.status || 200, Object.assign({ 'content-type': out.ctype || 'application/json' }, out.headers || {}));
      res.end(body);
    });
  });
  return new Promise((resolve) => {
    server.listen(0, '127.0.0.1', () => {
      resolve({
        server,
        port: server.address().port,
        hits,
        close: () => new Promise((r) => { server.closeAllConnections && server.closeAllConnections(); server.close(() => r()); })
      });
    });
  });
}

async function bootApp({ providers, maxTotalAttempts = 4, attemptDelayMs = 10, adminToken = 'testtoken', configExtras = {} }) {
  const dataDir = tmpDir('air-data-');
  const config = Object.assign({ maxTotalAttempts, attemptDelayMs, providers }, configExtras);
  const app = createServer({ config, dataDir, adminToken, maxTotalAttempts, attemptDelayMs });
  const port = await app.listen(0, '127.0.0.1');
  return {
    app, port, dataDir, router: app.router,
    close: async () => { await app.close(); fs.rmSync(dataDir, { recursive: true, force: true }); }
  };
}

/**
 * Stdlib-only HTTP test client (no global fetch: undici keeps keep-alive
 * sockets open and would prevent clean process exit). agent:false closes the
 * socket after every request.
 */
function httpReq({ port, path: p, method = 'GET', body = null, headers = {} }) {
  return new Promise((resolve, reject) => {
    const data = body == null ? null : (typeof body === 'string' || Buffer.isBuffer(body) ? body : JSON.stringify(body));
    const req = http.request({
      host: '127.0.0.1',
      port,
      path: p,
      method,
      headers: Object.assign(
        data != null ? { 'content-type': 'application/json', 'content-length': Buffer.byteLength(data) } : {},
        headers
      ),
      agent: false
    }, (res) => {
      const chunks = [];
      res.on('data', (c) => chunks.push(c));
      res.on('end', () => resolve({
        status: res.statusCode,
        headers: res.headers,
        text: () => Buffer.concat(chunks).toString('utf8'),
        json: () => JSON.parse(Buffer.concat(chunks).toString('utf8'))
      }));
    });
    req.on('error', reject);
    if (data != null) req.write(data);
    req.end();
  });
}

async function postJson(port, p, body, headers) {
  return httpReq({ port, path: p, method: 'POST', body, headers });
}
function getJson(port, p, headers) {
  return httpReq({ port, path: p, headers });
}

function openaiOk(content, usage) {
  return {
    id: 'chatcmpl-mock', object: 'chat.completion', created: Math.floor(Date.now() / 1000),
    model: 'test-model',
    choices: [{ index: 0, message: { role: 'assistant', content }, finish_reason: 'stop' }],
    usage: usage || { prompt_tokens: 7, completion_tokens: 5, total_tokens: 12 }
  };
}

/* ------------------------------------------------------------------ */
/* 1. classifyStatus                                                   */
/* ------------------------------------------------------------------ */

test('classifyStatus maps status codes to categories', () => {
  assert.equal(classifyStatus(429), 'rate_limit');
  assert.equal(classifyStatus(401), 'auth');
  assert.equal(classifyStatus(403), 'auth');
  assert.equal(classifyStatus(500), 'server');
  assert.equal(classifyStatus(503), 'server');
  assert.equal(classifyStatus(200), 'ok');
  assert.equal(classifyStatus(201), 'ok');
  assert.equal(classifyStatus(204), 'ok');
  assert.equal(classifyStatus(408), 'retry_now');
  assert.equal(classifyStatus(425), 'retry_now');
  assert.equal(classifyStatus(0), 'retry_now', 'network errors count as retryable');
  assert.equal(classifyStatus(400), 'ok', 'other 4xx must not burn a key');
  assert.equal(classifyStatus(404), 'ok');
});

/* ------------------------------------------------------------------ */
/* 2. exponential cooldown math                                        */
/* ------------------------------------------------------------------ */

test('computeCooldownMs doubles from 30s and caps at 30min', () => {
  assert.equal(computeCooldownMs(0), 0);
  assert.equal(computeCooldownMs(-3), 0);
  assert.equal(computeCooldownMs(1), 30_000);
  assert.equal(computeCooldownMs(2), 60_000);
  assert.equal(computeCooldownMs(3), 120_000);
  assert.equal(computeCooldownMs(6), 30_000 * 32);
  assert.equal(computeCooldownMs(8), 30 * 60_000, 'cap reached');
  assert.equal(computeCooldownMs(30), 30 * 60_000, 'stays capped');
  assert.equal(computeCooldownMs(2, 17, { baseMs: 1000, growth: 3, maxMs: 10_000 }), 3000);
  assert.equal(computeCooldownMs(5, 17, { baseMs: 1000, growth: 3, maxMs: 10_000 }), 10_000, 'custom cap');
});

/* ------------------------------------------------------------------ */
/* 3. weighted round-robin rotation                                    */
/* ------------------------------------------------------------------ */

test('chooseNextKey rotates keys in order (weighted round-robin)', () => {
  const a = createKeyState('p', 'A', 0, 1);
  const b = createKeyState('p', 'B', 1, 1);
  const arr = [a, b];
  // manually simulate the side-effects the router normally performs
  const seq = [];
  let t = 0;
  for (let i = 0; i < 4; i++) {
    const pick = chooseNextKey(arr, ++t);
    assert.ok(pick, 'a key is available');
    seq.push(pick.key);
    pick.uses += 1;
    pick.lastUsedAt = t;
  }
  assert.deepEqual(seq, ['A', 'B', 'A', 'B']);
  // pure: entries untouched when we only call it
  const c1 = createKeyState('p', 'C', 2, 1);
  assert.equal(chooseNextKey([c1], 5).key, 'C');
});

test('chooseNextKey honours weight 1:2 (A,B,B,A,B,B...)', () => {
  const a = createKeyState('p', 'A', 0, 1);
  const b = createKeyState('p', 'B', 1, 2);
  const arr = [a, b];
  const seq = [];
  let t = 0;
  for (let i = 0; i < 6; i++) {
    const pick = chooseNextKey(arr, ++t);
    seq.push(pick.key);
    pick.uses += 1;
    pick.lastUsedAt = t;
  }
  assert.deepEqual(seq, ['A', 'B', 'B', 'A', 'B', 'B']);
});

test('chooseNextKey skips cooling keys and returns null when all are hot', () => {
  const a = createKeyState('p', 'A', 0, 1);
  const b = createKeyState('p', 'B', 1, 1);
  a.coolUntil = 100;
  assert.equal(chooseNextKey([a, b], 99).key, 'B', 'A is cooling -> pick B');
  b.coolUntil = 100;
  assert.equal(chooseNextKey([a, b], 99), null, 'everyone is hot -> null');
  assert.equal(chooseNextKey([a], 101).key, 'A', 'cooldown elapsed -> usable again');
  assert.equal(chooseNextKey([], 99), null);
  const d = createKeyState('p', 'D', 2, 1);
  d.disabled = true;
  assert.equal(chooseNextKey([d], 99), null, 'disabled keys never picked');
});

/* ------------------------------------------------------------------ */
/* 4. router factory: fail/success semantics                           */
/* ------------------------------------------------------------------ */

test('createRouter: rotation, onFail cooldown ladder, onSuccess reset', () => {
  const r = createRouter({ providers: [{ name: 'gemini', apiKey: 'k1,k2', models: ['m1'], weight: 1 }] });
  const p1 = r.chooseKey(1000);
  assert.equal(p1.keyId, 'gemini#1');
  assert.equal(p1.key, 'k1');
  const p2 = r.chooseKey(1001);
  assert.equal(p2.keyId, 'gemini#2');

  // cooldown doubles on REPEATED failures of the same key:
  // 1st failure -> 30s, 2nd -> 60s, 3rd -> 120s (tested via direct onFail marks,
  // which is also what happens after each cooldown expiry on live traffic)
  const f1 = r.onFail('gemini#1', 429, 2000);
  assert.equal(f1.consecutive, 1);
  assert.equal(f1.cooldownMs, 30_000);
  assert.ok(r.isKeyHot('gemini#1', 3000));
  assert.equal(r.isKeyHot('gemini#1', 32_001), false, '2000+30000=32000 -> free at 32001');

  const f2 = r.onFail('gemini#1', 429, 33_000); // failed again after comeback
  assert.equal(f2.consecutive, 2);
  assert.equal(f2.cooldownMs, 60_000);
  assert.ok(r.isKeyHot('gemini#1', 60_000), '33000+60000=93000 -> still hot at 60000');
  assert.equal(r.isKeyHot('gemini#1', 93_500), false);

  const f3 = r.onFail('gemini#1', 429, 94_000);
  assert.equal(f3.consecutive, 3);
  assert.equal(f3.cooldownMs, 120_000);

  // success resets the streak (not the lifetime stats) and clears cooldown
  r.onSuccess('gemini#1', 95_000);
  assert.equal(r.isKeyHot('gemini#1', 95_000), false, 'success clears active cooldown');
  const k1 = r.keys.find((k) => k.id === 'gemini#1');
  assert.equal(k1.consecutive, 0, 'streak reset');
  assert.equal(k1.ok, 1);
  assert.equal(k1.fail, 3, 'lifetime counter kept for analytics');
  // after reset, the next failure starts again from the base cooldown
  const f4 = r.onFail('gemini#1', 429, 96_000);
  assert.equal(f4.consecutive, 1);
  assert.equal(f4.cooldownMs, 30_000, 'ladder restarts at base after success');

  // both keys hot -> nothing available
  r.onFail('gemini#2', 429, 96_100);
  assert.ok(r.hotKeys(97_000).length === 2);
  assert.equal(r.chooseKey(97_000), null);
  assert.ok(r.minMsUntilAnyKeyReady(97_000) > 0);
  const snap = r.snapshot(97_000);
  assert.equal(snap.keys_total, 2);
  assert.equal(snap.keys_hot, 2);
});

/* ------------------------------------------------------------------ */
/* 5-8. buildUpstreamRequest for all styles                            */
/* ------------------------------------------------------------------ */

test('buildUpstreamRequest: openai style (Bearer, /chat/completions)', () => {
  const prov = { name: 'deepseek', style: 'openai', baseUrl: 'https://api.deepseek.com/', models: ['deepseek-chat'] };
  const b = buildUpstreamRequest(prov, '/v1/chat/completions', { model: 'deepseek-chat', messages: [{ role: 'user', content: 'Hi' }] }, 'sk-key');
  assert.equal(b.url, 'https://api.deepseek.com/chat/completions');
  assert.equal(b.headers.authorization, 'Bearer sk-key');
  assert.equal(b.headers['content-type'], 'application/json');
  const j = JSON.parse(b.bodyBuffer.toString('utf8'));
  assert.equal(j.model, 'deepseek-chat');
  assert.equal(j.messages[0].content, 'Hi');
  assert.equal(j.stream, false, 'stream normalized to boolean');
  // full URL pasted by user must not be doubled
  const prov2 = { ...prov, baseUrl: 'https://api.deepseek.com/chat/completions' };
  assert.equal(buildUpstreamRequest(prov2, '/v1/chat/completions', b, 'sk').url, 'https://api.deepseek.com/chat/completions');
});

test('buildUpstreamRequest: gemini style transliteration', () => {
  const prov = { name: 'gemini', style: 'gemini', baseUrl: 'https://generativelanguage.googleapis.com/v1beta', models: ['gemini-2.0-flash'] };
  const body = {
    model: 'gemini-2.0-flash',
    messages: [
      { role: 'system', content: 'You are helpful' },
      { role: 'user', content: 'Hello' },
      { role: 'assistant', content: 'Hi!' },
      { role: 'user', content: 'Bye' }
    ],
    max_tokens: 100,
    temperature: 0.5,
    stream: false
  };
  const b = buildUpstreamRequest(prov, '/v1/chat/completions', body, 'AIza-KEY');
  assert.match(b.url, /\/v1beta\/models\/gemini-2\.0-flash:generateContent\?key=AIza-KEY$/);
  const j = JSON.parse(b.bodyBuffer.toString('utf8'));
  assert.equal(j.contents.length, 3, 'system message excluded from contents');
  assert.equal(j.contents[0].role, 'user');
  assert.equal(j.contents[0].parts[0].text, 'Hello');
  assert.equal(j.contents[1].role, 'model');
  assert.equal(j.contents[2].parts[0].text, 'Bye');
  assert.equal(j.systemInstruction.parts[0].text, 'You are helpful');
  assert.equal(j.generationConfig.maxOutputTokens, 100);
  assert.equal(j.generationConfig.temperature, 0.5);
  assert.equal(j.stream, undefined, 'no stream flag leaks to gemini');
  const u = extractUsage({ usageMetadata: { promptTokenCount: 9, candidatesTokenCount: 4 } }, 'gemini', '/v1/chat/completions');
  assert.deepEqual(u, { tokens_in: 9, tokens_out: 4 });
});

test('openAiToGemini maps system/macros safely', () => {
  const g = openAiToGemini({ messages: [{ role: 'user', content: [{ type: 'text', text: 'part1' }, { type: 'text', text: 'part2' }] }], stop: 'END' });
  assert.equal(g.contents[0].parts[0].text, 'part1\npart2');
  assert.deepEqual(g.generationConfig.stopSequences, ['END']);
});

test('buildUpstreamRequest: anthropic style from OpenAI input', () => {
  const prov = { name: 'anthropic', style: 'anthropic', baseUrl: 'https://api.anthropic.com', models: ['claude-sonnet-4-5'] };
  const b = buildUpstreamRequest(prov, '/v1/chat/completions', { model: 'claude-sonnet-4-5', messages: [{ role: 'system', content: 'sys' }, { role: 'user', content: 'Hey' }], max_tokens: 55 }, 'ak-key');
  assert.equal(b.url, 'https://api.anthropic.com/v1/messages');
  assert.equal(b.headers['x-api-key'], 'ak-key');
  assert.equal(b.headers['anthropic-version'], '2023-06-01');
  const j = JSON.parse(b.bodyBuffer.toString('utf8'));
  assert.equal(j.system, 'sys');
  assert.equal(j.messages[0].role, 'user');
  assert.equal(j.max_tokens, 55);
});

test('buildUpstreamRequest: anthropic passthrough for /v1/messages', () => {
  const prov = { name: 'anthropic', style: 'anthropic', baseUrl: 'https://api.anthropic.com', models: ['claude-sonnet-4-5'] };
  const inBody = { model: 'claude-x', max_tokens: 64, system: 'SYS', messages: [{ role: 'user', content: 'msg' }] };
  const b = buildUpstreamRequest(prov, '/v1/messages', inBody, 'ak-key');
  const j = JSON.parse(b.bodyBuffer.toString('utf8'));
  assert.equal(j.system, 'SYS');
  assert.equal(j.max_tokens, 64);
  assert.equal(j.messages[0].content, 'msg');
  assert.equal(b.headers['x-api-key'], 'ak-key');
});

test('buildUpstreamRequest: /v1/messages -> openai provider (Claude Code on DeepSeek)', () => {
  const prov = { name: 'deepseek', style: 'openai', baseUrl: 'https://api.deepseek.com', models: ['deepseek-chat'] };
  const inBody = { model: 'deepseek-chat', max_tokens: 64, system: 'SYS', messages: [{ role: 'user', content: 'msg' }], stream: false };
  const b = buildUpstreamRequest(prov, '/v1/messages', inBody, 'sk-key');
  assert.equal(b.url, 'https://api.deepseek.com/chat/completions');
  const j = JSON.parse(b.bodyBuffer.toString('utf8'));
  assert.equal(j.messages[0].role, 'system');
  assert.equal(j.messages[0].content, 'SYS');
  assert.equal(j.messages[1].content, 'msg');
  assert.equal(j.max_tokens, 64);
  assert.equal(j.stream, false);
  assert.equal(b.headers.authorization, 'Bearer sk-key');
  // and back: OpenAI response -> Anthropic message
  const oj = { id: 'oa1', choices: [{ message: { role: 'assistant', content: 'Hello!' }, finish_reason: 'stop' }], usage: { prompt_tokens: 7, completion_tokens: 5 } };
  const aj = openAiToAnthropicResponse(oj, 'deepseek-chat');
  assert.equal(aj.type, 'message');
  assert.equal(aj.content[0].text, 'Hello!');
  assert.equal(aj.usage.input_tokens, 7);
  assert.equal(aj.usage.output_tokens, 5);
  assert.equal(aj.stop_reason, 'end_turn');
});

test('response converters + extractUsage', () => {
  const gj = { candidates: [{ content: { parts: [{ text: 'Gemini hi' }] }, finishReason: 'STOP' }], usageMetadata: { promptTokenCount: 9, candidatesTokenCount: 4, totalTokenCount: 13 } };
  const oai = geminiToOpenAiResponse(gj, 'gemini-2.0-flash');
  assert.equal(oai.choices[0].message.content, 'Gemini hi');
  assert.equal(oai.usage.prompt_tokens, 9);
  const u1 = extractUsage(oai, 'openai', '/v1/chat/completions');
  assert.deepEqual(u1, { tokens_in: 9, tokens_out: 4 }, 'openai response with gemini usage amounts');
  const anthropicMsg = { id: 'msg_1', content: [{ type: 'text', text: 'OK' }], usage: { input_tokens: 3, output_tokens: 2 }, stop_reason: 'end_turn' };
  const u2 = extractUsage(anthropicMsg, 'anthropic', '/v1/messages');
  assert.deepEqual(u2, { tokens_in: 3, tokens_out: 2 });
  const conv = anthropicToOpenAi(anthropicMsg); // anthropic request-shape conversion sanity
  assert.equal(conv.messages.length, 0);
  assert.equal(openAiToAnthropic({ messages: [{ role: 'user', content: 'x' }] }).max_tokens, 4096, 'anthropic always needs max_tokens');
});

test('stream synthesis helpers emit valid SSE', () => {
  const completion = openaiOk('Hello!');
  const sse = openAiStreamFromCompletion(completion);
  const lines = sse.split('\n').filter((l) => l.startsWith('data:'));
  assert.equal(lines.length, 4, '3 chunks + [DONE]');
  assert.match(sse, /"chat\.completion\.chunk"/);
  assert.match(sse, /data: \[DONE\]/);
  assert.ok(lines[0].includes('"content":""'));
  assert.ok(lines[1].includes('Hello!'));
  const asse = anthropicStreamFromMessage({ id: 'msg_1', model: 'claude-x', content: [{ type: 'text', text: 'Hi' }], stop_reason: 'end_turn', usage: { input_tokens: 3, output_tokens: 2 } });
  assert.match(asse, /event: message_start/);
  assert.match(asse, /event: content_block_delta/);
  assert.match(asse, /"text":"Hi"/);
  assert.match(asse, /event: message_stop/);
});

test('maskKey + anthropicToOpenAi basics', () => {
  assert.equal(maskKey('sk-abcdef1234567890'), 'sk-a••••7890');
  assert.equal(maskKey('short'), 'shor••••');
  const conv = anthropicToOpenAi({ model: 'm', max_tokens: 11, system: 'S', messages: [{ role: 'user', content: 'Q' }], stream: true });
  assert.equal(conv.messages[0].role, 'system');
  assert.equal(conv.messages[1].content, 'Q');
  assert.equal(conv.max_tokens, 11);
  assert.equal(conv.stream, true);
});

/* ------------------------------------------------------------------ */
/* 9. config: ${ENV:VAR} + .env loader                                 */
/* ------------------------------------------------------------------ */

test('config: ${ENV:VAR} substitution', () => {
  const env = { FOO: '123', ARR: 'a,b' };
  assert.equal(substituteEnv('sk-${ENV:FOO}-x', env), 'sk-123-x');
  assert.equal(substituteEnv('${ENV:NOPE}', env), '', 'missing var -> empty (provider simply has 0 keys)');
  assert.equal(substituteEnv('${ENV:ARR}', env), 'a,b');
  const nested = deepSubstitute({ a: '${ENV:FOO}', list: ['${ENV:ARR}'], n: 5 }, env);
  assert.deepEqual(nested, { a: '123', list: ['a,b'], n: 5 });
});

test('config: legacy .env loader (stdlib, no dotenv dep)', () => {
  const dir = tmpDir('air-env-');
  const file = path.join(dir, '.env');
  fs.writeFileSync(file, [
    '# comment line',
    'TEST_A=1',
    'TEST_B="x y"',
    '',
    'TEST_C=3 # inline comment'
  ].join('\n'));
  const env = { TEST_A: '9' }; // shell wins: TEST_A untouched
  const n = loadEnvFile(file, env);
  assert.equal(n, 2);
  assert.equal(env.TEST_A, '9');
  assert.equal(env.TEST_B, 'x y');
  assert.equal(env.TEST_C, '3');
  fs.rmSync(dir, { recursive: true, force: true });
});

/* ------------------------------------------------------------------ */
/* 10. analytics: JSONL append + read + aggregation widget logic       */
/* ------------------------------------------------------------------ */

test('analytics: JSONL daily append, read back, aggregate widget logic', () => {
  const dir = tmpDir('air-analytics-');
  const a = new Analytics({ dataDir: dir });
  const e1 = a.log({ ide_hint: 'Cursor', provider: 'gemini', model: 'gemini-2.0-flash', status: 200, dur_ms: 120.6, tokens_in: 10, tokens_out: 5, saved: true, attempt: 2 });
  a.log({ ide_hint: 'Claude Code', provider: 'deepseek', model: 'deepseek-chat', status: 429, dur_ms: 51.2, attempt: 1 });
  a.log({ ide_hint: 'Cursor', provider: 'deepseek', model: 'deepseek-chat', status: 200, dur_ms: 80, tokens_in: 3, tokens_out: 7 });
  assert.ok(e1.ts > 0);

  const files = fs.readdirSync(dir).filter((f) => f.endsWith('.jsonl'));
  assert.equal(files.length, 1);
  assert.match(files[0], /^traffic-\d{4}-\d{2}-\d{2}\.jsonl$/, 'daily-rotated JSONL');
  const lines = readJsonl(path.join(dir, files[0]));
  assert.equal(lines.length, 3);
  for (const l of lines) {
    assert.ok('ts' in l && 'ide_hint' in l && 'provider' in l && 'model' in l && 'status' in l && 'dur_ms' in l);
  }

  const agg = aggregateEntries(lines);
  assert.equal(agg.total, 3);
  assert.equal(agg.ok, 2);
  assert.equal(agg.rate_limit, 1);
  assert.equal(agg.saved_429, 1);
  assert.equal(agg.per_provider.gemini.total, 1);
  assert.equal(agg.per_provider.deepseek.total, 2);
  assert.equal(agg.per_provider.deepseek.rate_limit, 1);
  assert.equal(agg.per_model['gemini-2.0-flash'].count, 1);
  assert.equal(agg.per_model['gemini-2.0-flash'].tokens_in, 10);
  assert.equal(agg.per_model['deepseek-chat'].tokens_out, 7);
  assert.equal(agg.per_ide.Cursor, 2);
  assert.equal(agg.avg_ms > 0, true);

  // in-memory summary + warmup on second instance (restart resilience)
  const s = a.summary();
  assert.equal(s.requests_total, 3);
  assert.equal(s.saved_429, 1);
  assert.equal(s.recent.length, 3);
  assert.equal(s.requests_1h >= 3, true);
  assert.equal(s.per_model[0].model, 'deepseek-chat', 'sorted by count desc');

  const b = new Analytics({ dataDir: dir });
  assert.equal(b.summary().requests_total, 3, 'warmup reloads today file');
  fs.rmSync(dir, { recursive: true, force: true });
});

/* ------------------------------------------------------------------ */
/* 11. detectIde                                                       */
/* ------------------------------------------------------------------ */

test('detectIde maps User-Agent to IDE hints', () => {
  assert.equal(detectIde('Cursor/2024.1 (linux)'), 'Cursor');
  assert.equal(detectIde('claude-code/1.0'), 'Claude Code');
  assert.equal(detectIde('opencode/2.0'), 'OpenCode');
  assert.equal(detectIde('vscode/1.9 copilot'), 'VS Code');
  assert.equal(detectIde(''), 'other');
  assert.equal(detectIde('Mozilla/5.0'), 'other');
});

/* ------------------------------------------------------------------ */
/* 12. server integration: 429 -> failover -> 200                      */
/* ------------------------------------------------------------------ */

test('server: transparent failover 429->next key, cooldown set, saved counter', async () => {
  let mode = 'up';
  const mock = await startMock((hit, i) => {
    if (mode !== 'up') return { status: 429, body: { error: { message: 'rate limited by mock' } } };
    if (i === 0) return { status: 429, body: { error: { message: 'rate limited by mock' } } };
    return { status: 200, body: openaiOk('Hello!') };
  });
  const app = await bootApp({
    providers: [{
      name: 'mock', style: 'openai', baseUrl: `http://127.0.0.1:${mock.port}`,
      apiKey: 'keyA,keyB', models: ['test-model'], maxPerMinute: 0
    }]
  });
  try {
    const res1 = await postJson(app.port, '/v1/chat/completions', {
      model: 'test-model',
      messages: [{ role: 'user', content: 'Hi' }]
    }, { 'user-agent': 'cursor/1.0' });
    assert.equal(res1.status, 200, 'client must not see the 429 (failover)');
    const j1 = await res1.json();
    assert.equal(j1.choices[0].message.content, 'Hello!');
    assert.equal(j1.usage.prompt_tokens, 7);
    assert.equal(j1.usage.completion_tokens, 5);

    assert.equal(mock.hits.length, 2, 'exactly one retry happened');
    assert.equal(mock.hits[0].headers.authorization, 'Bearer keyA');
    assert.equal(mock.hits[1].headers.authorization, 'Bearer keyB', 'second key used after 429');
    assert.equal(res1.headers['x-ai-router-provider'], 'mock');
    assert.equal(res1.headers['x-ai-router-attempts'], '2');
    assert.ok(res1.headers['x-ai-router-key']);

    // keyA must now be cooling: consecutive=1 -> 30s
    const kA = app.router.keys.find((k) => k.id === 'mock#1');
    assert.equal(kA.consecutive, 1);
    assert.equal(kA.coolUntil > Date.now(), true, 'cooldown active');

    const health = await (await getJson(app.port, '/health')).json();
    assert.equal(health.ok, true);
    assert.equal(health.keys_total, 2);
    assert.equal(health.keys_hot, 1, 'one hot key reported');
    assert.ok(typeof health.uptime === 'number');

    const sum = await (await getJson(app.port, '/admin/api/summary')).json();
    assert.equal(sum.requests_total, 2, 'one JSONL line per upstream attempt (429 + 200)');
    assert.equal(sum.saved_429, 1, '429 rescued counter');
    assert.equal(sum.per_provider.mock.total, 2);
    assert.equal(sum.recent[0].status, 200);
    assert.equal(sum.recent[0].tokens_in, 7);

    // immediate second request: keyA still cooling -> straight to keyB, no retry
    const res2 = await postJson(app.port, '/v1/chat/completions', { model: 'test-model', messages: [{ role: 'user', content: 'again' }] });
    assert.equal(res2.status, 200);
    assert.equal(mock.hits.length, 3, 'no wasted retry for keyB');
    assert.equal(mock.hits[2].headers.authorization, 'Bearer keyB');

    // analytics JSONL written (one line per attempt: 429 + 200 + res2 200)
    const files = fs.readdirSync(app.dataDir).filter((f) => f.endsWith('.jsonl'));
    assert.equal(files.length, 1);
    assert.equal(readJsonl(path.join(app.dataDir, files[0])).length, 3);
  } finally {
    await app.close();
    await mock.close();
  }
});

/* ------------------------------------------------------------------ */
/* 13. server: all keys exhausted -> 429 to IDE, attempts counted      */
/* ------------------------------------------------------------------ */

test('server: upstream always 429 -> max attempts, cooldown ladder, 429 passthrough', async () => {
  const mock = await startMock(() => ({ status: 429, body: { error: { message: 'no quota left' } } }));
  const app = await bootApp({
    maxTotalAttempts: 4, attemptDelayMs: 5,
    providers: [{ name: 'solo', style: 'openai', baseUrl: `http://127.0.0.1:${mock.port}`, apiKey: 'only', models: ['m'] }]
  });
  try {
    const res = await postJson(app.port, '/v1/chat/completions', { model: 'm', messages: [{ role: 'user', content: 'x' }] });
    assert.equal(res.status, 429);
    const j = await res.json();
    assert.equal(j.error.message, 'no quota left', 'last upstream error passed verbatim');
    assert.equal(mock.hits.length, 4, 'one request per max attempt');
    assert.ok(mock.hits.every((h) => h.headers.authorization === 'Bearer only'));
    const k = app.router.keys[0];
    assert.equal(k.consecutive, 4);
    assert.equal(k.coolUntil - Date.now() > 200_000, true, '4 consecutive failures -> ~240s cooldown');
    assert.equal((app.router.keys.filter((x) => x.coolUntil > Date.now())).length, 1);

    // next request instantly: everything hot -> synthesized 429 with retry-after
    const res2 = await postJson(app.port, '/v1/chat/completions', { model: 'm', messages: [{ role: 'user', content: 'y' }] });
    assert.equal(res2.status, 429);
    assert.ok(res2.headers['retry-after'], 'retry-after header present');
    const j2 = await res2.json();
    assert.match(j2.error.message, /cooling down/);
    assert.equal(mock.hits.length, 4, 'no upstream call when all keys hot');
  } finally {
    await app.close();
    await mock.close();
  }
});

/* ------------------------------------------------------------------ */
/* 14. server: gemini end-to-end transliteration                       */
/* ------------------------------------------------------------------ */

test('server: gemini provider transliterates request and response', async () => {
  const mock = await startMock((hit) => {
    assert.match(hit.path, /\/v1beta\/models\/gemini-2\.0-flash:generateContent\?key=gemkey$/);
    const rb = JSON.parse(hit.body);
    assert.equal(rb.contents[0].role, 'user');
    assert.equal(rb.contents[0].parts[0].text, 'Hi gemini');
    assert.equal(rb.systemInstruction.parts[0].text, 'SYS');
    return {
      status: 200,
      body: {
        candidates: [{ content: { parts: [{ text: 'Gemini hi' }] }, finishReason: 'STOP' }],
        usageMetadata: { promptTokenCount: 9, candidatesTokenCount: 4, totalTokenCount: 13 }
      }
    };
  });
  const app = await bootApp({
    providers: [{ name: 'gemini', style: 'gemini', baseUrl: `http://127.0.0.1:${mock.port}/v1beta`, apiKey: 'gemkey', models: ['gemini-2.0-flash'] }]
  });
  try {
    const res = await postJson(app.port, '/v1/chat/completions', {
      model: 'gemini-2.0-flash',
      messages: [{ role: 'system', content: 'SYS' }, { role: 'user', content: 'Hi gemini' }]
    });
    assert.equal(res.status, 200);
    const j = await res.json();
    assert.equal(j.choices[0].message.content, 'Gemini hi', 'translated into OpenAI format');
    assert.equal(j.usage.prompt_tokens, 9);
    assert.equal(j.usage.completion_tokens, 4);
    assert.equal(j.object, 'chat.completion');
  } finally {
    await app.close();
    await mock.close();
  }
});

/* ------------------------------------------------------------------ */
/* 15. server: /v1/messages passthrough (Claude Code on Anthropic)     */
/* ------------------------------------------------------------------ */

test('server: /v1/messages passthrough keeps Anthropic semantics', async () => {
  const mock = await startMock((hit) => {
    assert.equal(hit.path, '/v1/messages');
    assert.equal(hit.headers['x-api-key'], 'anthkey');
    assert.ok(hit.headers['anthropic-version']);
    const rb = JSON.parse(hit.body);
    assert.equal(rb.system, 'YOU ARE CLAUDE');
    assert.equal(rb.max_tokens, 64);
    assert.equal(rb.messages[0].content, 'msg');
    return {
      status: 200,
      body: { id: 'msg_1', type: 'message', role: 'assistant', model: 'claude-x', content: [{ type: 'text', text: 'OK' }], stop_reason: 'end_turn', usage: { input_tokens: 3, output_tokens: 2 } }
    };
  });
  const app = await bootApp({
    providers: [{ name: 'anthropic', style: 'anthropic', baseUrl: `http://127.0.0.1:${mock.port}`, apiKey: 'anthkey', models: ['claude-x'] }]
  });
  try {
    const res = await postJson(app.port, '/v1/messages', {
      model: 'claude-x', max_tokens: 64, system: 'YOU ARE CLAUDE',
      messages: [{ role: 'user', content: 'msg' }]
    }, { 'user-agent': 'claude-code/1.0' });
    assert.equal(res.status, 200);
    const j = await res.json();
    assert.equal(j.id, 'msg_1', 'verbatim passthrough');
    assert.equal(j.content[0].text, 'OK');
    assert.equal(j.usage.input_tokens, 3);
  } finally {
    await app.close();
    await mock.close();
  }
});

/* ------------------------------------------------------------------ */
/* 16. server: /v1/messages -> openai provider (Claude Code on DeepSeek)*/
/* ------------------------------------------------------------------ */

test('server: /v1/messages translated to OpenAI provider and back', async () => {
  const mock = await startMock((hit) => {
    const rb = JSON.parse(hit.body);
    assert.equal(rb.model, 'deepseek-chat');
    assert.equal(rb.messages[0].role, 'system');
    assert.equal(rb.messages[1].content, 'msg');
    assert.equal(rb.max_tokens, 64);
    return { status: 200, body: openaiOk('Hello!', { prompt_tokens: 7, completion_tokens: 5, total_tokens: 12 }) };
  });
  const app = await bootApp({
    providers: [{ name: 'deepseek', style: 'openai', baseUrl: `http://127.0.0.1:${mock.port}`, apiKey: 'sk-d', models: ['deepseek-chat'] }]
  });
  try {
    const res = await postJson(app.port, '/v1/messages', {
      model: 'deepseek-chat', max_tokens: 64, system: 'SYS',
      messages: [{ role: 'user', content: 'msg' }]
    }, { 'user-agent': 'claude-code/1.0' });
    assert.equal(res.status, 200);
    const j = await res.json();
    assert.equal(j.type, 'message');
    assert.equal(j.role, 'assistant');
    assert.equal(j.content[0].text, 'Hello!');
    assert.equal(j.stop_reason, 'end_turn');
    assert.equal(j.usage.input_tokens, 7);
    assert.equal(j.usage.output_tokens, 5);
  } finally {
    await app.close();
    await mock.close();
  }
});

/* ------------------------------------------------------------------ */
/* 17. server: streaming pass-through (native SSE)                     */
/* ------------------------------------------------------------------ */

test('server: native SSE streaming is piped through untouched', async () => {
  const SSE = 'data: {"id":"1","choices":[{"index":0,"delta":{"role":"assistant","content":"Hel"}}]}\n\n' +
              'data: {"id":"1","choices":[{"index":0,"delta":{"content":"lo"},"finish_reason":null}]}\n\n' +
              'data: [DONE]\n\n';
  const mock = await startMock((hit) => {
    return { status: 200, ctype: 'text/event-stream', body: SSE };
  });
  const app = await bootApp({
    providers: [{ name: 'mock', style: 'openai', baseUrl: `http://127.0.0.1:${mock.port}`, apiKey: 'k1', models: ['test-model'] }]
  });
  try {
    const res = await postJson(app.port, '/v1/chat/completions', {
      model: 'test-model', stream: true, messages: [{ role: 'user', content: 'hi' }]
    });
    assert.equal(res.status, 200);
    assert.match(res.headers['content-type'] || '', /text\/event-stream/);
    const text = await res.text();
    assert.equal(text, SSE, 'bytes pass untouched');
    assert.match(text, /data: \[DONE\]/);
  } finally {
    await app.close();
    await mock.close();
  }
});

/* ------------------------------------------------------------------ */
/* 18. server: cross-style stream synthesis (gemini, stream:true)       */
/* ------------------------------------------------------------------ */

test('server: stream:true on translated style synthesizes SSE from full JSON', async () => {
  const mock = await startMock(() => ({
    status: 200,
    body: { candidates: [{ content: { parts: [{ text: 'G-hi' }] }, finishReason: 'STOP' }], usageMetadata: { promptTokenCount: 4, candidatesTokenCount: 2, totalTokenCount: 6 } }
  }));
  const app = await bootApp({
    providers: [{ name: 'gemini', style: 'gemini', baseUrl: `http://127.0.0.1:${mock.port}/v1beta`, apiKey: 'gk', models: ['gemini-2.0-flash'] }]
  });
  try {
    const res = await postJson(app.port, '/v1/chat/completions', {
      model: 'gemini-2.0-flash', stream: true, messages: [{ role: 'user', content: 'hi' }]
    });
    assert.equal(res.status, 200);
    assert.match(res.headers['content-type'] || '', /text\/event-stream/);
    const text = await res.text();
    assert.match(text, /"chat\.completion\.chunk"/);
    assert.match(text, /G-hi/);
    assert.match(text, /data: \[DONE\]/);
  } finally {
    await app.close();
    await mock.close();
  }
});

/* ------------------------------------------------------------------ */
/* 19. server: /v1/models aggregation + bad requests + routes          */
/* ------------------------------------------------------------------ */

test('server: /v1/models aggregates unique models', async () => {
  const app = await bootApp({
    providers: [
      { name: 'a', baseUrl: 'http://127.0.0.1:1', apiKey: 'k', models: ['m1', 'm2'] },
      { name: 'b', baseUrl: 'http://127.0.0.1:1', apiKey: 'k', models: ['m2', 'm3'] }
    ]
  });
  try {
    const j = await (await getJson(app.port, '/v1/models')).json();
    assert.equal(j.object, 'list');
    const ids = j.data.map((m) => m.id);
    assert.deepEqual(ids, ['m1', 'm2', 'm3'], 'unique across providers');
    assert.equal(j.data[0].owned_by, 'a');

    // bad JSON -> 400
    const bad = await postJson(app.port, '/v1/chat/completions', '{oops', { 'content-type': 'application/json' });
    assert.equal(bad.status, 400);
    // missing messages -> 400
    const noMsg = await postJson(app.port, '/v1/chat/completions', { model: 'm1' });
    assert.equal(noMsg.status, 400);
    // unknown route -> 404
    const nf = await getJson(app.port, '/nope');
    assert.equal(nf.status, 404);
    // OPTIONS -> 204
    const opt = await httpReq({ port: app.port, path: '/v1/chat/completions', method: 'OPTIONS' });
    assert.equal(opt.status, 204);
  } finally {
    await app.close();
  }
});

/* ------------------------------------------------------------------ */
/* 20. server: dashboard + admin keys API                              */
/* ------------------------------------------------------------------ */

test('server: /admin serves dashboard; /admin/api/keys add/remove with token', async () => {
  const mock = await startMock(() => ({ status: 200, body: openaiOk('ok') }));
  const app = await bootApp({
    providers: [{ name: 'gemini', style: 'gemini', baseUrl: `http://127.0.0.1:${mock.port}/v1beta`, apiKey: 'k1', models: ['gemini-2.0-flash'] }]
  });
  try {
    const htmlRes = await getJson(app.port, '/admin');
    const html = htmlRes.text();
    assert.equal(htmlRes.status, 200);
    assert.match(html, /<title>AI Router Pro/);
    assert.match(html, /dashboard/i);
    assert.match(html, /I18N/, 'inline script present');

    // no token -> 401
    const noTok = await postJson(app.port, '/admin/api/keys', { action: 'add', provider: 'gemini', key: 'QUESTION' });
    assert.equal(noTok.status, 401);
    // wrong token -> 401
    const badTok = await postJson(app.port, '/admin/api/keys', { action: 'add', provider: 'gemini', key: 'x' }, { 'x-admin-token': 'wrong' });
    assert.equal(badTok.status, 401);

    // add key at runtime
    const add = await postJson(app.port, '/admin/api/keys', { action: 'add', provider: 'gemini', key: 'AIza-newkey0987' }, { 'x-admin-token': 'testtoken' });
    assert.equal(add.status, 200);
    const addJ = await add.json();
    assert.equal(addJ.ok, true);
    assert.equal(addJ.keys_total, 2);
    assert.ok(addJ.keys.some((k) => k.masked.startsWith('AIza') && k.masked.endsWith('0987')));

    // remove the ORIGINAL key (gemini#1) — only the just-added one remains
    const del = await postJson(app.port, '/admin/api/keys', { action: 'remove', keyId: 'gemini#1' }, { 'x-admin-token': 'testtoken' });
    assert.equal(del.status, 200);
    const delJ = await del.json();
    assert.equal(delJ.keys_total, 1);

    // unknown provider -> 404
    const ghost = await postJson(app.port, '/admin/api/keys', { action: 'add', provider: 'ghost', key: 'k' }, { 'x-admin-token': 'testtoken' });
    assert.equal(ghost.status, 404);

    // the runtime-added key is actually used by the router
    const r = await postJson(app.port, '/v1/chat/completions', { model: 'gemini-2.0-flash', messages: [{ role: 'user', content: 'q' }] });
    assert.equal(r.status, 200);
    assert.equal(mock.hits.length, 1);
    assert.equal(mock.hits[0].path.includes('AIza-newkey0987'), true, 'runtime-added key reaches upstream');
  } finally {
    await app.close();
    await mock.close();
  }
});

/* ------------------------------------------------------------------ */
/* 21. server: per-provider maxPerMinute throttle                      */
/* ------------------------------------------------------------------ */

test('server: maxPerMinute throttles provider rotations', async () => {
  let calls = 0;
  const mock = await startMock(() => ({ status: 200, body: openaiOk('ok') }));
  const app = await bootApp({
    providers: [{ name: 'lim', style: 'openai', baseUrl: `http://127.0.0.1:${mock.port}`, apiKey: 'k', models: ['m'], maxPerMinute: 2 }]
  });
  try {
    for (let i = 0; i < 2; i++) {
      const r = await postJson(app.port, '/v1/chat/completions', { model: 'm', messages: [{ role: 'user', content: 'x' }] });
      assert.equal(r.status, 200);
    }
    assert.equal(mock.hits.length, 2);
    // provider at 2 req/min -> third request finds no key in the window
    const r3 = await postJson(app.port, '/v1/chat/completions', { model: 'm', messages: [{ role: 'user', content: 'x' }] });
    assert.equal(r3.status, 429, 'throttled provider counts as nothing-available');
    assert.match((await r3.json()).error.message, /cooling down|limits/);
    calls = mock.hits.length;
    assert.equal(calls, 2);
  } finally {
    await app.close();
    await mock.close();
  }
});

/* ------------------------------------------------------------------ */
/* 22. modelMap (optional nicety)                                      */
/* ------------------------------------------------------------------ */

test('buildUpstreamRequest: provider.modelMap remaps IDE model names', () => {
  const prov = { name: 'deepseek', style: 'openai', baseUrl: 'https://api.deepseek.com', models: ['deepseek-chat'], modelMap: { 'gpt-4o-mini': 'deepseek-chat' } };
  const b = buildUpstreamRequest(prov, '/v1/chat/completions', { model: 'gpt-4o-mini', messages: [{ role: 'user', content: 'x' }] }, 'k');
  const j = JSON.parse(b.bodyBuffer.toString('utf8'));
  assert.equal(j.model, 'deepseek-chat');
});

/* ------------------------------------------------------------------ */
/* 23. model affinity: requested model picks the provider listing it   */
/* ------------------------------------------------------------------ */

test('chooseKey: model affinity prefers providers listing the model', () => {
  const r = createRouter({
    providers: [
      { name: 'gemini', apiKey: 'g1', models: ['gemini-2.0-flash'], weight: 5 },
      { name: 'deepseek', apiKey: 'd1', models: ['deepseek-chat'], weight: 5 }
    ]
  });
  const p = r.chooseKey(1000, null, 'deepseek-chat');
  assert.equal(p.provider, 'deepseek', 'deepseek listed the model, gemini did not');
  const p2 = r.chooseKey(1001, null, 'mystery-model');
  assert.ok(p2.provider === 'gemini' || p2.provider === 'deepseek', 'unknown model falls back to any provider');
  // unavailable affinity provider -> fallback to the others
  const r2 = createRouter({
    cooldownBaseMs: 30_000,
    providers: [
      { name: 'a', apiKey: 'a1', models: ['shared'], weight: 1 },
      { name: 'b', apiKey: 'b1', models: ['other'], weight: 1 }
    ]
  });
  r2.onFail('a#1', 429, 1000); // provider a cooling
  const p3 = r2.chooseKey(1500, null, 'shared');
  assert.equal(p3.provider, 'b', 'affinity provider hot -> served by fallback provider');
});
