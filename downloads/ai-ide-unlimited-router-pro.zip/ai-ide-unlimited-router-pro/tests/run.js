#!/usr/bin/env node
'use strict';

/**
 * run.js — zero-dependency test runner.
 *
 *   node tests/run.js        (plain)
 *   npm test  /  node --run tests   (package.json scripts)
 *   node --test tests/suite.js      (built-in runner, same thing)
 *
 * Delegates to the Node built-in test runner for proper reporting + exit
 * codes. Everything runs offline: only pure logic and 127.0.0.1 ephemeral
 * mock servers.
 */

const path = require('path');
const { spawnSync } = require('child_process');

const suite = path.join(__dirname, 'suite.js');
const res = spawnSync(process.execPath, ['--test', suite], { stdio: 'inherit', env: process.env });

if (res.status === null) {
  // Extremely defensive fallback: if `node --test` is unsupported for some
  // reason, require the suite directly (node:test executes tests in-process).
  console.error('[tests/run.js] node --test unavailable, running suite in-process…');
  require('./suite.js');
} else {
  process.exitCode = res.status;
}
