#!/usr/bin/env bash
# install-banner.sh — prints the product banner. Standalone or sourced by install.sh.
# shellcheck disable=SC2034
if [ "${1:-}" != "--off" ]; then
  C_GREEN=$'\033[1;32m'; C_BLUE=$'\033[1;34m'; C_DIM=$'\033[2m'; C_OFF=$'\033[0m'
else
  C_GREEN=""; C_BLUE=""; C_DIM=""; C_OFF=""
fi
cat <<'EOT'
   ___   ______ ______ _____   ____  __  ___    ____
  |_  | / / ___// ___// ___/  / __ \/  |/  /   /  _/
   / /|_|\__ \ \__ \ \__ \  / / / / /|_/ /   / /
 /___/___/___/____/____/ /__/_/_/_/_/__/__/ /___/
EOT
cat <<EOT2
${C_BLUE}╔══════════════════════════════════════════════════════════════╗
║  AI IDE Unlimited Router Pro v1.0.0                          ║
║  Локальный AI-роутер и балансировщик запросов                ║
║  для Cursor / Claude Code / OpenCode / VS Code               ║
╠══════════════════════════════════════════════════════════════╣
║  • Крутит ВАШИ ключи: Gemini, DeepSeek, Groq, OpenRouter     ║
║  • 429 → охлаждение ключа (30с → 30мин) → failover           ║
║  • Статистика запросов в JSONL + дашборд                     ║
║  • 0 зависимостей, чистый Node.js ≥ 18                       ║
╚══════════════════════════════════════════════════════════════╝${C_OFF}
EOT2
