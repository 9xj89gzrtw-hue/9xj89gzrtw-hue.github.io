'use strict';

/**
 * config.js — config loading for AI IDE Unlimited Router Pro.
 *
 * - Supports ${ENV:VAR} substitution in any string value of the JSON config.
 * - Supports a minimal .env loader (KEY=VALUE lines, # comments) so users do
 *   not need a dotenv dependency — pure Node stdlib.
 * - Never fabricates keys: missing env vars simply become empty strings and
 *   the corresponding provider has zero keys (= never selected for pickup).
 */

const fs = require('fs');
const path = require('path');

/** Replace all ${ENV:NAME} placeholders in a string. Missing vars -> ''. */
function substituteEnv(value, env) {
  if (typeof value !== 'string') return value;
  const lookup = env || process.env;
  return value.replace(/\$\{ENV:([A-Za-z_][A-Za-z0-9_]*)\}/g, (m, name) => {
    const v = lookup[name];
    if (v === undefined || v === null) return '';
    return String(v);
  });
}

function deepSubstitute(node, env) {
  if (typeof node === 'string') return substituteEnv(node, env);
  if (Array.isArray(node)) return node.map((x) => deepSubstitute(x, env));
  if (node && typeof node === 'object') {
    const out = {};
    for (const [k, v] of Object.entries(node)) out[k] = deepSubstitute(v, env);
    return out;
  }
  return node;
}

const ENV_LINE_RE = /^\s*(?:export\s+)?([A-Za-z_][A-Za-z0-9_]*)\s*=\s*(.*?)\s*(:?#.*)?$/;

/**
 * Minimal .env loader: VAR=value per line, supports `#` comment lines and
 * inline values quoted with " or '. Existing process.env values are NOT
 * overwritten (shell wins). Returns number of vars set.
 */
function loadEnvFile(file, targetEnv) {
  const env = targetEnv || process.env;
  let text;
  try {
    text = fs.readFileSync(file, 'utf8');
  } catch (_) {
    return 0; // no .env — fine
  }
  let n = 0;
  for (const rawLine of text.split(/\r?\n/)) {
    const line = rawLine.trim();
    if (!line || line.startsWith('#')) continue;
    const m = ENV_LINE_RE.exec(line);
    if (!m) continue;
    const name = m[1];
    let value = m[2] || '';
    if (value.length >= 2 &&
        ((value.startsWith('"') && value.endsWith('"')) ||
         (value.startsWith("'") && value.endsWith("'")))) {
      value = value.slice(1, -1);
    }
    if (env[name] === undefined || env[name] === '') {
      env[name] = value;
      n += 1;
    }
  }
  return n;
}

/** Load + ${ENV:VAR}-substitute a JSON config file. Throws on bad JSON. */
function loadConfig(configPath, { env } = {}) {
  const raw = fs.readFileSync(configPath, 'utf8');
  const parsed = JSON.parse(raw);
  return deepSubstitute(parsed, env || process.env);
}

/** Resolve the config path: env override, then <root>/config/config.json. */
function defaultConfigPath(rootDir, env) {
  const e = env || process.env;
  if (e.AI_ROUTER_CONFIG) return path.resolve(e.AI_ROUTER_CONFIG);
  return path.join(rootDir, 'config', 'config.json');
}

module.exports = {
  substituteEnv,
  deepSubstitute,
  loadEnvFile,
  loadConfig,
  defaultConfigPath
};
