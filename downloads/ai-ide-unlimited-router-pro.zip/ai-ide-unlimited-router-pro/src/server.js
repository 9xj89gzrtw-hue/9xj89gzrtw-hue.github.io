'use strict';

/**
 * server.js — local proxy for AI IDE Unlimited Router Pro.
 *
 * Endpoints:
 *   POST /v1/chat/completions — OpenAI-style; rotates keys on 429/auth/5xx,
 *                               supports streaming pass-through.
 *   POST /v1/messages         — Anthropic-style passthrough / transliteration
 *                               (for Claude Code via ANTHROPIC_BASE_URL).
 *   GET  /health              -> {ok, uptime, keys_total, keys_hot, ...}
 *   GET  /v1/models           -> aggregate of all provider models
 *   GET  /admin               — web dashboard (single-file HTML)
 *   GET  /admin/api/summary   — JSON analytics snapshot
 *   POST /admin/api/keys      — add/remove a key at runtime (token required)
 *
 * Everything binds to 127.0.0.1 by default (PORT / HOST env override).
 * Zero runtime dependencies — Node standard library only.
 */

const http = require('http');
const https = require('https');
const crypto = require('crypto');
const fs = require('fs');
const path = require('path');

const { createRouter, buildUpstreamRequest, classifyStatus, extractUsage, needsTranslation, translateUpstream, makeStreamBody, maskKey, RETRYABLE_STATUSES } = require('./router');
const { Analytics } = require('./analytics');
const { loadConfig, loadEnvFile, defaultConfigPath } = require('./config');

const ROOT = path.resolve(__dirname, '..');
const VERSION = (() => {
  try { return JSON.parse(fs.readFileSync(path.join(ROOT, 'package.json'), 'utf8')).version || '1.0.0'; }
  catch (_) { return '1.0.0'; }
})();

const MAX_BODY_BYTES = 32 * 1024 * 1024;      // 32MB incoming JSON cap
const MAX_UPSTREAM_BYTES = 64 * 1024 * 1024;  // 64MB upstream buffer cap

const CHAT_PATH = '/v1/chat/completions';
const MESSAGES_PATH = '/v1/messages';

/* ------------------------------------------------------------------ */
/* Small helpers                                                       */
/* ------------------------------------------------------------------ */

function detectIde(ua) {
  const s = String(ua || '').toLowerCase();
  if (s.includes('cursor')) return 'Cursor';
  if (s.includes('claude') || s.includes('anthropic')) return 'Claude Code';
  if (s.includes('opencode')) return 'OpenCode';
  if (s.includes('vscode') || s.includes('visual-studio-code') || s.includes('copilot') || s.includes('continue')) return 'VS Code';
  if (s.includes('jetbrains')) return 'JetBrains AI';
  if (s.includes('curl/')) return 'curl';
  if (s.includes('node')) return 'node';
  return 'other';
}

function safeEqual(a, b) {
  const ha = crypto.createHash('sha256').update(String(a || '')).digest();
  const hb = crypto.createHash('sha256').update(String(b || '')).digest();
  return crypto.timingSafeEqual(ha, hb);
}

function readBody(req, maxBytes) {
  return new Promise((resolve, reject) => {
    const chunks = [];
    let size = 0;
    req.on('data', (c) => {
      size += c.length;
      if (size > maxBytes) {
        reject(Object.assign(new Error('request body too large'), { code: 'EBODYTOOLARGE' }));
        req.destroy();
        return;
      }
      chunks.push(c);
    });
    req.on('end', () => resolve(Buffer.concat(chunks)));
    req.on('error', reject);
  });
}

function readUpstream(stream, maxBytes) {
  return new Promise((resolve, reject) => {
    const chunks = [];
    let size = 0;
    stream.on('data', (c) => {
      size += c.length;
      if (size > maxBytes) {
        stream.destroy();
        reject(Object.assign(new Error('upstream response too large'), { code: 'EUPSTREAMBIG' }));
        return;
      }
      chunks.push(c);
    });
    stream.on('end', () => resolve(Buffer.concat(chunks)));
    stream.on('error', reject);
  });
}

function safeJson(buf) {
  try { return JSON.parse(buf.toString('utf8')); } catch (_) { return null; }
}

function shapedError(incomingPath, status, message) {
  if (incomingPath === MESSAGES_PATH) {
    const type = status === 429 ? 'rate_limit_error'
      : (status === 401 || status === 403 ? 'authentication_error' : 'api_error');
    return { type: 'error', error: { type, message } };
  }
  return {
    error: {
      message,
      type: status === 429 ? 'rate_limit_error' : 'api_error',
      code: String(status || 500)
    }
  };
}

const CORS = { 'access-control-allow-origin': '*', 'access-control-allow-methods': 'GET, POST, OPTIONS', 'access-control-allow-headers': 'content-type, authorization, x-api-key, anthropic-version, x-admin-token' };

function baseResHeaders(extra) {
  return { ...CORS, ...(extra || {}) };
}

function sendJson(res, status, obj, extra) {
  if (res.writableEnded || res.destroyed) return;
  const buf = Buffer.from(JSON.stringify(obj), 'utf8');
  try {
    res.writeHead(status, baseResHeaders({ 'content-type': 'application/json; charset=utf-8', 'content-length': buf.length, ...(extra || {}) }));
    res.end(buf);
  } catch (_) { /* client disappeared */ }
}

function sendBuffer(res, status, ctype, buf, extra) {
  if (res.writableEnded || res.destroyed) return;
  try {
    res.writeHead(status, baseResHeaders({
      'content-type': ctype,
      'content-length': buf.length,
      ...(extra || {})
    }));
    res.end(buf);
  } catch (_) { /* client disappeared */ }
}

/* ------------------------------------------------------------------ */
/* Upstream transport                                                  */
/* ------------------------------------------------------------------ */

/**
 * Issue one HTTP(S) request to the upstream provider.
 * Resolves {status, headers, res(rawIncomingMessage)} on response headers.
 * Rejects on network errors/timeouts (callers treat it as status 0).
 */
function upstreamRequest(built, opts) {
  const timeoutMs = (opts && opts.timeoutMs) || 300000;
  return new Promise((resolve, reject) => {
    let u;
    try { u = new URL(built.url); } catch (err) {
      reject(Object.assign(new Error(`bad upstream URL: ${built.url}`), { code: 'EBADURL' }));
      return;
    }
    const isHttp = u.protocol === 'http:';
    const mod = isHttp ? http : https;
    const req = mod.request({
      hostname: u.hostname,
      port: u.port ? Number(u.port) : (isHttp ? 80 : 443),
      path: `${u.pathname}${u.search}`,
      method: built.method || 'POST',
      headers: built.headers
    }, (upres) => {
      resolve({ status: upres.statusCode || 0, headers: upres.headers, res: upres });
    });
    req.setTimeout(timeoutMs, () => {
      req.destroy(Object.assign(new Error(`upstream timeout after ${timeoutMs}ms`), { code: 'ETIMEDOUT' }));
    });
    req.on('error', (err) => reject(err));
    if (built.bodyBuffer && built.bodyBuffer.length) req.write(built.bodyBuffer);
    req.end();
  });
}

/** Pipe an upstream SSE/body stream to the client untouched. */
function awaitPipe(upres, clientRes, status, headers) {
  return new Promise((resolve) => {
    if (clientRes.writableEnded || clientRes.destroyed) { upres.destroy(); resolve(); return; }
    try {
      clientRes.writeHead(status, baseResHeaders({
        'content-type': headers['content-type'] || 'text/event-stream',
        'cache-control': 'no-cache',
        ...(['x-request-id', 'openai-request-id', 'x-ratelimit-limit-requests', 'x-ratelimit-remaining-requests'].reduce((acc, h) => {
          if (upres.headers[h] !== undefined) acc[h] = String(upres.headers[h]);
          return acc;
        }, {})),
        ...(headers.extra || {})
      }));
    } catch (_) { upres.destroy(); resolve(); return; }
    upres.pipe(clientRes);
    upres.on('error', () => { try { clientRes.end(); } catch (_) { /* ignore */ } resolve(); });
    clientRes.on('error', () => { upres.destroy(); resolve(); });
    clientRes.on('finish', () => resolve());
  });
}

function upstreamDebugHeaders(meta) {
  const out = {};
  if (meta.provider) out['x-ai-router-provider'] = meta.provider;
  if (meta.keyId) out['x-ai-router-key'] = meta.keyId;
  if (meta.attempts) out['x-ai-router-attempts'] = String(meta.attempts);
  return out;
}

/* ------------------------------------------------------------------ */
/* createServer                                                        */
/* ------------------------------------------------------------------ */

/**
 * createServer(options) -> app
 * options: {
 *   config,                     — already-substituted config object
 *   port,                       — 0 allowed (ephemeral), default 8080
 *   host,                       — default 127.0.0.1
 *   dataDir, webRoot,           — paths
 *   adminToken,                 — required for POST /admin/api/keys
 *   maxTotalAttempts?, attemptDelayMs?, upstreamTimeoutMs?
 * }
 * app = { server, router, analytics, listen(port,host)->Promise<port>,
 *         close()->Promise, port (getter), adminToken, version }
 */
function createServer(options) {
  const opts = options || {};
  const config = opts.config || {};
  const router = createRouter(config);
  const dataDir = opts.dataDir || path.join(ROOT, 'data');
  const webRoot = opts.webRoot || path.join(ROOT, 'web');
  const analytics = new Analytics({ dataDir });

  const maxTotalAttempts = Math.max(1, Number(opts.maxTotalAttempts != null ? opts.maxTotalAttempts : config.maxTotalAttempts) || 4);
  const attemptDelayMs = Math.max(0, Number(opts.attemptDelayMs != null ? opts.attemptDelayMs : config.attemptDelayMs) || 150);
  const upstreamTimeoutMs = Math.max(1000, Number(opts.upstreamTimeoutMs != null ? opts.upstreamTimeoutMs : config.upstreamTimeoutMs) || 300000);

  const adminToken = opts.adminToken || process.env.ADMIN_TOKEN || crypto.randomBytes(16).toString('hex');
  const bootTs = Date.now();

  const server = http.createServer((req, res) => {
    handle(req, res).catch((err) => {
      if (process.env.AI_ROUTER_DEBUG) console.error('[ai-router] handler error:', err);
      try { sendJson(res, 500, shapedError(CHAT_PATH, 500, `internal error: ${err && err.message}`)); } catch (_) { /* ignore */ }
    });
  });
  server.on('clientError', (err, socket) => {
    try { socket.end('HTTP/1.1 400 Bad Request\r\n\r\n'); } catch (_) { /* ignore */ }
  });
  server.keepAliveTimeout = 75000;
  server.headersTimeout = 80000;

  /* ---------------- routing ---------------- */

  async function handle(req, res) {
    const u = new URL(req.url, 'http://localhost');
    const p = u.pathname.replace(/\/+$/, '') || '/';

    if (req.method === 'OPTIONS') {
      res.writeHead(204, baseResHeaders({}));
      res.end();
      return;
    }

    if (req.method === 'GET' || req.method === 'HEAD') {
      if (p === '/' ) { sendIndex(res); return; }
      if (p === '/health') { sendHealth(res); return; }
      if (p === '/v1/models') { sendModels(res); return; }
      if (p === '/admin') { sendDashboard(res); return; }
      if (p === '/admin/api/summary') { sendSummary(res); return; }
    }

    if (req.method === 'POST') {
      if (p === CHAT_PATH || p === MESSAGES_PATH) {
        await handleChat(req, res, p);
        return;
      }
      if (p === '/admin/api/keys') {
        handleAdminKeys(req, res);
        return;
      }
    }

    sendJson(res, 404, { error: { message: `no route: ${req.method} ${p}`, type: 'not_found', code: '404' } });
  }

  function sendIndex(res) {
    const snap = router.snapshot();
    sendJson(res, 200, {
      ok: true,
      product: 'AI IDE Unlimited Router Pro',
      version: VERSION,
      dashboard: '/admin',
      health: '/health',
      keys_total: snap.keys_total,
      keys_hot: snap.keys_hot,
      hint: 'Point your IDE base URL to this server. See /admin for the dashboard.'
    });
  }

  function sendHealth(res) {
    const snap = router.snapshot();
    sendJson(res, 200, {
      ok: true,
      uptime: Math.round((Date.now() - bootTs) / 1000),
      uptime_s: Math.round((Date.now() - bootTs) / 1000),
      keys_total: snap.keys_total,
      keys_hot: snap.keys_hot,
      requests_total: analytics.totals.requests,
      port: server.address() ? server.address().port : null,
      version: VERSION
    });
  }

  function sendModels(res) {
    const data = [];
    const seen = new Set();
    for (const prov of router.providers) {
      for (const m of prov.models) {
        if (seen.has(m)) continue;
        seen.add(m);
        data.push({ id: m, object: 'model', created: Math.floor(bootTs / 1000), owned_by: prov.name, style: prov.style });
      }
    }
    // IDEs may also ask for models they know; report configured ones only.
    sendJson(res, 200, { object: 'list', data, _note: 'Aggregated across all configured providers' });
  }

  function sendDashboard(res) {
    const file = path.join(webRoot, 'dashboard.html');
    fs.readFile(file, (err, buf) => {
      if (err) {
        sendJson(res, 500, { error: { message: 'dashboard file missing (web/dashboard.html)', type: 'internal', code: '500' } });
        return;
      }
      try {
        res.writeHead(200, baseResHeaders({ 'content-type': 'text/html; charset=utf-8', 'content-length': buf.length, 'cache-control': 'no-store' }));
        res.end(buf);
      } catch (_) { /* ignore */ }
    });
  }

  function sendSummary(res) {
    const snap = router.snapshot();
    const sum = analytics.summary();
    sendJson(res, 200, {
      ok: true,
      ts: sum.ts,
      version: VERSION,
      uptime_s: Math.round((Date.now() - bootTs) / 1000),
      requests_total: sum.requests_total,
      ok_total: sum.ok_total,
      rate_limit_total: sum.rate_limit_total,
      auth_total: sum.auth_total,
      server_total: sum.server_total,
      requests_1h: sum.requests_1h,
      requests_24h: sum.requests_24h,
      saved_429: sum.saved_429,
      avg_dur_ms: sum.avg_dur_ms,
      per_provider: sum.per_provider,
      per_ide: sum.per_ide,
      per_model: sum.per_model,
      hourly: sum.hourly,
      recent: sum.recent,
      keys_total: snap.keys_total,
      keys_hot: snap.keys_hot,
      keys: snap.keys,
      providers: snap.providers
    });
  }

  function handleAdminKeys(req, res) {
    const provided = req.headers['x-admin-token'] || bearerOf(req.headers.authorization) || '';
    if (!safeEqual(provided, adminToken)) {
      sendJson(res, 401, { error: { message: 'invalid admin token (set via x-admin-token header or ADMIN_TOKEN env)', type: 'auth_error', code: '401' } });
      return;
    }
    readBody(req, 1024 * 1024).then((buf) => {
      const j = safeJson(buf) || {};
      const action = String(j.action || '').toLowerCase();
      if (action === 'add') {
        const providerName = String(j.provider || '').trim();
        const key = String(j.key || '').trim();
        if (!key) { sendJson(res, 400, { error: { message: 'field "key" required', type: 'bad_request', code: '400' } }); return; }
        if (!providerName) { sendJson(res, 400, { error: { message: 'field "provider" required', type: 'bad_request', code: '400' } }); return; }
        const added = router.addKeyNow(providerName, key);
        if (!added) { sendJson(res, 404, { error: { message: `unknown provider: ${providerName}`, type: 'not_found', code: '404' } }); return; }
        const snap = router.snapshot();
        sendJson(res, 200, { ok: true, added: added.id, keys_total: snap.keys_total, keys: snap.keys });
      } else if (action === 'remove') {
        const keyId = String(j.keyId || '').trim();
        if (!keyId) { sendJson(res, 400, { error: { message: 'field "keyId" required', type: 'bad_request', code: '400' } }); return; }
        const removed = router.removeKeyNow(keyId);
        if (!removed) { sendJson(res, 404, { error: { message: `unknown key: ${keyId}`, type: 'not_found', code: '404' } }); return; }
        const snap = router.snapshot();
        sendJson(res, 200, { ok: true, removed: keyId, keys_total: snap.keys_total, keys: snap.keys });
      } else {
        sendJson(res, 400, { error: { message: 'action must be "add" or "remove"', type: 'bad_request', code: '400' } });
      }
    }).catch(() => sendJson(res, 400, { error: { message: 'bad request body', type: 'bad_request', code: '400' } }));
  }

  /* ---------------- the chat proxy with failover ---------------- */

  async function handleChat(req, res, incomingPath) {
    const t0 = Date.now();
    const ideHint = detectIde(req.headers['user-agent']);
    const isAnthropicIn = incomingPath === MESSAGES_PATH;

    let bodyBuf;
    try {
      bodyBuf = await readBody(req, MAX_BODY_BYTES);
    } catch (err) {
      sendJson(res, err && err.code === 'EBODYTOOLARGE' ? 413 : 400,
        shapedError(incomingPath, err && err.code === 'EBODYTOOLARGE' ? 413 : 400, err.message));
      return;
    }
    let body;
    try { body = JSON.parse(bodyBuf.toString('utf8') || '{}'); } catch (_) {
      sendJson(res, 400, shapedError(incomingPath, 400, 'invalid JSON body'));
      return;
    }
    if (typeof body !== 'object' || body === null) body = {};
    if (!Array.isArray(body.messages) || !body.messages.length) {
      sendJson(res, 400, shapedError(incomingPath, 400, isAnthropicIn ? '"messages" array required' : '"messages" array required'));
      return;
    }
    const model = typeof body.model === 'string' ? body.model : (body.model ? String(body.model) : '(unknown)');
    const wantStream = body.stream === true;

    let responded = false;
    const failedThisRequest = []; // allowed to be re-picked within THIS request (budget), see chooseKey

    for (let attempt = 1; attempt <= maxTotalAttempts && !responded; attempt++) {
      const pick = router.chooseKey(
        Date.now(),
        failedThisRequest,
        typeof body.model === 'string' && body.model ? body.model : null
      );

      /* nothing available: every key is cooling down or throttled */
      if (!pick) {
        const waitMs = router.minMsUntilAnyKeyReady();
        analytics.log({
          ide_hint: ideHint, provider: '(none)', model, status: 429,
          dur_ms: Date.now() - t0, attempt, saved: false
        });
        sendJson(res, 429,
          shapedError(incomingPath, 429,
            `AI Router Pro: all API keys are cooling down (limits). Next key is ready in ~${Math.max(1, Math.ceil(waitMs / 1000))}s.`),
          { 'retry-after': String(Math.max(1, Math.ceil(waitMs / 1000))), 'x-ai-router-attempts': String(attempt) });
        responded = true;
        break;
      }

      const provider = router.providerByName(pick.provider);
      if (!provider) {
        sendJson(res, 500, shapedError(incomingPath, 500, `internal: unknown provider ${pick.provider}`));
        responded = true;
        break;
      }

      let built;
      try {
        built = buildUpstreamRequest(provider, incomingPath, body, pick.key);
      } catch (err) {
        analytics.log({
          ide_hint: ideHint, provider: pick.provider, model, status: 500,
          dur_ms: Date.now() - t0, attempt, saved: false
        });
        sendJson(res, 500, shapedError(incomingPath, 500, `configuration error on provider "${provider.name}": ${err.message}`));
        responded = true;
        break;
      }

      let ures;
      try {
        ures = await upstreamRequest(built, { timeoutMs: upstreamTimeoutMs });
      } catch (err) {
        // network error / timeout -> status 0 -> retryable, does NOT punish the key much
        const info = router.onFail(pick.keyId, 0);
        failedThisRequest.push(pick.keyId);
        analytics.log({
          ide_hint: ideHint, provider: pick.provider, model, status: 0,
          dur_ms: Date.now() - t0, attempt, saved: false,
          error: String((err && err.message) || err).slice(0, 200)
        });
        if (info && process.env.AI_ROUTER_DEBUG) console.log(`[ai-router] fail ${pick.keyId}: ${err.message}`);
        if (attempt < maxTotalAttempts) {
          await delay(attemptDelayMs);
          continue;
        }
        sendJson(res, 502, shapedError(incomingPath, 502, `providers unreachable after ${attempt} attempts (last: ${err.message})`),
          { 'x-ai-router-attempts': String(attempt) });
        responded = true;
        break;
      }

      const status = ures.status;

      /* success */
      if (status >= 200 && status < 300) {
        router.onSuccess(pick.keyId);
        const usage = await deliverSuccess({
          ures, res, wantStream, style: built.style, incomingPath,
          model: built.model, meta: { provider: pick.provider, keyId: pick.keyId, attempts: attempt }
        });
        analytics.log({
          ide_hint: ideHint, provider: pick.provider, model: built.model, status,
          dur_ms: Date.now() - t0, tokens_in: usage.tokens_in, tokens_out: usage.tokens_out,
          attempt, stream: usage.stream, saved: attempt > 1
        });
        responded = true;
        break;
      }

      /* failure -> classify */
      const cls = classifyStatus(status);
      let raw = null;
      try { raw = await readUpstream(ures.res, MAX_UPSTREAM_BYTES); } catch (_) { raw = null; }
      router.onFail(pick.keyId, status);
      failedThisRequest.push(pick.keyId);
      analytics.log({
        ide_hint: ideHint, provider: pick.provider, model, status,
        dur_ms: Date.now() - t0, attempt, saved: false
      });
      if (info_dbg(cls, pick.keyId, status)) console.log(`[ai-router] fail ${pick.keyId} status=${status} class=${cls}`);
      if (RETRYABLE_STATUSES.has(cls) && attempt < maxTotalAttempts) {
        await delay(attemptDelayMs);
        continue;
      }
      // retryable-exhausted or non-retryable: show the IDE what upstream said
      sendUpstreamError(res, incomingPath, status, ures, raw, {
        provider: pick.provider, keyId: pick.keyId, attempts: attempt
      });
      responded = true;
      break;
    }

    if (!responded) {
      // paranoia: loop fell through without responding
      sendJson(res, 502, shapedError(incomingPath, 502, 'AI Router Pro: no upstream attempt made'));
    }
  }

  function info_dbg() { return !!process.env.AI_ROUTER_DEBUG; }

  /**
   * Deliver a 2xx upstream response to the IDE.
   * Returns {tokens_in, tokens_out, stream} for analytics.
   */
  async function deliverSuccess({ ures, res, wantStream, style, incomingPath, model, meta }) {
    const debug = upstreamDebugHeaders(meta);
    const ctype = String(ures.headers['content-type'] || '');
    const isSse = ctype.includes('text/event-stream');
    const native = !needsTranslation(style, incomingPath);

    /* native streaming pass-through (openai->openai or anthropic->anthropic) */
    if (native && wantStream && isSse) {
      await awaitPipe(ures.res, res, ures.status, { 'content-type': ctype, extra: debug });
      return { tokens_in: null, tokens_out: null, stream: true };
    }

    let raw;
    try {
      raw = await readUpstream(ures.res, MAX_UPSTREAM_BYTES);
    } catch (_) {
      raw = Buffer.from('{"error":{"message":"upstream stream error"}}', 'utf8');
    }
    const json = safeJson(raw);
    const usage = json ? extractUsage(json, style, incomingPath) : null;

    if (native) {
      // pass upstream bytes verbatim (keeps provider semantics 1:1)
      const outCtype = ctype || 'application/json';
      if (wantStream && !isSse && json) {
        // upstream ignored stream:true — synthesize SSE from the JSON result
        const sseBuf = Buffer.from(makeStreamBody(incomingPath, json), 'utf8');
        sendBuffer(res, ures.status, 'text/event-stream', sseBuf, debug);
        return { tokens_in: usage ? usage.tokens_in : null, tokens_out: usage ? usage.tokens_out : null, stream: true };
      }
      sendBuffer(res, ures.status, outCtype, raw, debug);
      return {
        tokens_in: usage ? usage.tokens_in : null,
        tokens_out: usage ? usage.tokens_out : null,
        stream: false
      };
    }

    /* cross-style: translate upstream JSON into the incoming protocol */
    const translated = json ? translateUpstream(json, { style, incomingPath, model }) : null;
    if (!translated) {
      sendJson(res, 502, shapedError(incomingPath, 502, 'upstream returned non-JSON response body'));
      return { tokens_in: null, tokens_out: null, stream: false };
    }
    if (wantStream) {
      const sseBuf = Buffer.from(makeStreamBody(incomingPath, translated), 'utf8');
      sendBuffer(res, 200, 'text/event-stream', sseBuf, debug);
      return { tokens_in: usage ? usage.tokens_in : null, tokens_out: usage ? usage.tokens_out : null, stream: true };
    }
    sendBuffer(res, 200, 'application/json; charset=utf-8', Buffer.from(JSON.stringify(translated), 'utf8'), debug);
    return {
      tokens_in: usage ? usage.tokens_in : null,
      tokens_out: usage ? usage.tokens_out : null,
      stream: false
    };
  }

  function sendUpstreamError(res, incomingPath, status, ures, raw, meta) {
    const ctype = ures ? String(ures.headers['content-type'] || '') : '';
    let buf = raw || Buffer.alloc(0);
    let outCtype = ctype.includes('json') ? ctype : 'application/json; charset=utf-8';
    if (!buf.length) {
      buf = Buffer.from(JSON.stringify(shapedError(incomingPath, status, `upstream returned HTTP ${status} (via AI Router Pro)`)), 'utf8');
      outCtype = 'application/json; charset=utf-8';
    } else if (!/json|text|html|xml/i.test(ctype)) {
      // non-text error bodies get wrapped so IDEs can parse them
      buf = Buffer.from(JSON.stringify(shapedError(incomingPath, status,
        `upstream returned HTTP ${status}: ${(buf.toString('utf8') || '').slice(0, 2000)}`)), 'utf8');
      outCtype = 'application/json; charset=utf-8';
    }
    const extra = {
      'x-ai-router-provider': meta.provider || '',
      'x-ai-router-key': meta.keyId || '',
      'x-ai-router-attempts': String(meta.attempts || 1)
    };
    if (res.writableEnded || res.destroyed) return;
    try {
      res.writeHead(status, baseResHeaders({ 'content-type': outCtype, 'content-length': buf.length, ...extra }));
      res.end(buf);
    } catch (_) { /* ignore */ }
  }

  /* ---------------- lifecycle ---------------- */

  const app = {
    server,
    router,
    analytics,
    adminToken,
    version: VERSION,
    bootTs,
    listen(port, host) {
      const pArg = port != null ? Number(port) : (opts.port != null ? Number(opts.port) : NaN);
      // port 0 = ephemeral (used by tests) — must NOT fall back to 8080!
      const p = (Number.isFinite(pArg) && pArg >= 0 && pArg <= 65535)
        ? pArg
        : (Number(process.env.PORT) || 8080);
      const h = host != null ? host : (opts.host != null ? opts.host : '127.0.0.1');
      return new Promise((resolve) => {
        server.listen(p, h, () => resolve(server.address().port));
      });
    },
    close() {
      return new Promise((resolve) => {
        server.close(() => resolve());
        // drop keep-alive sockets so the process can exit deterministically
        if (typeof server.closeAllConnections === 'function') server.closeAllConnections();
      });
    },
    get port() {
      return server.address() ? server.address().port : null;
    }
  };
  return app;
}

function bearerOf(header) {
  if (!header) return '';
  const m = /^Bearer\s+(.+)$/i.exec(String(header).trim());
  return m ? m[1].trim() : '';
}

function delay(ms) {
  return new Promise((r) => setTimeout(r, ms));
}

/* ------------------------------------------------------------------ */
/* CLI / main                                                          */
/* ------------------------------------------------------------------ */

function generateAdminToken(dataDir) {
  let token = '';
  const file = path.join(dataDir, 'admin_token.txt');
  try {
    token = fs.readFileSync(file, 'utf8').trim();
  } catch (_) {
    token = crypto.randomBytes(16).toString('hex');
    try {
      fs.mkdirSync(dataDir, { recursive: true });
      fs.writeFileSync(file, token + '\n', { mode: 0o600 });
    } catch (_) { /* best effort */ }
  }
  return token;
}

function parseArgs(argv) {
  const out = { help: false, port: null, host: null, config: null, debug: false };
  for (let i = 0; i < argv.length; i++) {
    const a = argv[i];
    if (a === '--help' || a === '-h') out.help = true;
    else if (a === '--port' || a === '-p') out.port = Number(argv[++i]);
    else if (a.startsWith('--port=')) out.port = Number(a.slice(7));
    else if (a === '--host') out.host = argv[++i];
    else if (a.startsWith('--host=')) out.host = a.slice(7);
    else if (a === '--config' || a === '-c') out.config = argv[++i];
    else if (a.startsWith('--config=')) out.config = a.slice(9);
    else if (a === '--debug') out.debug = true;
  }
  return out;
}

function printUsage() {
  console.log(`AI IDE Unlimited Router Pro v${VERSION}
Usage: node src/server.js [--port 8080] [--host 127.0.0.1] [--config config.json] [--debug]

Endpoints:
  POST /v1/chat/completions      OpenAI-compatible (Cursor / OpenCode / Continue)
  POST /v1/messages              Anthropic-compatible (Claude Code)
  GET  /health                   status {ok, uptime, keys_total, keys_hot}
  GET  /v1/models                aggregated model list
  GET  /admin                    web dashboard (RU/EN)
  POST /admin/api/keys           add/remove key (x-admin-token required)

Config: config/config.json (copy from config.example.json, keys via .env)
`);
}

function printStartupBanner(app, listenPort, listenHost) {
  const snap = app.router.snapshot();
  const line = '─'.repeat(64);
  console.log('');
  console.log(`  AI IDE Unlimited Router Pro v${app.version}`);
  console.log(line);
  console.log(`  API endpoint : http://${listenHost}:${listenPort}/v1`);
  console.log(`  Dashboard    : http://localhost:${listenPort}/admin`);
  console.log(`  Health       : curl http://${listenHost}:${listenPort}/health`);
  console.log(`  Providers    : ${snap.providers.length}   Keys: ${snap.keys_total}`);
  console.log(`  Data dir     : ${app.analytics.dir}`);
  if (process.env.ADMIN_TOKEN) {
    console.log('  Admin token  : ADMIN_TOKEN from environment (hidden)');
  } else {
    console.log(`  Admin token  : ${app.adminToken}`);
    console.log('                 (saved to data/admin_token.txt; needed for key management)');
  }
  console.log(line);
  console.log('  IDE setup:');
  console.log(`   • Cursor:     Base URL = http://127.0.0.1:${listenPort}/v1  (OpenAI)`);
  console.log(`   • Claude Code: ANTHROPIC_BASE_URL=http://127.0.0.1:${listenPort}`);
  console.log(`   • OpenCode:   baseURL = http://127.0.0.1:${listenPort}/v1`);
  console.log(`   • VS Code:    apiBase = http://127.0.0.1:${listenPort}/v1`);
  console.log(line);
  console.log('');
}

function main() {
  const args = parseArgs(process.argv.slice(2));
  if (args.help) { printUsage(); process.exit(0); }
  if (args.debug) process.env.AI_ROUTER_DEBUG = '1';

  loadEnvFile(path.join(ROOT, '.env'));

  const configPath = args.config
    ? path.resolve(args.config)
    : process.env.AI_ROUTER_CONFIG
      ? path.resolve(process.env.AI_ROUTER_CONFIG)
      : defaultConfigPath(ROOT);

  if (!fs.existsSync(configPath)) {
    console.error('[ai-router] Config file not found:\n  ' + configPath);
    console.error(`
Сначала создайте конфиг (first run):
  cp config/config.example.json config/config.json
  cp .env.example .env        # и впишите СВОИ ключи
  node src/server.js

(English) Copy config.example.json -> config/config.json, put YOUR keys into
.env (never hardcoded anywhere), then run the server again.`);
    process.exit(1);
  }

  let config;
  try {
    config = loadConfig(configPath);
  } catch (err) {
    console.error(`[ai-router] Cannot parse config ${configPath}: ${err.message}`);
    process.exit(1);
  }

  const dataDir = process.env.AI_ROUTER_DATA || path.join(ROOT, 'data');
  const AdminToken = process.env.ADMIN_TOKEN || generateAdminToken(dataDir);
  const app = createServer({
    config,
    dataDir,
    adminToken: AdminToken,
    maxTotalAttempts: config.maxTotalAttempts,
    attemptDelayMs: config.attemptDelayMs,
    upstreamTimeoutMs: config.upstreamTimeoutMs
  });

  const listenPort = Number.isFinite(args.port) && args.port > 0 ? args.port : (Number(process.env.PORT) || 8080);
  const listenHost = args.host || process.env.HOST || '127.0.0.1';

  app.listen(listenPort, listenHost).then((port) => {
    printStartupBanner(app, port, listenHost);
  });

  const shutdown = (sig) => {
    console.log(`\n[ai-router] ${sig} received, shutting down...`);
    app.close().then(() => process.exit(0));
  };
  process.on('SIGINT', () => shutdown('SIGINT'));
  process.on('SIGTERM', () => shutdown('SIGTERM'));

  return app;
}

module.exports = {
  createServer,
  upstreamRequest,
  detectIde,
  readBody,
  readUpstream,
  shapedError,
  generateAdminToken,
  parseArgs,
  main,
  VERSION,
  ROOT
};

if (require.main === module) main();
