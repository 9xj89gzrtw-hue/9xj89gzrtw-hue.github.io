'use strict';

/**
 * analytics.js — per-request analytics for AI IDE Unlimited Router Pro.
 *
 * Every request gets one JSONL line appended to
 *     <dataDir>/traffic-YYYY-MM-DD.jsonl   (rotated daily, UTC date)
 *
 * Line shape (stable keys, extra fields may appear):
 *   {ts, ide_hint, provider, model, status, dur_ms, tokens_in, tokens_out,
 *    attempt, stream, saved}
 *
 * In-memory summaries power the dashboard (GET /admin/api/summary):
 * totals, per-provider, per-model, hourly/minute histograms, recent list,
 * and the "429 saved" counter (a request that recovered via failover).
 *
 * At this scale (single user, localhost) fs.appendFileSync is perfectly fine
 * and gives simple, lock-free-per-process appends.
 */

const fs = require('fs');
const path = require('path');

const MINUTE_MS = 60 * 1000;
const HOUR_MS = 60 * MINUTE_MS;
const MAX_RECENT = 100;
const WARMUP_MAX_LINES = 20000;

function utcDateStamp(ts) {
  return new Date(ts).toISOString().slice(0, 10); // YYYY-MM-DD (UTC)
}

function trafficFilename(ts) {
  return `traffic-${utcDateStamp(ts)}.jsonl`;
}

/** Read a JSONL file into objects; malformed lines are skipped. */
function readJsonl(file) {
  let text;
  try {
    text = fs.readFileSync(file, 'utf8');
  } catch (_) {
    return [];
  }
  const out = [];
  for (const line of text.split(/\r?\n/)) {
    const l = line.trim();
    if (!l) continue;
    try { out.push(JSON.parse(l)); } catch (_) { /* skip bad line */ }
  }
  return out;
}

/**
 * Pure aggregation over JSONL entries (testable widget logic).
 * Returns {total, ok, rate_limit, auth, server, saved_429, avg_ms,
 *          per_provider, per_model, per_ide}
 */
function aggregateEntries(entries) {
  const agg = {
    total: 0, ok: 0, rate_limit: 0, auth: 0, server: 0,
    saved_429: 0, sum_ms: 0, n_ms: 0,
    per_provider: {},
    per_model: {},
    per_ide: {}
  };
  for (const e of (Array.isArray(entries) ? entries : [])) {
    if (!e || typeof e !== 'object') continue;
    agg.total += 1;
    const status = Number(e.status) || 0;
    if (status >= 200 && status < 300) agg.ok += 1;
    else if (status === 429) agg.rate_limit += 1;
    else if (status === 401 || status === 403) agg.auth += 1;
    else if (status >= 500) agg.server += 1;
    if (e.saved) agg.saved_429 += 1;
    if (typeof e.dur_ms === 'number') {
      agg.sum_ms += e.dur_ms;
      agg.n_ms += 1;
    }
    const prov = e.provider || '(none)';
    if (!agg.per_provider[prov]) {
      agg.per_provider[prov] = { total: 0, ok: 0, rate_limit: 0, avg_ms: 0, sum_ms: 0, n: 0 };
    }
    const pp = agg.per_provider[prov];
    pp.total += 1;
    if (status >= 200 && status < 300) pp.ok += 1;
    if (status === 429) pp.rate_limit += 1;
    if (typeof e.dur_ms === 'number') { pp.sum_ms += e.dur_ms; pp.n += 1; }
    pp.avg_ms = pp.n ? Math.round(pp.sum_ms / pp.n) : 0;
    delete pp.sum_ms; delete pp.n;

    const model = e.model || '(unknown)';
    if (!agg.per_model[model]) {
      agg.per_model[model] = { model, count: 0, tokens_in: 0, tokens_out: 0 };
    }
    const pm = agg.per_model[model];
    pm.count += 1;
    if (typeof e.tokens_in === 'number') pm.tokens_in += e.tokens_in;
    if (typeof e.tokens_out === 'number') pm.tokens_out += e.tokens_out;

    const ide = e.ide_hint || 'other';
    agg.per_ide[ide] = (agg.per_ide[ide] || 0) + 1;
  }
  agg.avg_ms = agg.n_ms ? Math.round(agg.sum_ms / agg.n_ms) : 0;
  delete agg.sum_ms;
  return agg;
}

class Analytics {
  constructor({ dataDir } = {}) {
    this.dir = dataDir || path.join(process.cwd(), 'data');
    try { fs.mkdirSync(this.dir, { recursive: true }); } catch (_) { /* exists */ }
    this.startedAt = Date.now();
    // in-memory counters
    this.totals = { requests: 0, ok: 0, rate_limit: 0, auth: 0, server: 0 };
    this.saved429 = 0;
    this.sumMs = 0;
    this.nMs = 0;
    this.perProvider = {};
    this.perModel = {};
    this.perIde = {};
    this.hourly = new Map();  // hourBucketTs -> count
    this.minutely = new Map(); // minuteBucketTs -> count
    this.recent = [];
    this._warmup();
  }

  /** Recover today's counters from the existing JSONL (restart resilience). */
  _warmup() {
    const file = path.join(this.dir, trafficFilename(Date.now()));
    const lines = readJsonl(file);
    const slice = lines.slice(-WARMUP_MAX_LINES);
    for (const e of slice) this._update(e);
  }

  get todayFile() {
    return path.join(this.dir, trafficFilename(Date.now()));
  }

  _logFile(ts) {
    return path.join(this.dir, trafficFilename(ts));
  }

  /** Append one line + update in-memory summaries. */
  log(entry) {
    const e = {
      ts: Date.now(),
      ide_hint: entry.ide_hint || 'other',
      provider: entry.provider || '(none)',
      model: entry.model || '(unknown)',
      status: Number(entry.status) || 0,
      dur_ms: typeof entry.dur_ms === 'number' ? Math.round(entry.dur_ms) : null,
      tokens_in: typeof entry.tokens_in === 'number' ? entry.tokens_in : null,
      tokens_out: typeof entry.tokens_out === 'number' ? entry.tokens_out : null,
      attempt: entry.attempt || null,
      stream: !!entry.stream,
      saved: !!entry.saved
    };
    try {
      fs.appendFileSync(this._logFile(e.ts), JSON.stringify(e) + '\n');
    } catch (err) {
      // never let analytics kill the proxy
      if (process.env.AI_ROUTER_DEBUG) console.error('[analytics] append failed:', err.message);
    }
    this._update(e);
    return e;
  }

  _update(e) {
    this.totals.requests += 1;
    if (e.status >= 200 && e.status < 300) this.totals.ok += 1;
    else if (e.status === 429) this.totals.rate_limit += 1;
    else if (e.status === 401 || e.status === 403) this.totals.auth += 1;
    else if (e.status >= 500) this.totals.server += 1;
    if (e.saved) this.saved429 += 1;
    if (typeof e.dur_ms === 'number') { this.sumMs += e.dur_ms; this.nMs += 1; }

    const pp = this.perProvider[e.provider] || (this.perProvider[e.provider] = { total: 0, ok: 0, rate_limit: 0, avg_ms: 0 });
    pp.total += 1;
    if (e.status >= 200 && e.status < 300) pp.ok += 1;
    if (e.status === 429) pp.rate_limit += 1;
    if (typeof e.dur_ms === 'number') { pp.avg_ms = pp.avg_ms ? Math.round((pp.avg_ms * (pp.total - 1) + e.dur_ms) / pp.total) : Math.round(e.dur_ms); }

    const pm = this.perModel[e.model] || (this.perModel[e.model] = { model: e.model, count: 0, tokens_in: 0, tokens_out: 0 });
    pm.count += 1;
    if (typeof e.tokens_in === 'number') pm.tokens_in += e.tokens_in;
    if (typeof e.tokens_out === 'number') pm.tokens_out += e.tokens_out;

    const pi = this.perIde;
    pi[e.ide_hint] = (pi[e.ide_hint] || 0) + 1;

    const hour = Math.floor(e.ts / HOUR_MS) * HOUR_MS;
    this.hourly.set(hour, (this.hourly.get(hour) || 0) + 1);
    const minute = Math.floor(e.ts / MINUTE_MS) * MINUTE_MS;
    this.minutely.set(minute, (this.minutely.get(minute) || 0) + 1);

    this.recent.unshift(e);
    if (this.recent.length > MAX_RECENT) this.recent.length = MAX_RECENT;
  }

  _pruneBuckets(now) {
    const cutoffMin = now - 25 * HOUR_MS;
    for (const k of this.hourly.keys()) {
      if (k < cutoffMin) this.hourly.delete(k);
    }
    const cutoffM = now - 65 * MINUTE_MS;
    for (const k of this.minutely.keys()) {
      if (k < cutoffM) this.minutely.delete(k);
    }
  }

  /** Summary JSON for the dashboard (merged with router snapshot upstream). */
  summary(now) {
    const t = now || Date.now();
    this._pruneBuckets(t);
    let requests1h = 0;
    for (const [k, v] of this.minutely) if (k >= t - HOUR_MS) requests1h += v;
    let requests24h = 0;
    for (const [k, v] of this.hourly) if (k >= t - 24 * HOUR_MS) requests24h += v;

    const perModel = Object.values(this.perModel)
      .sort((a, b) => b.count - a.count);
    const recent = this.recent.slice(0, 50).map((e) => ({
      ts: e.ts, ide_hint: e.ide_hint, provider: e.provider, model: e.model,
      status: e.status, dur_ms: e.dur_ms, tokens_in: e.tokens_in, tokens_out: e.tokens_out
    }));

    return {
      ts: t,
      requests_total: this.totals.requests,
      ok_total: this.totals.ok,
      rate_limit_total: this.totals.rate_limit,
      auth_total: this.totals.auth,
      server_total: this.totals.server,
      requests_1h: requests1h,
      requests_24h: requests24h,
      saved_429: this.saved429,
      avg_dur_ms: this.nMs ? Math.round(this.sumMs / this.nMs) : null,
      per_provider: this.perProvider,
      per_ide: this.perIde,
      per_model: perModel,
      hourly: [...this.hourly.entries()]
        .sort((a, b) => a[0] - b[0])
        .slice(-24)
        .map(([k, v]) => ({ ts: k, count: v })),
      recent
    };
  }
}

module.exports = {
  Analytics,
  aggregateEntries,
  readJsonl,
  utcDateStamp,
  trafficFilename,
  MINUTE_MS,
  HOUR_MS
};
