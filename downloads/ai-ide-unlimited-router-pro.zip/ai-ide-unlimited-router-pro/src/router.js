'use strict';

/**
 * router.js — pure core logic of "AI IDE Unlimited Router Pro".
 *
 * This module contains NO I/O (except nothing at all — it is fully pure),
 * so every function here can be unit-tested offline.
 *
 * Design notes:
 *  - A "key state" object describes one provider+key pair. The router owns the
 *    authoritative list of key states; pure helpers (chooseNextKey, ...) never
 *    mutate anything — mutation happens only in createRouter().chooseKey().
 *  - When an upstream call returns 429 (or another retryable failure) the key
 *    is put on a cooldown that doubles per consecutive failure:
 *        1st failure -> 30s, 2nd -> 60s, 3rd -> 120s ... capped at 30 minutes.
 *  - A SUCCESSFUL call resets the *failure streak* (consecutive counter) to 0
 *    and clears the active cooldown. It deliberately does NOT wipe long-lived
 *    stats (ok/fail counters, usage) — those stay for analytics so the
 *    dashboard can show flaky or burned keys. Rationale: a success is strong
 *    evidence the key/quota is healthy again, hence the next single 429 only
 *    costs the base cooldown (30s), not the whole exponential ladder.
 */

const DEFAULT_COOLDOWN_BASE_MS = 30 * 1000;       // 30 seconds
const DEFAULT_COOLDOWN_MAX_MS = 30 * 60 * 1000;   // 30 minutes
const DEFAULT_COOLDOWN_GROWTH = 2;                // exponential backoff factor
const WEIGHT_EPSILON = 1e-9;

const DEFAULT_GEMINI_BASE = 'https://generativelanguage.googleapis.com/v1beta';
const DEFAULT_ANTHROPIC_BASE = 'https://api.anthropic.com';
const DEFAULT_ANTHROPIC_VERSION = '2023-06-01';
const DEFAULT_ANTHROPIC_MAX_TOKENS = 4096;

const CHAT_PATH = '/v1/chat/completions'; // OpenAI-style incoming
const MESSAGES_PATH = '/v1/messages';     // Anthropic-style incoming

/* ------------------------------------------------------------------ */
/* Status classification                                               */
/* ------------------------------------------------------------------ */

/**
 * classifyStatus(status) -> 'rate_limit' | 'auth' | 'server' | 'ok' | 'retry_now'
 *
 *  429                -> rate_limit  (cooldown + failover to next key)
 *  401 / 403          -> auth        (key is dead/quota-wiped: also cooldown)
 *  408 / 425          -> retry_now   (transient request-timing failures)
 *  500..599           -> server      (provider outage: cooldown + failover)
 *  200..299           -> ok
 *  0 (network error)  -> retry_now   (DNS/connect/refused: retry next attempt)
 *  other 4xx          -> 'ok' category (do NOT burn cooldown: the request itself
 *                        is bad, e.g. 400 malformed body — the IDE must see it)
 */
function classifyStatus(status) {
  const s = Number(status) || 0;
  if (s === 429) return 'rate_limit';
  if (s === 401 || s === 403) return 'auth';
  if (s === 408 || s === 425) return 'retry_now';
  if (s >= 500 && s < 600) return 'server';
  if (s >= 200 && s < 300) return 'ok';
  if (s === 0) return 'retry_now';
  return 'ok'; // non-retryable client errors pass straight to the IDE
}

/** Statuses that trigger key cooldown + failover inside the proxy. */
const RETRYABLE_STATUSES = new Set(['rate_limit', 'auth', 'server', 'retry_now']);

/* ------------------------------------------------------------------ */
/* Cooldown math                                                       */
/* ------------------------------------------------------------------ */

/**
 * computeCooldownMs(consecutive, lastFailedAt, opts) -> ms
 *   consecutive=1 -> base (30s), 2 -> 60s, 3 -> 120s ... capped at max (30min).
 *   consecutive <= 0 -> 0 (never cooling).
 *
 * `lastFailedAt` is currently unused but kept in the signature per public API
 * (reserved for future per-key jitter / sticky floor logic).
 */
function computeCooldownMs(consecutiveFailures, lastFailedAt, opts) {
  void lastFailedAt; // see comment above
  const o = opts || {};
  const base = numOr(o.baseMs, DEFAULT_COOLDOWN_BASE_MS);
  const max = numOr(o.maxMs, DEFAULT_COOLDOWN_MAX_MS);
  const growth = (typeof o.growth === 'number' && o.growth >= 1) ? o.growth : DEFAULT_COOLDOWN_GROWTH;
  const n = Math.max(0, Math.floor(Number(consecutiveFailures) || 0));
  if (n < 1) return 0;
  const exp = Math.min(n - 1, 32); // guard: 2**32 * base already >> cap
  let ms = base * Math.pow(growth, exp);
  if (!Number.isFinite(ms) || ms < 0) ms = max;
  return Math.min(Math.round(ms), max);
}

/* ------------------------------------------------------------------ */
/* Key state + weighted round-robin                                    */
/* ------------------------------------------------------------------ */

function createKeyState(providerName, key, index, weight) {
  return {
    id: `${providerName}#${index + 1}`, // stable id like "gemini#2"
    provider: providerName,
    key: String(key),
    idx: Number(index) || 0,
    weight: Math.max(1, Number(weight) || 1),
    uses: 0,          // selections by the balancer
    ok: 0,            // successful upstream completions
    fail: 0,          // retryable failures (lifetime, never zeroed)
    consecutive: 0,   // current failure streak (reset on success)
    lastFailedAt: 0,
    lastUsedAt: 0,
    coolUntil: 0,     // epoch ms while key is "hot"
    lastStatus: 0,
    lastError: '',
    disabled: false
  };
}

/**
 * chooseNextKey(keys, now) -> keyState | null
 *
 * Smooth weighted round-robin: pick the available (not cooling, not disabled)
 * key with the smallest `uses / weight`. Ties resolved by oldest lastUsedAt,
 * then by array order — fully deterministic, no randomness.
 * Returns the key-state entry itself which carries `.provider` and `.key`
 * (superset of the documented {provider, key} shape).
 * Pure: does NOT mutate the passed entries.
 */
function chooseNextKey(keys, now) {
  const t = numOr(now, Date.now());
  if (!Array.isArray(keys)) return null;
  let best = null;
  let bestScore = Infinity;
  let bestIdx = -1;
  for (let i = 0; i < keys.length; i++) {
    const k = keys[i];
    if (!k || k.disabled) continue;
    if (k.coolUntil && k.coolUntil > t) continue; // skip keys in cooldown
    const score = k.uses / k.weight;
    let take = best === null;
    if (!take) {
      if (score < bestScore - WEIGHT_EPSILON) take = true;
      else if (Math.abs(score - bestScore) <= WEIGHT_EPSILON) {
        if (k.lastUsedAt < best.lastUsedAt) take = true;
        else if (k.lastUsedAt === best.lastUsedAt && i < bestIdx) take = true;
      }
    }
    if (take) { best = k; bestScore = score; bestIdx = i; }
  }
  return best;
}

/* ------------------------------------------------------------------ */
/* Router factory                                                      */
/* ------------------------------------------------------------------ */

/**
 * createRouter(config) where
 *   config = {
 *     providers: [{ name, style?, baseUrl, apiKey (string "k1,k2"|[...]),
 *                   models: [], headersExtra?, modelMap?, maxPerMinute?, weight? }],
 *     cooldownBaseMs?, cooldownMaxMs?, cooldownGrowth?, maxPerMinute?
 *   }
 *
 * Returns an object with:
 *   providers, keys          — normalized state
 *   chooseKey(now?)          -> {provider, key, keyId, style} | null (mutates counters)
 *   onFail(keyId, status, now?) / onSuccess(keyId, now?)
 *   isKeyHot(id, now?) / hotKeys(now?) / minMsUntilAnyKeyReady(now?)
 *   providerByName(name)     -> provider object or null
 *   providerByKeyId(keyId)   -> provider object or null
 *   snapshot(now?)           -> analytics-friendly state
 *   options                  — resolved timing options
 */
function createRouter(config) {
  const cfg = config || {};
  const providers = [];
  const keys = [];
  const providersByName = new Map();

  const cfgProviders = Array.isArray(cfg.providers) ? cfg.providers : [];
  cfgProviders.forEach((p, pi) => {
    const name = String(p.name || `provider-${pi + 1}`);
    const style = String(p.style || 'openai').toLowerCase();
    const baseUrl = String(p.baseUrl || '').replace(/\/+$/, '');
    const models = Array.isArray(p.models) ? p.models.map(String) : [];
    const rawKeys = Array.isArray(p.apiKey) ? p.apiKey.join(',') : String(p.apiKey || '');
    const keyList = rawKeys.split(',').map((s) => s.trim()).filter(Boolean);

    const provider = {
      name,
      style,
      baseUrl,
      models,
      headersExtra: isPlainObj(p.headersExtra) ? p.headersExtra : {},
      modelMap: isPlainObj(p.modelMap) ? p.modelMap : {},
      maxPerMinute: Math.max(0, Number(p.maxPerMinute) || 0),
      weight: Math.max(1, Number(p.weight) || 1),
      defaultMaxTokens: Number(p.defaultMaxTokens) || DEFAULT_ANTHROPIC_MAX_TOKENS,
      anthropicVersion: String(p.anthropicVersion || DEFAULT_ANTHROPIC_VERSION),
      window: [],   // rolling request timestamps for maxPerMinute
      _keys: []
    };

    keyList.forEach((k, i) => {
      const ks = createKeyState(name, k, i, p.weight);
      keys.push(ks);
      provider._keys.push(ks);
    });

    providers.push(provider);
    providersByName.set(name, provider);
  });

  const options = {
    baseMs: numOr(cfg.cooldownBaseMs, DEFAULT_COOLDOWN_BASE_MS),
    maxMs: numOr(cfg.cooldownMaxMs, DEFAULT_COOLDOWN_MAX_MS),
    growth: (typeof cfg.cooldownGrowth === 'number' && cfg.cooldownGrowth >= 1) ? cfg.cooldownGrowth : DEFAULT_COOLDOWN_GROWTH,
    perMinuteWindowMs: numOr(cfg.perMinuteWindowMs, 60 * 1000)
  };

  function keyById(id) {
    for (const k of keys) if (k.id === id) return k;
    return null;
  }

  function pruneWindow(p, now) {
    const cutoff = now - options.perMinuteWindowMs;
    while (p.window.length && p.window[0] <= cutoff) p.window.shift();
  }

  function providerThrottled(p, now) {
    pruneWindow(p, now);
    return p.maxPerMinute > 0 && p.window.length >= p.maxPerMinute;
  }

  /**
   * Pick the next available key. Rotates across all providers; providers that
   * hit their maxPerMinute budget are skipped this minute (conservative:
   * failed attempts also count into the window).
   *
   * allowCoolingKeyIds: key ids that may be picked EVEN IF in cooldown.
   * Used by the server so a client request can use its full retry budget
   * within one request (re-failing the same key still grows the exponential
   * ladder; across separate requests cooldown is enforced strictly).
   *
   * preferredModel: if some providers explicitly list this model in their
   * `models`, pick only among them (model affinity); when none of those are
   * available OR nobody lists the model, fall back to all providers.
   */
  function chooseKey(now, allowCoolingKeyIds, preferredModel) {
    const t = numOr(now, Date.now());
    const allowSet = Array.isArray(allowCoolingKeyIds) && allowCoolingKeyIds.length
      ? new Set(allowCoolingKeyIds)
      : null;
    const candidates = [];
    for (const p of providers) {
      if (providerThrottled(p, t)) continue;
      for (const k of p._keys) {
        if (k.coolUntil > t && !(allowSet && allowSet.has(k.id))) continue;
        candidates.push(k);
      }
    }
    if (!candidates.length) return null;

    const pickFrom = (list) => {
      // chooseNextKey() also skips cooling keys internally — temporarily
      // neutralize the cooldown of explicitly-allowed keys (synchronous, so
      // no interleaving hazard), then restore.
      const temporarilyFreed = [];
      if (allowSet) {
        for (const k of list) {
          if (k.coolUntil > t && allowSet.has(k.id)) {
            k._savedCoolUntil = k.coolUntil;
            k.coolUntil = 0;
            temporarilyFreed.push(k);
          }
        }
      }
      const chosen = chooseNextKey(list, t);
      for (const k of temporarilyFreed) k.coolUntil = k._savedCoolUntil;
      return chosen;
    };

    let pick = null;
    if (preferredModel) {
      const matching = candidates.filter((k) => {
        const prov = providersByName.get(k.provider);
        return prov && prov.models.includes(preferredModel);
      });
      if (matching.length) pick = pickFrom(matching);
    }
    if (!pick) pick = pickFrom(candidates);
    if (!pick) return null;

    pick.uses += 1;
    pick.lastUsedAt = t;
    const prov = providersByName.get(pick.provider);
    if (prov) prov.window.push(t);
    return { provider: pick.provider, key: pick.key, keyId: pick.id, style: prov ? prov.style : 'openai' };
  }

  /** Register a retryable failure on a key; returns cooldown info. */
  function onFail(keyId, status, now) {
    const k = keyById(keyId);
    if (!k) return null;
    const t = numOr(now, Date.now());
    k.fail += 1;
    k.consecutive += 1;
    k.lastFailedAt = t;
    k.lastStatus = Number(status) || 0;
    k.lastError = `status ${k.lastStatus}`;
    k.coolUntil = t + computeCooldownMs(k.consecutive, t, options);
    if (k.lastStatus === 401 || k.lastStatus === 403) k.lastError = 'auth/rejected';
    return {
      keyId: k.id,
      consecutive: k.consecutive,
      cooldownMs: computeCooldownMs(k.consecutive, t, options),
      coolUntil: k.coolUntil
    };
  }

  /**
   * Register a success on a key: resets the failure streak and clears the
   * active cooldown. Lifetime counters (ok/fail/uses) intentionally preserved —
   * see the rationale in the file header comment.
   */
  function onSuccess(keyId, now) {
    const k = keyById(keyId);
    if (!k) return null;
    const t = numOr(now, Date.now());
    k.ok += 1;
    k.consecutive = 0;
    k.coolUntil = 0;
    k.lastStatus = 200;
    k.lastError = '';
    k.lastUsedAt = t;
    return { keyId: k.id };
  }

  function isKeyHot(keyId, now) {
    const k = keyById(keyId);
    if (!k) return false;
    return k.coolUntil > numOr(now, Date.now());
  }

  function hotKeys(now) {
    const t = numOr(now, Date.now());
    return keys.filter((k) => k.coolUntil > t);
  }

  function minMsUntilAnyKeyReady(now) {
    const t = numOr(now, Date.now());
    let min = Infinity;
    for (const k of keys) {
      if (k.disabled) continue;
      if (k.coolUntil > t) min = Math.min(min, k.coolUntil - t);
      else return 0; // some key is ready right now
    }
    return Number.isFinite(min) ? min : 0;
  }

  function providerByName(name) {
    return providersByName.get(name) || null;
  }

  function providerByKeyId(keyId) {
    const k = keyById(keyId);
    return k ? (providersByName.get(k.provider) || null) : null;
  }

  function snapshot(now) {
    const t = numOr(now, Date.now());
    return {
      ts: t,
      keys_total: keys.length,
      keys_hot: hotKeys(t).length,
      keys: keys.map((k) => ({
        keyId: k.id,
        provider: k.provider,
        masked: maskKey(k.key),
        hot: k.coolUntil > t,
        cool_remaining_ms: k.coolUntil > t ? k.coolUntil - t : 0,
        consecutive: k.consecutive,
        uses: k.uses,
        ok: k.ok,
        fail: k.fail,
        lastStatus: k.lastStatus,
        lastError: k.lastError,
        weight: k.weight
      })),
      providers: providers.map((p) => ({
        name: p.name,
        style: p.style,
        models_count: p.models.length,
        maxPerMinute: p.maxPerMinute,
        weight: p.weight,
        keys: p._keys.length,
        used_this_minute: p.window.length
      }))
    };
  }

  return {
    providers,
    keys,
    options,
    chooseKey,
    onFail,
    onSuccess,
    isKeyHot,
    hotKeys,
    minMsUntilAnyKeyReady,
    providerByName,
    providerByKeyId,
    snapshot,
    keyById,
    addKeyNow(providerName, rawKey, now) {
      const p = providersByName.get(providerName);
      if (!p) return null;
      const key = String(rawKey || '').trim();
      if (!key) return null;
      const maxIdx = p._keys.reduce((m, k) => Math.max(m, k.idx), -1);
      const ks = createKeyState(providerName, key, maxIdx + 1, p.weight);
      keys.push(ks);
      p._keys.push(ks);
      return ks;
    },
    removeKeyNow(keyId) {
      const k = keyById(keyId);
      if (!k) return false;
      k.disabled = true;
      const p = providersByName.get(k.provider);
      if (p) {
        const i = p._keys.indexOf(k);
        if (i >= 0) p._keys.splice(i, 1);
      }
      const i = keys.indexOf(k);
      if (i >= 0) keys.splice(i, 1);
      return true;
    }
  };
}

/* ------------------------------------------------------------------ */
/* Request/response transliteration                                    */
/* ------------------------------------------------------------------ */

/**
 * Flatten OpenAI/Anthropic `content` into plain text:
 *   string -> itself; array -> joins {type:'text'} parts; other -> ''.
 */
function contentToText(content) {
  if (content == null) return '';
  if (typeof content === 'string') return content;
  if (Array.isArray(content)) {
    return content.map((part) => {
      if (typeof part === 'string') return part;
      if (part && typeof part === 'object' && part.type === 'text') return String(part.text || '');
      return '';
    }).filter((s) => s.length).join('\n');
  }
  return '';
}

/**
 * OpenAI chat body -> Gemini generateContent body.
 * Bulletproof mapping (tools/function-calls are out of scope of v1):
 *   messages                    -> contents[{role: 'user'|'model', parts:[{text}]}]
 *   system messages             -> systemInstruction.parts[0].text
 *   max_tokens                  -> generationConfig.maxOutputTokens
 *   temperature / top_p / stop  -> generationConfig
 */
function openAiToGemini(body) {
  const src = body || {};
  const contents = [];
  let systemText = '';
  for (const m of (Array.isArray(src.messages) ? src.messages : [])) {
    const text = contentToText(m.content);
    if (m.role === 'system') {
      systemText = systemText ? `${systemText}\n${text}` : text;
      continue;
    }
    contents.push({
      role: m.role === 'assistant' ? 'model' : 'user',
      parts: [{ text }]
    });
  }
  const out = { contents, generationConfig: {} };
  if (systemText) out.systemInstruction = { parts: [{ text: systemText }] };
  const gc = out.generationConfig;
  if (src.max_tokens != null) gc.maxOutputTokens = Number(src.max_tokens) || undefined;
  if (src.temperature != null) gc.temperature = src.temperature;
  if (src.top_p != null) gc.topP = src.top_p;
  if (src.stop != null) gc.stopSequences = Array.isArray(src.stop) ? src.stop.map(String) : [String(src.stop)];
  return out;
}

/** Gemini generateContent response -> OpenAI chat.completion (non-stream). */
function geminiToOpenAiResponse(gj, model) {
  const j = gj || {};
  const cand = (Array.isArray(j.candidates) && j.candidates[0]) || {};
  const parts = (cand.content && Array.isArray(cand.content.parts)) ? cand.content.parts : [];
  const text = parts.map((p) => (p && typeof p.text === 'string') ? p.text : '').join('');
  const u = j.usageMetadata || {};
  return {
    id: `chatcmpl-gemini-${j.responseId || Date.now().toString(36)}`,
    object: 'chat.completion',
    created: Math.floor(Date.now() / 1000),
    model: model || 'gemini',
    choices: [{
      index: 0,
      message: { role: 'assistant', content: text },
      finish_reason: mapGeminiFinish(cand.finishReason)
    }],
    usage: {
      prompt_tokens: u.promptTokenCount || 0,
      completion_tokens: u.candidatesTokenCount || 0,
      total_tokens: u.totalTokenCount || ((u.promptTokenCount || 0) + (u.candidatesTokenCount || 0))
    }
  };
}

function mapGeminiFinish(fr) {
  if (!fr) return 'stop';
  switch (String(fr).toUpperCase()) {
    case 'STOP': return 'stop';
    case 'MAX_TOKENS': return 'length';
    case 'SAFETY': return 'content_filter';
    case 'RECITATION': return 'content_filter';
    default: return 'stop';
  }
}

/** OpenAI chat body -> Anthropic /v1/messages body. */
function openAiToAnthropic(body, opts) {
  const src = body || {};
  const o = opts || {};
  const messages = [];
  let system = '';
  for (const m of (Array.isArray(src.messages) ? src.messages : [])) {
    const text = contentToText(m.content);
    if (m.role === 'system') {
      system = system ? `${system}\n${text}` : text;
      continue;
    }
    messages.push({ role: m.role === 'assistant' ? 'assistant' : 'user', content: text });
  }
  const out = {
    model: src.model || '',
    max_tokens: Number(src.max_tokens) || o.defaultMaxTokens || DEFAULT_ANTHROPIC_MAX_TOKENS,
    messages
  };
  if (system) out.system = system;
  if (src.temperature != null) out.temperature = src.temperature;
  if (src.top_p != null) out.top_p = src.top_p;
  if (src.stop != null) out.stop_sequences = Array.isArray(src.stop) ? src.stop.map(String) : [String(src.stop)];
  if (src.stream === true) out.stream = true;
  return out;
}

/** Anthropic /v1/messages body -> OpenAI chat body (system becomes a message). */
function anthropicToOpenAi(body) {
  const src = body || {};
  const messages = [];
  if (src.system) {
    const sys = typeof src.system === 'string'
      ? src.system
      : (Array.isArray(src.system)
        ? src.system.map((b) => (b && typeof b.text === 'string') ? b.text : '').join('\n')
        : '');
    if (sys) messages.push({ role: 'system', content: sys });
  }
  for (const m of (Array.isArray(src.messages) ? src.messages : [])) {
    messages.push({ role: m.role === 'assistant' ? 'assistant' : 'user', content: contentToText(m.content) });
  }
  const out = { model: src.model || '', messages, stream: src.stream === true };
  if (src.max_tokens != null) out.max_tokens = src.max_tokens;
  if (src.temperature != null) out.temperature = src.temperature;
  if (src.top_p != null) out.top_p = src.top_p;
  if (src.stop_sequences) out.stop = src.stop_sequences;
  return out;
}

/** Anthropic message response -> OpenAI chat.completion. */
function anthropicToOpenAiResponse(aj, model) {
  const j = aj || {};
  const text = contentToText(j.content);
  const u = j.usage || {};
  return {
    id: j.id || `chatcmpl-anthropic-${Date.now().toString(36)}`,
    object: 'chat.completion',
    created: Math.floor(Date.now() / 1000),
    model: model || j.model || 'anthropic',
    choices: [{
      index: 0,
      message: { role: 'assistant', content: text },
      finish_reason: j.stop_reason === 'max_tokens' ? 'length'
        : (j.stop_reason === 'stop_sequence' ? 'stop'
          : (j.stop_reason === 'content_filter' ? 'content_filter' : 'stop'))
    }],
    usage: {
      prompt_tokens: u.input_tokens || 0,
      completion_tokens: u.output_tokens || 0,
      total_tokens: (u.input_tokens || 0) + (u.output_tokens || 0)
    }
  };
}

/** OpenAI chat.completion -> Anthropic message (for /v1/messages IDEs). */
function openAiToAnthropicResponse(oj, model) {
  const j = oj || {};
  const choice = (Array.isArray(j.choices) && j.choices[0]) || {};
  const msg = choice.message || {};
  const u = j.usage || {};
  const fr = choice.finish_reason || 'stop';
  return {
    id: j.id || `msg_${Date.now().toString(36)}`,
    type: 'message',
    role: 'assistant',
    model: model || j.model || '',
    content: [{ type: 'text', text: contentToText(msg.content) }],
    stop_reason: fr === 'length' ? 'max_tokens' : (fr === 'content_filter' ? 'content_filter' : 'end_turn'),
    stop_sequence: null,
    usage: {
      input_tokens: u.prompt_tokens || 0,
      output_tokens: u.completion_tokens || 0
    }
  };
}

/** Gemini generateContent response -> Anthropic message (for /v1/messages IDEs). */
function geminiToAnthropicResponse(gj, model) {
  const oai = geminiToOpenAiResponse(gj, model);
  return openAiToAnthropicResponse(oai, model);
}

/* ------------------------------------------------------------------ */
/* Aggregated translation + stream synthesis                           */
/* ------------------------------------------------------------------ */

/**
 * Does the upstream reply need a protocol translation for this (style, path)?
 *   openai style + /v1/chat/completions  -> native, no translation
 *   anthropic style + /v1/messages       -> native, no translation
 *   anything else                        -> transliterate
 */
function needsTranslation(style, incomingPath) {
  const nativeOpenAi = style === 'openai' && incomingPath === CHAT_PATH;
  const nativeAnthropic = style === 'anthropic' && incomingPath === MESSAGES_PATH;
  return !(nativeOpenAi || nativeAnthropic);
}

/**
 * Translate an upstream JSON response into the incoming protocol.
 * Call only when needsTranslation() is true.
 */
function translateUpstream(json, { style, incomingPath, model }) {
  const toAnthropic = incomingPath === MESSAGES_PATH;
  if (style === 'gemini') {
    return toAnthropic ? geminiToAnthropicResponse(json, model) : geminiToOpenAiResponse(json, model);
  }
  if (style === 'anthropic') {
    return anthropicToOpenAiResponse(json, model); // to OpenAI clients
  }
  // style === 'openai' -> to Anthropic clients (Claude Code on DeepSeek/Groq/OR)
  return openAiToAnthropicResponse(json, model);
}

/**
 * Build the SSE body (string) announcing a fully materialized result as
 * stream chunks, in the incoming protocol. Used when an IDE asked
 * stream:true but the upstream path we took was non-streaming (translated).
 */
function makeStreamBody(incomingPath, resultObj) {
  return incomingPath === MESSAGES_PATH
    ? anthropicStreamFromMessage(resultObj)
    : openAiStreamFromCompletion(resultObj);
}

/** Render an OpenAI chat.completion as an OpenAI-compatible SSE body. */
function openAiStreamFromCompletion(completion) {
  const c = completion || {};
  const base = {
    id: c.id || `chatcmpl-${Date.now().toString(36)}`,
    object: 'chat.completion.chunk',
    created: c.created || Math.floor(Date.now() / 1000),
    model: c.model || ''
  };
  const choice = (Array.isArray(c.choices) && c.choices[0]) || {};
  const msg = choice.message || {};
  const finish = choice.finish_reason || 'stop';
  const parts = [
    { delta: { role: 'assistant', content: '' }, finish_reason: null },
    { delta: { content: contentToText(msg.content) }, finish_reason: null },
    { delta: {}, finish_reason: finish }
  ];
  let out = '';
  for (const p of parts) {
    out += `data: ${JSON.stringify({ ...base, choices: [{ index: 0, ...p }] })}\n\n`;
  }
  out += 'data: [DONE]\n\n';
  return out;
}

/** Render an Anthropic message as an Anthropic-compatible SSE body. */
function anthropicStreamFromMessage(message) {
  const m = message || {};
  const usage = m.usage || {};
  const lines = [];
  const push = (event, data) => {
    lines.push(`event: ${event}\ndata: ${JSON.stringify(data)}\n\n`);
  };
  push('message_start', {
    type: 'message_start',
    message: {
      id: m.id || `msg_${Date.now().toString(36)}`,
      type: 'message',
      role: 'assistant',
      model: m.model || '',
      content: [],
      stop_reason: null,
      usage: { input_tokens: usage.input_tokens || 0, output_tokens: 0 }
    }
  });
  push('content_block_start', { type: 'content_block_start', index: 0, content_block: { type: 'text', text: '' } });
  const text = contentToText(m.content);
  if (text) {
    push('content_block_delta', { type: 'content_block_delta', index: 0, delta: { type: 'text_delta', text } });
  }
  push('content_block_stop', { type: 'content_block_stop', index: 0 });
  push('message_delta', {
    type: 'message_delta',
    delta: { stop_reason: m.stop_reason || 'end_turn', stop_sequence: null },
    usage: { output_tokens: usage.output_tokens || 0 }
  });
  push('message_stop', { type: 'message_stop' });
  return lines.join('');
}

/* ------------------------------------------------------------------ */
/* Upstream request building                                           */
/* ------------------------------------------------------------------ */

/**
 * buildUpstreamRequest(provider, incomingPath, body, apiKey) -> {
 *   url, method:'POST', headers, bodyBuffer:Buffer, style, incomingPath, model
 * }
 *
 * Supports:
 *   /v1/chat/completions -> provider.style
 *     'openai'    : $baseUrl + /chat/completions, Bearer key, body passthrough
 *     'gemini'    : $baseUrl/models/$model:generateContent?key=..., transliterated body
 *     'anthropic' : $baseUrl + /v1/messages, x-api-key, transliterated body
 *   /v1/messages (Anthropic-style incoming)
 *     'anthropic' : passthrough with our key (Claude Code native upstream)
 *     'openai'    : transliteration to chat/completions
 *     'gemini'    : transliteration via Anthropic->OpenAI->Gemini chain
 */
function buildUpstreamRequest(provider, incomingPath, body, apiKey) {
  if (!provider || typeof provider !== 'object') throw new Error('buildUpstreamRequest: provider object required');
  if (!apiKey) throw new Error('buildUpstreamRequest: apiKey required');
  const style = String(provider.style || 'openai').toLowerCase();
  const src = body || {};
  const inPath = incomingPath === MESSAGES_PATH ? MESSAGES_PATH : CHAT_PATH;
  const upstreamModel = applyModelMap(provider, src.model || (Array.isArray(provider.models) ? provider.models[0] : null) || 'default');
  const headers = { 'content-type': 'application/json' };
  let url;
  let payload;

  if (inPath === CHAT_PATH) {
    if (style === 'openai') {
      ensureBaseUrl(provider, style);
      url = joinUrl(provider.baseUrl, '/chat/completions');
      payload = { ...src, model: upstreamModel };
      if (typeof payload.stream !== 'boolean') payload.stream = false;
      headers.authorization = `Bearer ${apiKey}`;
    } else if (style === 'gemini') {
      const base = provider.baseUrl || DEFAULT_GEMINI_BASE;
      url = joinUrl(base, `/models/${encodeURIComponent(upstreamModel)}`) + `:generateContent?key=${encodeURIComponent(apiKey)}`;
      payload = openAiToGemini({ ...src, model: upstreamModel });
    } else if (style === 'anthropic') {
      ensureBaseUrl(provider, style);
      url = joinUrl(provider.baseUrl, '/v1/messages');
      payload = openAiToAnthropic({ ...src, model: upstreamModel }, { defaultMaxTokens: provider.defaultMaxTokens });
      headers['x-api-key'] = apiKey;
      headers['anthropic-version'] = provider.anthropicVersion || DEFAULT_ANTHROPIC_VERSION;
    } else {
      throw new Error(`buildUpstreamRequest: unknown provider style "${style}"`);
    }
  } else { // incoming /v1/messages
    if (style === 'anthropic') {
      ensureBaseUrl(provider, style);
      url = joinUrl(provider.baseUrl, '/v1/messages');
      payload = { ...src, model: applyModelMap(provider, src.model || (Array.isArray(provider.models) ? provider.models[0] : '')) || upstreamModel };
      if (!payload.max_tokens) payload.max_tokens = provider.defaultMaxTokens || DEFAULT_ANTHROPIC_MAX_TOKENS;
      headers['x-api-key'] = apiKey;
      headers['anthropic-version'] = provider.anthropicVersion || DEFAULT_ANTHROPIC_VERSION;
    } else if (style === 'openai') {
      ensureBaseUrl(provider, style);
      url = joinUrl(provider.baseUrl, '/chat/completions');
      payload = anthropicToOpenAi(src);
      payload.model = upstreamModel;
      if (typeof payload.stream !== 'boolean') payload.stream = false;
      headers.authorization = `Bearer ${apiKey}`;
    } else if (style === 'gemini') {
      const base = provider.baseUrl || DEFAULT_GEMINI_BASE;
      url = joinUrl(base, `/models/${encodeURIComponent(upstreamModel)}`) + `:generateContent?key=${encodeURIComponent(apiKey)}`;
      payload = openAiToGemini({ ...anthropicToOpenAi(src), model: upstreamModel });
    } else {
      throw new Error(`buildUpstreamRequest: unknown provider style "${style}"`);
    }
  }

  // headersExtra: let users add/override anything (e.g. OpenRouter headers)
  for (const [hk, hv] of Object.entries(provider.headersExtra || {})) {
    const lower = String(hk).toLowerCase();
    for (const existing of Object.keys(headers)) {
      if (existing.toLowerCase() === lower) delete headers[existing];
    }
    headers[lower] = String(hv);
  }

  return {
    url,
    method: 'POST',
    headers,
    bodyBuffer: Buffer.from(JSON.stringify(payload), 'utf8'),
    style,
    incomingPath: inPath,
    model: upstreamModel
  };
}

function ensureBaseUrl(provider, style) {
  if (!provider.baseUrl) {
    throw new Error(`provider "${provider.name}" (style ${style}) needs a baseUrl`);
  }
}

function applyModelMap(provider, model) {
  const map = (provider && provider.modelMap) || {};
  return (model && map[model]) ? map[model] : (model || 'default');
}

/** Join baseUrl with a path suffix, tolerating user-pasted full URLs. */
function joinUrl(base, suffix) {
  const b = String(base || '').replace(/\/+$/, '');
  if (b.endsWith(suffix)) return b;
  return b + suffix;
}

/* ------------------------------------------------------------------ */
/* Usage extraction (tokens for analytics)                             */
/* ------------------------------------------------------------------ */

/**
 * extractUsage(json, style, incomingPath) -> { tokens_in, tokens_out } | null
 * Works for the JSON (non-SSE) responses of all three styles.
 */
function extractUsage(json, style, incomingPath) {
  if (!json || typeof json !== 'object') return null;
  const toAnthropic = incomingPath === MESSAGES_PATH;
  if (style === 'openai') {
    const u = json.usage || {};
    if (toAnthropic && u.input_tokens != null) {
      return { tokens_in: u.input_tokens || 0, tokens_out: u.output_tokens || 0 };
    }
    return {
      tokens_in: u.prompt_tokens || 0,
      tokens_out: u.completion_tokens || 0
    };
  }
  if (style === 'anthropic') {
    const u = json.usage || {};
    return { tokens_in: u.input_tokens || 0, tokens_out: u.output_tokens || 0 };
  }
  if (style === 'gemini') {
    const u = json.usageMetadata || {};
    return { tokens_in: u.promptTokenCount || 0, tokens_out: u.candidatesTokenCount || 0 };
  }
  return null;
}

/* ------------------------------------------------------------------ */
/* Small shared helpers                                                */
/* ------------------------------------------------------------------ */

function numOr(v, dflt) {
  return typeof v === 'number' && Number.isFinite(v) && v >= 0 ? v : dflt;
}

function isPlainObj(o) {
  return o !== null && typeof o === 'object' && !Array.isArray(o);
}

/** "sk-abcdef1234567890" -> "sk-a••••7890" (dashboard display). */
function maskKey(key) {
  const s = String(key || '');
  if (!s) return '••••';
  const head = s.slice(0, 4);
  const tail = s.slice(-4);
  if (s.length <= 8) return `${head}••••`;
  return `${head}••••${tail}`;
}

module.exports = {
  // constants
  DEFAULT_COOLDOWN_BASE_MS,
  DEFAULT_COOLDOWN_MAX_MS,
  DEFAULT_COOLDOWN_GROWTH,
  DEFAULT_GEMINI_BASE,
  DEFAULT_ANTHROPIC_BASE,
  CHAT_PATH,
  MESSAGES_PATH,
  RETRYABLE_STATUSES,
  // pure core
  classifyStatus,
  computeCooldownMs,
  chooseNextKey,
  createKeyState,
  createRouter,
  maskKey,
  // transliteration
  contentToText,
  openAiToGemini,
  geminiToOpenAiResponse,
  openAiToAnthropic,
  anthropicToOpenAi,
  anthropicToOpenAiResponse,
  openAiToAnthropicResponse,
  geminiToAnthropicResponse,
  needsTranslation,
  translateUpstream,
  makeStreamBody,
  openAiStreamFromCompletion,
  anthropicStreamFromMessage,
  // upstream building
  buildUpstreamRequest,
  extractUsage,
  joinUrl
};
