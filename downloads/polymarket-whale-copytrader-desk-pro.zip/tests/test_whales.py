"""Engine tests: profiling, copy simulation, ranking, alert rendering."""

from __future__ import annotations

import sys
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

import desk  # noqa: E402
import whales  # noqa: E402

NOW = 1_700_000_000 + int(10 * whales.DAY)


def bundle(n: int = 6, price: float = 0.5, size: float = 1000, closed: int = 1, win: bool = True):
    activity, ts = [], 1_700_000_000
    for i in range(n):
        activity.append({
            "type": "TRADE", "side": "BUY", "proxyWallet": "0xW",
            "size": size, "price": price, "usdcSize": size * price,
            "timestamp": ts, "conditionId": f"c{i}", "asset": f"a{i}",
            "title": f"m{i}", "outcome": "Yes", "transactionHash": f"0x{i}",
        })
        ts += 60
    positions = [{
        "asset": f"a{i}", "conditionId": f"c{i}", "size": size,
        "curPrice": 1.0 if win else 0.0,
        "cashPnl": 100.0 if win else -100.0,
        "currentValue": size, "redeemable": True,
    } for i in range(closed)]
    return activity, positions


def test_trade_usd_is_absolute():
    assert whales.trade_usd({"size": -10, "price": 2}) == 20
    assert whales.trade_usd({"size": "x"}) == 0


def test_parse_trades_drops_non_trades():
    rows = [{"side": "BUY", "proxyWallet": "0xA", "size": 1, "price": 1},
            {"side": "REDEEM", "proxyWallet": "0xA"}]
    assert len(whales.parse_trades(rows)) == 1
    assert whales.parse_trades(rows)[0].wallet == "0xa"


def test_profile_winrate_uses_closed_only():
    act, pos = bundle(closed=2, win=True)
    pos.append({"asset": "open", "curPrice": 0.4, "cashPnl": -50, "redeemable": False})
    p = whales.profile("0xw", act, pos, now=NOW)
    assert p.n_closed == 2
    assert p.winrate == 1.0


def test_profile_fresh_and_insider():
    act, pos = bundle(n=8, size=4000, closed=6)
    p = whales.profile("0xw", act, pos, now=NOW)
    assert p.fresh is True
    assert p.insider_flag is True
    act2, pos2 = bundle(n=8, size=4000, closed=2)
    assert whales.profile("0xw", act2, pos2, now=NOW).insider_flag is False
    act3, pos3 = bundle(n=2, size=4000, closed=6)
    assert whales.profile("0xw", act3, pos3, now=NOW).fresh is False


def test_profile_empty_is_safe():
    p = whales.profile("0xw", [], [], now=NOW)
    assert (p.n_trades, p.volume_usd, p.score, p.fresh) == (0, 0.0, p.score, False)


def test_score_bounded():
    act, pos = bundle(n=30, size=100_000, closed=30)
    p = whales.profile("0xw", act, pos, now=NOW)
    assert 0 <= p.score <= 100


def test_simulate_charges_slippage():
    act, pos = bundle(n=1, price=0.5, size=100, closed=1)
    pos[0]["curPrice"] = 0.6
    sim = whales.simulate_copy(act, pos, stake_usd=100, slippage_bps=100)
    assert sim["fills"][0]["entry"] == pytest.approx(0.505)
    assert sim["fills"][0]["pnl"] > 0


def test_simulate_resolution_marks_at_one():
    act, pos = bundle(n=1, price=0.4, size=100, closed=1)
    sim = whales.simulate_copy(act, pos, stake_usd=50, slippage_bps=0)
    assert sim["fills"][0]["mark"] == 1.0
    assert sim["roi_pct"] == pytest.approx(150.0)


def test_simulate_empty():
    sim = whales.simulate_copy([], [], stake_usd=100)
    assert sim["n_fills"] == 0 and sim["pnl_usd"] == 0.0


def test_rank_orders_by_score_then_volume():
    a = whales.WalletProfile("0xa", score=10, volume_usd=1)
    b = whales.WalletProfile("0xb", score=10, volume_usd=9)
    assert [p.address for p in whales.rank_wallets([a, b])] == ["0xb", "0xa"]


def test_render_alert_escapes_and_caps():
    profiles = [whales.WalletProfile(f"0x{i:040x}", score=50, n_trades=9, volume_usd=10_000,
                                     winrate=0.5, n_closed=9, age_days=9) for i in range(60)]
    text = whales.render_alert(profiles, limit=60)
    assert len(text) < 4096
    evil = whales.render_alert([whales.WalletProfile("0x<s>", score=1)])
    assert "<s>" not in evil and "&lt;s&gt;" in evil


def test_fixture_summary_reconciles():
    data = whales.summary(desk.load_fixture())
    assert data["counts"]["wallets"] == len(data["wallets"])
    t = data["totals"]
    assert t["buy_usd"] + t["sell_usd"] == pytest.approx(t["whale_usd"], abs=0.02)
