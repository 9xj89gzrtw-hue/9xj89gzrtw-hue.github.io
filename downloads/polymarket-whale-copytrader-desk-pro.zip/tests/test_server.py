"""HTTP tests against a real socket on a random port."""

from __future__ import annotations

import json
import sys
import tempfile
import threading
import urllib.error
import urllib.request
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

import server  # noqa: E402


@pytest.fixture(scope="module")
def httpd():
    tmp = tempfile.TemporaryDirectory()
    server.CONFIG_PATH = Path(tmp.name) / "config.json"
    server.reset_cache()
    srv = server.ThreadingHTTPServer(("127.0.0.1", 0), server.Handler)
    port = srv.server_address[1]
    thread = threading.Thread(target=srv.serve_forever, daemon=True)
    thread.start()
    yield f"http://127.0.0.1:{port}"
    srv.shutdown()
    srv.server_close()
    tmp.cleanup()


def get(base, path):
    with urllib.request.urlopen(base + path, timeout=15) as r:
        return r.status, r.read()


def post(base, path, payload):
    req = urllib.request.Request(base + path, data=json.dumps(payload).encode(),
                                 headers={"Content-Type": "application/json"}, method="POST")
    with urllib.request.urlopen(req, timeout=15) as r:
        return r.status, r.read()


def test_index_serves_terminal(httpd):
    status, body = get(httpd, "/")
    assert status == 200 and b"Whale Desk" in body


def test_health(httpd):
    _, body = get(httpd, "/api/health")
    data = json.loads(body)
    assert data["ok"] is True and data["fixture"] is True


def test_scan_is_fixture_backed(httpd):
    _, body = get(httpd, "/api/scan")
    data = json.loads(body)
    assert data["source"] == "fixture"
    assert data["counts"]["wallets"] == len(data["wallets"])


def test_wallets_are_sorted(httpd):
    _, body = get(httpd, "/api/wallets")
    scores = [w["score"] for w in json.loads(body)["wallets"]]
    assert scores == sorted(scores, reverse=True)


def test_feed_is_whale_only(httpd):
    _, body = get(httpd, "/api/feed")
    usd = [t["usd"] for t in json.loads(body)["feed"]]
    assert min(usd) >= 2000 and usd == sorted(usd, reverse=True)


def test_copy_requires_wallet(httpd):
    with pytest.raises(urllib.error.HTTPError) as exc:
        get(httpd, "/api/copy")
    assert exc.value.code == 400


def test_copy_unknown_wallet_is_404(httpd):
    with pytest.raises(urllib.error.HTTPError) as exc:
        get(httpd, "/api/copy?wallet=0xdead")
    assert exc.value.code == 404


def test_copy_replays_known_wallet(httpd):
    _, body = get(httpd, "/api/wallets")
    wallet = json.loads(body)["wallets"][0]["address"]
    _, raw = get(httpd, f"/api/copy?wallet={wallet}&stake=100&max_trades=5")
    sim = json.loads(raw)
    assert sim["stake_usd"] == 100
    assert sim["n_fills"] <= 5


def test_csv_header(httpd):
    _, body = get(httpd, "/api/export.csv")
    assert body.decode().splitlines()[0].startswith("address,name,score")


def test_config_roundtrip_and_redaction(httpd):
    post(httpd, "/api/config", {"stake_usd": 321, "telegram_token": "1:x"})
    _, body = get(httpd, "/api/config")
    data = json.loads(body)
    assert data["stake_usd"] == 321
    assert data["telegram_token"] == "***"


def test_unknown_config_key_ignored(httpd):
    post(httpd, "/api/config", {"nope": 1})
    _, body = get(httpd, "/api/config")
    assert "nope" not in json.loads(body)


def test_telegram_preview(httpd):
    _, body = post(httpd, "/api/telegram", {"limit": 2})
    data = json.loads(body)
    assert data["chars"] == len(data["text"])
    assert "not financial advice" in data["text"]


def test_unknown_route_404(httpd):
    with pytest.raises(urllib.error.HTTPError) as exc:
        get(httpd, "/api/nope")
    assert exc.value.code == 404
