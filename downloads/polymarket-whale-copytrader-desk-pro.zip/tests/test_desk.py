"""Snapshot assembly tests: ranking, partial failure, market normalisation."""

from __future__ import annotations

import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

import desk  # noqa: E402
import poly  # noqa: E402


def test_top_wallets_ranks_by_notional():
    rows = [{"proxyWallet": "0xa", "size": 1, "price": 100},
            {"proxyWallet": "0xb", "size": 1, "price": 500},
            {"proxyWallet": "0xa", "size": 1, "price": 100}]
    assert desk.top_wallets(rows, 2) == ["0xb", "0xa"]


def test_top_wallets_is_deterministic_on_ties():
    rows = [{"proxyWallet": "0xb", "size": 1, "price": 1},
            {"proxyWallet": "0xa", "size": 1, "price": 1}]
    assert desk.top_wallets(rows, 2) == desk.top_wallets(rows, 2) == ["0xa", "0xb"]


def test_top_wallets_skips_blank_addresses():
    rows = [{"proxyWallet": "", "size": 1, "price": 100}, {"proxyWallet": "0xa", "size": 1, "price": 1}]
    assert desk.top_wallets(rows) == ["0xa"]


class FakeClient:
    def __init__(self, fail: str | None = None):
        self.fail = fail

    def trades(self, limit=250, min_cash=None):
        if self.fail == "trades":
            raise poly.PolyError("503")
        return [
            {"proxyWallet": "0xaaa", "side": "BUY", "size": 3000, "price": 1, "timestamp": 1,
             "title": "a", "conditionId": "c1"},
            {"proxyWallet": "0xbbb", "side": "SELL", "size": 4000, "price": 1, "timestamp": 2,
             "title": "b", "conditionId": "c2"},
        ]

    def activity(self, wallet, limit=500):
        if wallet == "0xaaa":
            raise poly.PolyError("429")
        return [{"type": "TRADE", "side": "BUY", "proxyWallet": wallet, "size": 10, "price": 1,
                 "usdcSize": 10, "timestamp": 2, "conditionId": "c2", "asset": "z"}]

    def positions(self, wallet, limit=200):
        return []

    def closed_positions(self, wallet, limit=50):
        return []

    def value(self, wallet):
        return 2.0

    def markets(self, limit=12):
        if self.fail == "markets":
            raise poly.PolyError("503")
        return [{"question": "q", "conditionId": "c2", "outcomePrices": '["0.5","0.5"]'}]

    def holders(self, condition_id, limit=10):
        return [{"token": "t", "holders": [{"proxyWallet": "0xbbb", "amount": 100}]}]


def test_collect_keeps_going_after_one_wallet_fails():
    data = desk.collect(FakeClient(), wallets=4)
    assert list(data["profiles"]) == ["0xbbb"]
    assert any("429" in e for e in data["errors"])


def test_collect_falls_back_to_holders_when_trades_die():
    data = desk.collect(FakeClient("trades"))
    assert data["trades"] == []
    assert list(data["profiles"]) == ["0xbbb"]
    assert any("trades" in e for e in data["errors"])


def test_collect_survives_dead_markets():
    data = desk.collect(FakeClient("markets"), wallets=1)
    assert data["markets"] == []
    assert any("markets" in e for e in data["errors"])


def test_market_view_parses_json_strings():
    view = desk.market_view([{
        "question": "Q?", "outcomePrices": '["0.62","0.38"]', "outcomes": '["Yes","No"]',
        "volume24hr": "1000", "liquidity": "50", "endDate": "2026-11-01", "spread": "0.01",
        "oneDayPriceChange": "0.04",
    }])
    assert view[0]["yes"] == 0.62
    assert view[0]["outcomes"] == ["Yes", "No"]


def test_market_view_tolerates_junk():
    view = desk.market_view([{"question": None, "outcomePrices": "nope", "volume24hr": "x"}])
    assert view[0]["yes"] == 0.0 and view[0]["question"] == ""


def test_fixture_has_expected_shape():
    payload = desk.load_fixture()
    assert len(payload["trades"]) >= 100
    assert len(payload["profiles"]) >= 6
    assert payload["captured_at"]
