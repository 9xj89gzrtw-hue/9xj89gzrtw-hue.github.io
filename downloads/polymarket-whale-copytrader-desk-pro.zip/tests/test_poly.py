"""Transport tests: JSON parsing, caching, throttling, honest failures."""

from __future__ import annotations

import io
import sys
import time
import urllib.error
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

import poly  # noqa: E402


class Resp:
    def __init__(self, body: bytes):
        self.body = body

    def read(self):
        return self.body

    def __enter__(self):
        return self

    def __exit__(self, *exc):
        return False


@pytest.fixture
def client():
    c = poly.Client(ttl=0)
    c.MIN_GAP = 0
    return c


def patch(monkeypatch, fn):
    monkeypatch.setattr(poly.urllib.request, "urlopen", fn)


def test_parses_json(client, monkeypatch):
    patch(monkeypatch, lambda req, timeout=0: Resp(b'[{"a": 1}]'))
    assert client.trades() == [{"a": 1}]


def test_cache_avoids_second_request(client, monkeypatch):
    calls = []
    patch(monkeypatch, lambda req, timeout=0: (calls.append(1), Resp(b"[]"))[1])
    client.ttl = 60
    client.trades(limit=5)
    client.trades(limit=5)
    assert len(calls) == 1


def test_different_params_bypass_cache(client, monkeypatch):
    calls = []
    patch(monkeypatch, lambda req, timeout=0: (calls.append(1), Resp(b"[]"))[1])
    client.ttl = 60
    client.trades(limit=5)
    client.trades(limit=6)
    assert len(calls) == 2


def test_429_raises(client, monkeypatch):
    def boom(req, timeout=0):
        raise urllib.error.HTTPError(req.full_url, 429, "slow", {}, io.BytesIO(b"no"))

    patch(monkeypatch, boom)
    with pytest.raises(poly.PolyError, match="429"):
        client.trades()
    assert client.errors == 1


def test_network_error_raises(client, monkeypatch):
    def boom(req, timeout=0):
        raise urllib.error.URLError("down")

    patch(monkeypatch, boom)
    with pytest.raises(poly.PolyError):
        client.markets()


def test_wrong_shape_raises(client, monkeypatch):
    patch(monkeypatch, lambda req, timeout=0: Resp(b'{"a": 1}'))
    with pytest.raises(poly.PolyError):
        client.trades()


def test_min_cash_adds_filter(client, monkeypatch):
    seen = []
    patch(monkeypatch, lambda req, timeout=0: (seen.append(req.full_url), Resp(b"[]"))[1])
    client.trades(min_cash=2500)
    assert "filterType=CASH" in seen[0]
    assert "filterAmount=2500" in seen[0]


def test_limit_clamped(client, monkeypatch):
    seen = []
    patch(monkeypatch, lambda req, timeout=0: (seen.append(req.full_url), Resp(b"[]"))[1])
    client.trades(limit=10_000)
    assert "limit=500" in seen[0]


def test_throttle_spaces_requests(client, monkeypatch):
    client.MIN_GAP = 0.1
    stamps = []
    patch(monkeypatch, lambda req, timeout=0: (stamps.append(time.monotonic()), Resp(b"[]"))[1])
    client.trades(limit=1)
    client.trades(limit=2)
    assert stamps[1] - stamps[0] >= 0.08


def test_value_tolerates_empty(client, monkeypatch):
    patch(monkeypatch, lambda req, timeout=0: Resp(b"[]"))
    assert client.value("0xabc") == 0.0
