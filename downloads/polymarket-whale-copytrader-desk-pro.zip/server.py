"""Local HTTP server for the whale desk.

stdlib only: `ThreadingHTTPServer` plus a small router. Binds to 127.0.0.1.
There is no key, no wallet and no order path in this product, but it still does
not belong on a public interface: a copy-trade size is a position, and a
position is nobody else's business.

Routes
------
GET  /                     the terminal (terminal.html)
GET  /api/health           liveness, version, whether live mode is enabled
GET  /api/config           effective config
POST /api/config           merge a partial config
GET  /api/scan             snapshot; `?live=1` hits the public APIs
GET  /api/wallets          ranked wallet profiles only
GET  /api/feed             whale trades only
GET  /api/markets          market metadata behind the snapshot
GET  /api/copy             replay one wallet's buys at your stake
GET  /api/export.csv       wallet table as CSV
POST /api/telegram         render the alert text
"""

from __future__ import annotations

import csv
import io
import json
import os
import sys
import threading
import time
from datetime import datetime, timezone
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from typing import Any
from urllib.parse import parse_qs, urlparse

import desk
import poly
import whales

VERSION = "1.0.0"
ROOT = Path(__file__).resolve().parent
CONFIG_PATH = Path(os.environ.get("WHALE_CONFIG", ROOT / "config.json"))

_lock = threading.Lock()
_cache: dict[str, Any] = {"summary": None, "payload": None, "at": 0.0, "live": False}
CACHE_TTL = 45.0

SERVER_KEYS = {"wallets", "trade_limit", "min_cash", "market_limit", "holder_markets", "fixture"}
SECRET_KEYS = {"telegram_token", "telegram_chat_id"}
WRITABLE = set(whales.DEFAULT_CONFIG) | SERVER_KEYS | SECRET_KEYS
SECRET_HINTS = ("token", "secret", "key", "password", "private")


def load_config() -> dict:
    merged = dict(whales.DEFAULT_CONFIG)
    merged.update({
        "wallets": 8,
        "trade_limit": 250,
        "min_cash": None,
        "market_limit": 12,
        "holder_markets": 4,
        "fixture": str(desk.FIXTURE),
        "telegram_token": "",
        "telegram_chat_id": "",
    })
    if CONFIG_PATH.exists():
        try:
            merged.update(json.loads(CONFIG_PATH.read_text()))
        except (OSError, ValueError):
            pass
    return merged


def save_config(patch: dict) -> dict:
    cfg = load_config()
    cfg.update({k: v for k, v in patch.items() if k in WRITABLE})
    CONFIG_PATH.write_text(json.dumps(cfg, indent=2) + "\n")
    try:
        os.chmod(CONFIG_PATH, 0o600)
    except OSError:
        pass
    reset_cache()
    return cfg


def redact(cfg: dict) -> dict:
    out = json.loads(json.dumps(cfg))
    for key in list(out):
        if any(word in key.lower() for word in SECRET_HINTS):
            out[key] = "***" if out[key] else ""
    return out


def reset_cache() -> None:
    with _lock:
        _cache.update(summary=None, payload=None, at=0.0)


def build_snapshot(live: bool = False, force: bool = False) -> dict:
    """Load fixture or live snapshot, then score it. Cached for CACHE_TTL."""
    now = time.time()
    with _lock:
        if not force and _cache["payload"] and now - _cache["at"] < CACHE_TTL and _cache["live"] == live:
            return _cache["summary"]

    cfg = load_config()
    source = "fixture"
    errors: list[str] = []

    if live:
        payload = desk.collect(
            poly.Client(),
            wallets=int(cfg.get("wallets") or 8),
            trade_limit=int(cfg.get("trade_limit") or 250),
            min_cash=int(cfg["min_cash"]) if cfg.get("min_cash") else None,
            market_limit=int(cfg.get("market_limit") or 12),
            holder_markets=int(cfg.get("holder_markets") or 4),
        )
        source = "live"
        errors = payload.get("errors") or []
        if not payload.get("trades"):
            payload = desk.load_fixture(cfg.get("fixture") or desk.FIXTURE)
            source = "fixture (live failed)"
    else:
        payload = desk.load_fixture(cfg.get("fixture") or desk.FIXTURE)

    data = whales.summary(payload, cfg, source=source, errors=errors)
    data["at"] = datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
    data["markets"] = desk.market_view(payload.get("markets") or [], int(cfg.get("market_limit") or 12))
    data["config"] = redact(cfg)
    data["live"] = live

    with _lock:
        _cache.update(summary=data, payload=payload, at=now, live=live)
    return data


def current_payload(live: bool = False) -> dict:
    build_snapshot(live=live)
    with _lock:
        return _cache["payload"] or {}


def copy_for(wallet: str, live: bool = False, stake_usd: float | None = None,
             max_trades: int | None = None, slippage_bps: float | None = None) -> dict:
    payload = current_payload(live=live)
    key = wallet.lower()
    bundle = (payload.get("profiles") or {}).get(key)
    if bundle is None:
        # The wallet may be in the fixture under a mixed-case key.
        for candidate, value in (payload.get("profiles") or {}).items():
            if candidate.lower() == key:
                bundle = value
                break
    if bundle is None:
        raise KeyError(wallet)
    cfg = load_config()
    result = whales.simulate_copy(
        bundle.get("activity") or [], bundle.get("positions") or [], cfg,
        stake_usd=stake_usd, max_trades=max_trades, slippage_bps=slippage_bps,
    )
    result["source"] = payload.get("source", "fixture")
    result["captured_at"] = payload.get("captured_at")
    return result


def to_csv(data: dict) -> str:
    buf = io.StringIO()
    fields = [
        "address", "name", "score", "age_days", "n_trades", "n_closed", "winrate",
        "volume_usd", "roi_pct", "portfolio_usd", "insider_flag", "fresh",
    ]
    writer = csv.DictWriter(buf, fieldnames=fields, extrasaction="ignore")
    writer.writeheader()
    for row in data.get("wallets", []):
        writer.writerow({k: row.get(k) for k in fields})
    return buf.getvalue()


def _as_profile(row: dict) -> whales.WalletProfile:
    fields = set(whales.WalletProfile.__dataclass_fields__)
    return whales.WalletProfile(**{k: v for k, v in row.items() if k in fields})


def _as_trade(row: dict) -> whales.Trade:
    fields = set(whales.Trade.__dataclass_fields__)
    return whales.Trade(**{k: v for k, v in row.items() if k in fields})


class Handler(BaseHTTPRequestHandler):
    server_version = f"WhaleDesk/{VERSION}"
    protocol_version = "HTTP/1.1"

    def _send(self, status: int, body: bytes, content_type: str) -> None:
        self.send_response(status)
        self.send_header("Content-Type", content_type)
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.send_header("X-Content-Type-Options", "nosniff")
        self.send_header("Referrer-Policy", "no-referrer")
        self.end_headers()
        if self.command != "HEAD":
            self.wfile.write(body)

    def _json(self, payload: Any, status: int = 200) -> None:
        self._send(status, json.dumps(payload, indent=2).encode(), "application/json; charset=utf-8")

    def _html(self, text: str) -> None:
        self._send(200, text.encode(), "text/html; charset=utf-8")

    def _read_json(self) -> dict:
        length = int(self.headers.get("Content-Length") or 0)
        if length <= 0:
            return {}
        if length > 1_000_000:
            raise ValueError("body too large")
        return json.loads(self.rfile.read(length).decode("utf-8") or "{}")

    def log_message(self, fmt: str, *args: Any) -> None:
        if args and "/api/" in str(args[0]):
            sys.stderr.write("[%s] %s\n" % (time.strftime("%H:%M:%S"), fmt % args))

    # -- routes -----------------------------------------------------------
    def do_HEAD(self) -> None:
        self.do_GET()

    def do_GET(self) -> None:
        parsed = urlparse(self.path)
        path = parsed.path
        query = parse_qs(parsed.query)
        live = query.get("live", ["0"])[0] in ("1", "true", "yes")

        try:
            if path in ("/", "/index.html", "/terminal"):
                page = ROOT / "terminal.html"
                if not page.exists():
                    return self._html("<h1>terminal.html missing</h1>")
                return self._html(page.read_text())

            if path == "/api/health":
                return self._json({
                    "ok": True,
                    "version": VERSION,
                    "python": sys.version.split()[0],
                    "liveEnabled": os.environ.get("POLY_LIVE", "0") == "1",
                    "fixture": desk.FIXTURE.exists(),
                    "cacheAgeSec": round(time.time() - _cache["at"], 1) if _cache["at"] else None,
                })

            if path == "/api/config":
                return self._json(redact(load_config()))

            if path == "/api/scan":
                force = query.get("force", ["0"])[0] in ("1", "true", "yes")
                return self._json(build_snapshot(live=live, force=force))

            if path == "/api/wallets":
                data = build_snapshot(live=live)
                return self._json({
                    "source": data["source"],
                    "at": data["at"],
                    "wallets": data["wallets"],
                    "totals": data["totals"],
                    "errors": data["errors"],
                })

            if path == "/api/feed":
                data = build_snapshot(live=live)
                return self._json({
                    "source": data["source"],
                    "at": data["at"],
                    "feed": data["feed"],
                    "counts": data["counts"],
                })

            if path == "/api/markets":
                data = build_snapshot(live=live)
                return self._json({"source": data["source"], "markets": data["markets"]})

            if path == "/api/copy":
                wallet = (query.get("wallet", [""])[0] or "").strip()
                if not wallet:
                    return self._json({"error": "wallet is required"}, 400)
                stake = query.get("stake", [None])[0]
                limit = query.get("max_trades", [None])[0]
                slip = query.get("slippage", [None])[0]
                try:
                    result = copy_for(
                        wallet, live=live,
                        stake_usd=float(stake) if stake else None,
                        max_trades=int(limit) if limit else None,
                        slippage_bps=float(slip) if slip else None,
                    )
                except KeyError:
                    return self._json({"error": "wallet not in this snapshot", "wallet": wallet}, 404)
                return self._json(result)

            if path == "/api/export.csv":
                data = build_snapshot(live=live)
                body = to_csv(data).encode()
                self.send_response(200)
                self.send_header("Content-Type", "text/csv; charset=utf-8")
                self.send_header("Content-Disposition", 'attachment; filename="whales.csv"')
                self.send_header("Content-Length", str(len(body)))
                self.end_headers()
                return self.wfile.write(body)

            return self._json({"error": "not found", "path": path}, 404)
        except Exception as exc:  # noqa: BLE001 - the terminal must see the reason
            return self._json({"error": f"{type(exc).__name__}: {exc}"}, 500)

    def do_POST(self) -> None:
        path = urlparse(self.path).path
        try:
            body = self._read_json()
        except ValueError as exc:
            return self._json({"error": str(exc)}, 400)

        try:
            if path == "/api/config":
                return self._json(redact(save_config(body)))
            if path == "/api/telegram":
                data = build_snapshot(live=bool(body.get("live")))
                profiles = [_as_profile(r) for r in data["wallets"]]
                trades = [_as_trade(r) for r in data["feed"][:3]]
                text = whales.render_alert(
                    profiles, trades, limit=int(body.get("limit") or 5),
                    bot_name=body.get("bot_name", "Whale Desk"),
                )
                return self._json({"text": text, "chars": len(text)})
            return self._json({"error": "not found", "path": path}, 404)
        except Exception as exc:
            return self._json({"error": f"{type(exc).__name__}: {exc}"}, 500)


def serve(host: str = "127.0.0.1", port: int = 8791, live: bool = False) -> None:
    if live:
        os.environ["POLY_LIVE"] = "1"
        build_snapshot(live=True)
    httpd = ThreadingHTTPServer((host, port), Handler)
    httpd.daemon_threads = True
    print(f"polymarket-whale-copytrader-desk-pro {VERSION}")
    print(f"  http://{host}:{port}/")
    print(f"  live data: {'on' if live else 'off (fixture)'}")
    print("  Ctrl-C to stop")
    try:
        httpd.serve_forever()
    except KeyboardInterrupt:
        print("\nstopped")
    finally:
        httpd.server_close()


def main(argv: list[str] | None = None) -> int:
    import argparse

    parser = argparse.ArgumentParser(description="polymarket whale desk local server")
    parser.add_argument("--host", default="127.0.0.1")
    parser.add_argument("--port", type=int, default=8791)
    parser.add_argument("--live", action="store_true", help="fetch a fresh snapshot on startup")
    args = parser.parse_args(argv)
    serve(args.host, args.port, args.live)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
