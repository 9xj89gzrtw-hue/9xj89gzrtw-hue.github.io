"""Polymarket public clients. No key, no wallet, no signature.

Three hosts, all public:

* `data-api.polymarket.com` — trades, per-wallet activity, positions, portfolio value
* `gamma-api.polymarket.com` — market metadata (question, volume, liquidity, end date)
* `clob.polymarket.com`          — order books and server time

Two things this module takes seriously:

1. **Rate limits are real.** The public data API answers 429 when you fan out, so
   every request goes through one process-wide throttle (`MIN_GAP`, default
   0.35 s) and a small TTL cache. A whale scan of eight wallets costs eight
   requests, spaced, not eight at once.
2. **A failed call is not a zero.** Every method raises `PolyError` instead of
   returning an empty list, so the desk can say "the API refused" rather than
   showing a wallet with no trades.
"""

from __future__ import annotations

import json
import threading
import time
import urllib.error
import urllib.parse
import urllib.request
from dataclasses import dataclass
from typing import Any

UA = "polymarket-whale-desk/1.0 (+local analysis tool)"
DATA = "https://data-api.polymarket.com"
GAMMA = "https://gamma-api.polymarket.com"
CLOB = "https://clob.polymarket.com"


class PolyError(RuntimeError):
    """The API refused or was unreachable. Never silently swallowed."""


@dataclass
class Cached:
    at: float
    value: Any


class Client:
    MIN_GAP = 0.35          # seconds between requests, process-wide
    TTL = 30.0              # seconds a response stays fresh

    def __init__(self, timeout: float = 20.0, ttl: float | None = None):
        self.timeout = timeout
        self.ttl = self.TTL if ttl is None else ttl
        self._lock = threading.Lock()
        self._cache: dict[str, Cached] = {}
        self._last = 0.0
        self.requests = 0
        self.errors = 0

    # -- transport --------------------------------------------------------
    def _throttle(self) -> None:
        with self._lock:
            wait = self.MIN_GAP - (time.monotonic() - self._last)
            if wait > 0:
                time.sleep(wait)
            self._last = time.monotonic()

    def get(self, url: str, params: dict[str, Any] | None = None, ttl: float | None = None) -> Any:
        if params:
            clean = {k: v for k, v in params.items() if v is not None}
            url = f"{url}?{urllib.parse.urlencode(clean)}"
        ttl = self.ttl if ttl is None else ttl
        hit = self._cache.get(url)
        if hit and time.monotonic() - hit.at < ttl:
            return hit.value

        self._throttle()
        req = urllib.request.Request(url, headers={"user-agent": UA, "accept": "application/json"})
        self.requests += 1
        try:
            with urllib.request.urlopen(req, timeout=self.timeout) as resp:
                payload = json.loads(resp.read())
        except urllib.error.HTTPError as exc:
            self.errors += 1
            body = exc.read().decode("utf-8", "replace")[:200]
            if exc.code == 429:
                raise PolyError(f"429 rate limited on {url}") from exc
            raise PolyError(f"HTTP {exc.code} on {url}: {body}") from exc
        except (urllib.error.URLError, TimeoutError, OSError, json.JSONDecodeError) as exc:
            self.errors += 1
            raise PolyError(f"{type(exc).__name__} on {url}: {exc}") from exc

        self._cache[url] = Cached(time.monotonic(), payload)
        return payload

    # -- data api ---------------------------------------------------------
    def trades(self, limit: int = 100, min_cash: int | None = None) -> list[dict]:
        params: dict[str, Any] = {"limit": max(1, min(500, limit))}
        if min_cash:
            params.update({"filterType": "CASH", "filterAmount": int(min_cash)})
        rows = self.get(f"{DATA}/trades", params)
        if not isinstance(rows, list):
            raise PolyError("trades: expected a list")
        return rows

    def activity(self, wallet: str, limit: int = 100, oldest_first: bool = False) -> list[dict]:
        rows = self.get(f"{DATA}/activity", {
            "user": wallet, "limit": max(1, min(500, limit)),
            "sortBy": "TIMESTAMP", "sortDirection": "ASC" if oldest_first else "DESC",
        })
        if not isinstance(rows, list):
            raise PolyError("activity: expected a list")
        return rows

    def positions(self, wallet: str, limit: int = 100) -> list[dict]:
        rows = self.get(f"{DATA}/positions", {
            "user": wallet, "limit": max(1, min(500, limit)), "sortBy": "CASHPNL",
        })
        if not isinstance(rows, list):
            raise PolyError("positions: expected a list")
        return rows

    def closed_positions(self, wallet: str, limit: int = 50) -> list[dict]:
        """Recently closed positions with `realizedPnl`.

        This is the honest source for a win rate. `/positions` only shows what is
        still held, so a redeemed winner disappears while a worthless loser
        lingers at `curPrice: 0` — which biases a naive win rate downwards.

        The endpoint silently caps at 50 rows and sorts by realized PnL unless
        told otherwise; the default sort returns the *most profitable* 50, which
        would turn every wallet into a 100% winner. We ask for the most recent
        50 instead, and say so in the README.
        """
        rows = self.get(f"{DATA}/closed-positions", {
            "user": wallet, "limit": max(1, min(50, limit)),
            "sortBy": "TIMESTAMP", "sortDirection": "DESC",
        })
        if not isinstance(rows, list):
            raise PolyError("closed-positions: expected a list")
        return rows

    def value(self, wallet: str) -> float:
        rows = self.get(f"{DATA}/value", {"user": wallet})
        if isinstance(rows, list) and rows:
            return float(rows[0].get("value") or 0.0)
        return 0.0

    def holders(self, condition_id: str, limit: int = 10) -> list[dict]:
        rows = self.get(f"{DATA}/holders", {"market": condition_id, "limit": limit})
        if isinstance(rows, list):
            return rows
        return []

    # -- gamma / clob -----------------------------------------------------
    def markets(self, limit: int = 24, order: str = "volume24hr") -> list[dict]:
        rows = self.get(f"{GAMMA}/markets", {
            "limit": limit, "closed": "false", "order": order, "ascending": "false",
        }, ttl=self.ttl * 2)
        if not isinstance(rows, list):
            raise PolyError("markets: expected a list")
        return rows

    def market(self, condition_id: str) -> dict | None:
        rows = self.get(f"{GAMMA}/markets", {"condition_ids": condition_id}, ttl=120)
        if isinstance(rows, list) and rows:
            return rows[0]
        return None

    def book(self, token_id: str) -> dict:
        payload = self.get(f"{CLOB}/book", {"token_id": token_id}, ttl=5)
        if not isinstance(payload, dict):
            raise PolyError("book: expected an object")
        return payload

    def server_time(self) -> int:
        self._throttle()
        req = urllib.request.Request(f"{CLOB}/time", headers={"user-agent": UA})
        try:
            with urllib.request.urlopen(req, timeout=self.timeout) as resp:
                return int(resp.read().decode().strip())
        except Exception as exc:  # noqa: BLE001
            raise PolyError(f"clob time: {exc}") from exc
