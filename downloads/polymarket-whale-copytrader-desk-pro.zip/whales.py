"""Whale analytics: profile a wallet, score it, and simulate copying it.

Everything here is a pure function over the JSON that `poly.py` returns. That
keeps the arithmetic testable without the network, and it means the desk can run
against a captured snapshot byte-for-byte the same way it runs live.

The one opinionated thing: `copy_score` is multiplicative on purpose. A wallet
with a 90% win rate over three trades scores *low*, because three trades is not a
record. A fresh wallet with twenty closed positions and a real edge scores high.
"""

from __future__ import annotations

import json
import math
import statistics
from dataclasses import dataclass, asdict, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Iterable

DEFAULT_CONFIG: dict = {
    # A trade is "whale" at or above this notional, in USDC.
    "whale_usd": 2000.0,
    # Copy simulation assumptions.
    "stake_usd": 250.0,
    "max_trades": 40,
    "slippage_bps": 120,
    # A wallet younger than this is "fresh" — the band where insider edges live.
    "fresh_days": 45,
    # Minimum closed positions before a win rate is allowed to mean anything.
    "min_closed": 5,
    # Context weights. Edge is a *gate*, not a term: no edge means no score.
    "w_fresh": 0.20,
    "w_size": 0.20,
    "w_consistency": 0.20,
}

DAY = 86_400.0


def utc(ts: float | int | None) -> str:
    if not ts:
        return ""
    return datetime.fromtimestamp(float(ts), tz=timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


def clamp(x: float, lo: float = 0.0, hi: float = 1.0) -> float:
    return max(lo, min(hi, x))


# --- models ----------------------------------------------------------------

@dataclass
class Trade:
    wallet: str
    side: str
    asset: str
    condition_id: str
    size: float
    price: float
    usd: float
    ts: int
    title: str
    outcome: str
    slug: str = ""
    tx: str = ""
    name: str = ""
    pseudonym: str = ""

    @property
    def key(self) -> str:
        return self.tx or f"{self.wallet}:{self.ts}"


@dataclass
class WalletProfile:
    address: str
    name: str = ""
    pseudonym: str = ""
    age_days: float = 0.0
    first_ts: int = 0
    last_ts: int = 0
    n_activity: int = 0
    n_trades: int = 0
    volume_usd: float = 0.0
    median_trade_usd: float = 0.0
    max_trade_usd: float = 0.0
    markets: int = 0
    buy_ratio: float = 0.0
    n_open: int = 0
    open_value: float = 0.0
    unrealized_pnl: float = 0.0
    realized_pnl: float = 0.0
    winrate: float = 0.0
    n_closed: int = 0
    roi_pct: float = 0.0
    portfolio_usd: float = 0.0
    score: float = 0.0
    fresh: bool = False
    insider_flag: bool = False
    reasons: list[str] = field(default_factory=list)

    def as_dict(self) -> dict:
        return asdict(self)


# --- parsing ---------------------------------------------------------------

def trade_usd(row: dict) -> float:
    """Notional of a trade row. `size` is shares, `price` is dollars per share."""
    try:
        return abs(float(row.get("size") or 0.0) * float(row.get("price") or 0.0))
    except (TypeError, ValueError):
        return 0.0


def parse_trades(rows: Iterable[dict]) -> list[Trade]:
    out: list[Trade] = []
    for row in rows:
        if row.get("side") not in ("BUY", "SELL"):
            continue
        out.append(Trade(
            wallet=(row.get("proxyWallet") or "").lower(),
            side=row["side"],
            asset=str(row.get("asset") or ""),
            condition_id=row.get("conditionId") or "",
            size=float(row.get("size") or 0.0),
            price=float(row.get("price") or 0.0),
            usd=trade_usd(row),
            ts=int(row.get("timestamp") or 0),
            title=row.get("title") or "",
            outcome=row.get("outcome") or "",
            slug=row.get("slug") or "",
            tx=row.get("transactionHash") or "",
            name=row.get("name") or "",
            pseudonym=row.get("pseudonym") or "",
        ))
    return out


def activity_trades(rows: Iterable[dict]) -> list[Trade]:
    """Activity rows carry `usdcSize`, which is exact. Trades carry size*price."""
    out: list[Trade] = []
    for row in rows:
        if row.get("type") != "TRADE" or row.get("side") not in ("BUY", "SELL"):
            continue
        usd = row.get("usdcSize")
        out.append(Trade(
            wallet=(row.get("proxyWallet") or "").lower(),
            side=row["side"],
            asset=str(row.get("asset") or ""),
            condition_id=row.get("conditionId") or "",
            size=float(row.get("size") or 0.0),
            price=float(row.get("price") or 0.0),
            usd=float(usd) if usd is not None else trade_usd(row),
            ts=int(row.get("timestamp") or 0),
            title=row.get("title") or "",
            outcome=row.get("outcome") or "",
            slug=row.get("slug") or "",
            tx=row.get("transactionHash") or "",
            name=row.get("name") or "",
            pseudonym=row.get("pseudonym") or "",
        ))
    return out


# --- profile ---------------------------------------------------------------

def profile(wallet: str, activity: list[dict], positions: list[dict], portfolio_usd: float = 0.0,
            config: dict | None = None, now: int | None = None,
            closed: list[dict] | None = None) -> WalletProfile:
    """Score one wallet.

    `closed` is the `/closed-positions` history. When it is present it is the
    source of truth for win rate and realised PnL; when it is absent the code
    falls back to resolved rows in `positions`, which is biased against wallets
    that redeemed their winners.
    """
    cfg = {**DEFAULT_CONFIG, **(config or {})}
    now = now or int(datetime.now(timezone.utc).timestamp())
    trades = activity_trades(activity)
    buys = [t for t in trades if t.side == "BUY"]
    usds = sorted(t.usd for t in trades) or [0.0]
    first_ts = min((t.ts for t in trades), default=0)
    last_ts = max((t.ts for t in trades), default=0)
    age = max(0.0, (now - first_ts) / DAY) if first_ts else 0.0

    if closed:
        history = closed
        wins = [p for p in history if float(p.get("realizedPnl") or p.get("cashPnl") or 0) > 0]
        realized = sum(float(p.get("realizedPnl") or p.get("cashPnl") or 0) for p in history)
    else:
        history = [p for p in positions if p.get("redeemable") or float(p.get("curPrice") or 0) in (0.0, 1.0)]
        wins = [p for p in history if float(p.get("cashPnl") or 0) > 0]
        realized = sum(float(p.get("realizedPnl") or 0) for p in positions)
    winrate = len(wins) / len(history) if history else 0.0
    unrealized = sum(float(p.get("cashPnl") or 0) for p in positions if not p.get("redeemable"))
    open_value = sum(float(p.get("currentValue") or 0) for p in positions)

    volume = sum(t.usd for t in trades)
    prof = WalletProfile(
        address=wallet.lower(),
        name=(trades[0].name if trades else "") or "",
        pseudonym=(trades[0].pseudonym if trades else "") or "",
        age_days=round(age, 2),
        first_ts=first_ts,
        last_ts=last_ts,
        n_activity=len(activity),
        n_trades=len(trades),
        volume_usd=round(volume, 2),
        median_trade_usd=round(statistics.median(usds), 2),
        max_trade_usd=round(usds[-1], 2),
        markets=len({t.condition_id for t in trades}),
        buy_ratio=round(len(buys) / len(trades), 3) if trades else 0.0,
        n_open=len(positions),
        open_value=round(open_value, 2),
        unrealized_pnl=round(unrealized, 2),
        realized_pnl=round(realized, 2),
        winrate=round(winrate, 3),
        n_closed=len(history),
        roi_pct=round((realized + unrealized) / max(1.0, volume) * 100.0, 2) if volume else 0.0,
        portfolio_usd=round(portfolio_usd or open_value, 2),
    )

    edge = 0.60 * clamp(winrate) + 0.40 * clamp(prof.roi_pct / 25.0)
    freshness = 1.0 - clamp(age / 120.0)
    size = clamp(math.log10(max(1.0, volume) / 1_000.0) / 2.5)
    consistency = clamp(len(history) / 20.0)

    # Multiplicative, as advertised: no edge means no score. A wallet with a
    # 90% win rate over one closed position is then discounted by `confidence`,
    # so a thin record cannot outrank a real one on freshness alone.
    context_w = cfg["w_fresh"] + cfg["w_size"] + cfg["w_consistency"]
    context = (
        cfg["w_fresh"] * freshness
        + cfg["w_size"] * size
        + cfg["w_consistency"] * consistency
    ) / context_w if context_w > 0 else 0.0
    confidence = clamp(len(history) / max(1, cfg["min_closed"]))
    prof.score = round(100.0 * edge * confidence * (0.35 + 0.65 * context), 1)
    prof.fresh = age <= cfg["fresh_days"] and prof.n_trades >= 3
    prof.insider_flag = bool(
        prof.fresh and prof.n_closed >= cfg["min_closed"]
        and prof.winrate >= 0.70 and prof.volume_usd >= 10_000)
    prof.reasons = explain(prof, cfg)
    return prof


def explain(prof: WalletProfile, cfg: dict) -> list[str]:
    out: list[str] = []
    if prof.fresh:
        out.append(f"wallet is {prof.age_days:.0f} days old — inside the price-discovery window")
    if prof.n_closed >= cfg["min_closed"]:
        out.append(f"{prof.winrate:.0%} of {prof.n_closed} closed positions finished green")
    elif prof.n_closed:
        out.append(f"only {prof.n_closed} closed positions — win rate is not yet evidence")
    if prof.volume_usd >= 50_000:
        out.append(f"${prof.volume_usd:,.0f} traded across {prof.markets} markets")
    if prof.max_trade_usd >= cfg["whale_usd"] * 5:
        out.append(f"largest single ticket ${prof.max_trade_usd:,.0f}")
    if abs(prof.roi_pct) >= 1:
        out.append(f"realised + unrealised {prof.roi_pct:+.1f}% of volume")
    if prof.insider_flag:
        out.append("FRESH + GREEN: the profile this desk exists to surface")
    return out


# --- copy simulation -------------------------------------------------------

def simulate_copy(activity: list[dict], positions: list[dict], config: dict | None = None,
                  stake_usd: float | None = None, max_trades: int | None = None,
                  slippage_bps: float | None = None) -> dict:
    """Replay a wallet's BUYs as if you had copied each one at a fixed stake.

    Marking: the current price of the same asset if the wallet still holds it,
    otherwise the last price that asset traded at in the history. A position that
    resolved is marked at 0 or 1, because `curPrice` is the resolution.

    The model charges slippage on entry and nothing on exit — Polymarket has no
    trading fee, only the spread. Ignoring the exit spread is the generous
    assumption, and it is stated here rather than buried.
    """
    cfg = {**DEFAULT_CONFIG, **(config or {})}
    stake = float(stake_usd if stake_usd is not None else cfg["stake_usd"])
    limit = int(max_trades if max_trades is not None else cfg["max_trades"])
    slip = float(slippage_bps if slippage_bps is not None else cfg["slippage_bps"]) / 10_000.0

    marks = {str(p.get("asset")): float(p.get("curPrice") or 0.0) for p in positions}
    trades = sorted(activity_trades(activity), key=lambda t: t.ts)
    last_price: dict[str, float] = {}
    for t in trades:
        last_price[t.asset] = t.price

    buys = [t for t in trades if t.side == "BUY"][:limit]
    fills: list[dict] = []
    equity = 0.0
    peak = 0.0
    max_dd = 0.0
    curve: list[dict] = []

    for i, t in enumerate(buys, 1):
        entry = t.price * (1.0 + slip)
        if entry <= 0 or entry >= 1:
            continue
        shares = stake / entry
        mark = marks.get(t.asset, last_price.get(t.asset, t.price))
        pnl = shares * (mark - entry)
        equity += pnl
        peak = max(peak, equity)
        max_dd = min(max_dd, equity - peak)
        fills.append({
            "n": i, "ts": t.ts, "title": t.title, "outcome": t.outcome,
            "entry": round(entry, 4), "mark": round(mark, 4), "shares": round(shares, 2),
            "stake": round(stake, 2), "pnl": round(pnl, 2),
            "roi_pct": round((mark - entry) / entry * 100.0, 2),
            "resolved": t.asset in marks and marks[t.asset] in (0.0, 1.0),
        })
        curve.append({"i": i, "equity": round(equity, 2)})

    wins = [f for f in fills if f["pnl"] > 0]
    invested = stake * len(fills)
    return {
        "wallet": (buys[0].wallet if buys else ""),
        "stake_usd": round(stake, 2),
        "n_fills": len(fills),
        "invested_usd": round(invested, 2),
        "pnl_usd": round(equity, 2),
        "roi_pct": round(equity / invested * 100.0, 2) if invested else 0.0,
        "hit_rate": round(len(wins) / len(fills), 3) if fills else 0.0,
        "max_drawdown_usd": round(max_dd, 2),
        "avg_pnl_usd": round(equity / len(fills), 2) if fills else 0.0,
        "best": max(fills, key=lambda f: f["pnl"], default=None),
        "worst": min(fills, key=lambda f: f["pnl"], default=None),
        "fills": fills,
        "curve": curve,
    }


# --- ranking ---------------------------------------------------------------

def rank_wallets(profiles: Iterable[WalletProfile]) -> list[WalletProfile]:
    return sorted(profiles, key=lambda p: (-p.score, -p.volume_usd))


def whale_trades(trades: Iterable[Trade], min_usd: float = 2000.0) -> list[Trade]:
    return sorted([t for t in trades if t.usd >= min_usd], key=lambda t: -t.usd)


# --- alerts ----------------------------------------------------------------

def render_alert(profiles: list[WalletProfile], trades: list[Trade] | None = None,
                 limit: int = 5, bot_name: str = "Whale Desk") -> str:
    """Telegram-ready HTML. Hard-capped below the API's 4096-char message limit.

    Rows are added one at a time and the loop stops before the cap, so a wallet
    that would push the message over the limit is dropped rather than truncated
    mid-sentence.
    """

    def esc(text: str) -> str:
        return str(text).replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")

    CAP = 3900
    lines = [f"<b>{esc(bot_name)}</b> · {len(profiles)} wallet(s) scored", ""]
    shown = 0
    for i, p in enumerate(profiles[:limit], 1):
        tag = " 🐋" if p.insider_flag else ""
        block = (
            f"{i}. <code>{esc(p.address[:10])}…</code> <b>score {p.score:.0f}</b>{tag}\n"
            f"   age {p.age_days:.0f}d · {p.n_trades} trades · ${p.volume_usd:,.0f} volume\n"
            f"   winrate {p.winrate:.0%} over {p.n_closed} closed · roi {p.roi_pct:+.1f}%"
        )
        if len("\n".join(lines + [block])) > CAP:
            break
        lines.append(block)
        shown += 1
    if shown < min(limit, len(profiles)):
        lines.append(f"… {min(limit, len(profiles)) - shown} more, see the desk")
    if trades:
        lines.append("")
        lines.append("<b>largest tickets</b>")
        for t in trades[:3]:
            block = f"· {esc(t.side)} ${t.usd:,.0f} <i>{esc(t.title[:60])}</i> @ {t.price:.2f}"
            if len("\n".join(lines + [block])) > CAP:
                break
            lines.append(block)
    lines.append("")
    lines.append("<i>public data; not financial advice</i>")
    return "\n".join(lines)


# --- summary ---------------------------------------------------------------

def load_fixture(path: str | Path) -> dict:
    return json.loads(Path(path).read_text())


def summary(payload: dict, config: dict | None = None, source: str = "fixture",
            errors: list[str] | None = None) -> dict:
    cfg = {**DEFAULT_CONFIG, **(config or {})}
    trades = parse_trades(payload.get("trades", []))
    profiles = []
    for wallet, bundle in (payload.get("profiles") or {}).items():
        value = 0.0
        rows = bundle.get("value")
        if isinstance(rows, list) and rows:
            value = float(rows[0].get("value") or 0.0)
        profiles.append(profile(
            wallet, bundle.get("activity") or [], bundle.get("positions") or [],
            portfolio_usd=value, config=cfg, closed=bundle.get("closed") or None))
    ranked = rank_wallets(profiles)
    whales = whale_trades(trades, cfg["whale_usd"])

    by_side = {"BUY": 0.0, "SELL": 0.0}
    for t in whales:
        by_side[t.side] = by_side.get(t.side, 0.0) + t.usd

    insiders = [p for p in ranked if p.insider_flag]
    return {
        "source": source,
        "captured_at": payload.get("captured_at"),
        "at": datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ"),
        "counts": {
            "trades": len(trades),
            "whale_trades": len(whales),
            "wallets": len(ranked),
            "insiders": len(insiders),
            "markets": len({t.condition_id for t in trades}),
        },
        "totals": {
            "whale_usd": round(sum(t.usd for t in whales), 2),
            "buy_usd": round(by_side.get("BUY", 0.0), 2),
            "sell_usd": round(by_side.get("SELL", 0.0), 2),
            "largest_usd": round(max((t.usd for t in whales), default=0.0), 2),
            "avg_score": round(sum(p.score for p in ranked) / len(ranked), 1) if ranked else 0.0,
            "portfolio_usd": round(sum(p.portfolio_usd for p in ranked), 2),
        },
        "wallets": [p.as_dict() for p in ranked],
        "insiders": [p.as_dict() for p in insiders],
        "feed": [asdict(t) for t in whales],
        "markets": payload.get("markets", [])[:12],
        "errors": errors or [],
        "config": cfg,
    }
