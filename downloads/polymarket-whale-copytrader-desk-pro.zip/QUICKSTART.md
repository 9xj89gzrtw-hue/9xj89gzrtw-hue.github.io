# Quick start

Python 3.9+. No dependencies. No keys, no wallet.

```bash
cd polymarket-whale-copytrader-desk-pro
python3 verify.py        # 80 offline checks, should end "80/80"
python3 server.py        # open http://127.0.0.1:8791
```

You will see 9 scored wallets, 492 whale prints and 12 markets from the bundled
snapshot. Everything works with the network off.

## Two-minute tour

1. **Look at the score column.** It is sorted descending. The bar under each
   number is relative to the best wallet in the snapshot.
2. **Click a wallet.** It expands into the reasons it scored what it did, the
   full profile, and a copy simulation at your stake (default $250).
3. **Change the stake** in the header (or in the row) and press **Re-run**. PnL,
   ROI, hit rate, max drawdown and the equity curve update.
4. **Switch to Whale feed.** Every print at or above `whale_usd`, largest first,
   with side, price, outcome and wallet.
5. **Switch to Markets.** The 12 markets behind the snapshot, with Yes price,
   24-hour move, liquidity and spread.
6. **Press Alert preview.** You get the exact Telegram text, HTML-escaped and
   capped below the 4096-character API limit.
7. **Press CSV.** `whales.csv` lands in your downloads folder.

## Go live

```bash
python3 server.py --live
```

or tick **Live data** in the header. The footer shows the source and every API
warning. A dead wallet degrades the snapshot instead of killing it; a dead live
fetch falls back to the fixture and labels itself `fixture (live failed)`.

Live mode is deliberately slow: one request at a time, 0.35 s apart, 30-second
cache. That is what keeps the public API from answering 429.

## Make it yours

```bash
cp config.example.json config.json
```

- Set `stake_usd` to the size you would actually copy with.
- Set `whale_usd` higher if your feed is too noisy, lower to see smaller prints.
- Set `min_closed` higher if you only trust a long record.
- Reweight the context in `w_fresh` / `w_size` / `w_consistency` — they are
  normalised, so only their ratio matters. Edge stays a gate: a losing wallet
  cannot buy its way back into the ranking.

## How to read a wallet

1. **`n_closed` first, win rate second.** `100% / 2` is not a record.
2. **Age matters.** A 10-day-old wallet with size and a green record is the
   profile this desk exists to surface — and the one most likely to be noise.
3. **`THIN` means thin.** Under five closed positions the score is capped by the
   consistency term on purpose.
4. **Read the reasons.** They are generated from the same numbers the score uses,
   so you can audit the conclusion.
5. **Run the copy simulation before believing the win rate.** A high hit rate
   with a negative copy PnL means the wins were small and the losses were large.

## When the feed is empty

That is possible and not a bug: `whale_usd` may be above every print in the
window, or the API may have returned an error (check the footer). Lower
`whale_usd` or refresh with live data on.

## What this tool will not do

- It will not connect a wallet, sign anything, or place an order.
- It will not tell you a wallet is an insider. It flags `FRESH + GREEN` and shows
  the evidence; the conclusion is yours.
- It will not promise that a historical copy replay repeats.
