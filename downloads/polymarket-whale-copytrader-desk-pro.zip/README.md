# polymarket-whale-copytrader-desk-pro

A local research desk for Polymarket's public trade feed. It finds the wallets
taking the biggest positions, scores whether their record is *evidence* or just
a small sample, and replays their buys at a stake you choose — so you can see
what copying them would actually have paid, before you copy anything.

No wallet. No private key. No order path. No telemetry. One folder, stdlib
Python, one browser tab.

```
python3 server.py            # http://127.0.0.1:8791  (bundled snapshot)
python3 server.py --live     # fresh snapshot from the public Polymarket APIs
```

---

## The problem this desk is built around

Polymarket publishes every trade. That is a gift and a trap: a wallet with a 90%
win rate looks like an oracle until you notice it has closed three positions, or
that the "win" was buying `Yes` at 0.98 for a 2% return. Copy-trading dashboards
usually show you the win rate and hide the denominator.

This one makes the denominator the point:

| The question | Where the answer is |
|---|---|
| Is that wallet actually good? | score, with the win rate shown **over `n_closed`** |
| Is the sample big enough to mean anything? | `min_closed` (default 5); thinner wallets are tagged `THIN` |
| Is this a fresh wallet with an edge? | `FRESH + GREEN` flag: young, green, and large enough to matter |
| What would copying have paid? | `/api/copy` replays every buy at your stake, net of entry slippage |
| Which wallet is biggest *right now*? | whale feed sorted by notional, `≥ $2,000` by default |
| Did the API refuse? | `errors[]` in every payload and in the footer — never a silent zero |

## What the score means — and what it does not

The score is 0–100 and **multiplicative on purpose**:

```
edge        0.60 × win rate  +  0.40 × clamp(ROI / 25%)
confidence  min(1, closed positions / min_closed)
context     0.35 + 0.65 × weighted(freshness, size, consistency)

score       100 × edge × confidence × context
```

A wallet with a 90% win rate over three trades scores **low**, because three
trades is not a record. A wallet that lost money scores **zero**, no matter how
fresh or how large — there is no weight that lets a losing record buy its way
back in. A wallet with twenty closed positions and a real edge scores high.

That is the entire opinion of this tool. It does **not** mean "will make money
next"; it means "this record is worth looking at, and here is how thin it is".
Every score ships with its reasons in `wallets[].reasons`, so you can disagree
with the arithmetic in public.

## What the copy simulation does

`/api/copy?wallet=0x…&stake=250` replays the wallet's BUY history:

- **Entry** = the wallet's fill price **plus your slippage** (`slippage_bps`,
  default 120).
- **Mark** = the current price of the same asset if the wallet still holds it;
  otherwise the last price that asset traded at in the history. Positions that
  resolved are marked at 0 or 1, because that is the resolution.
- **Fees** = none on exit. Polymarket has no trading fee, only the spread. The
  entry spread is charged; ignoring the exit spread is the *generous* assumption
  and it is stated here rather than buried.
- **Output** = PnL, ROI, hit rate, max drawdown, equity curve, and every fill.

What it cannot model: your fill would move the book, the wallet's later trades,
or a market that resolved after the snapshot. It is a historical replay, not a
backtest with your size, and it is labelled that way in the UI.

## What is in the box

```
polymarket-whale-copytrader-desk-pro/
├── poly.py                public API clients: trades, activity, positions, gamma, clob
├── whales.py              scoring, profiling, copy simulation, alert rendering
├── desk.py                snapshot assembly, wallet ranking, market normalisation
├── server.py              local HTTP server + JSON/CSV API
├── terminal.html          the desk: wallets, whale feed, markets, no CDN
├── config.example.json    copy to config.json and edit
├── verify.py              80 offline checks: math, transport, HTTP routes
├── tests/
│   ├── test_whales.py     12 engine cases
│   ├── test_poly.py       10 transport cases
│   ├── test_desk.py       9 assembly cases
│   ├── test_server.py     13 HTTP cases
│   └── fixtures/polymarket.json   live capture: 500 trades, 9 wallets, 12 markets
├── assets/
│   ├── cover.png          2400x1600 product cover
│   └── make_cover.py      reproducible cover generator (Pillow, build-time only)
├── docs/desk.png          screenshot of the running desk (fixture data)
├── README.md
├── QUICKSTART.md
└── LICENSE                MIT, with an explicit "not financial advice" note
```

## Install

Python **3.9+**. Nothing to install for the product itself. Pillow is needed
only if you want to rebuild the cover.

```bash
cd polymarket-whale-copytrader-desk-pro
python3 verify.py            # 80 checks, offline
python3 server.py            # open http://127.0.0.1:8791
```

## The API

Every response is JSON unless noted. The server binds to `127.0.0.1` and has no
authentication; do not expose it.

| Route | What it returns |
|---|---|
| `GET /` | the terminal |
| `GET /api/health` | version, Python, fixture presence, cache age |
| `GET /api/scan` | full snapshot: counts, totals, wallets, feed, markets, errors |
| `GET /api/wallets` | ranked wallet profiles only |
| `GET /api/feed` | whale trades only, largest first |
| `GET /api/markets` | normalised market metadata |
| `GET /api/copy?wallet=&stake=&max_trades=&slippage=` | copy simulation for one wallet |
| `GET /api/export.csv` | wallet table as CSV |
| `POST /api/telegram` | rendered alert text (`limit`, `bot_name`) |
| `GET/POST /api/config` | read or merge config (secret keys redacted) |

Add `?live=1` to `scan`, `wallets`, `feed`, `markets`, `copy` or `export.csv`
to use a fresh public-API snapshot. `?force=1` bypasses the 45-second cache.

## Live mode and rate limits

All data comes from three public hosts, with no key of any kind:

- `https://data-api.polymarket.com` — trades, activity, positions, portfolio value
- `https://gamma-api.polymarket.com` — market metadata
- `https://clob.polymarket.com` — order books and server time

The public data API answers **429** when you fan out. This desk walks wallets
one at a time through a single process-wide throttle:

- `MIN_GAP = 0.35 s` between any two requests,
- 30-second TTL cache per URL (gamma: 60 s),
- one request per wallet per field, no parallel fan-out.

If a wallet fails, the snapshot keeps the other wallets and records the error.
If the whole live fetch fails, the desk falls back to the fixture and **says so**
in `source` (`fixture (live failed)`), because a silent fallback is a lie.

## Configuration

```bash
cp config.example.json config.json
```

| Key | Default | Meaning |
|---|---|---|
| `whale_usd` | `2000` | minimum notional to count as a whale print |
| `stake_usd` | `250` | default stake per copied buy |
| `max_trades` | `40` | cap on replayed buys |
| `slippage_bps` | `120` | charged on entry only |
| `fresh_days` | `45` | a wallet younger than this is "fresh" |
| `min_closed` | `5` | closed positions before a win rate is evidence |
| `w_fresh` / `w_size` / `w_consistency` | `0.2 / 0.2 / 0.2` | context weights (normalised; edge is a separate gate) |
| `wallets` | `8` | wallets profiled per live snapshot |
| `trade_limit` | `250` | trades pulled per snapshot |
| `min_cash` | `null` | server-side `CASH` filter, if you want one |
| `market_limit` | `12` | markets pulled for the context table |

Config is written `0600`. Any key containing `token`, `secret`, `key` or
`password` is redacted on read.

## Five rules the desk enforces

1. **A win rate without its denominator is not shown.** `n_closed` sits next to
   every percentage.
2. **Thin samples are labelled, not hidden.** `THIN` under five closed positions.
3. **API failure is an error, not a zero.** `errors[]` reaches the footer.
4. **Copy PnL is a replay, not a promise.** Entry slippage is charged; the
   assumption about exit spread is written down.
5. **Nothing leaves the machine.** No key, no order, no telemetry, `127.0.0.1`.

## Verification

```bash
python3 verify.py            # human output, 80 checks
python3 verify.py --json     # machine-readable
python3 -m pytest tests -q   # 44 unit/HTTP cases
```

The verifier is offline by design: exact arithmetic on the engine, parsers fed
canned payloads, a client fed a fake transport, and a server started on a random
localhost port. No API call is made.

## Honest limitations

- The public API is not a historical archive. `activity` returns the most recent
  rows the endpoint will give you; a very active wallet is truncated.
- `/closed-positions` silently caps at 50 rows. The desk asks for the most recent
  50 (not the most profitable 50, which is the API default and would make every
  wallet look like a 100% winner), so a win rate is a sample, not a lifetime record.
- Wallet age is measured from the first trade *in that window*, so it is a lower
  bound on true age. The `FRESH` flag is a lead, not proof of insider trading.
- Positions marked at the last traded price are approximations, not marks you
  could execute at.
- The fixture is a point-in-time capture. Prices in it are not current.
- This is research software. It is not financial advice, and it does not place
  orders.

## License

MIT. See `LICENSE`. The software displays public market data and performs
arithmetic on it; it comes with no expectation that any copied trade is
profitable or executable.
