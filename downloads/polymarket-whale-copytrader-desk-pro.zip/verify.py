#!/usr/bin/env python3
"""Self-check for polymarket-whale-copytrader-desk-pro.

Runs offline. No wallet, no key, no network. Every assertion is either exact
arithmetic over the scoring engine, a parser fed a canned payload, a client fed
a fake transport, or an HTTP request against a server this script starts on a
random localhost port.

    python3 verify.py            # human output
    python3 verify.py --quiet    # exit code only
    python3 verify.py --json     # machine-readable

Exit code 0 means every check passed.
"""

from __future__ import annotations

import io
import json
import math
import struct
import sys
import tempfile
import threading
import traceback
import urllib.error
import urllib.request
from pathlib import Path

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))

import desk  # noqa: E402
import poly  # noqa: E402
import whales  # noqa: E402

RESULTS: list[tuple[str, bool, str]] = []


def check(name: str):
    def wrap(fn):
        try:
            detail = fn()
            RESULTS.append((name, True, "" if detail is None else str(detail)))
        except Exception:
            RESULTS.append((name, False, traceback.format_exc(limit=3).strip().splitlines()[-1]))
        return fn

    return wrap


def eq(actual, expected, label=""):
    if actual != expected:
        raise AssertionError(f"{label or 'value'}: got {actual!r}, want {expected!r}")
    return actual


def near(actual, expected, tol=1e-9, label=""):
    a, b = float(actual), float(expected)
    if abs(a - b) > tol:
        raise AssertionError(f"{label or 'value'}: got {a!r}, want {b!r} (±{tol})")
    return a


def raises(fn, exc, label=""):
    try:
        fn()
    except exc:
        return True
    except Exception as other:  # noqa: BLE001
        raise AssertionError(f"{label}: raised {type(other).__name__}, want {exc.__name__}") from other
    raise AssertionError(f"{label}: nothing raised")


# ---------------------------------------------------------------------------
# layout
# ---------------------------------------------------------------------------

REQUIRED = [
    "poly.py", "whales.py", "desk.py", "server.py", "terminal.html",
    "config.example.json", "README.md", "QUICKSTART.md", "LICENSE", "verify.py",
    "assets/cover.png", "assets/make_cover.py", "docs/desk.png",
    "tests/fixtures/polymarket.json", "tests/test_whales.py",
    "tests/test_poly.py", "tests/test_desk.py", "tests/test_server.py",
]


@check("layout: every shipped file exists")
def _layout():
    missing = [p for p in REQUIRED if not (ROOT / p).exists()]
    if missing:
        raise AssertionError("missing: " + ", ".join(missing))
    return f"{len(REQUIRED)} files"


@check("layout: no file is empty")
def _nonempty():
    empty = [p for p in REQUIRED if (ROOT / p).exists() and (ROOT / p).stat().st_size == 0]
    if empty:
        raise AssertionError("empty: " + ", ".join(empty))
    return "ok"


@check("layout: terminal.html has no external asset references")
def _selfcontained():
    page = (ROOT / "terminal.html").read_text()
    for bad in ("http://", "https://", "//cdn", "integrity="):
        if bad in page:
            raise AssertionError(f"external reference: {bad}")
    if "<style>" not in page or "<script>" not in page:
        raise AssertionError("inline style/script missing")
    if "fetch(" not in page:
        raise AssertionError("terminal never calls the API")
    return f"{len(page)} bytes"


@check("layout: cover is a 2400x1600 PNG")
def _cover():
    raw = (ROOT / "assets/cover.png").read_bytes()
    if raw[:8] != b"\x89PNG\r\n\x1a\n":
        raise AssertionError("not a PNG")
    width, height = struct.unpack(">II", raw[16:24])
    eq((width, height), (2400, 1600), "dimensions")
    if len(raw) < 40_000:
        raise AssertionError(f"cover looks empty: {len(raw)} bytes")
    return f"{width}x{height}, {len(raw)//1024} KiB"


@check("layout: docs/desk.png is a real screenshot, not a 1px placeholder")
def _shot():
    raw = (ROOT / "docs/desk.png").read_bytes()
    if raw[:8] != b"\x89PNG\r\n\x1a\n":
        raise AssertionError("not a PNG")
    width, height = struct.unpack(">II", raw[16:24])
    if width < 1200 or height < 800:
        raise AssertionError(f"too small: {width}x{height}")
    if len(raw) < 60_000:
        raise AssertionError(f"suspiciously small: {len(raw)} bytes")
    return f"{width}x{height}, {len(raw)//1024} KiB"


@check("layout: README documents the data sources and the risks")
def _readme():
    text = (ROOT / "README.md").read_text().lower()
    for needle in ("data-api.polymarket.com", "not financial advice", "rate limit", "copy"):
        if needle not in text:
            raise AssertionError(f"README missing {needle!r}")
    if len(text) < 4000:
        raise AssertionError(f"README is {len(text)} chars")
    return f"{len(text)} chars"


# ---------------------------------------------------------------------------
# poly transport
# ---------------------------------------------------------------------------


class FakeResponse:
    def __init__(self, payload: bytes, status: int = 200):
        self.payload = payload
        self.status = status

    def read(self):
        return self.payload

    def __enter__(self):
        return self

    def __exit__(self, *exc):
        return False


def _patch_urlopen(monkey):
    original = poly.urllib.request.urlopen
    poly.urllib.request.urlopen = monkey
    return original


@check("poly: response payloads are parsed as JSON")
def _poly_parse():
    c = poly.Client(ttl=0)
    c.MIN_GAP = 0
    original = _patch_urlopen(lambda req, timeout=0: FakeResponse(b'[{"ok": 1}]'))
    try:
        eq(c.trades(limit=5), [{"ok": 1}])
    finally:
        poly.urllib.request.urlopen = original
    eq(c.requests, 1)
    return "1 request"


@check("poly: a cached URL is not requested twice")
def _poly_cache():
    c = poly.Client(ttl=60)
    c.MIN_GAP = 0
    calls = {"n": 0}

    def fake(req, timeout=0):
        calls["n"] += 1
        return FakeResponse(b"[]")

    original = _patch_urlopen(fake)
    try:
        c.trades(limit=10)
        c.trades(limit=10)
    finally:
        poly.urllib.request.urlopen = original
    eq(calls["n"], 1)
    return "1 request, 2 calls"


@check("poly: different params are different cache keys")
def _poly_cache_key():
    c = poly.Client(ttl=60)
    c.MIN_GAP = 0
    calls = {"n": 0}

    def fake(req, timeout=0):
        calls["n"] += 1
        return FakeResponse(b"[]")

    original = _patch_urlopen(fake)
    try:
        c.trades(limit=10)
        c.trades(limit=20)
    finally:
        poly.urllib.request.urlopen = original
    eq(calls["n"], 2)
    return "2 requests"


@check("poly: a 429 becomes PolyError, not an empty list")
def _poly_429():
    c = poly.Client(ttl=0)
    c.MIN_GAP = 0

    def fake(req, timeout=0):
        raise urllib.error.HTTPError(req.full_url, 429, "Too Many", {}, io.BytesIO(b"slow down"))

    original = _patch_urlopen(fake)
    try:
        raises(lambda: c.trades(), poly.PolyError, "429")
    finally:
        poly.urllib.request.urlopen = original
    eq(c.errors, 1)
    return "raised"


@check("poly: a network failure becomes PolyError")
def _poly_net():
    c = poly.Client(ttl=0)
    c.MIN_GAP = 0
    original = _patch_urlopen(lambda req, timeout=0: (_ for _ in ()).throw(urllib.error.URLError("down")))
    try:
        raises(lambda: c.markets(), poly.PolyError, "network")
    finally:
        poly.urllib.request.urlopen = original
    return "raised"


@check("poly: a non-list trades payload is rejected")
def _poly_shape():
    c = poly.Client(ttl=0)
    c.MIN_GAP = 0
    original = _patch_urlopen(lambda req, timeout=0: FakeResponse(b'{"nope": 1}'))
    try:
        raises(lambda: c.trades(), poly.PolyError, "shape")
    finally:
        poly.urllib.request.urlopen = original
    return "raised"


@check("poly: value picks the first row and tolerates an empty list")
def _poly_value():
    c = poly.Client(ttl=0)
    c.MIN_GAP = 0
    original = _patch_urlopen(lambda req, timeout=0: FakeResponse(b'[{"value": 123.5}]'))
    try:
        near(c.value("0xabc"), 123.5)
    finally:
        poly.urllib.request.urlopen = original
    c2 = poly.Client(ttl=0)
    c2.MIN_GAP = 0
    original = _patch_urlopen(lambda req, timeout=0: FakeResponse(b"[]"))
    try:
        eq(c2.value("0xabc"), 0.0)
    finally:
        poly.urllib.request.urlopen = original
    return "ok"


@check("poly: min_cash adds the documented CASH filter")
def _poly_filter():
    seen: list[str] = []
    c = poly.Client(ttl=0)
    c.MIN_GAP = 0

    def fake(req, timeout=0):
        seen.append(req.full_url)
        return FakeResponse(b"[]")

    original = _patch_urlopen(fake)
    try:
        c.trades(limit=10, min_cash=2500)
    finally:
        poly.urllib.request.urlopen = original
    url = seen[0]
    if "filterType=CASH" not in url or "filterAmount=2500" not in url:
        raise AssertionError(url)
    return "CASH≥2500"


@check("poly: trade limit is clamped to the API maximum")
def _poly_clamp():
    seen: list[str] = []
    c = poly.Client(ttl=0)
    c.MIN_GAP = 0

    def fake(req, timeout=0):
        seen.append(req.full_url)
        return FakeResponse(b"[]")

    original = _patch_urlopen(fake)
    try:
        c.trades(limit=99999)
    finally:
        poly.urllib.request.urlopen = original
    if "limit=500" not in seen[0]:
        raise AssertionError(seen[0])
    return "500"


@check("poly: throttle spaces requests by at least MIN_GAP")
def _poly_throttle():
    import time

    c = poly.Client(ttl=0)
    c.MIN_GAP = 0.12
    stamps: list[float] = []
    original = _patch_urlopen(lambda req, timeout=0: (stamps.append(time.monotonic()), FakeResponse(b"[]"))[1])
    try:
        c.trades(limit=1)
        c.trades(limit=2)
    finally:
        poly.urllib.request.urlopen = original
    gap = stamps[1] - stamps[0]
    if gap < 0.10:
        raise AssertionError(f"gap {gap:.3f}s")
    return f"{gap*1000:.0f} ms apart"


# ---------------------------------------------------------------------------
# trade parsing and notional
# ---------------------------------------------------------------------------


@check("whales: trade_usd is size × price, absolute")
def _usd():
    near(whales.trade_usd({"size": 100, "price": 0.25}), 25.0)
    near(whales.trade_usd({"size": -100, "price": 0.25}), 25.0)
    eq(whales.trade_usd({}), 0.0)
    eq(whales.trade_usd({"size": "x", "price": 1}), 0.0)
    return "ok"


@check("whales: parse_trades keeps only BUY and SELL")
def _parse():
    rows = [
        {"proxyWallet": "0xAbC", "side": "BUY", "size": 10, "price": 0.5, "timestamp": 100},
        {"proxyWallet": "0xDef", "side": "SELL", "size": 20, "price": 0.25, "timestamp": 101},
        {"proxyWallet": "0xGhi", "side": "MERGE", "size": 30, "price": 0.1, "timestamp": 102},
    ]
    out = whales.parse_trades(rows)
    eq(len(out), 2)
    eq(out[0].wallet, "0xabc", "wallet lowercased")
    near(out[0].usd, 5.0)
    near(out[1].usd, 5.0)
    return "2 of 3"


@check("whales: activity_trades prefers the exact usdcSize")
def _activity_usd():
    rows = [{
        "type": "TRADE", "side": "BUY", "proxyWallet": "0xabc", "size": 1000, "price": 0.50,
        "usdcSize": 499.99, "timestamp": 5,
    }, {"type": "SPLIT", "size": 1, "price": 1}]
    out = whales.activity_trades(rows)
    eq(len(out), 1)
    near(out[0].usd, 499.99)
    return "usdcSize"


@check("whales: activity_trades falls back to size × price when usdcSize is absent")
def _activity_fallback():
    rows = [{"type": "TRADE", "side": "SELL", "proxyWallet": "0xabc", "size": 40, "price": 0.25,
             "timestamp": 5}]
    near(whales.activity_trades(rows)[0].usd, 10.0)
    return "fallback"


@check("whales: trade key is the tx hash when present")
def _trade_key():
    t = whales.Trade("0xabc", "BUY", "1", "0xcond", 1, 0.5, 0.5, 7, "t", "Yes", tx="0xdead")
    eq(t.key, "0xdead")
    t2 = whales.Trade("0xabc", "BUY", "1", "0xcond", 1, 0.5, 0.5, 7, "t", "Yes")
    eq(t2.key, "0xabc:7")
    return "ok"


# ---------------------------------------------------------------------------
# profile scoring
# ---------------------------------------------------------------------------


def _bundle(n_buys: int = 6, price: float = 0.5, size: float = 1000, start: int = 1_700_000_000,
            closed_win: bool = True, age_days: float = 10.0, n_closed: int = 1):
    """Synthetic wallet: n_buys, `n_closed` resolved positions, deterministic timestamps."""
    now = int(start + age_days * whales.DAY)
    activity, ts = [], start
    for i in range(n_buys):
        activity.append({
            "type": "TRADE", "side": "BUY", "proxyWallet": "0xwallet",
            "size": size, "price": price, "usdcSize": size * price,
            "timestamp": ts, "conditionId": f"c{i}", "asset": f"a{i}",
            "title": f"market {i}", "outcome": "Yes", "transactionHash": f"0x{i}",
        })
        ts += 3600
    positions = [{
        "proxyWallet": "0xwallet", "asset": f"a{i}", "conditionId": f"c{i}", "size": size,
        "curPrice": 1.0 if closed_win else 0.0, "cashPnl": 500.0 if closed_win else -500.0,
        "realizedPnl": 0.0, "currentValue": size, "redeemable": True,
    } for i in range(n_closed)]
    return now, activity, positions


@check("profile: age is measured from the first trade")
def _age():
    now, act, pos = _bundle(age_days=10.0)
    p = whales.profile("0xWALLET", act, pos, now=now)
    near(p.age_days, 10.0, tol=0.01)
    eq(p.address, "0xwallet")
    return f"{p.age_days}d"


@check("profile: volume sums notional, not share count")
def _volume():
    now, act, pos = _bundle(n_buys=4, price=0.5, size=1000)
    p = whales.profile("0xwallet", act, pos, now=now)
    near(p.volume_usd, 4 * 500.0)
    eq(p.n_trades, 4)
    return f"${p.volume_usd:,.0f}"


@check("profile: markets counts distinct conditions, not trades")
def _markets():
    now, act, pos = _bundle(n_buys=3)
    for row in act:
        row["conditionId"] = "same"
    p = whales.profile("0xwallet", act, pos, now=now)
    eq(p.markets, 1)
    return "1 market"


@check("profile: win rate divides wins by closed positions only")
def _winrate():
    now, act, pos = _bundle()
    pos.append({"asset": "a1", "curPrice": 0.42, "cashPnl": -10.0, "realizedPnl": 0,
                "currentValue": 100, "redeemable": False})
    p = whales.profile("0xwallet", act, pos, now=now)
    eq(p.n_closed, 1)
    near(p.winrate, 1.0)
    return "1/1"


@check("profile: a losing resolution is not counted as a win")
def _loss():
    now, act, pos = _bundle(closed_win=False)
    p = whales.profile("0xwallet", act, pos, now=now)
    eq(p.n_closed, 1)
    eq(p.winrate, 0.0)
    return "0/1"


@check("profile: fresh requires age and at least three trades")
def _fresh():
    now, act, pos = _bundle(n_buys=4, age_days=5)
    p = whales.profile("0xwallet", act, pos, now=now)
    eq(p.fresh, True)
    now2, act2, pos2 = _bundle(n_buys=2, age_days=5)
    p2 = whales.profile("0xwallet", act2, pos2, now=now2)
    eq(p2.fresh, False, "two trades is not a record")
    now3, act3, pos3 = _bundle(n_buys=4, age_days=200)
    eq(whales.profile("0xwallet", act3, pos3, now=now3).fresh, False, "old wallet")
    return "ok"


@check("profile: insider flag needs fresh + green + a real sample")
def _insider():
    now, act, pos = _bundle(n_buys=8, price=0.5, size=4000, age_days=5, n_closed=6)
    p = whales.profile("0xwallet", act, pos, now=now)
    eq(p.insider_flag, True)
    now2, act2, pos2 = _bundle(n_buys=8, price=0.5, size=4000, age_days=5, n_closed=2)
    eq(whales.profile("0xwallet", act2, pos2, now=now2).insider_flag, False, "thin record")
    now3, act3, pos3 = _bundle(n_buys=8, price=0.5, size=100, age_days=5, n_closed=6)
    eq(whales.profile("0xwallet", act3, pos3, now=now3).insider_flag, False, "too small")
    now4, act4, pos4 = _bundle(n_buys=8, price=0.5, size=4000, age_days=5, closed_win=False, n_closed=6)
    eq(whales.profile("0xwallet", act4, pos4, now=now4).insider_flag, False, "not green")
    return "ok"


@check("profile: closed-positions history beats the held-position fallback")
def _closed_history():
    now, act, pos = _bundle(n_buys=6, closed_win=False, n_closed=6)
    history = [{"realizedPnl": 10.0 if i < 4 else -5.0} for i in range(6)]
    p = whales.profile("0xwallet", act, pos, now=now, closed=history)
    eq(p.n_closed, 6)
    near(p.winrate, 4 / 6, tol=1e-3)
    near(p.realized_pnl, 4 * 10.0 - 2 * 5.0)
    # without the history the fallback sees six losing held positions
    eq(whales.profile("0xwallet", act, pos, now=now).winrate, 0.0)
    return "4/6 from history"


@check("poly: closed-positions asks for the most recent 50, not the richest")
def _closed_params():
    seen: list[str] = []
    c = poly.Client(ttl=0)
    c.MIN_GAP = 0

    def fake(req, timeout=0):
        seen.append(req.full_url)
        return FakeResponse(b"[]")

    original = _patch_urlopen(fake)
    try:
        c.closed_positions("0xabc", limit=500)
    finally:
        poly.urllib.request.urlopen = original
    url = seen[0]
    for needle in ("sortBy=TIMESTAMP", "sortDirection=DESC", "limit=50"):
        if needle not in url:
            raise AssertionError(url)
    return "recent 50"



def _score_bounds():
    for wins in (True, False):
        now, act, pos = _bundle(n_buys=20, price=0.5, size=10_000, age_days=2, closed_win=wins)
        p = whales.profile("0xwallet", act, pos, now=now)
        if not 0 <= p.score <= 100:
            raise AssertionError(p.score)
    return "bounded"


@check("profile: a bigger record outranks a lucky three-trade wallet")
def _score_ordering():
    now, act, pos = _bundle(n_buys=20, price=0.5, size=5000, age_days=30)
    big = whales.profile("0xbig", act, pos, now=now)
    now2, act2, pos2 = _bundle(n_buys=3, price=0.5, size=100, age_days=30)
    small = whales.profile("0xsmall", act2, pos2, now=now2)
    if big.score <= small.score:
        raise AssertionError(f"big {big.score} <= small {small.score}")
    return f"{big.score} > {small.score}"


@check("profile: thin samples are called thin in the reasons")
def _thin():
    now, act, pos = _bundle(n_buys=2)
    p = whales.profile("0xwallet", act, pos, now=now)
    text = " ".join(p.reasons)
    if "not yet evidence" not in text:
        raise AssertionError(text)
    return "flagged"


@check("profile: an empty wallet is zeroed, not crashed")
def _empty_profile():
    p = whales.profile("0xEMPTY", [], [], now=1_700_000_000)
    eq(p.n_trades, 0)
    eq(p.volume_usd, 0.0)
    eq(p.winrate, 0.0)
    eq(p.fresh, False)
    eq(p.insider_flag, False)
    return "zeros"


# ---------------------------------------------------------------------------
# copy simulation
# ---------------------------------------------------------------------------


@check("copy: entry price includes the slippage charge")
def _copy_entry():
    now, act, pos = _bundle(n_buys=1, price=0.50, size=100, age_days=3)
    pos[0]["curPrice"] = 0.60
    pos[0]["asset"] = "a0"
    sim = whales.simulate_copy(act, pos, stake_usd=100, slippage_bps=100)
    f = sim["fills"][0]
    near(f["entry"], 0.505, tol=1e-9)
    near(f["pnl"], (100 / 0.505) * (0.60 - 0.505), tol=0.01)
    return f"${f['pnl']:.2f}"


@check("copy: a resolved position is marked at 0 or 1")
def _copy_resolved():
    now, act, pos = _bundle(n_buys=1, price=0.40, size=100, age_days=3)
    pos[0]["curPrice"] = 1.0
    sim = whales.simulate_copy(act, pos, stake_usd=50, slippage_bps=0)
    f = sim["fills"][0]
    eq(f["resolved"], True)
    near(f["mark"], 1.0)
    near(f["roi_pct"], 150.0, tol=0.01)
    return "+150%"


@check("copy: a held position is marked at curPrice")
def _copy_mark():
    now, act, pos = _bundle(n_buys=1, price=0.40, size=100, age_days=3)
    pos[0]["curPrice"] = 0.55
    sim = whales.simulate_copy(act, pos, stake_usd=50, slippage_bps=0)
    near(sim["fills"][0]["mark"], 0.55)
    eq(sim["fills"][0]["resolved"], False)
    return "0.55"


@check("copy: stake and max_trades are honoured")
def _copy_limits():
    now, act, pos = _bundle(n_buys=10, price=0.5, size=100, age_days=3)
    sim = whales.simulate_copy(act, pos, stake_usd=33, max_trades=4, slippage_bps=0)
    eq(sim["n_fills"], 4)
    near(sim["invested_usd"], 132.0)
    near(sim["stake_usd"], 33.0)
    return "4 × $33"


@check("copy: hit rate counts only positive fills")
def _copy_hit():
    now, act, pos = _bundle(n_buys=4, price=0.5, size=100, age_days=3)
    pos = [
        {"asset": "a0", "curPrice": 1.0, "cashPnl": 1, "currentValue": 1},
        {"asset": "a1", "curPrice": 0.1, "cashPnl": -1, "currentValue": 1},
    ]
    sim = whales.simulate_copy(act, pos, stake_usd=10, slippage_bps=0)
    eq(sim["n_fills"], 4)
    # a0 wins, a1 loses, a2/a3 fall back to the last traded price (0.5) = flat
    eq(sim["hit_rate"], 0.25)
    return "1/4"


@check("copy: drawdown is reported as a non-positive number")
def _copy_dd():
    now, act, pos = _bundle(n_buys=2, price=0.5, size=100, age_days=3)
    pos = [{"asset": "a0", "curPrice": 1.0, "cashPnl": 1}, {"asset": "a1", "curPrice": 0.0, "cashPnl": -1}]
    sim = whales.simulate_copy(act, pos, stake_usd=10, slippage_bps=0)
    if sim["max_drawdown_usd"] > 0:
        raise AssertionError(sim["max_drawdown_usd"])
    return f"{sim['max_drawdown_usd']}"


@check("copy: the equity curve ends at the reported PnL")
def _copy_curve():
    now, act, pos = _bundle(n_buys=5, price=0.5, size=100, age_days=3)
    sim = whales.simulate_copy(act, pos, stake_usd=20, slippage_bps=50)
    near(sim["curve"][-1]["equity"], sim["pnl_usd"], tol=0.02)
    eq(len(sim["curve"]), sim["n_fills"])
    return "reconciled"


@check("copy: an empty history is an empty simulation, not an error")
def _copy_empty():
    sim = whales.simulate_copy([], [], stake_usd=100)
    eq(sim["n_fills"], 0)
    eq(sim["pnl_usd"], 0.0)
    eq(sim["roi_pct"], 0.0)
    eq(sim["fills"], [])
    return "empty"


@check("copy: buy order follows timestamp, not payload order")
def _copy_order():
    now, act, pos = _bundle(n_buys=3, price=0.5, size=100, age_days=3)
    shuffled = [act[2], act[0], act[1]]
    sim = whales.simulate_copy(shuffled, pos, stake_usd=10, slippage_bps=0)
    eq([f["ts"] for f in sim["fills"]], sorted(row["timestamp"] for row in act))
    return "sorted"


# ---------------------------------------------------------------------------
# ranking, alerts, summary
# ---------------------------------------------------------------------------


@check("rank: wallets sort by score descending")
def _rank():
    a = whales.WalletProfile("0xa", score=11.0, volume_usd=1)
    b = whales.WalletProfile("0xb", score=99.0, volume_usd=1)
    c = whales.WalletProfile("0xc", score=11.0, volume_usd=50)
    eq([p.address for p in whales.rank_wallets([a, b, c])], ["0xb", "0xc", "0xa"])
    return "ok"


@check("whale_trades: filters below the threshold and sorts by notional")
def _whale_trades():
    def t(usd):
        return whales.Trade("0xw", "BUY", "a", "c", 1, usd, usd, 1, "t", "Yes")

    out = whales.whale_trades([t(100), t(5000), t(2000)], 2000)
    eq([x.usd for x in out], [5000, 2000])
    return "2 of 3"


@check("alert: render contains the header, scores and the disclaimer")
def _alert():
    text = whales.render_alert([whales.WalletProfile("0xabcdef123456", score=88.0, n_trades=12,
                                                      volume_usd=50_000, winrate=0.75, n_closed=8,
                                                      age_days=9, roi_pct=12.5)])
    for needle in ("<b>", "score 88", "75%", "not financial advice"):
        if needle not in text:
            raise AssertionError(f"missing {needle!r}")
    return f"{len(text)} chars"


@check("alert: limit 0 prints no wallet rows")
def _alert_limit():
    p = whales.WalletProfile("0xabc", score=50)
    text = whales.render_alert([p], limit=0)
    if "1. " in text:
        raise AssertionError("printed a row")
    return "ok"


@check("alert: untrusted names are HTML-escaped")
def _alert_escape():
    p = whales.WalletProfile("0x<script>", score=1, name="<img onerror=x>")
    text = whales.render_alert([p])
    if "<script>" in text or "<img" in text:
        raise AssertionError("raw HTML survived")
    if "&lt;script&gt;" not in text:
        raise AssertionError("address was not escaped")
    return "escaped"


@check("alert: output stays under the Telegram 4096-char limit")
def _alert_len():
    profiles = [whales.WalletProfile(f"0x{i:040x}", score=50, n_trades=10, volume_usd=10_000,
                                     winrate=0.5, n_closed=10, age_days=10) for i in range(40)]
    text = whales.render_alert(profiles, limit=40)
    if len(text) > 4000:
        raise AssertionError(f"{len(text)} chars")
    return f"{len(text)} chars"


@check("summary: counts reconcile with the wallet list")
def _summary():
    payload = desk.load_fixture()
    s = whales.summary(payload, source="fixture")
    eq(s["counts"]["wallets"], len(s["wallets"]))
    eq(s["counts"]["trades"], len(whales.parse_trades(payload["trades"])))
    eq(s["counts"]["whale_trades"], len(whales.whale_trades(
        whales.parse_trades(payload["trades"]), s["config"]["whale_usd"])))
    eq(s["source"], "fixture")
    if s["counts"]["markets"] < 5:
        raise AssertionError("too few markets")
    return f"{s['counts']['wallets']} wallets"


@check("summary: totals.buy + totals.sell equals whale notional")
def _summary_totals():
    s = whales.summary(desk.load_fixture())
    t = s["totals"]
    near(t["buy_usd"] + t["sell_usd"], t["whale_usd"], tol=0.02)
    if t["largest_usd"] > t["whale_usd"]:
        raise AssertionError("largest ticket exceeds the total")
    return f"${t['whale_usd']:,.0f}"


@check("summary: a higher whale threshold shrinks the feed")
def _summary_threshold():
    payload = desk.load_fixture()
    low = whales.summary(payload, {"whale_usd": 2_000})
    high = whales.summary(payload, {"whale_usd": 10_000})
    if high["counts"]["whale_trades"] >= low["counts"]["whale_trades"]:
        raise AssertionError("threshold had no effect")
    if high["totals"]["whale_usd"] >= low["totals"]["whale_usd"]:
        raise AssertionError("notional did not fall")
    return f"{low['counts']['whale_trades']} → {high['counts']['whale_trades']}"


@check("summary: insider list is a subset of the ranked wallets")
def _summary_insiders():
    s = whales.summary(desk.load_fixture())
    addresses = {w["address"] for w in s["wallets"]}
    for row in s["insiders"]:
        if row["address"] not in addresses:
            raise AssertionError("insider not in wallet list")
        eq(row["insider_flag"], True)
    return f"{len(s['insiders'])} insiders"


@check("fixture: carries the live capture metadata")
def _fixture_meta():
    payload = desk.load_fixture()
    for key in ("captured_at", "source", "trades", "profiles", "markets"):
        if key not in payload:
            raise AssertionError(f"missing {key}")
    if len(payload["trades"]) < 100:
        raise AssertionError("fixture is too thin")
    if len(payload["profiles"]) < 6:
        raise AssertionError("too few wallets")
    if payload["captured_at"].count("-") < 2:
        raise AssertionError("captured_at is not a date")
    return f"{len(payload['trades'])} trades"


@check("fixture: every trade has the fields the parser needs")
def _fixture_trades():
    payload = desk.load_fixture()
    for row in payload["trades"]:
        for key in ("proxyWallet", "side", "size", "price", "timestamp", "title", "conditionId"):
            if key not in row:
                raise AssertionError(f"trade missing {key}")
        if row["side"] not in ("BUY", "SELL"):
            raise AssertionError(row["side"])
    return "ok"


# ---------------------------------------------------------------------------
# desk assembly
# ---------------------------------------------------------------------------


@check("desk: top_wallets ranks by notional and is deterministic")
def _top():
    rows = [
        {"proxyWallet": "0xa", "size": 10, "price": 1.0},
        {"proxyWallet": "0xb", "size": 50, "price": 1.0},
        {"proxyWallet": "0xa", "size": 40, "price": 1.0},
    ]
    eq(desk.top_wallets(rows, 2), ["0xa", "0xb"])
    eq(desk.top_wallets(rows, 2), desk.top_wallets(rows, 2))
    return "0xa first"


@check("desk: collect records a dead wallet without dropping the others")
def _collect_partial():
    class FakeClient:
        def trades(self, limit=250, min_cash=None):
            return [
                {"proxyWallet": "0xaaa", "side": "BUY", "size": 3000, "price": 1.0, "timestamp": 1,
                 "title": "a", "conditionId": "c1"},
                {"proxyWallet": "0xbbb", "side": "SELL", "size": 4000, "price": 1.0, "timestamp": 2,
                 "title": "b", "conditionId": "c2"},
            ]

        def activity(self, wallet, limit=500):
            if wallet == "0xaaa":
                raise poly.PolyError("429 rate limited")
            return [{"type": "TRADE", "side": "BUY", "proxyWallet": wallet, "size": 10, "price": 1,
                     "usdcSize": 10, "timestamp": 2, "conditionId": "c2", "asset": "z"}]

        def positions(self, wallet, limit=200):
            return []

        def closed_positions(self, wallet, limit=50):
            return []

        def value(self, wallet):
            return 1.0

        def markets(self, limit=12):
            return [{"question": "q", "conditionId": "c2", "outcomePrices": '["0.5", "0.5"]'}]

        def holders(self, condition_id, limit=10):
            return [{"token": "t", "holders": [{"proxyWallet": "0xbbb", "amount": 100}]}]

    payload = desk.collect(FakeClient(), wallets=4)
    eq(payload["source"], "live")
    eq(list(payload["profiles"]), ["0xbbb"])
    if not any("rate limited" in e for e in payload["errors"]):
        raise AssertionError("error was swallowed")
    eq(len(payload["markets"]), 1)
    return "1 of 2 + error"


@check("desk: collect survives a dead trades endpoint")
def _collect_dead():
    class Dead:
        def trades(self, **kw):
            raise poly.PolyError("503")

        def markets(self, limit=12):
            raise poly.PolyError("503")

    payload = desk.collect(Dead())
    eq(payload["trades"], [])
    eq(payload["profiles"], {})
    eq(len(payload["errors"]), 2)
    return "2 errors"


@check("desk: market_view parses the JSON-string outcome prices")
def _market_view():
    rows = [{
        "question": "Q?", "slug": "q", "conditionId": "0x1",
        "outcomePrices": '["0.62", "0.38"]', "outcomes": '["Yes", "No"]',
        "volume24hr": "1234.5", "liquidity": "99", "endDate": "2026-11-01T00:00:00Z",
        "spread": "0.01", "oneDayPriceChange": "0.04",
    }]
    view = desk.market_view(rows)
    eq(len(view), 1)
    near(view[0]["yes"], 0.62)
    eq(view[0]["outcomes"], ["Yes", "No"])
    near(view[0]["volume24hr"], 1234.5)
    eq(view[0]["question"], "Q?")
    return "parsed"


@check("desk: market_view tolerates junk instead of raising")
def _market_view_junk():
    view = desk.market_view([{"question": None, "outcomePrices": "not json", "volume24hr": "x"}])
    eq(view[0]["yes"], 0.0)
    eq(view[0]["volume24hr"], 0.0)
    eq(view[0]["question"], "")
    return "zeros"


# ---------------------------------------------------------------------------
# server over a real socket
# ---------------------------------------------------------------------------


class ServerFixture:
    def __init__(self):
        import server

        self.server_mod = server
        self.tmp = tempfile.TemporaryDirectory()
        server.CONFIG_PATH = Path(self.tmp.name) / "config.json"
        server.reset_cache()
        self.httpd = server.ThreadingHTTPServer(("127.0.0.1", 0), server.Handler)
        self.port = self.httpd.server_address[1]
        self.thread = threading.Thread(target=self.httpd.serve_forever, daemon=True)
        self.thread.start()

    def url(self, path):
        return f"http://127.0.0.1:{self.port}{path}"

    def get(self, path):
        with urllib.request.urlopen(self.url(path), timeout=15) as r:
            return r.status, r.read()

    def post(self, path, payload):
        data = json.dumps(payload).encode()
        req = urllib.request.Request(self.url(path), data=data,
                                     headers={"Content-Type": "application/json"}, method="POST")
        with urllib.request.urlopen(req, timeout=15) as r:
            return r.status, r.read()

    def post_raw(self, path, raw: bytes):
        req = urllib.request.Request(self.url(path), data=raw,
                                     headers={"Content-Type": "application/json"}, method="POST")
        try:
            with urllib.request.urlopen(req, timeout=15) as r:
                return r.status, r.read()
        except urllib.error.HTTPError as exc:
            return exc.code, exc.read()

    def close(self):
        self.httpd.shutdown()
        self.httpd.server_close()
        self.tmp.cleanup()


_SERVER: ServerFixture | None = None


def server_fixture() -> ServerFixture:
    global _SERVER
    if _SERVER is None:
        _SERVER = ServerFixture()
    return _SERVER


@check("server: / serves the terminal HTML")
def _s_root():
    status, body = server_fixture().get("/")
    eq(status, 200)
    if b"Whale Desk" not in body:
        raise AssertionError("page title missing")
    return f"{len(body)} bytes"


@check("server: /api/health reports version and fixture presence")
def _s_health():
    status, body = server_fixture().get("/api/health")
    eq(status, 200)
    data = json.loads(body)
    eq(data["ok"], True)
    eq(data["fixture"], True)
    if data["version"].count(".") != 2:
        raise AssertionError("version not semver-ish")
    return data["version"]


@check("server: /api/scan returns the fixture snapshot without network")
def _s_scan():
    status, body = server_fixture().get("/api/scan")
    eq(status, 200)
    data = json.loads(body)
    eq(data["source"], "fixture")
    eq(data["live"], False)
    if len(data["wallets"]) < 6:
        raise AssertionError("too few wallets")
    if not data["feed"] or not data["markets"]:
        raise AssertionError("empty sections")
    eq(data["counts"]["wallets"], len(data["wallets"]))
    return f"{len(data['wallets'])} wallets"


@check("server: /api/scan honours ?force=1 and stays consistent")
def _s_force():
    _, first = server_fixture().get("/api/scan")
    _, second = server_fixture().get("/api/scan?force=1")
    a, b = json.loads(first), json.loads(second)
    eq(a["counts"], b["counts"])
    return "ok"


@check("server: /api/wallets returns the ranked list only")
def _s_wallets():
    _, body = server_fixture().get("/api/wallets")
    data = json.loads(body)
    eq(sorted(data), ["at", "errors", "source", "totals", "wallets"])
    scores = [w["score"] for w in data["wallets"]]
    if scores != sorted(scores, reverse=True):
        raise AssertionError("not sorted")
    return f"{len(scores)} wallets"


@check("server: /api/feed returns whale prints, largest first")
def _s_feed():
    _, body = server_fixture().get("/api/feed")
    data = json.loads(body)
    usd = [t["usd"] for t in data["feed"]]
    if usd != sorted(usd, reverse=True):
        raise AssertionError("feed not sorted by notional")
    if min(usd) < 2000:
        raise AssertionError("sub-whale ticket in the feed")
    return f"{len(usd)} prints"


@check("server: /api/markets returns normalised metadata")
def _s_markets():
    _, body = server_fixture().get("/api/markets")
    data = json.loads(body)
    eq(len(data["markets"]), 12)
    for key in ("question", "yes", "volume24hr", "liquidity", "endDate"):
        if key not in data["markets"][0]:
            raise AssertionError(f"market missing {key}")
    return "12 markets"


@check("server: /api/copy replays a known wallet")
def _s_copy():
    _, body = server_fixture().get("/api/wallets")
    wallet = json.loads(body)["wallets"][0]["address"]
    status, raw = server_fixture().get(f"/api/copy?wallet={wallet}&stake=100")
    eq(status, 200)
    sim = json.loads(raw)
    near(sim["stake_usd"], 100.0)
    if sim["n_fills"] < 1:
        raise AssertionError("no fills")
    eq(sim["wallet"], wallet.lower())
    return f"{sim['n_fills']} fills"


@check("server: /api/copy accepts max_trades and slippage")
def _s_copy_params():
    _, body = server_fixture().get("/api/wallets")
    wallet = json.loads(body)["wallets"][0]["address"]
    _, raw = server_fixture().get(f"/api/copy?wallet={wallet}&stake=50&max_trades=3&slippage=0")
    sim = json.loads(raw)
    if sim["n_fills"] > 3:
        raise AssertionError(sim["n_fills"])
    near(sim["stake_usd"], 50.0)
    return "capped"


@check("server: /api/copy on an unknown wallet is a 404")
def _s_copy_404():
    try:
        server_fixture().get("/api/copy?wallet=0xdeadbeef")
    except urllib.error.HTTPError as exc:
        eq(exc.code, 404)
        eq(json.loads(exc.read())["error"], "wallet not in this snapshot")
        return "404"
    raise AssertionError("no 404")


@check("server: /api/copy without a wallet is a 400")
def _s_copy_400():
    try:
        server_fixture().get("/api/copy")
    except urllib.error.HTTPError as exc:
        eq(exc.code, 400)
        return "400"
    raise AssertionError("no 400")


@check("server: /api/export.csv has the documented header")
def _s_csv():
    _, body = server_fixture().get("/api/export.csv")
    lines = body.decode().strip().splitlines()
    header = lines[0].split(",")
    for col in ("address", "score", "volume_usd", "winrate", "insider_flag"):
        if col not in header:
            raise AssertionError(f"missing column {col}")
    if len(lines) < 7:
        raise AssertionError("csv has no rows")
    return f"{len(lines)-1} rows"


@check("server: /api/config redacts secret-ish keys")
def _s_config():
    server_fixture().post("/api/config", {"telegram_token": "123:abc", "stake_usd": 400})
    _, body = server_fixture().get("/api/config")
    data = json.loads(body)
    eq(data["telegram_token"], "***")
    near(data["stake_usd"], 400.0)
    return "redacted"


@check("server: unknown config keys are ignored")
def _s_config_unknown():
    server_fixture().post("/api/config", {"wibble": 1, "fresh_days": 30})
    _, body = server_fixture().get("/api/config")
    data = json.loads(body)
    if "wibble" in data:
        raise AssertionError("unknown key persisted")
    eq(data["fresh_days"], 30)
    server_fixture().post("/api/config", {"fresh_days": 45})
    return "ok"


@check("server: a malformed JSON body is a 400")
def _s_bad_json():
    status, body = server_fixture().post_raw("/api/config", b"{not json")
    eq(status, 400)
    if b"error" not in body:
        raise AssertionError("no error message")
    return "400"


@check("server: a config change reaches the next snapshot")
def _s_config_effect():
    _, base = server_fixture().get("/api/scan?force=1")
    before = json.loads(base)["counts"]["whale_trades"]
    server_fixture().post("/api/config", {"whale_usd": 9000})
    _, after_raw = server_fixture().get("/api/scan?force=1")
    after = json.loads(after_raw)["counts"]["whale_trades"]
    if after >= before:
        raise AssertionError(f"{before} → {after}")
    server_fixture().post("/api/config", {"whale_usd": 2000})
    _, reset_raw = server_fixture().get("/api/scan?force=1")
    eq(json.loads(reset_raw)["counts"]["whale_trades"], before)
    return f"{before} → {after}"


@check("server: POST /api/telegram returns escaped text")
def _s_tg():
    status, body = server_fixture().post("/api/telegram", {"limit": 2})
    eq(status, 200)
    data = json.loads(body)
    eq(data["chars"], len(data["text"]))
    if "<b>" not in data["text"]:
        raise AssertionError("no formatting")
    if "not financial advice" not in data["text"]:
        raise AssertionError("no disclaimer")
    return f"{data['chars']} chars"


@check("server: unknown route is a JSON 404")
def _s_404():
    try:
        server_fixture().get("/api/nope")
    except urllib.error.HTTPError as exc:
        eq(exc.code, 404)
        eq(json.loads(exc.read())["error"], "not found")
        return "404"
    raise AssertionError("no 404")


@check("server: path traversal is not served")
def _s_traversal():
    try:
        server_fixture().get("/../../etc/passwd")
    except urllib.error.HTTPError as exc:
        eq(exc.code, 404)
        return "404"
    raise AssertionError("traversal returned 200")


@check("server: HEAD returns headers and no body")
def _s_head():
    req = urllib.request.Request(server_fixture().url("/api/health"), method="HEAD")
    with urllib.request.urlopen(req, timeout=15) as r:
        eq(r.status, 200)
        eq(r.read(), b"")
    return "ok"


@check("server: the config file is written with 0600")
def _s_perms():
    import os
    import stat

    server_fixture().post("/api/config", {"stake_usd": 200})
    mode = stat.S_IMODE(os.stat(server_fixture().server_mod.CONFIG_PATH).st_mode)
    eq(mode, 0o600)
    return "0600"


# ---------------------------------------------------------------------------
# runner
# ---------------------------------------------------------------------------


def main(argv: list[str] | None = None) -> int:
    argv = argv if argv is not None else sys.argv[1:]
    quiet = "--quiet" in argv
    as_json = "--json" in argv

    if _SERVER is not None:
        _SERVER.close()

    passed = sum(1 for _, ok, _ in RESULTS if ok)
    failed = [r for r in RESULTS if not r[1]]

    if as_json:
        print(json.dumps({
            "total": len(RESULTS),
            "passed": passed,
            "failed": len(failed),
            "checks": [{"name": n, "ok": ok, "detail": d} for n, ok, d in RESULTS],
        }, indent=2))
    elif not quiet:
        width = max(len(n) for n, _, _ in RESULTS) + 2
        for name, ok, detail in RESULTS:
            mark = "PASS" if ok else "FAIL"
            print(f"  [{mark}] {name.ljust(width)} {detail}")
        print()
        print(f"  {passed}/{len(RESULTS)} checks passed")

    if failed and not quiet and not as_json:
        print("\n  failures:")
        for name, _, detail in failed:
            print(f"    - {name}: {detail}")

    return 0 if not failed else 1


if __name__ == "__main__":
    raise SystemExit(main())
