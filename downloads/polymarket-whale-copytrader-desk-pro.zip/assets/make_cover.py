#!/usr/bin/env python3
"""Generate assets/cover.png — the 2400x1600 product cover.

Reproducible: same input, same pixels. Only Pillow is required, and only to
build the cover; the product itself is stdlib-only.

    python3 assets/make_cover.py

Every number drawn on the card is read from the fixture through the engine, so
the cover cannot drift away from what the software actually reports.
"""

from __future__ import annotations

import sys
from pathlib import Path

from PIL import Image, ImageDraw, ImageFilter, ImageFont

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))
import desk  # noqa: E402
import whales  # noqa: E402

W, H = 2400, 1600
OUT = ROOT / "assets" / "cover.png"

BG_TOP = (6, 9, 13)
BG_BOT = (10, 17, 25)
INK = (232, 239, 248)
DIM = (127, 142, 164)
FAINT = (76, 90, 108)
LINE = (29, 40, 54)
GREEN = (53, 224, 161)
BLUE = (106, 168, 255)
AMBER = (255, 179, 71)
GOLD = (232, 194, 106)

FONT_DIRS = [
    Path("/System/Library/Fonts/Supplemental"),
    Path("/System/Library/Fonts"),
    Path("/Library/Fonts"),
]


def font(names: list[str], size: int) -> ImageFont.FreeTypeFont:
    for directory in FONT_DIRS:
        for name in names:
            path = directory / name
            if path.exists():
                try:
                    return ImageFont.truetype(str(path), size)
                except OSError:
                    continue
    return ImageFont.load_default(size)


def sans(size: int, bold: bool = False) -> ImageFont.FreeTypeFont:
    return font(["Arial Bold.ttf", "Arial.ttf"] if bold else ["Arial.ttf"], size)


def mono(size: int) -> ImageFont.FreeTypeFont:
    return font(["Menlo.ttc", "SFNSMono.ttf", "Courier New.ttf"], size)


def gradient() -> Image.Image:
    base = Image.new("RGB", (1, H))
    px = base.load()
    for y in range(H):
        t = (y / (H - 1)) ** 0.85
        px[0, y] = tuple(int(BG_TOP[i] + (BG_BOT[i] - BG_TOP[i]) * t) for i in range(3))
    return base.resize((W, H), Image.BILINEAR)


def glow(canvas: Image.Image, center: tuple[int, int], radius: int, color: tuple[int, int, int], alpha: int) -> None:
    layer = Image.new("RGBA", (W, H), (0, 0, 0, 0))
    d = ImageDraw.Draw(layer)
    steps = 26
    for i in range(steps, 0, -1):
        r = int(radius * i / steps)
        a = int(alpha * (1 - i / steps) ** 1.6)
        d.ellipse((center[0] - r, center[1] - r, center[0] + r, center[1] + r), fill=color + (a,))
    canvas.alpha_composite(layer.filter(ImageFilter.GaussianBlur(60)))


def grid(draw: ImageDraw.ImageDraw) -> None:
    for x in range(0, W, 80):
        draw.line([(x, 0), (x, H)], fill=(255, 255, 255, 7), width=1)
    for y in range(0, H, 80):
        draw.line([(0, y), (W, y)], fill=(255, 255, 255, 7), width=1)


def text(draw, x, y, s, f, fill, anchor=None):
    draw.text((x, y), s, font=f, fill=fill, anchor=anchor)


def rounded(draw, box, radius, fill=None, outline=None, width=1):
    draw.rounded_rectangle(box, radius=radius, fill=fill, outline=outline, width=width)


def logo(draw, x, y, scale: float = 1.0) -> None:
    s = scale
    rounded(draw, (x, y, x + int(76 * s), y + int(76 * s)), int(20 * s),
            fill=(15, 23, 33), outline=(41, 57, 76), width=2)
    pts = [
        (x + int(14 * s), y + int(52 * s)),
        (x + int(25 * s), y + int(34 * s)),
        (x + int(35 * s), y + int(44 * s)),
        (x + int(45 * s), y + int(22 * s)),
        (x + int(61 * s), y + int(22 * s)),
    ]
    draw.line(pts, fill=GREEN, width=int(4 * s), joint="curve")
    r = int(5 * s)
    cx, cy = x + int(61 * s), y + int(22 * s)
    draw.ellipse((cx - r, cy - r, cx + r, cy + r), fill=GOLD)


def chip(draw, x, y, label, fg, bg, f) -> int:
    w = draw.textlength(label, font=f)
    pad_x, h = 22, 46
    rounded(draw, (x, y, x + w + pad_x * 2, y + h), 23, fill=bg, outline=fg, width=1)
    text(draw, x + pad_x, y + h // 2, label, f, fg, anchor="lm")
    return int(w + pad_x * 2)


def money(v: float) -> str:
    if abs(v) >= 1_000_000:
        return f"${v/1_000_000:.1f}M"
    if abs(v) >= 1_000:
        return f"${v/1_000:.0f}k"
    return f"${v:,.0f}"


def main() -> int:
    payload = desk.load_fixture()
    data = whales.summary(payload)
    wallets = data["wallets"][:5]
    counts, totals = data["counts"], data["totals"]

    canvas = gradient().convert("RGBA")
    glow(canvas, (1850, 210), 720, (24, 70, 108), 120)
    glow(canvas, (280, 1330), 640, (14, 88, 72), 95)

    overlay = Image.new("RGBA", (W, H), (0, 0, 0, 0))
    grid(ImageDraw.Draw(overlay))
    canvas.alpha_composite(overlay)
    draw = ImageDraw.Draw(canvas)

    # ---- header -----------------------------------------------------------
    logo(draw, 120, 104)
    text(draw, 218, 114, "WHALE DESK", sans(34, bold=True), INK)
    text(draw, 219, 157, "POLYMARKET  ·  COPY-TRADE RESEARCH", mono(18), DIM)

    chip(draw, W - 120 - 360, 114, "v1.0.0  ·  PUBLIC DATA", GREEN, (13, 38, 32), mono(19))

    # ---- headline ---------------------------------------------------------
    text(draw, 118, 300, "Wallets leave", sans(102, bold=True), INK)
    text(draw, 118, 412, "a trail.", sans(102, bold=True), (154, 180, 210))
    text(draw, 122, 570, "Win rates, ages and sizes, scored together —", sans(34), DIM)
    text(draw, 122, 618, "then replayed at your stake, before you copy.", sans(34), DIM)

    # ---- feature list -----------------------------------------------------
    feats = [
        ("FRESH + GREEN", "young wallets with a real, sized record", GOLD),
        ("COPY SIM", "every buy replayed at your stake, net of slippage", GREEN),
        ("RATE-LIMITED", "one request at a time; 429 is an error, not a zero", BLUE),
        ("LOCAL", "stdlib Python, 127.0.0.1, no wallet, no orders", GREEN),
    ]
    y = 790
    for tag, desc, color in feats:
        draw.ellipse((124, y + 10, 140, y + 26), fill=color)
        text(draw, 160, y, tag, mono(23), color)
        text(draw, 400, y - 2, desc, sans(28), (196, 210, 226))
        y += 60

    # ---- metrics ----------------------------------------------------------
    stats = [
        (money(totals["whale_usd"]), "whale notional"),
        (str(counts["whale_trades"]), "prints ≥ $2k"),
        (str(counts["wallets"]), "wallets scored"),
        (str(counts["insiders"]), "fresh + green"),
    ]
    for x, (value, label) in zip((122, 400, 690, 970), stats):
        text(draw, x, 1080, value, sans(58, bold=True), INK)
        text(draw, x, 1152, label.upper(), mono(16), FAINT)

    # ---- card -------------------------------------------------------------
    card = (1180, 286, 2282, 1362)
    rounded(draw, card, 26, fill=(11, 17, 25, 238), outline=LINE, width=2)

    draw.ellipse((1218, 322, 1232, 336), fill=GREEN)
    text(draw, 1244, 316, "wallets by score", mono(21), DIM)
    text(draw, 2244, 316, "copy sim at $250", mono(19), FAINT, anchor="ra")
    draw.line([(1208, 364), (2254, 364)], fill=LINE, width=1)

    headers = [("WALLET", 1218), ("AGE", 1770), ("VOLUME", 1940), ("WIN", 2084), ("SCORE", 2244)]
    for label, hx in headers:
        anchor = "ra" if label in ("AGE", "VOLUME", "WIN", "SCORE") else "la"
        text(draw, hx, 392, label, mono(18), FAINT, anchor=anchor)
    draw.line([(1208, 430), (2254, 430)], fill=(24, 33, 45), width=1)

    row_y = 466
    for i, w in enumerate(wallets):
        if i % 2 == 1:
            rounded(draw, (1200, row_y - 18, 2262, row_y + 74), 10, fill=(14, 21, 30))
        text(draw, 1218, row_y - 4, str(i + 1), mono(18), FAINT)
        name = w["name"] or ""
        if name.startswith("0x") and len(name) > 20:
            name = w["pseudonym"] or w["address"][:10]
        name = name[:26]
        text(draw, 1252, row_y - 8, name, sans(26, bold=True), INK)
        text(draw, 1252, row_y + 26, w["address"][:10] + "…" + w["address"][-4:], mono(16), FAINT)
        text(draw, 1770, row_y, f"{w['age_days']:.0f}d", mono(22), DIM, anchor="ra")
        text(draw, 1940, row_y, money(w["volume_usd"]), mono(22), (178, 195, 214), anchor="ra")
        text(draw, 2084, row_y, f"{w['winrate']*100:.0f}%", mono(22),
             GREEN if w["winrate"] >= 0.5 else DIM, anchor="ra")
        text(draw, 2244, row_y, f"{w['score']:.0f}", mono(30), INK, anchor="ra")
        bar_w = int(min(1.0, w["score"] / 100.0) * 70)
        rounded(draw, (2244 - bar_w - 8, row_y + 40, 2236, row_y + 45), 2, fill=(31, 44, 60))
        rounded(draw, (2244 - bar_w - 8, row_y + 40, 2244 - bar_w - 8 + max(6, bar_w), row_y + 45), 2, fill=GREEN)
        if w["insider_flag"]:
            text(draw, 1252, row_y + 44, "FRESH + GREEN", mono(13), GOLD)
        row_y += 112

    draw.line([(1208, 1032), (2254, 1032)], fill=LINE, width=1)
    text(draw, 1218, 1058, "largest prints", mono(19), FAINT)
    text(draw, 2244, 1058, "side · notional · price", mono(17), FAINT, anchor="ra")

    fy = 1098
    for t in data["feed"][:4]:
        tag_color = GREEN if t["side"] == "BUY" else (255, 97, 113)
        text(draw, 1218, fy, t["side"], mono(18), tag_color)
        text(draw, 1310, fy, money(t["usd"]), mono(21), INK)
        text(draw, 1440, fy, f"@ {t['price']:.2f}", mono(19), DIM)
        text(draw, 1570, fy, t["outcome"][:8], mono(18), (150, 168, 188))
        title = t["title"][:42]
        text(draw, 1710, fy, title, sans(19), (186, 202, 220))
        fy += 44

    # ---- footer -----------------------------------------------------------
    draw.line([(120, 1452), (2282, 1452)], fill=(26, 35, 47), width=1)
    text(draw, 120, 1490, "polymarket-whale-copytrader-desk-pro", sans(27, bold=True), (168, 186, 206))
    text(draw, 120, 1530,
         "2400 × 1600  ·  Python 3.9+  ·  no dependencies  ·  no wallet  ·  not financial advice",
         mono(18), FAINT)
    text(draw, 2282, 1498, "80 self-checks", mono(21), DIM, anchor="ra")
    text(draw, 2282, 1534, "verify.py --json", mono(18), FAINT, anchor="ra")

    OUT.parent.mkdir(parents=True, exist_ok=True)
    canvas.convert("RGB").save(OUT, "PNG", optimize=True)
    print(f"wrote {OUT} ({OUT.stat().st_size // 1024} KiB)")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
