"""Snapshot assembly: turn live API calls into the payload `whales.summary` reads.

Two rules, both learned from watching this API:

1. **Fan-out is the enemy.** The public data API starts answering 429 once you
   open a handful of connections at once. `collect()` therefore walks wallets
   one at a time through the throttled client and stops early rather than
   hammering a limit it has already hit.
2. **Partial is fine, silent is not.** If four of eight wallets fail, the
   snapshot still ships with four wallets and four errors. Every error is
   returned to the caller and rendered in the terminal footer.

The fixture path is a plain JSON read, so the desk works with no network at
all — which is also how the self-check runs.
"""

from __future__ import annotations

import json
import time
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

import poly
import whales

ROOT = Path(__file__).resolve().parent
FIXTURE = ROOT / "tests" / "fixtures" / "polymarket.json"


def _now() -> str:
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


def load_fixture(path: str | Path | None = None) -> dict:
    payload = json.loads(Path(path or FIXTURE).read_text())
    payload.setdefault("source", "fixture")
    return payload


def top_wallets(trades: list[dict], limit: int = 8) -> list[str]:
    """Rank wallets by notional traded in the window, ties broken deterministically."""
    totals: dict[str, float] = {}
    for row in trades:
        wallet = (row.get("proxyWallet") or "").lower()
        if not wallet:
            continue
        totals[wallet] = totals.get(wallet, 0.0) + whales.trade_usd(row)
    ranked = sorted(totals.items(), key=lambda kv: (-kv[1], kv[0]))
    return [wallet for wallet, _ in ranked[: max(1, limit)]]


def bundle(client: poly.Client, wallet: str, activity_limit: int = 500) -> dict:
    """One wallet's calls. Any failure is the caller's to record."""
    return {
        "activity": client.activity(wallet, limit=activity_limit),
        "positions": client.positions(wallet, limit=200),
        "closed": client.closed_positions(wallet, limit=50),
        "value": client.value(wallet),
    }


def holder_wallets(rows: list[dict], limit: int = 10) -> list[str]:
    """Flatten `/holders` into wallet addresses, Yes and No sides included."""
    out: list[str] = []
    for group in rows or []:
        for row in (group.get("holders") or [])[:limit]:
            wallet = (row.get("proxyWallet") or "").lower()
            if wallet and wallet not in out:
                out.append(wallet)
    return out


def collect(client: poly.Client | None = None, wallets: int = 8, trade_limit: int = 250,
            min_cash: int | None = None, market_limit: int = 12,
            holder_markets: int = 4, sleep: float = 0.0) -> dict:
    """Build a snapshot from the public API.

    Candidates come from two places on purpose: the wallets printing the largest
    trades, and the wallets holding the largest positions in the busiest
    markets. Trade flow alone over-samples market makers and longshot sprayers;
    holders alone over-samples bagholders. Half of each makes a better table.

    `sleep` is a deliberate extra pause between wallets on top of the client's
    own throttle; leave it at 0 unless the API is already complaining.
    """
    client = client or poly.Client()
    errors: list[str] = []
    trades: list[dict] = []
    markets: list[dict] = []
    try:
        trades = client.trades(limit=trade_limit, min_cash=min_cash)
    except poly.PolyError as exc:
        errors.append(f"trades: {exc}")
    try:
        markets = client.markets(limit=market_limit)
    except poly.PolyError as exc:
        errors.append(f"markets: {exc}")

    trade_slots = max(1, wallets // 2)
    candidates = top_wallets(trades, trade_slots)
    for market in markets[:holder_markets]:
        try:
            rows = client.holders(market.get("conditionId") or "", limit=10)
        except poly.PolyError as exc:
            errors.append(f"holders {market.get('slug', '')[:20]}: {exc}")
            continue
        for wallet in holder_wallets(rows):
            if wallet not in candidates:
                candidates.append(wallet)
            if len(candidates) >= wallets:
                break
        if len(candidates) >= wallets:
            break

    profiles: dict[str, dict] = {}
    for wallet in candidates[:wallets]:
        try:
            profiles[wallet] = bundle(client, wallet)
        except poly.PolyError as exc:
            errors.append(f"{wallet[:10]}…: {exc}")
        if sleep:
            time.sleep(sleep)

    return {
        "captured_at": _now(),
        "source": "live",
        "trades": trades,
        "profiles": profiles,
        "markets": markets,
        "errors": errors,
    }


def market_view(rows: list[dict], limit: int = 12) -> list[dict]:
    """Normalise gamma rows to the handful of fields the terminal draws."""
    out: list[dict] = []
    for row in rows[:limit]:
        try:
            prices = json.loads(row.get("outcomePrices") or "[]")
        except (TypeError, ValueError):
            prices = []
        outcomes = row.get("outcomes")
        if isinstance(outcomes, str):
            try:
                outcomes = json.loads(outcomes)
            except ValueError:
                outcomes = []
        out.append({
            "question": row.get("question") or "",
            "slug": row.get("slug") or "",
            "conditionId": row.get("conditionId") or "",
            "volume24hr": _num(row.get("volume24hr")),
            "liquidity": _num(row.get("liquidity") or row.get("liquidityNum")),
            "endDate": row.get("endDate") or "",
            "yes": _num(prices[0]) if prices else _num(row.get("lastTradePrice")),
            "outcomes": outcomes or [],
            "spread": _num(row.get("spread")),
            "change24h": _num(row.get("oneDayPriceChange")),
        })
    return out


def _num(value: Any) -> float:
    try:
        return round(float(value), 4)
    except (TypeError, ValueError):
        return 0.0
