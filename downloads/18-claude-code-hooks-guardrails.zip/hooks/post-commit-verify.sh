#!/usr/bin/env bash
# Automated test runner after agent modifications
echo "[*] Running automated test verification..."
if [ -f "pytest.ini" ] || [ -d "tests" ]; then
    pytest -q --tb=short 2>&1 || { echo "[-] Tests failed! Rolling back changes..."; exit 1; }
fi
echo "[+] All checks passed."
exit 0
