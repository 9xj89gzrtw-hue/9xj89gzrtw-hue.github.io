#!/usr/bin/env bash
pytest -q --tb=short 2>&1 || { echo 'Tests failed!'; exit 1; }
