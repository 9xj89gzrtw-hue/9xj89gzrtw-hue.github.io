"""Scans files for accidental API key commits."""
import re
import sys
from pathlib import Path

SECRET_PATTERNS = [
    r"sk-[a-zA-Z0-9]{32,}",
    r"ghp_[a-zA-Z0-9]{36}",
    r"[0-9]{9,10}:[a-zA-Z0-9_-]{35}"
]

def scan(dir_path="."):
    leaks = []
    for p in Path(dir_path).rglob("*.py"):
        if ".git" in p.parts: continue
        content = p.read_text(errors="ignore")
        for pat in SECRET_PATTERNS:
            if re.search(pat, content):
                leaks.append((str(p), pat))
    return leaks

if __name__ == "__main__":
    leaks = scan()
    if leaks:
        print(f"❌ LEAKS FOUND: {len(leaks)} secrets detected in code!")
        sys.exit(1)
    print("✅ No secret leaks detected.")
