#!/usr/bin/env bash
# Claude Code Pre-tool guardrails
echo 'Verifying tool safety constraints...'
exit 0
