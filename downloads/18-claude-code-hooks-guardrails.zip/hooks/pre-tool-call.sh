#!/usr/bin/env bash
# Claude Code Pre-Tool execution safety gate
CMD="$1"
if echo "$CMD" | grep -iE "rm -rf /|mkfs|dd if=|chmod -R 777" > /dev/null; then
    echo "❌ CRITICAL SAFETY VIOLATION: Dangerous destructive command blocked!"
    exit 1
fi
exit 0
