@echo off
echo Очистка временных файлов шейдеров DirectX и NVIDIA...
del /q /f /s "%localappdata%\D3DSCache\*.*" 2>nul
del /q /f /s "%localappdata%\NVIDIA\DXCache\*.*" 2>nul
echo [+] Готово!
