#!/usr/bin/env python3
"""Steam Cache & Shader Flush Utility."""
print("Steam Cache Flush: Clears HTTP cache, browser cookies, and shader logs.")
