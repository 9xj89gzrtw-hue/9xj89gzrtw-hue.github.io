# 🐙 GitHub & Postgres MCP Server Bundle
Готовые конфиги и пошаговый мануал по подключению GitHub и PostgreSQL к Claude Code и Cursor.