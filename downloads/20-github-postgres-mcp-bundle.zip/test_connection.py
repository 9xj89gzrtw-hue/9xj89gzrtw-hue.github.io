import psycopg2
print('PostgreSQL MCP helper: Ready for connection testing.')
