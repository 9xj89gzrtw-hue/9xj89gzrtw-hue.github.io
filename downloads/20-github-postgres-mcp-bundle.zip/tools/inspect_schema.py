"""Introspects Postgres schema and outputs markdown table."""
def get_mock_schema():
    return """
    ### Таблица: users
    - id: UUID (PRIMARY KEY)
    - email: VARCHAR(255) (UNIQUE)
    - created_at: TIMESTAMPTZ

    ### Таблица: orders
    - id: VARCHAR(32) (PRIMARY KEY)
    - user_id: UUID (FOREIGN KEY)
    - amount_rub: NUMERIC(10, 2)
    """

if __name__ == "__main__":
    print(get_mock_schema())
