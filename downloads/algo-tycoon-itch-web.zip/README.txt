AI & Market Tycoon — standalone browser build

Open index.html in any modern browser, or upload this zip to itch.io
(Kind: HTML, "This file will be played in the browser").

Start: 1 000 RUB and one server rack. Take orders in one click, buy racks,
grow from freelance to the quantum cluster.
Free: chapters 1-2 (16 orders, 4 upgrades, reputation).
Pro: chapter 3 "Wall Street & Quantum Cluster", $1 000 000 sandbox,
x5/x10 speed, crisis constructor and a report export.
Unlock with a TW1-ALGO-... or TW1-ALL-... key, or buy by card/SBP:
https://plati.market/itm/algo-tycoon-pro-algo-trading-and-pipeline-simulator-with-sandbox/6365339

No network calls, no telemetry, progress stays in localStorage.
