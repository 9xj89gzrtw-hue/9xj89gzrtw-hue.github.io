Algo Tycoon Pro — standalone browser build

Open index.html in any modern browser, or upload this zip to itch.io
(Kind: HTML, "This file will be played in the browser").

Free tier: 6 pipeline cards, act I.
Pro: 11 cards, sandbox, level editor, telemetry.
Unlock with a TW1-ALGO-… or TW1-ALL-… key, or buy by card/SBP:
https://plati.market/itm/algo-tycoon-pro-algo-trading-and-pipeline-simulator-with-sandbox/6365339

No network calls, no telemetry, progress stays in localStorage.
