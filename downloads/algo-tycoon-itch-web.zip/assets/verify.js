/* DefiLlama fee-audit storefront — on-chain payment verification.
 * Works in the browser (window.DefiAudit) and in Node (module.exports) so the
 * same code that unlocks the page is the code that gets tested. */
(function (root, factory) {
  const api = factory();
  if (typeof module === "object" && module.exports) module.exports = api;
  root.DefiAudit = api;
})(typeof globalThis !== "undefined" ? globalThis : this, function () {
  "use strict";

  const CONFIG = {
    USDC: "0x833589fcd6edb6e08f4c7c32d4f71b54bda02913",
    PAY_TO: "0x72Aa6edDE71B94f6b99c8e52EdC02B5C75F74d1a",
    CHAIN_ID: "0x2105",
    RPCS: [
      "https://mainnet.base.org",
      "https://base-rpc.publicnode.com",
      "https://base.llamarpc.com",
      "https://1rpc.io/base"
    ],
    PRICES: { "9": 9000000n, "12": 12000000n, "29": 29000000n, "99": 99000000n }
  };

  const TRANSFER =
    "0xddf252ad1be2c89b69c2b068fc378daa952ba7f163c4a11628f55a4df523b3ef";

  const pad32 = h => "0x" + h.replace(/^0x/, "").toLowerCase().padStart(64, "0");
  const HASH_RE = /^0x[0-9a-fA-F]{64}$/;
  const RPC_TIMEOUT_MS = 9000;

  async function rpc(method, params, opts) {
    const urls = (opts && opts.rpcs) || CONFIG.RPCS;
    const timeout = (opts && opts.timeout) || RPC_TIMEOUT_MS;
    let lastErr;
    for (const url of urls) {
      // A dead endpoint must not hang the page: without a deadline the browser
      // waits on the socket for a minute or more and the buyer sees "checking".
      const ctl = typeof AbortController === "function" ? new AbortController() : null;
      const timer = ctl ? setTimeout(() => ctl.abort(), timeout) : null;
      try {
        const res = await fetch(url, {
          method: "POST",
          headers: { "content-type": "application/json" },
          body: JSON.stringify({ jsonrpc: "2.0", id: 1, method, params }),
          signal: ctl ? ctl.signal : undefined
        });
        const j = await res.json();
        if (j.error) { lastErr = new Error(j.error.message); continue; }
        return j.result;
      } catch (e) { lastErr = e; }
      finally { if (timer) clearTimeout(timer); }
    }
    throw lastErr || new Error("all RPC endpoints failed");
  }

  /** Sum every native-USDC Transfer into `to` inside the receipt's logs. */
  function sumUsdcIn(receipt, to) {
    const want = pad32(to);
    const usdc = CONFIG.USDC.toLowerCase();
    let total = 0n;
    for (const l of receipt.logs || []) {
      if (String(l.address).toLowerCase() !== usdc) continue;
      if (String(l.topics && l.topics[0]).toLowerCase() !== TRANSFER) continue;
      if (String(l.topics[2]).toLowerCase() !== want) continue;
      total += BigInt(l.data);
    }
    return total;
  }

  /** Load a receipt and make sure it is a successful Base transaction. */
  async function loadReceipt(hash, o) {
    const clean = String(hash || "").trim();
    if (!HASH_RE.test(clean))
      throw new Error("That is not a transaction hash — a Base hash is 0x followed by 64 hex characters.");
    const h = clean.toLowerCase();
    if (o && o.usedHashes && o.usedHashes.includes(h))
      throw new Error("This hash was already redeemed in this browser. Re-open the download link, or mail us the hash for a re-issue.");

    const receipt = await rpc("eth_getTransactionReceipt", [h], { rpcs: o && o.rpcs });
    if (!receipt)
      throw new Error("No receipt yet. The transaction is unknown or still pending — wait for a confirmation and retry.");
    if (receipt.status !== "0x1")
      throw new Error("That transaction reverted (status 0). Nothing was transferred, so nothing unlocks.");
    return { receipt, hash: h };
  }

  /**
   * Verify that a transaction paid at least `usd` USDC to our Base address.
   * Used by the fixed-price tools ($9, $12) that have a single tier.
   */
  async function verifyAtLeast(hash, usd, opts) {
    const o = opts || {};
    const cfg = Object.assign({}, CONFIG, o.config || {});
    const min = BigInt(Math.round(Number(usd) * 1e6));
    if (!(min > 0n)) throw new Error("No price configured for that product.");
    const { receipt, hash: h } = await loadReceipt(hash, o);
    const received = sumUsdcIn(receipt, cfg.PAY_TO);
    if (received === 0n)
      throw new Error("No USDC transfer to " + cfg.PAY_TO.slice(0, 6) + "…" + cfg.PAY_TO.slice(-4) +
        " in that transaction. If you paid from an exchange, the withdrawal hash is the exchange's — find the transfer it produced, or pay directly from a wallet.");
    if (received < min)
      throw new Error("This transaction carried " + Number(received) / 1e6 +
        " USDC, and the price is " + Number(min) / 1e6 + " USDC. Send the difference and verify the second hash.");
    return { receipt, received, hash: h };
  }

  /**
   * Verify a Base tx hash and decide which tier it unlocks.
   * Returns {receipt, received, tier, hash} or throws an Error with a
   * human-readable reason (the page prints it verbatim).
   */
  async function verify(hash, opts) {
    const o = opts || {};
    const cfg = Object.assign({}, CONFIG, o.config || {});
    const { receipt, hash: h } = await loadReceipt(hash, o);
    const received = sumUsdcIn(receipt, cfg.PAY_TO);
    if (received === 0n)
      throw new Error("No USDC transfer to " + cfg.PAY_TO.slice(0, 6) + "…" + cfg.PAY_TO.slice(-4) +
        " in that transaction. If you paid from an exchange, the withdrawal hash is the exchange's — find the transfer it produced, or pay directly from a wallet.");

    let tier = null;
    if (received >= cfg.PRICES["99"]) tier = "99";
    else if (received >= cfg.PRICES["29"]) tier = "29";
    else throw new Error("Amount is " + Number(received) / 1e6 + " USDC — under the $29 minimum. Send the difference and verify the second hash, or mail us both hashes.");

    return { receipt, received, tier, hash: h };
  }

  /* --- offline license keys ------------------------------------------------
   *
   * A key is TW1-<CODE>-<KEY_ID>-<SIGNATURE>: an ECDSA P-256 / SHA-256
   * signature (base64url over the raw 64-byte IEEE P1363 pair) of the string
   * "TW1-<CODE>-<KEY_ID>". The public key below verifies it with crypto.subtle,
   * so a buyer who paid by card gets Pro in the same millisecond — no server,
   * no bot, no receipt mailed to anyone. The private key stays offline.
   *
   * CODE "ALL" is universal: it opens every product.
   */
  const LICENSE_PUBLIC_KEY = {
    kty: "EC",
    crv: "P-256",
    x: "YVH3fyYkuivpkuKQjUqw02XxX3mO5FadXsxijuK52so",
    y: "POqoRl3cMmg1UUxmwpCDBj2q3kVqwuH-EySTT3zcefQ"
  };

  /* slug (data-product, localStorage) <-> code (what is inside the key) */
  const LICENSE_PRODUCTS = {
    "audio-dub-studio": "AUDIO",
    "tg-chats": "TG",
    "docsearch": "DOC",
    "newsflow": "NEWS",
    "live-radar": "RADAR",
    "data-clipper": "CLIP",
    "base-tax-audit": "TAX",
    "all-in-one": "ALL"
  };
  const LICENSE_CODE_SLUG = Object.fromEntries(
    Object.keys(LICENSE_PRODUCTS).map(slug => [LICENSE_PRODUCTS[slug], slug])
  );

  const UNIVERSAL_CODE = "ALL";

  function b64uToBytes(text) {
    const b64 = String(text).replace(/-/g, "+").replace(/_/g, "/");
    const pad = b64.length % 4 ? "=".repeat(4 - (b64.length % 4)) : "";
    const bin = atob(b64 + pad);
    const out = new Uint8Array(bin.length);
    for (let i = 0; i < bin.length; i += 1) out[i] = bin.charCodeAt(i);
    return out;
  }

  /** Split a key without verifying it. Never throws.
   *  The base64url signature is case-sensitive and may contain "-", so the key
   *  is cut from the left by a fixed-shape regex, never by lastIndexOf("-"). */
  function parseLicense(text) {
    const clean = String(text == null ? "" : text).trim().replace(/\s+/g, "");
    const m = /^(TW1)-([A-Z0-9]{2,8})-([A-Z0-9]{6})-(.+)$/i.exec(clean);
    if (!m) return { ok: false, error: "format", key: clean };
    const signature = m[4];
    if (!/^[A-Za-z0-9_-]{86}$/.test(signature)) return { ok: false, error: "format", key: clean };
    const code = m[2].toUpperCase();
    const kid = m[3].toUpperCase();
    return {
      ok: true,
      version: "TW1",
      code,
      kid,
      payload: "TW1-" + code + "-" + kid,
      signature,
      key: "TW1-" + code + "-" + kid + "-" + signature
    };
  }

  function isLicenseKey(text) {
    return /^TW1-/i.test(String(text == null ? "" : text).trim());
  }

  /** Does a verified code open this product? `ALL` opens everything. */
  function licenseCovers(code, product) {
    if (!product) return true;
    const want = LICENSE_PRODUCTS[String(product).toLowerCase()] ||
      (/^[A-Z0-9]{2,8}$/.test(product) ? product : null);
    if (!want) return false;
    return code === UNIVERSAL_CODE || code === want;
  }

  let licenseKeyPromise = null;
  function licenseCryptoKey() {
    if (!licenseKeyPromise) {
      const subtle = globalThis.crypto && globalThis.crypto.subtle;
      if (!subtle) return Promise.reject(new Error("WebCrypto is not available in this browser."));
      licenseKeyPromise = subtle.importKey(
        "jwk",
        LICENSE_PUBLIC_KEY,
        { name: "ECDSA", namedCurve: "P-256" },
        false,
        ["verify"]
      );
    }
    return licenseKeyPromise;
  }

  /**
   * Verify a TW1 key. Resolves (never rejects) with
   *   { valid, code, kid, slug, key, error? }
   * error is one of: format | signature | product | crypto.
   */
  async function verifyLicense(text, opts) {
    const o = opts || {};
    const parsed = parseLicense(text);
    if (!parsed.ok) return { valid: false, error: "format", key: parsed.key };
    const product = o.product == null ? null : String(o.product).toLowerCase();
    try {
      const key = await licenseCryptoKey();
      const sig = b64uToBytes(parsed.signature);
      if (sig.length !== 64) return { valid: false, error: "signature", code: parsed.code, kid: parsed.kid };
      const ok = await globalThis.crypto.subtle.verify(
        { name: "ECDSA", hash: "SHA-256" },
        key,
        sig,
        new TextEncoder().encode(parsed.payload)
      );
      if (!ok) return { valid: false, error: "signature", code: parsed.code, kid: parsed.kid };
    } catch (e) {
      return { valid: false, error: "crypto", message: String((e && e.message) || e) };
    }
    const slug = LICENSE_CODE_SLUG[parsed.code] || null;
    if (!licenseCovers(parsed.code, product)) {
      return { valid: false, error: "product", code: parsed.code, kid: parsed.kid, slug, key: parsed.key };
    }
    return { valid: true, code: parsed.code, kid: parsed.kid, slug, key: parsed.key, universal: parsed.code === UNIVERSAL_CODE };
  }

  /** Build the EIP-155 calldata for USDC.transfer(payTo, amount). */
  function transferCalldata(amountUnits, payTo) {
    const to = (payTo || CONFIG.PAY_TO).replace(/^0x/, "").toLowerCase();
    if (!/^[0-9a-f]{40}$/.test(to)) throw new Error("bad payTo");
    return "0xa9059cbb" + to.padStart(64, "0") + BigInt(amountUnits).toString(16).padStart(64, "0");
  }

  /**
   * Build the eth_sendTransaction payload for a one-click USDC payment.
   * The buyer's wallet signs it — this page never sees a private key. Kept here
   * (not in the UI file) so the exact object the wallet is asked to sign can be
   * asserted in a test.
   */
  function buildTransferTx(opts) {
    const o = opts || {};
    const cfg = Object.assign({}, CONFIG, o.config || {});
    let amount;
    if (o.amountUnits != null) amount = BigInt(o.amountUnits);
    else amount = BigInt(Math.round(Number(o.usd) * 1e6));
    if (!(amount > 0n)) throw new Error("No amount to pay.");
    if (!/^0x[0-9a-fA-F]{40}$/.test(String(o.from || "")))
      throw new Error("No wallet address: connect a wallet before paying.");
    return {
      from: o.from,
      to: cfg.USDC,
      value: "0x0",
      data: transferCalldata(amount, o.payTo || cfg.PAY_TO),
      chainId: cfg.CHAIN_ID
    };
  }

  /**
   * Wait until the transaction has a receipt, so a one-click buyer never has to
   * copy anything. Resolves with the receipt, or throws with a message that
   * names the hash so a pending payment is never lost.
   */
  async function waitForReceipt(hash, opts) {
    const o = opts || {};
    const clean = String(hash || "").trim();
    if (!HASH_RE.test(clean))
      throw new Error("That is not a transaction hash — a Base hash is 0x followed by 64 hex characters.");
    const h = clean.toLowerCase();
    const timeout = o.timeoutMs == null ? 120000 : o.timeoutMs;
    const interval = o.intervalMs == null ? 1500 : o.intervalMs;
    const now = o.now || (() => Date.now());
    const pause = o.sleep || (ms => new Promise(r => setTimeout(r, ms)));
    const deadline = now() + timeout;
    let lastErr = null;
    for (;;) {
      try {
        const receipt = await rpc("eth_getTransactionReceipt", [h], { rpcs: o.rpcs, timeout: o.rpcTimeoutMs });
        if (receipt) {
          if (receipt.status !== "0x1")
            throw new Error("That transaction reverted (status 0). Nothing was transferred, so nothing unlocks.");
          return receipt;
        }
      } catch (e) {
        if (/reverted/.test(String(e && e.message))) throw e;
        lastErr = e;
      }
      if (now() >= deadline) {
        const why = lastErr ? " Last RPC error: " + lastErr.message : "";
        throw new Error("The transaction has no receipt after " + Math.round(timeout / 1000) +
          "s, so it is still pending or was dropped. Hash " + h + " — paste it below once it confirms." + why);
      }
      await pause(interval);
    }
  }

  return {
    CONFIG, verify, verifyAtLeast, loadReceipt, sumUsdcIn, transferCalldata,
    buildTransferTx, waitForReceipt, rpc, TRANSFER, pad32,
    LICENSE_PUBLIC_KEY, LICENSE_PRODUCTS, LICENSE_CODE_SLUG, UNIVERSAL_CODE,
    parseLicense, isLicenseKey, licenseCovers, verifyLicense
  };
});
