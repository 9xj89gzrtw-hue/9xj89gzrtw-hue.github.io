"""Multi-agent coordinator and dispatcher."""
import json
from typing import Dict, Any

class AgentOrchestrator:
    def __init__(self, manifest_file="agents.json"):
        with open(manifest_file) as f:
            self.agents = json.load(f)

    def route_task(self, task_description: str) -> str:
        desc_lower = task_description.lower()
        if any(w in desc_lower for w in ["css", "html", "react", "vue", "frontend", "дизайн"]):
            return "frontend_expert"
        if any(w in desc_lower for w in ["api", "db", "sql", "backend", "fastapi", "бэкенд"]):
            return "backend_architect"
        if any(w in desc_lower for w in ["test", "тест", "pytest", "coverage"]):
            return "qa_engineer"
        return "code_reviewer"

if __name__ == "__main__":
    orch = AgentOrchestrator()
    print("Assigned agent:", orch.route_task("Настроить подключение к PostgreSQL и написать миграцию"))
