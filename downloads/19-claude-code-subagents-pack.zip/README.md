# 🤖 Claude Code Multi-Agent Subagent Pack
Готовые промпты и роли автономных субагентов для Claude Code и OpenCode.