# System Architect Subagent
Designs decoupled schemas, selects dependencies, creates ADRs.
