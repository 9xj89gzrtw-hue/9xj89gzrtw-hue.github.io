# QA / Test Engineer Subagent
Generates edge-case test suites using pytest-asyncio and Playwright.
