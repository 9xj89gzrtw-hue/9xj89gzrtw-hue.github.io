# Security Auditor Subagent
Detects OWASP vulnerabilities, hardcoded tokens, and SSRF attack vectors.
