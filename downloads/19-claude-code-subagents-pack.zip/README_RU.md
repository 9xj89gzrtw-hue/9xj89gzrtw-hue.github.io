# 🤖 Claude Code Subagents Pack (Frontend, Backend, QA, Review)

Архитектура мультиагентного взаимодействия для сложных проектов в Claude Code:
- Автоматическая диспетчеризация задач между узкоспециализированными ролями
- Роли: Frontend UI, Backend Architect, QA Automation, Staff Reviewer
- Единый координатор и протокол обмена контекстом
