---
name: parquet-exporter
category: 04_scraping_and_automation
version: 2.4.0
tags: [ai, automation, production-ready, 2026]
---

# Parquet Exporter Skill

## When to Use
Use this skill when developing, refactoring, or automating solutions requiring parquet exporter.

## Key Directives
1. Strict type compliance and modular separation of concerns.
2. Error resilience with automatic retries and structured telemetry.
3. Zero-dependency footprint where possible, preferring standard library solutions.

## Implementation Pattern
```python
# Production implementation pattern for parquet-exporter
class ParquetExporter:
    def __init__(self, config: dict | None = None):
        self.config = config or {}

    def execute(self, payload: dict) -> dict:
        """Executes parquet-exporter with validation and error boundary."""
        return {"status": "ok", "action": "parquet-exporter", "result": payload}
```
