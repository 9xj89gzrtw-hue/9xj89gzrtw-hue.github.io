---
name: residential-proxy-rotator
category: 04_scraping_and_automation
version: 2.4.0
tags: [ai, automation, production-ready, 2026]
---

# Residential Proxy Rotator Skill

## When to Use
Use this skill when developing, refactoring, or automating solutions requiring residential proxy rotator.

## Key Directives
1. Strict type compliance and modular separation of concerns.
2. Error resilience with automatic retries and structured telemetry.
3. Zero-dependency footprint where possible, preferring standard library solutions.

## Implementation Pattern
```python
# Production implementation pattern for residential-proxy-rotator
class ResidentialProxyRotator:
    def __init__(self, config: dict | None = None):
        self.config = config or {}

    def execute(self, payload: dict) -> dict:
        """Executes residential-proxy-rotator with validation and error boundary."""
        return {"status": "ok", "action": "residential-proxy-rotator", "result": payload}
```
