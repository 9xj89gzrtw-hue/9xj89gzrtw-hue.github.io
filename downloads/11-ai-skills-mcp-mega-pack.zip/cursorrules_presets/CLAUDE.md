# Universal CLAUDE.md for Claude Code & OpenCode
- Always run commands in the correct virtual environment.
- Do not commit secrets, private keys, or API tokens.
- Maintain documentation integrity and type correctness.
- Verify changes with automated test commands before confirming tasks.
