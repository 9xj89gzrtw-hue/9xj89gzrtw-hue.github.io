# ☘️ 500+ AI SKILLS & MCP СЕРВЕРОВ (2026 Edition)
### Для Claude Code, Cursor IDE, Windsurf, Codex CLI и OpenCode

Добро пожаловать в самый полный и актуальный набор AI-инструментов, промптов и MCP-серверов!

---

## 🚀 Быстрый старт за 2 минуты

### 1. Подключение MCP серверов в Claude Desktop / Claude Code:
1. Откройте `mcp_configs/claude_desktop_config.json`.
2. Скопируйте его содержимое в ваш конфиг Claude Desktop:
   - macOS: `~/Library/Application Support/Claude/claude_desktop_config.json`
   - Windows: `%APPDATA%\Claude\claude_desktop_config.json`
3. Перезапустите Claude — у вас появятся инструменты файловой системы, SQLite, веб-поиска и последовательного мышления!

### 2. Подключение в Cursor IDE / Windsurf:
1. Скопируйте нужный файл из `cursorrules_presets/` в корень вашего проекта как `.cursorrules`.
2. Настройте MCP во вкладке Settings -> Features -> MCP -> Add new MCP server (используйте данные из `mcp_configs/cursor_mcp_config.json`).

### 3. Использование каталога навыков (Skills Catalog):
- В папке `skills_catalog/` собраны готовые модули навыков (`SKILL.md`) по 6 ключевым направлениям (Backend, Frontend, AI Agents, Scraping, Web3, DevOps).
- Добавляйте их в свои агентные пайплайны или подключайте как контекст в диалогах!

---
Разработано для разработчиков нового поколения. 100% практическая ценность!
