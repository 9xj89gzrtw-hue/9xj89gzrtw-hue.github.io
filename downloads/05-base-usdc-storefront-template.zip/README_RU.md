# 🛒 Base USDC Storefront Template (Web3 E-Commerce)

Шаблон интернет-магазина для приема платежей в стейблкоинах USDC в сети Base (L2 от Coinbase) с нулевыми комиссиями и мгновенным подтверждением.

## Состав продукта
- `contracts/USDCReceiver.sol`: Смарт-контракт верификации заказов.
- `server/watcher.js`: Node.js сервис отслеживания входящих транзакций по WebSockets.
- `server/server.py`: FastAPI бэкенд создания заказов и выдачи цифровых ссылок.
- `web/index.html`: Готовая страница витрины с интеграцией Ethers.js v6.
