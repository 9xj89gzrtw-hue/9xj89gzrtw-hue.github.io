// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

interface IERC20 {
    function transferFrom(address sender, address recipient, uint256 amount) external returns (bool);
    function balanceOf(address account) external view returns (uint256);
}

contract USDCReceiver {
    address public immutable owner;
    IERC20 public immutable usdcToken;
    
    event PaymentReceived(address indexed buyer, uint256 orderId, uint256 amount, uint256 timestamp);

    constructor(address _usdcToken) {
        owner = msg.sender;
        usdcToken = IERC20(_usdcToken);
    }

    function payOrder(uint256 orderId, uint256 amount) external {
        require(amount > 0, "Amount must be greater than 0");
        bool success = usdcToken.transferFrom(msg.sender, owner, amount);
        require(success, "USDC transfer failed");
        emit PaymentReceived(msg.sender, orderId, amount, block.timestamp);
    }
}
