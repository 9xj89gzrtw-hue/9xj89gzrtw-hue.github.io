/**
 * On-chain USDC transaction listener for Base Mainnet.
 */
const { ethers } = require("ethers");
require("dotenv").config();

const RPC_URL = process.env.BASE_RPC_URL || "https://mainnet.base.org";
const USDC_ADDRESS = "0x833589fCD6eDb6E08f4c7C32D4f71b54bdA02913"; // Base Native USDC
const MERCHANT_WALLET = process.env.MERCHANT_WALLET;

const ERC20_ABI = [
  "event Transfer(address indexed from, address indexed to, uint256 value)"
];

async function startWatcher() {
  const provider = new ethers.JsonRpcProvider(RPC_URL);
  const usdc = new ethers.Contract(USDC_ADDRESS, ERC20_ABI, provider);

  console.log(`[+] Listening for USDC payments to ${MERCHANT_WALLET} on Base...`);

  usdc.on("Transfer", (from, to, value) => {
    if (to.toLowerCase() === MERCHANT_WALLET.toLowerCase()) {
      const formatted = ethers.formatUnits(value, 6);
      console.log(`[⚡ PAYMENT RECEIVED] ${formatted} USDC from ${from}`);
      // Trigger order fulfillment webhook
    }
  });
}

startWatcher().catch(console.error);
