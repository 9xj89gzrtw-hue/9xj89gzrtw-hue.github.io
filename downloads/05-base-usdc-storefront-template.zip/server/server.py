"""FastAPI backend with order creation and verification."""
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
import uuid
import time

app = FastAPI(title="USDC Storefront Backend")
ORDERS_DB = {}

class OrderCreate(BaseModel):
    product_id: str
    price_usdc: float
    customer_email: str

@app.post("/api/orders/create")
def create_order(order: OrderCreate):
    order_id = str(uuid.uuid4())[:8]
    ORDERS_DB[order_id] = {
        "product_id": order.product_id,
        "amount": order.price_usdc,
        "email": order.customer_email,
        "status": "pending",
        "created_at": time.time()
    }
    return {"order_id": order_id, "amount_usdc": order.price_usdc, "pay_to": "0x742d35Cc6634C0532925a3b844Bc454e4438f44e"}

@app.get("/api/orders/{order_id}")
def get_order_status(order_id: str):
    if order_id not in ORDERS_DB:
        raise HTTPException(status_code=404, detail="Order not found")
    return ORDERS_DB[order_id]
