# Telegram Mini App "CoinRush Club" — tap game + wheel + shop, ready to ship

> **Working-interface screenshots:** see [`screenshots/`](screenshots/) —
> `01-tap-dashboard.png`, `02-wheel.png`, `03-admin.png` (WebApp and the admin
> panel, 1280×800).

A complete boxed product: a **Telegram Mini App** (tap game with a wheel of
fortune, a shop and daily tasks), payment via **Telegram Stars (XTR)** and
**TON Connect** (invoices with a unique memo code + webhook settlement), plus a
**web admin panel** (balances, tasks, top players, ⭐/TON revenue).

Zero dependencies: the backend is **pure Python 3 stdlib** (`http.server` +
`sqlite3` + `hmac`), the bot is stdlib `urllib`, the frontend is a single HTML
file with no build step. No `pip install` at all.

> ⚠️ Honest non-gambling note: everything inside uses an **internal game
> currency only**. The wheel awards game coins; there is **no cash-out and no
> exchange**. When you deploy your own instance, comply with the Telegram ToS
> and local law.

## What's inside

| Folder | What it is |
|---|---|
| `backend/` | stdlib-only API server: taps (rate limit 400/10s), wheel (server-side odds), shop, tasks, daily streak, TON orders, admin API. `app.py` is the server, `game.py` re-exports the game core for bot/tests |
| `bot/` | Telegram bot (long-poll): WebApp launch button, **XTR** invoice links (`createInvoiceLink`), automatic crediting of `successful_payment` (idempotent by charge id), `/balance` |
| `webapp/` | Mobile WebApp: tap game with animations, wheel, ⭐/TON shop, tasks, daily reward. One file, no build |
| `admin/` | Web admin panel: stats, balances, task create/toggle, top players, recent purchases |
| `tests/` | **56 offline tests** (unittest, stdlib): game core, initData HMAC auth, live HTTP loop, payment idempotency |

## Verified to work

```
$ python3 -m tests.run          # from the product root
Ran 56 tests in ~10s
OK
```

56/56 on Python 3.9 (macOS and Linux). Real cases handled: tap rate limit, the
daily spin cap, XTR-payment idempotency (Telegram may redeliver
`successful_payment` — no double crediting), admin balance corrections clamped
at zero, the TON webhook is closed without a token (401).

## Requirements

- Python 3.9+ (no pip dependencies)
- For monetization: a @BotFather token (`BOT_TOKEN`)
- For real ⭐ sales: a bot with Telegram Stars enabled, `WEBAPP_URL` on HTTPS

## Quick start (7 commands)

```bash
# 1) demo mode (no bot): everything works, requests bind to demo user 424242
python3 -m backend.app --port 8090 --demo
#    then open http://127.0.0.1:8090/          (WebApp)
#    and      http://127.0.0.1:8090/admin      (admin panel)

# 2) tests
python3 -m tests.run

# 3) production: backend with real initData verification
export BOT_TOKEN=123456:AA...
export ADMIN_TOKEN=$(openssl rand -hex 24)
export WEBAPP_URL=https://your-domain/
python3 -m backend.app --port 8090 --token "$ADMIN_TOKEN"

# 4) the bot: sales, XTR invoices, purchase crediting
BOT_TOKEN="$BOT_TOKEN" ADMIN_TOKEN="$ADMIN_TOKEN" python3 -m bot.bot
```

Connect in Telegram: @BotFather → `/newapp` (or the Menu Button) → set
`WEBAPP_URL`. When a user opens the app, WebApp initData is verified on the
server (HMAC-SHA256, official algorithm, 24h replay window).

## Monetization (as shipped)

1. **Telegram Stars (XTR):** the shop sells 3 coin packs + a 24h x2 boost
   (100/500/2000/300 ⭐). In production the bot creates invoice links;
   `successful_payment` credits the pack automatically.
2. **TON Connect:** the WebApp creates order `TON-XXXXXXXX` with a unique memo
   code; the payment gateway calls `POST /api/ton/webhook` → credited by code
   (a demo gateway is built in; a second settle fails with `already_paid`).
3. **Internal coins:** the coin-based price is 4× the list price and only for
   packs — buy-back is blocked.
4. **Tasks / daily streak** — retention, not monetization (clear caps).

Economy sheet: tap = 1 coin (×2 with boost), batch ≤ 100, window 10s ≤ 400;
wheel weights sum to 1000: jackpot 2.5% → 5000, big 7.5% → 1000–1500,
mid 15% → 400–700, small 30% → 100–250, tiny 35% → 10–90, zero 10% → 0;
spin cap 20/day (UTC); daily = 250 × min(streak, 7) × boost; a missed day
resets the streak.

## Security (already built in)

- `initData` is verified with HMAC per the official algorithm;
  forged or older than 24h → rejected
- Game logic is **fully server-side**: wheel odds, wallets, tasks — the client
  only animates
- Tap rate limit (400/10s) and the spin cap (20/day) live in the API itself
- Admin routes require `X-Admin-Token` (env `ADMIN_TOKEN` or `--token`);
  with no token configured access is denied by default (401) — tested
- `purchases.external_id` deduplication — Telegram cannot double-credit
- request body ≤ 1 MB, JSON validation, CORS `*` for the WebApp

## Layout

```
telegram-miniapp-starter-pro/
├── backend/app.py        # ~540 lines: API, SQLite, game, admin
├── backend/game.py       # re-export for the bot and tests
├── bot/bot.py            # long-poll bot: WebApp button, XTR invoices, crediting
├── webapp/index.html     # tap game / wheel / shop (1 file)
├── admin/index.html      # admin panel (1 file)
├── tests/                # 56 tests, python3 -m tests.run
├── screenshots/          # 3 PNG 1280×800
├── README_RU.md
├── README_EN.md          # this file
├── QUICKSTART_RU.txt     # a 20-line cheat sheet
├── .env.example
└── LICENSE            (MIT)
```

## Test checklist (all covered in `tests/`)

- taps: ×N crediting, boost, 100-tap batch cap, 400/10s rate limit + window reset
- wheel: weights sum to 1000, deterministic prize slots, 20/day cap
- daily: first reward, double-claim rejection, streak +1/day, streak reset
- shop: ⭐ packs, boost, unknown item, in-coin purchase only for pack items
- TON: order + settle, second settle → error
- tasks: static, progress gating, double-claim rejection, admin create/toggle
- admin: summary, balance correction (clamped at 0), mandatory token
- HTTP: a live server in tests — /health, WebApp, admin, 404, 429, 401
- bot: XTR payment, duplicate charge id → no second credit
- auth: valid initData, wrong token, tampered user, stale auth_date, missing hash

## License

MIT — do what you want; a link to this product in the bot description is
appreciated but not required.
