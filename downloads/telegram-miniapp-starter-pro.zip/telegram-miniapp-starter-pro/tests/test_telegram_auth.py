#!/usr/bin/env python3
"""tests/test_telegram_auth.py — Telegram WebApp initData HMAC verification."""
from __future__ import annotations

import hashlib
import hmac
import os
import sys
import time
import unittest
import urllib.parse
import json

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from backend.app import verify_init_data, parse_tma_header  # noqa: E402

BOT_TOKEN = "7000000001:TEST-local-token-for-unit-tests"


def sign_init_data(user: dict, bot_token: str = BOT_TOKEN, auth_date: int | None = None) -> str:
    auth_date = auth_date if auth_date is not None else int(time.time())
    params = {
        "auth_date": str(auth_date),
        "query_id": "AATestQuery",
        "user": urllib.parse.quote(json.dumps(user, separators=(",", ":")), safe=""),
    }
    data_check = "\n".join(f"{k}={v}" for k, v in sorted(params.items()))  # URL-encoded values, as received
    secret = hmac.new(b"WebAppData", bot_token.encode(), hashlib.sha256).digest()
    calc = hmac.new(secret, data_check.encode(), hashlib.sha256).hexdigest()
    raw = "&".join(f"{k}={v}" for k, v in params.items()) + f"&hash={calc}"
    return raw


import json  # noqa: E402


class TelegramAuthTest(unittest.TestCase):
    def test_valid_init_data_passes(self):
        raw = sign_init_data({"id": 555, "username": "tg", "first_name": "Тимур"})
        user = verify_init_data(raw, BOT_TOKEN)
        self.assertIsNotNone(user)
        self.assertEqual(user["id"], 555)

    def test_wrong_token_fails(self):
        raw = sign_init_data({"id": 555, "username": "tg", "first_name": "Тимур"})
        self.assertIsNone(verify_init_data(raw, "7000000002:OTHER"))

    def test_tampered_user_fails(self):
        raw = sign_init_data({"id": 555, "username": "tg", "first_name": "Тимур"})
        raw = raw.replace("tg", "hacked")
        self.assertIsNone(verify_init_data(raw, BOT_TOKEN))

    def test_stale_auth_date_rejected(self):
        old = int(time.time()) - 5 * 86400
        raw = sign_init_data({"id": 555}, auth_date=old)
        self.assertIsNone(verify_init_data(raw, BOT_TOKEN))

    def test_missing_hash_rejected(self):
        raw = sign_init_data({"id": 555})
        raw = "&".join(p for p in raw.split("&") if not p.startswith("hash="))
        self.assertIsNone(verify_init_data(raw, BOT_TOKEN))

    def test_empty_input_rejected(self):
        self.assertIsNone(verify_init_data("", BOT_TOKEN))
        self.assertIsNone(verify_init_data("auth_date=1&hash=ff", ""))

    def test_tma_header_parsed(self):
        self.assertEqual(parse_tma_header("tma abc"), "abc")
        self.assertEqual(parse_tma_header("TMA xyz"), "xyz")
        self.assertEqual(parse_tma_header("Bearer xyz"), "")
        self.assertEqual(parse_tma_header(""), "")


if __name__ == "__main__":
    unittest.main(verbosity=2)
