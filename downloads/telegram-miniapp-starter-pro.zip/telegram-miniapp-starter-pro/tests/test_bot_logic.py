#!/usr/bin/env python3
"""tests/test_bot_logic.py — Stars payment crediting (idempotent) + helpers."""
import os
import sys
import tempfile
import unittest

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from bot import bot  # noqa: E402
from backend import game  # noqa: E402


class BotLogicTest(unittest.TestCase):
    def setUp(self):
        self.db = os.path.join(tempfile.mkdtemp(), "game.sqlite3")
        game.init_db(self.db)
        self.uid = 777
        game.ensure_user(self.db, {"id": self.uid, "username": "paying", "first_name": "Пётр"})

    def _payment(self, charge_id="CHARGE-1", payload="pack:pack_pro"):
        return {
            "from": {"id": self.uid},
            "invoice_payload": payload,
            "telegram_payment_charge_id": charge_id,
            "total_amount": 500,
            "currency": "XTR",
        }

    def test_credit_stars_payment(self):
        res = bot.credit_successful_payment(self.db, self._payment())
        self.assertEqual(res["credited"], 55000)

    def test_credit_duplicate_charge_ignored(self):
        bot.credit_successful_payment(self.db, self._payment())
        res = bot.credit_successful_payment(self.db, self._payment())
        self.assertTrue(res.get("duplicate"))
        self.assertEqual(res["credited"], 0)

    def test_credit_default_pack(self):
        res = bot.credit_successful_payment(self.db, self._payment(charge_id="C2", payload=""))
        self.assertEqual(res["credited"], 10000)

    def test_balance_after_duplicate_single_credit(self):
        bot.credit_successful_payment(self.db, self._payment())
        bot.credit_successful_payment(self.db, self._payment())
        u = game.ensure_user(self.db, {"id": self.uid})
        self.assertEqual(int(u["coins"]), 55000)


if __name__ == "__main__":
    unittest.main(verbosity=2)
