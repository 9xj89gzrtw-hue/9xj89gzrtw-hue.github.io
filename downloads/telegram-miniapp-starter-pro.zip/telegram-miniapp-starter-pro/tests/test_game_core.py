#!/usr/bin/env python3
"""tests/test_game_core.py — taps, wheel, daily, tasks, shop, ton orders."""
import os
import sys
import tempfile
import unittest

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from backend import game  # noqa: E402


class FakeRng:
    """Deterministic rng: pops predefined floats, randint returns lo."""

    def __init__(self, floats):
        self.floats = list(floats)
        self.ints = []

    def random(self):
        return self.floats.pop(0) if self.floats else 0.999

    def randint(self, lo, hi):
        self.ints.append((lo, hi))
        return hi


class GameCoreTest(unittest.TestCase):
    def setUp(self):
        self.db = os.path.join(tempfile.mkdtemp(), "game.sqlite3")
        game.init_db(self.db)
        self.uid = 111
        game.ensure_user(self.db, {"id": self.uid, "username": "u", "first_name": "U"})

    # ---------------------------------------------------------------- taps
    def test_tap_credits_one_per_tap(self):
        res = game.do_tap(self.db, self.uid, taps=25)
        self.assertEqual(res["gained"], 25)
        self.assertEqual(res["coins"], 25)

    def test_tap_batch_capped_at_100(self):
        res = game.do_tap(self.db, self.uid, taps=10_000)
        self.assertEqual(res["gained"], 100)

    def test_tap_rate_limit_window(self):
        now = 1_000_000.0
        for _ in range(4):  # 4 batches x100 fill the window (400)
            game.do_tap(self.db, self.uid, taps=100, now=now)
        with self.assertRaises(ValueError):
            game.do_tap(self.db, self.uid, taps=100, now=now + 5)  # 500 > 400 in-window

    def test_tap_window_resets(self):
        now = 1_000_000.0
        game.do_tap(self.db, self.uid, taps=400, now=now)
        res = game.do_tap(self.db, self.uid, taps=5, now=now + 11)
        self.assertEqual(res["gained"], 5)

    def test_tap_boost_multiplier(self):
        game.buy_item(self.db, self.uid, "boost_x2", "admin")
        res = game.do_tap(self.db, self.uid, taps=10)
        self.assertEqual(res["gained"], 20)

    # --------------------------------------------------------------- wheel
    def test_wheel_weights_sum_1000(self):
        self.assertEqual(sum(w[1] for w in game.WHEEL), 1000)

    def test_wheel_jackpot_is_rarest(self):
        ids = [w[0] for w in game.WHEEL]
        self.assertEqual(min(game.WHEEL, key=lambda w: w[1])[0], "jackpot")
        self.assertIn("jackpot", ids)

    def test_spin_wheel_deterministic_jackpot(self):
        rng = FakeRng([0.0])  # first slice
        wid, coins, label = game.spin_wheel(rng)
        self.assertEqual(wid, "jackpot")
        self.assertEqual(coins, 5000)

    def test_spin_wheel_zero_slice(self):
        # cumulative weights: jackpot 25, big 100, mid 250, small 550, tiny 900, zero 1000
        rng = FakeRng([0.999])
        wid, coins, label = game.spin_wheel(rng)
        self.assertEqual(wid, "zero")
        self.assertEqual(coins, 0)

    def test_spin_credits_balance(self):
        res = game.do_spin(self.db, self.uid, rng=FakeRng([0.5]))  # -> small slice, hi=250
        self.assertEqual(res["coins"], 250)
        self.assertEqual(res["balance"], 250)

    def test_spin_daily_cap(self):
        for i in range(game.SPIN_DAILY_CAP):
            game.do_spin(self.db, self.uid, rng=FakeRng([0.99]))
        with self.assertRaises(ValueError):
            game.do_spin(self.db, self.uid, rng=FakeRng([0.99]))

    # --------------------------------------------------------------- daily
    def test_daily_first_claim(self):
        res = game.daily_claim(self.db, self.uid, now=1_700_000_000)
        self.assertEqual(res["streak"], 1)
        self.assertEqual(res["reward"], 250)

    def test_daily_no_double_claim(self):
        now = 1_700_000_000
        game.daily_claim(self.db, self.uid, now=now)
        with self.assertRaises(ValueError):
            game.daily_claim(self.db, self.uid, now=now + 60)

    def test_daily_streak_grows(self):
        now = 1_700_000_000
        game.daily_claim(self.db, self.uid, now=now)
        res = game.daily_claim(self.db, self.uid, now=now + 86400)
        self.assertEqual(res["streak"], 2)

    def test_daily_streak_resets_after_gap(self):
        now = 1_700_000_000
        game.daily_claim(self.db, self.uid, now=now)
        res = game.daily_claim(self.db, self.uid, now=now + 3 * 86400)
        self.assertEqual(res["streak"], 1)

    # ---------------------------------------------------------------- shop
    def test_shop_buy_stars_credits(self):
        res = game.buy_item(self.db, self.uid, "pack_starter", "stars")
        self.assertEqual(res["credited"], 10000)

    def test_shop_buy_unknown_item(self):
        with self.assertRaises(LookupError):
            game.buy_item(self.db, self.uid, "nope", "stars")

    def test_shop_bad_currency(self):
        with self.assertRaises(ValueError):
            game.buy_item(self.db, self.uid, "pack_starter", "btc")

    def test_boost_sets_multiplier_and_expires(self):
        now = 1_000_000.0
        game.buy_item(self.db, self.uid, "boost_x2", "stars", now=now)
        u = game.ensure_user(self.db, {"id": self.uid})
        self.assertEqual(game.boost_multiplier(u, now=now + 3600), 2.0)
        self.assertEqual(game.boost_multiplier(u, now=now + 86401), 1.0)

    # ---------------------------------------------------------- ton orders
    def test_ton_order_create_and_settle(self):
        order = game.ton_order_create(self.db, self.uid, "pack_pro")
        self.assertTrue(order["code"].startswith("TON-"))
        res = game.ton_order_settle(self.db, order["code"], "txhash1")
        self.assertEqual(res["credited"], 55000)

    def test_ton_order_no_double_settle(self):
        order = game.ton_order_create(self.db, self.uid, "pack_pro")
        game.ton_order_settle(self.db, order["code"], "txhash2")
        with self.assertRaises(ValueError):
            game.ton_order_settle(self.db, order["code"], "txhash2")

    # --------------------------------------------------------------- tasks
    def test_task_claim_static(self):
        state = game.state_payload(self.db, game.ensure_user(self.db, {"id": self.uid}))
        task = next(t for t in state["tasks"] if t["kind"] == "static")
        res = game.task_claim(self.db, self.uid, task["id"])
        self.assertGreater(res["reward"], 0)

    def test_task_no_double_claim(self):
        state = game.state_payload(self.db, game.ensure_user(self.db, {"id": self.uid}))
        task = next(t for t in state["tasks"] if t["kind"] == "static")
        game.task_claim(self.db, self.uid, task["id"])
        with self.assertRaises(ValueError):
            game.task_claim(self.db, self.uid, task["id"])

    def test_task_gated_by_progress(self):
        state = game.state_payload(self.db, game.ensure_user(self.db, {"id": self.uid}))
        task = next(t for t in state["tasks"] if t["kind"] == "taps_1000")
        with self.assertRaises(ValueError):
            game.task_claim(self.db, self.uid, task["id"])
        base = 2_000_000.0
        for i in range(10):  # 10 windows x 100 taps = 1000
            game.do_tap(self.db, self.uid, taps=100, now=base + i * 11)
        res = game.task_claim(self.db, self.uid, task["id"])
        self.assertGreater(res["reward"], 0)

    # --------------------------------------------------------------- admin
    def test_admin_balance_delta_clamped_at_zero(self):
        res = game.admin_balance(self.db, self.uid, -999_999)
        self.assertEqual(res["balance"], 0)

    def test_admin_task_create_and_toggle(self):
        tid = game.admin_task_create(self.db, "promo_1", "Промо задание", 777, "static")
        state = game.state_payload(self.db, game.ensure_user(self.db, {"id": self.uid}))
        self.assertIn(tid, [t["id"] for t in state["tasks"]])
        game.admin_task_toggle(self.db, tid, False)
        state = game.state_payload(self.db, game.ensure_user(self.db, {"id": self.uid}))
        self.assertNotIn(tid, [t["id"] for t in state["tasks"]])

    def test_admin_summary_shape(self):
        s = game.admin_summary(self.db)
        for key in ("users", "coins_in_circulation", "taps_total", "spins_total",
                    "revenue_stars", "revenue_ton", "top", "recent_purchases"):
            self.assertIn(key, s)


if __name__ == "__main__":
    unittest.main(verbosity=2)
