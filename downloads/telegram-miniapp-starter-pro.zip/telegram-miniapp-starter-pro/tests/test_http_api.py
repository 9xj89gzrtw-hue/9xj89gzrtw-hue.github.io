#!/usr/bin/env python3
"""tests/test_http_api.py — live HTTP loop: demo user, taps, spins, admin auth."""
import json
import os
import sys
import tempfile
import threading
import unittest
import urllib.request
from http.server import ThreadingHTTPServer

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from backend.app import make_handler, init_db  # noqa: E402


class LiveServer:
    def __init__(self, admin_token="admintok", bot_token=""):
        self.dir = tempfile.mkdtemp()
        self.db = os.path.join(self.dir, "game.sqlite3")
        init_db(self.db)
        self.httpd = ThreadingHTTPServer(("127.0.0.1", 0), make_handler(self.db, admin_token, bot_token, demo=True))
        self.port = self.httpd.server_address[1]
        threading.Thread(target=self.httpd.serve_forever, daemon=True).start()

    def stop(self):
        self.httpd.shutdown()

    def req(self, path, body=None, headers=None):
        h = {"Content-Type": "application/json"}
        if headers:
            h.update(headers)
        opt = urllib.request.Request(f"http://127.0.0.1:{self.port}{path}",
                                     data=json.dumps(body).encode() if body is not None else None, headers=h)
        try:
            with urllib.request.urlopen(opt, timeout=10) as r:
                payload = r.read().decode()
        except urllib.error.HTTPError as e:
            payload = e.read().decode()
            return e.code, (payload if e.headers.get("Content-Type", "").startswith("text/html") else json.loads(payload))
        ctype = r.headers.get("Content-Type", "")
        if ctype.startswith("text/html"):
            return r.status, payload
        return r.status, json.loads(payload)


class HttpApiTest(unittest.TestCase):
    def setUp(self):
        self.srv = LiveServer()
        self.addCleanup(self.srv.stop)

    def test_health(self):
        code, j = self.srv.req("/health")
        self.assertEqual(code, 200)
        self.assertTrue(j["ok"])
        self.assertTrue(j["demo"])

    def test_webapp_served(self):
        code, raw = self.srv.req("/")
        self.assertEqual(code, 200)
        self.assertIn("CoinRush", raw)

    def test_admin_html_served(self):
        code, raw = self.srv.req("/admin")
        self.assertEqual(code, 200)
        self.assertIn("админ-панель", raw)

    def test_state_demo_user(self):
        code, j = self.srv.req("/api/state")
        self.assertEqual(code, 200)
        self.assertEqual(j["user"]["tg_id"], 424242)
        self.assertIn("wheel", j)
        self.assertIn("shop", j)
        self.assertIn("tasks", j)
        self.assertEqual(j["spin_cap"], 20)

    def test_tap_endpoint(self):
        code, j = self.srv.req("/api/tap", {"taps": 30})
        self.assertEqual(code, 200)
        self.assertEqual(j["gained"], 30)

    def test_tap_rate_limit_429(self):
        for _ in range(4):  # fill the 400-tap window
            code, j = self.srv.req("/api/tap", {"taps": 100})
            self.assertEqual(code, 200)
        code, j = self.srv.req("/api/tap", {"taps": 100})
        self.assertEqual(code, 429)

    def test_spin_endpoint(self):
        code, j = self.srv.req("/api/spin", {})
        self.assertEqual(code, 200)
        self.assertIn("prize", j)
        self.assertIn("balance", j)

    def test_shop_buy_via_http(self):
        code, j = self.srv.req("/api/shop/buy", {"item_id": "pack_pro", "currency": "stars"})
        self.assertEqual(code, 200)
        self.assertEqual(j["credited"], 55000)

    def test_daily_claim_via_http(self):
        code, j = self.srv.req("/api/daily/claim", {})
        self.assertEqual(code, 200)
        self.assertEqual(j["streak"], 1)

    def test_task_claim_via_http(self):
        code, state = self.srv.req("/api/state")
        task = next(t for t in state["tasks"] if t["kind"] == "static")
        code, j = self.srv.req("/api/task/claim", {"task_id": task["id"]})
        self.assertEqual(code, 200)

    def test_admin_requires_token(self):
        code, j = self.srv.req("/admin/api/summary")
        self.assertEqual(code, 401)

    def test_admin_summary_ok(self):
        code, j = self.srv.req("/admin/api/summary", headers={"X-Admin-Token": "admintok"})
        self.assertEqual(code, 200)
        self.assertIn("coins_in_circulation", j)

    def test_admin_balance_via_http(self):
        self.srv.req("/api/state")  # create the demo user
        code, j = self.srv.req("/admin/api/balance",
                               {"tg_id": 424242, "delta": 1000}, headers={"X-Admin-Token": "admintok"})
        self.assertEqual(code, 200)
        self.assertEqual(j["balance"], 1000)

    def test_admin_task_create_via_http(self):
        code, j = self.srv.req("/admin/api/task",
                               {"code": "promo", "title": "Промо", "reward": 500},
                               headers={"X-Admin-Token": "admintok"})
        self.assertEqual(code, 200)
        self.assertTrue(j["ok"])

    def test_unknown_route_404(self):
        code, j = self.srv.req("/api/nope")
        self.assertEqual(code, 404)

    def test_ton_webhook_requires_admin(self):
        code, j = self.srv.req("/api/ton/webhook", {"code": "TON-XX", "tx_hash": "h"})
        self.assertEqual(code, 401)

    def test_ton_order_and_webhook_flow(self):
        code, order = self.srv.req("/api/ton/order", {"item_id": "pack_starter"})
        self.assertEqual(code, 200)
        code, j = self.srv.req("/api/ton/webhook", {"code": order["code"], "tx_hash": "tx1"},
                               headers={"X-Admin-Token": "admintok"})
        self.assertEqual(code, 200)
        self.assertEqual(j["credited"], 10000)


class NoTokenServerTest(unittest.TestCase):
    """Without ADMIN_TOKEN, admin routes must stay closed (deny by default)."""

    def setUp(self):
        self.srv = LiveServer(admin_token="")
        self.addCleanup(self.srv.stop)

    def test_admin_closed_without_token(self):
        code, j = self.srv.req("/admin/api/summary", headers={"X-Admin-Token": "anything"})
        self.assertEqual(code, 401)


if __name__ == "__main__":
    unittest.main(verbosity=2)
