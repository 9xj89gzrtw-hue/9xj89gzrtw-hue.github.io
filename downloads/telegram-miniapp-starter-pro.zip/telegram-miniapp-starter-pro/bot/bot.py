#!/usr/bin/env python3
"""bot/bot.py — Telegram bot for the tap-game starter (stdlib only).

Long-poll loop on getUpdates. No framework, no pip.

What it does
------------
* /start            — WebApp launch button + ref code support (startapp ref)
* /balance          — current coins
* successful_payment (XTR) — credits the coin pack via backend.game
* /admin <cmd>      — tiny admin CLI (summon the summary into the chat)

Run:
    BOT_TOKEN=123:AAA ADMIN_TOKEN=... python3 -m bot.bot

Stars flow (XTR): the WebApp shop calls POST /api/shop/buy with
currency=stars in demo mode; in production the bot calls
createInvoiceLink(title, currency=XTR, prices, payload=pack_pro) and the
WebApp opens it via Telegram.WebApp.openInvoice; the successful_payment
update lands here and is credited with backend.game.buy_item(..., 'stars',
external_id=telegram_payment_charge_id).
"""
from __future__ import annotations

import json
import os
import sys
import time
import urllib.parse
import urllib.request

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from backend import game  # noqa: E402  (app.py exposes game functions)

API = "https://api.telegram.org/bot{token}/{method}"
WEBAPP_URL = os.environ.get("WEBAPP_URL", "https://example.com/")
DB = os.environ.get("GAME_DB", "data/game.sqlite3")


def call(token: str, method: str, **params):
    url = API.format(token=token, method=method)
    data = json.dumps(params).encode()
    req = urllib.request.Request(url, data=data, headers={"Content-Type": "application/json"})
    with urllib.request.urlopen(req, timeout=70) as resp:
        return json.loads(resp.read().decode())


def stars_invoice(token: str, item_id: str, title: str, stars: int, payload: str) -> str:
    """createInvoiceLink for a Telegram Stars (XTR) pack."""
    res = call(token, "createInvoiceLink", title=title, description=f"CoinRush: {title}",
               payload=payload or f"pack:{item_id}", currency="XTR",
               prices=[{"label": title, "amount": stars}])
    if not res.get("ok"):
        raise RuntimeError(f"createInvoiceLink failed: {res}")
    return res["result"]


def credit_successful_payment(db: str, payment: dict) -> dict:
    """successful_payment update -> credit the pack, idempotent by charge id."""
    import sqlite3

    item_id = (payment.get("invoice_payload") or "").removeprefix("pack:") or "pack_starter"
    ext = payment.get("telegram_payment_charge_id") or ""
    tg_id = int(payment["from"]["id"])
    if ext:
        c = sqlite3.connect(db, timeout=15)
        try:
            row = c.execute("SELECT 1 FROM purchases WHERE external_id=?", (ext,)).fetchone()
            if row:  # Telegram may redeliver the update — never double-credit
                u = c.execute("SELECT coins FROM users WHERE tg_id=?", (tg_id,)).fetchone()
                return {"ok": True, "duplicate": True, "credited": 0,
                        "balance": int(u[0]) if u else 0}
        finally:
            c.close()
    return game.buy_item(db, tg_id, item_id, "stars", external_id=ext)


def loop() -> None:
    token = os.environ.get("BOT_TOKEN", "")
    if not token:
        raise SystemExit("BOT_TOKEN env is required")
    game.init_db(DB)
    offset = 0
    print("bot: long-poll started")
    while True:
        try:
            res = call(token, "getUpdates", offset=offset, timeout=50,
                       allowed_updates=["message", "pre_checkout_query", "successful_payment"])
            for upd in res.get("result", []):
                offset = upd["update_id"] + 1
                msg = upd.get("message") or {}
                chat = (msg.get("chat") or {})
                text = (msg.get("text") or "")
                if upd.get("successful_payment"):
                    done = credit_successful_payment(DB, upd["successful_payment"])
                    call(token, "sendMessage", chat_id=chat.get("id"),
                         text=f"✅ Зачислено {done.get('credited', 0)} монет. Баланс: {done.get('balance', 0)}")
                    continue
                if text.startswith("/start"):
                    call(token, "sendMessage", chat_id=chat.get("id"), text="Открываю CoinRush Club…",
                         reply_markup={"inline_keyboard": [[{"text": "🎮 Играть", "web_app": {"url": WEBAPP_URL}}]]})
                elif text.startswith("/balance"):
                    u = game.ensure_user(DB, {"id": msg["from"]["id"], "username": (msg["from"].get("username") or ""),
                                              "first_name": (msg["from"].get("first_name") or "")})
                    call(token, "sendMessage", chat_id=chat.get("id"),
                         text=f"Монет: {u['coins']} · тапов: {u['taps']} · вращений: {u['spins']}")
        except Exception as exc:  # never die on a bad update
            print("bot loop:", exc, file=sys.stderr)
            time.sleep(3)


if __name__ == "__main__":
    loop()
