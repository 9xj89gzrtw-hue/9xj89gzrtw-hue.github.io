#!/usr/bin/env python3
"""backend/app.py — Telegram Mini App tap-game starter: zero-dependency API.

Pure stdlib (http.server + sqlite3 + hmac). No pip, no framework:

    python3 -m backend.app --db data/game.sqlite3 --port 8090 [--demo]

Auth model
----------
* User requests carry `Authorization: tma <initDataRaw>` (Telegram WebApp
  initData). The signature is verified with HMAC-SHA256 per the official
  algorithm (secret = HMAC("WebAppData", bot_token)).
* Without a bot token configured the server runs in DEMO mode: any request
  is bound to a deterministic demo user (id 424242) — perfect for local
  development and screenshots.
* Admin routes need `X-Admin-Token` (ADMIN_TOKEN env or --token).

Routes
------
    GET  /                     -> webapp/index.html
    GET  /admin                -> admin/index.html
    GET  /api/state            -> {user, balance, tasks, shop, wheel, streak}
    POST /api/tap              -> {taps} batched taps (server-side rate limit)
    POST /api/spin             -> wheel of fortune (server-side odds, daily cap)
    POST /api/shop/buy         -> {item_id} spend coins on a boost
    POST /api/daily/claim      -> daily streak reward
    POST /api/task/claim       -> {task_id} claim a finished task
    GET  /health               -> {"ok": true}
    GET  /admin/api/summary    -> JSON stats (users, coins, purchases)
    POST /admin/api/balance    -> {tg_id, delta} adjust a user's balance
    POST /admin/api/task       -> {title, reward, kind} create a task
    POST /admin/api/task/toggle-> {task_id, enabled}

Payments
--------
Telegram Stars (XTR): bot/bot.py creates invoice links for coin packs
(`sendInvoice`, currency XTR). After successful payment Telegram sends a
successful_payment update; the bot credits the pack via
backend.game.credit_purchase — the same function the admin panel uses.
TON Connect: the WebApp generates a fresh comment code (ton:// invoice memo)
and backend exposes POST /api/ton/webhook for a payment gateway callback
(demo gateway included in demo mode).

This is a game with an internal currency only. It ships no wagering logic:
the wheel returns game coins, there is no way to cash out. Comply with the
Telegram ToS and local law when you deploy your own instance.
"""
from __future__ import annotations

import argparse
import hashlib
import hmac
import json
import os
import secrets
import sqlite3
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import parse_qs, unquote, urlparse

ROOT = Path(__file__).resolve().parent.parent

# --------------------------------------------------------------------- tuning
TAP_WINDOW_S = 10          # anti-cheat window
TAP_MAX_IN_WINDOW = 400    # a human with an autoclicker rarely beats this
SPIN_DAILY_CAP = 20        # wheel spins per UTC day
TAP_REWARD = 1             # coins per tap
SPIN_COST = 0              # a spin is free, but capped
DAILY_BASE = 250           # daily streak base reward

# Wheel: (id, weight, coins_min, coins_max, label). Sum of weights = 1000.
WHEEL = [
    ("jackpot",  25, 5000, 5000, "ДЖЕКПОТ 5000"),
    ("big",      75, 1000, 1500, "1000–1500"),
    ("mid",     150,  400,  700, "400–700"),
    ("small",   300,  100,  250, "100–250"),
    ("tiny",    350,   10,   90, "10–90"),
    ("zero",    100,    0,    0, "Мимо"),
]

# Coin packs sold for Telegram Stars (XTR) / TON.
SHOP = [
    {"item_id": "pack_starter", "coins": 10000,   "stars": 100, "ton": 0.5,  "label": "Стартовый"},
    {"item_id": "pack_pro",     "coins": 55000,   "stars": 500, "ton": 2.5,  "label": "Продвинутый"},
    {"item_id": "pack_legend",  "coins": 250000,  "stars": 2000, "ton": 10.0, "label": "Легендарный"},
    {"item_id": "boost_x2",     "coins": 0,       "stars": 300, "ton": 1.5,  "label": "Буст x2 (24ч)",
     "boost": {"mult": 2, "hours": 24}},
]

DEFAULT_TASKS = [
    ("join_channel", "Подпишись на наш канал", 5000, "static"),
    ("invite_3",     "Пригласи 3 друзей", 25000, "referral_3"),
    ("spin_10",      "Сделай 10 вращений колеса", 3000, "spins_10"),
    ("tap_1000",     "Сделай 1000 тапов", 2500, "taps_1000"),
]


# ---------------------------------------------------------------------- db
def init_db(path: str) -> None:
    parent = os.path.dirname(os.path.abspath(path))
    if parent:
        os.makedirs(parent, exist_ok=True)
    with _cx(path) as c:
        c.executescript(
            """
            CREATE TABLE IF NOT EXISTS users (
                tg_id       INTEGER PRIMARY KEY,
                username    TEXT NOT NULL DEFAULT '',
                first_name  TEXT NOT NULL DEFAULT '',
                coins       INTEGER NOT NULL DEFAULT 0,
                taps        INTEGER NOT NULL DEFAULT 0,
                spins       INTEGER NOT NULL DEFAULT 0,
                mult        REAL NOT NULL DEFAULT 1.0,
                boost_until INTEGER NOT NULL DEFAULT 0,
                last_tap_at INTEGER NOT NULL DEFAULT 0,
                window_taps INTEGER NOT NULL DEFAULT 0,
                streak_days INTEGER NOT NULL DEFAULT 0,
                last_daily  TEXT NOT NULL DEFAULT '',
                referrer    INTEGER,
                created_at  INTEGER NOT NULL
            );
            CREATE TABLE IF NOT EXISTS spins (
                id        INTEGER PRIMARY KEY AUTOINCREMENT,
                tg_id     INTEGER NOT NULL,
            prize     TEXT NOT NULL,
                coins     INTEGER NOT NULL,
                day       TEXT NOT NULL,
                created_at INTEGER NOT NULL
            );
            CREATE TABLE IF NOT EXISTS purchases (
                id        INTEGER PRIMARY KEY AUTOINCREMENT,
                tg_id     INTEGER NOT NULL,
                item_id   TEXT NOT NULL,
                coins     INTEGER NOT NULL,
                currency  TEXT NOT NULL,
                paid      REAL NOT NULL,
                external_id TEXT NOT NULL DEFAULT '',
                created_at INTEGER NOT NULL
            );
            CREATE TABLE IF NOT EXISTS tasks (
                id       INTEGER PRIMARY KEY AUTOINCREMENT,
                code     TEXT NOT NULL UNIQUE,
                title    TEXT NOT NULL,
                reward   INTEGER NOT NULL,
                kind     TEXT NOT NULL DEFAULT 'static',
                enabled  INTEGER NOT NULL DEFAULT 1
            );
            CREATE TABLE IF NOT EXISTS task_claims (
                tg_id    INTEGER NOT NULL,
                task_id  INTEGER NOT NULL,
                claimed_at INTEGER NOT NULL,
                PRIMARY KEY (tg_id, task_id)
            );
            CREATE TABLE IF NOT EXISTS ton_orders (
                id        INTEGER PRIMARY KEY AUTOINCREMENT,
                code      TEXT NOT NULL UNIQUE,
                tg_id     INTEGER NOT NULL,
                item_id   TEXT NOT NULL,
                amount_ton REAL NOT NULL,
                status    TEXT NOT NULL DEFAULT 'pending',
                created_at INTEGER NOT NULL
            );
            CREATE INDEX IF NOT EXISTS idx_spins_day ON spins(tg_id, day);
            """
        )
        for code, title, reward, kind in DEFAULT_TASKS:
            c.execute(
                "INSERT OR IGNORE INTO tasks (code, title, reward, kind, enabled) VALUES (?,?,?,?,1)",
                (code, title, reward, kind),
            )


class _Cx:
    """Short-lived sqlite connection context (commit on success)."""

    def __init__(self, path: str):
        self.path = path

    def __enter__(self):
        self.c = sqlite3.connect(self.path, timeout=15)
        self.c.row_factory = sqlite3.Row
        self.c.execute("PRAGMA journal_mode=WAL")
        return self.c

    def __exit__(self, et, ev, tb):
        if et is None:
            self.c.commit()
        else:
            self.c.rollback()
        self.c.close()
        return False


def _cx(path: str):
    return _Cx(path)


# ------------------------------------------------------------ telegram auth
def verify_init_data(init_data: str, bot_token: str) -> dict | None:
    """Official Telegram WebApp initData verification. Returns the user dict."""
    if not init_data or not bot_token:
        return None
    pairs = [p.split("=", 1) for p in init_data.split("&") if "=" in p]
    data = {k: v for k, v in pairs}
    received_hash = data.pop("hash", None)
    if not received_hash:
        return None
    data_check = "\n".join(f"{k}={data[k]}" for k in sorted(data))
    secret = hmac.new(b"WebAppData", bot_token.encode(), hashlib.sha256).digest()
    calc = hmac.new(secret, data_check.encode(), hashlib.sha256).hexdigest()
    if not hmac.compare_digest(calc, received_hash):
        return None
    if "user" not in data:
        return None
    try:
        user = json.loads(unquote(data["user"]))
    except json.JSONDecodeError:
        return None
    # auth_date freshness: reject data older than 24h (replay window)
    auth_date = int(data.get("auth_date", "0") or 0)
    if auth_date and abs(time.time() - auth_date) > 86400:
        return None
    return user


def parse_tma_header(header: str) -> str:
    if header.lower().startswith("tma "):
        return header[4:].strip()
    return ""


# ---------------------------------------------------------------- game core
DEMO_USER = {"id": 424242, "username": "demo_player", "first_name": "Демо"}


def ensure_user(path: str, tg: dict) -> sqlite3.Row:
    tg_id = int(tg.get("id") or 0)
    with _cx(path) as c:
        c.execute(
            """INSERT INTO users (tg_id, username, first_name, created_at)
               VALUES (?,?,?,?)
               ON CONFLICT(tg_id) DO UPDATE SET
                   username=excluded.username, first_name=excluded.first_name""",
            (tg_id, str(tg.get("username") or "")[:64],
             str(tg.get("first_name") or "")[:64], int(time.time())),
        )
    with _cx(path) as c:
        row = c.execute("SELECT * FROM users WHERE tg_id=?", (tg_id,)).fetchone()
    return row


def utc_day(ts: float | None = None) -> str:
    return time.strftime("%Y-%m-%d", time.gmtime(ts if ts is not None else time.time()))


def boost_multiplier(user: sqlite3.Row, now: float | None = None) -> float:
    now = now if now is not None else time.time()
    return float(user["mult"]) if int(user["boost_until"]) > now else 1.0


def do_tap(path: str, tg_id: int, taps: int, now: float | None = None) -> dict:
    now = now if now is not None else time.time()
    taps = max(1, min(int(taps or 1), 100))
    with _cx(path) as c:
        u = c.execute("SELECT * FROM users WHERE tg_id=?", (tg_id,)).fetchone()
        if not u:
            raise LookupError("user not found")
        window_start = int(u["last_tap_at"])
        window_taps = int(u["window_taps"])
        if now - window_start > TAP_WINDOW_S:
            window_taps = 0
        window_taps += taps
        if window_taps > TAP_MAX_IN_WINDOW:
            raise ValueError("rate_limited")
        gained = int(taps * TAP_REWARD * boost_multiplier(u, now))
        c.execute(
            """UPDATE users SET coins=coins+?, taps=taps+?, last_tap_at=?,
                   window_taps=? WHERE tg_id=?""",
            (gained, taps, int(now), window_taps, tg_id),
        )
        fresh = c.execute("SELECT coins, taps FROM users WHERE tg_id=?", (tg_id,)).fetchone()
    return {"gained": gained, "coins": int(fresh["coins"]), "taps_total": int(fresh["taps"])}


def spin_wheel(rng: random.Random | None = None, wheel: list | None = None) -> tuple:
    """Weighted wheel pick; returns (id, coins, label). Server-side odds."""
    import random as _r
    rng = rng or _r
    seq = wheel or WHEEL
    total = sum(w[1] for w in seq)
    x = rng.random() * total
    for wid, weight, lo, hi, label in seq:
        x -= weight
        if x <= 0:
            coins = rng.randint(lo, hi) if hi > lo else hi
            return wid, coins, label
    return seq[-1][0], seq[-1][3], seq[-1][4]


def do_spin(path: str, tg_id: int, now: float | None = None, rng=None) -> dict:
    now = now if now is not None else time.time()
    day = utc_day(now)
    with _cx(path) as c:
        n = c.execute("SELECT COUNT(*) FROM spins WHERE tg_id=? AND day=?", (tg_id, day)).fetchone()[0]
        if int(n) >= SPIN_DAILY_CAP:
            raise ValueError("spin_cap_reached")
        u = c.execute("SELECT * FROM users WHERE tg_id=?", (tg_id,)).fetchone()
        if not u:
            raise LookupError("user not found")
        wid, coins, label = spin_wheel(rng)
        mult = boost_multiplier(u, now)
        coins = int(coins * mult)
        c.execute(
            "INSERT INTO spins (tg_id, prize, coins, day, created_at) VALUES (?,?,?,?,?)",
            (tg_id, wid, coins, day, int(now)),
        )
        c.execute("UPDATE users SET spins=spins+1, coins=coins+? WHERE tg_id=?", (coins, tg_id))
        fresh = c.execute("SELECT coins FROM users WHERE tg_id=?", (tg_id,)).fetchone()
    return {"prize": wid, "coins": coins, "label": label, "balance": int(fresh["coins"])}


def buy_item(path: str, tg_id: int, item_id: str, currency: str, external_id: str = "",
             now: float | None = None) -> dict:
    """Credit a shop item. `currency` is 'stars' | 'ton' | 'coins' | 'admin'."""
    now = now if now is not None else time.time()
    item = next((i for i in SHOP if i["item_id"] == item_id), None)
    if not item:
        raise LookupError("item not found")
    if currency not in ("stars", "ton", "coins", "admin"):
        raise ValueError("bad currency")
    with _cx(path) as c:
        u = c.execute("SELECT * FROM users WHERE tg_id=?", (tg_id,)).fetchone()
        if not u:
            raise LookupError("user not found")
        if currency == "coins":
            if not item_id.startswith("pack_"):
                raise ValueError("coins_only_for_packs")
            price = item["coins"] * 4  # in-coin refund price is 4x the list price
            if int(u["coins"]) < price:
                raise ValueError("not_enough_coins")
            c.execute("UPDATE users SET coins=coins-? WHERE tg_id=?", (price, tg_id))
            paid = price
        elif currency == "stars":
            paid = item["stars"]
        elif currency == "ton":
            paid = item["ton"]
        else:
            paid = 0.0
        gained = item["coins"]
        extra = ""
        boost = item.get("boost")
        if boost:
            c.execute(
                "UPDATE users SET mult=?, boost_until=? WHERE tg_id=?",
                (float(boost["mult"]), int(now) + int(boost["hours"]) * 3600, tg_id),
            )
            extra = f"boost x{boost['mult']} {boost['hours']}h"
        if gained:
            c.execute("UPDATE users SET coins=coins+? WHERE tg_id=?", (gained, tg_id))
        c.execute(
            """INSERT INTO purchases (tg_id, item_id, coins, currency, paid, external_id, created_at)
               VALUES (?,?,?,?,?,?,?)""",
            (tg_id, item_id, gained, currency, paid, external_id, int(now)),
        )
        fresh = c.execute("SELECT coins FROM users WHERE tg_id=?", (tg_id,)).fetchone()
    return {"ok": True, "credited": gained, "extra": extra, "balance": int(fresh["coins"])}


def daily_claim(path: str, tg_id: int, now: float | None = None) -> dict:
    now = now if now is not None else time.time()
    today = utc_day(now)
    yesterday = utc_day(now - 86400)
    with _cx(path) as c:
        u = c.execute("SELECT * FROM users WHERE tg_id=?", (tg_id,)).fetchone()
        if not u:
            raise LookupError("user not found")
        if u["last_daily"] == today:
            raise ValueError("already_claimed")
        streak = int(u["streak_days"]) + 1 if u["last_daily"] == yesterday else 1
        reward = int(DAILY_BASE * min(streak, 7) * boost_multiplier(u, now))
        c.execute(
            "UPDATE users SET coins=coins+?, streak_days=?, last_daily=? WHERE tg_id=?",
            (reward, streak, today, tg_id),
        )
        fresh = c.execute("SELECT coins FROM users WHERE tg_id=?", (tg_id,)).fetchone()
    return {"reward": reward, "streak": streak, "balance": int(fresh["coins"])}


def task_claim(path: str, tg_id: int, task_id: int, now: float | None = None) -> dict:
    now = now if now is not None else time.time()
    with _cx(path) as c:
        t = c.execute("SELECT * FROM tasks WHERE id=? AND enabled=1", (task_id,)).fetchone()
        if not t:
            raise LookupError("task not found")
        done = c.execute("SELECT 1 FROM task_claims WHERE tg_id=? AND task_id=?", (tg_id, task_id)).fetchone()
        if done:
            raise ValueError("already_claimed")
        u = c.execute("SELECT * FROM users WHERE tg_id=?", (tg_id,)).fetchone()
        if not u:
            raise LookupError("user not found")
        if not task_progress_ok(u, t["kind"]):
            raise ValueError("task_not_finished")
        c.execute("INSERT INTO task_claims (tg_id, task_id, claimed_at) VALUES (?,?,?)", (tg_id, task_id, int(now)))
        c.execute("UPDATE users SET coins=coins+? WHERE tg_id=?", (int(t["reward"]), tg_id))
        fresh = c.execute("SELECT coins FROM users WHERE tg_id=?", (tg_id,)).fetchone()
    return {"reward": int(t["reward"]), "balance": int(fresh["coins"])}


def task_progress_ok(u: sqlite3.Row, kind: str) -> bool:
    if kind == "static":
        return True
    if kind == "spins_10":
        return int(u["spins"]) >= 10
    if kind == "taps_1000":
        return int(u["taps"]) >= 1000
    if kind == "referral_3":
        return False  # requires referral bookkeeping (schema has referrer)
    return True


def ton_order_create(path: str, tg_id: int, item_id: str, now: float | None = None) -> dict:
    now = now if now is not None else time.time()
    item = next((i for i in SHOP if i["item_id"] == item_id), None)
    if not item:
        raise LookupError("item not found")
    code = "TON-" + secrets.token_hex(4).upper()
    with _cx(path) as c:
        c.execute(
            "INSERT INTO ton_orders (code, tg_id, item_id, amount_ton, status, created_at) VALUES (?,?,?,?, 'pending', ?)",
            (code, tg_id, item_id, float(item["ton"]), int(now)),
        )
    return {"code": code, "amount_ton": float(item["ton"]), "item_id": item_id,
            "memo": f"order {code}"}


def ton_order_settle(path: str, code: str, tx_hash: str, now: float | None = None) -> dict:
    """Called by the payment gateway webhook after the TON transfer confirms."""
    now = now if now is not None else time.time()
    with _cx(path) as c:
        o = c.execute("SELECT * FROM ton_orders WHERE code=?", (code,)).fetchone()
        if not o:
            raise LookupError("order not found")
        if o["status"] == "paid":
            raise ValueError("already_paid")
        c.execute("UPDATE ton_orders SET status='paid' WHERE id=?", (int(o["id"]),))
    res = buy_item(path, int(o["tg_id"]), str(o["item_id"]), "ton", external_id=tx_hash, now=now)
    return {"ok": True, "code": code, **res}


# ------------------------------------------------------------------- admin
def admin_summary(path: str) -> dict:
    with _cx(path) as c:
        users = int(c.execute("SELECT COUNT(*) FROM users").fetchone()[0])
        coins = int(c.execute("SELECT COALESCE(SUM(coins),0) FROM users").fetchone()[0])
        taps = int(c.execute("SELECT COALESCE(SUM(taps),0) FROM users").fetchone()[0])
        spins = int(c.execute("SELECT COALESCE(SUM(spins),0) FROM users").fetchone()[0])
        stars = c.execute(
            "SELECT COALESCE(SUM(paid),0) FROM purchases WHERE currency='stars'"
        ).fetchone()[0]
        ton = c.execute(
            "SELECT COALESCE(SUM(paid),0) FROM purchases WHERE currency='ton'"
        ).fetchone()[0]
        top = [dict(r) for r in c.execute(
            "SELECT tg_id, username, coins, taps, spins FROM users ORDER BY coins DESC LIMIT 10")]
        recent = [dict(r) for r in c.execute(
            """SELECT id, tg_id, item_id, currency, paid, created_at FROM purchases
               ORDER BY id DESC LIMIT 10""")]
    return {"users": users, "coins_in_circulation": coins, "taps_total": taps,
            "spins_total": spins, "revenue_stars": int(stars), "revenue_ton": round(float(ton), 3),
            "top": top, "recent_purchases": recent}


def admin_balance(path: str, tg_id: int, delta: int) -> dict:
    with _cx(path) as c:
        u = c.execute("SELECT tg_id FROM users WHERE tg_id=?", (int(tg_id),)).fetchone()
        if not u:
            raise LookupError("user not found")
        c.execute("UPDATE users SET coins=MAX(0, coins+?) WHERE tg_id=?", (int(delta), int(tg_id)))
        fresh = c.execute("SELECT coins FROM users WHERE tg_id=?", (tg_id,)).fetchone()
    return {"tg_id": int(tg_id), "balance": int(fresh["coins"])}


def admin_task_create(path: str, code: str, title: str, reward: int, kind: str = "static") -> int:
    with _cx(path) as c:
        cur = c.execute(
            "INSERT INTO tasks (code, title, reward, kind, enabled) VALUES (?,?,?,?,1)",
            (str(code)[:32], str(title)[:120], int(reward), str(kind)[:24]),
        )
        return int(cur.lastrowid)


def admin_task_toggle(path: str, task_id: int, enabled: bool) -> None:
    with _cx(path) as c:
        c.execute("UPDATE tasks SET enabled=? WHERE id=?", (1 if enabled else 0, int(task_id)))


# ------------------------------------------------------------------ server
def state_payload(path: str, u: sqlite3.Row) -> dict:
    with _cx(path) as c:
        tasks = [dict(r) for r in c.execute("SELECT id, code, title, reward, kind FROM tasks WHERE enabled=1 ORDER BY reward DESC")]
        claimed = {int(r["task_id"]) for r in c.execute("SELECT task_id FROM task_claims WHERE tg_id=?", (int(u["tg_id"]),))}
    today = utc_day()
    spins_left = SPIN_DAILY_CAP
    with _cx(path) as c:
        n = c.execute("SELECT COUNT(*) FROM spins WHERE tg_id=? AND day=?", (int(u["tg_id"]), today)).fetchone()[0]
        spins_left = max(0, SPIN_DAILY_CAP - int(n))
    return {
        "user": {"tg_id": int(u["tg_id"]), "username": u["username"], "first_name": u["first_name"]},
        "coins": int(u["coins"]), "taps": int(u["taps"]), "spins": int(u["spins"]),
        "mult": boost_multiplier(u), "boost_until": int(u["boost_until"]),
        "streak_days": int(u["streak_days"]), "daily_claimed": u["last_daily"] == today,
        "daily_reward": int(DAILY_BASE * min(int(u["streak_days"]) + 1, 7)),
        "spins_left": spins_left, "spin_cap": SPIN_DAILY_CAP,
        "wheel": [{"id": w[0], "label": w[4]} for w in WHEEL],
        "shop": SHOP,
        "tasks": [{**t, "claimed": t["id"] in claimed} for t in tasks],
    }


def make_handler(db_path: str, admin_token: str, bot_token: str, demo: bool):
    webapp = (ROOT / "webapp" / "index.html")
    admin = (ROOT / "admin" / "index.html")

    class Handler(BaseHTTPRequestHandler):
        def _send(self, code: int, body: bytes, ctype: str = "application/json"):
            self.send_response(code)
            self.send_header("Content-Type", ctype)
            self.send_header("Content-Length", str(len(body)))
            self.send_header("Cache-Control", "no-store")
            self.send_header("Access-Control-Allow-Origin", "*")
            self.end_headers()
            self.wfile.write(body)

        def _json(self, code: int, obj):
            self._send(code, json.dumps(obj, ensure_ascii=False).encode())

        def _body(self) -> dict:
            n = int(self.headers.get("Content-Length") or 0)
            if n <= 0 or n > 1_000_000:
                return {}
            try:
                v = json.loads(self.rfile.read(n).decode("utf-8") or "{}")
                return v if isinstance(v, dict) else {}
            except json.JSONDecodeError:
                return {}

        def _user(self, q):
            init_raw = parse_tma_header(self.headers.get("Authorization", "")) or (q.get("tma", [""])[0])
            user = verify_init_data(init_raw, bot_token) if bot_token else None
            if user:
                return ensure_user(db_path, user), False
            if demo or not bot_token:
                return ensure_user(db_path, DEMO_USER), True
            self._json(401, {"error": "unauthorized: missing tma initData"})
            return None, None

        def _admin_ok(self, q) -> bool:
            given = self.headers.get("X-Admin-Token") or q.get("token", [""])[0]
            return bool(admin_token) and str(given) == str(admin_token)

        def do_GET(self):
            u = urlparse(self.path)
            q = parse_qs(u.query)
            if u.path == "/health":
                self._json(200, {"ok": True, "demo": bool(demo or not bot_token)})
                return
            if u.path in ("/", "/index.html"):
                self._send(200, webapp.read_bytes() if webapp.exists() else b"<h1>webapp missing</h1>",
                           "text/html; charset=utf-8")
                return
            if u.path in ("/admin", "/admin/"):
                self._send(200, admin.read_bytes() if admin.exists() else b"<h1>admin missing</h1>",
                           "text/html; charset=utf-8")
                return
            if u.path == "/api/state":
                user, _demo = self._user(q)
                if user is None:
                    return
                self._json(200, state_payload(db_path, user))
                return
            if u.path == "/admin/api/summary":
                if not self._admin_ok(q):
                    self._json(401, {"error": "unauthorized"})
                    return
                self._json(200, admin_summary(db_path))
                return
            self._json(404, {"error": "not found"})

        def do_POST(self):
            u = urlparse(self.path)
            q = parse_qs(u.query)
            body = self._body()
            if u.path == "/api/tap":
                user, _demo = self._user(q)
                if user is None:
                    return
                try:
                    self._json(200, do_tap(db_path, int(user["tg_id"]), int(body.get("taps", 1))))
                except ValueError as e:
                    self._json(429, {"error": str(e)})
                except LookupError:
                    self._json(404, {"error": "user"})
                return
            if u.path == "/api/spin":
                user, _demo = self._user(q)
                if user is None:
                    return
                try:
                    self._json(200, do_spin(db_path, int(user["tg_id"])))
                except ValueError as e:
                    self._json(429, {"error": str(e)})
                except LookupError:
                    self._json(404, {"error": "user"})
                return
            if u.path == "/api/shop/buy":
                user, _demo = self._user(q)
                if user is None:
                    return
                try:
                    self._json(200, buy_item(db_path, int(user["tg_id"]),
                                             str(body.get("item_id", "")), str(body.get("currency", "stars"))))
                except (LookupError, ValueError) as e:
                    self._json(400, {"error": str(e)})
                return
            if u.path == "/api/daily/claim":
                user, _demo = self._user(q)
                if user is None:
                    return
                try:
                    self._json(200, daily_claim(db_path, int(user["tg_id"])))
                except ValueError as e:
                    self._json(429, {"error": str(e)})
                except LookupError:
                    self._json(404, {"error": "user"})
                return
            if u.path == "/api/task/claim":
                user, _demo = self._user(q)
                if user is None:
                    return
                try:
                    self._json(200, task_claim(db_path, int(user["tg_id"]), int(body.get("task_id", 0))))
                except (LookupError, ValueError) as e:
                    self._json(400, {"error": str(e)})
                return
            if u.path == "/api/ton/order":
                user, _demo = self._user(q)
                if user is None:
                    return
                try:
                    self._json(200, ton_order_create(db_path, int(user["tg_id"]), str(body.get("item_id", ""))))
                except LookupError as e:
                    self._json(400, {"error": str(e)})
                return
            if u.path == "/api/ton/webhook":
                # gateway callback: {code, tx_hash}; demo gateway signs with ADMIN token
                if admin_token and not self._admin_ok(q):
                    self._json(401, {"error": "unauthorized"})
                    return
                try:
                    self._json(200, ton_order_settle(db_path, str(body.get("code", "")), str(body.get("tx_hash", ""))))
                except (LookupError, ValueError) as e:
                    self._json(400, {"error": str(e)})
                return
            if u.path == "/admin/api/balance":
                if not self._admin_ok(q):
                    self._json(401, {"error": "unauthorized"})
                    return
                try:
                    self._json(200, admin_balance(db_path, int(body.get("tg_id", 0)), int(body.get("delta", 0))))
                except (LookupError, ValueError) as e:
                    self._json(400, {"error": str(e)})
                return
            if u.path == "/admin/api/task":
                if not self._admin_ok(q):
                    self._json(401, {"error": "unauthorized"})
                    return
                tid = admin_task_create(db_path, str(body.get("code", "")), str(body.get("title", "")),
                                        int(body.get("reward", 0)), str(body.get("kind", "static")))
                self._json(200, {"ok": True, "id": tid})
                return
            if u.path == "/admin/api/task/toggle":
                if not self._admin_ok(q):
                    self._json(401, {"error": "unauthorized"})
                    return
                admin_task_toggle(db_path, int(body.get("task_id", 0)), bool(body.get("enabled", True)))
                self._json(200, {"ok": True})
                return
            self._json(404, {"error": "not found"})

        def log_message(self, *a):  # quiet
            pass

    return Handler


def main() -> None:
    ap = argparse.ArgumentParser(description="Telegram Mini App tap-game API (stdlib only)")
    ap.add_argument("--db", default="data/game.sqlite3")
    ap.add_argument("--host", default="127.0.0.1")
    ap.add_argument("--port", type=int, default=8090)
    ap.add_argument("--token", default="", help="ADMIN_TOKEN for /admin routes")
    ap.add_argument("--bot-token", default=os.environ.get("BOT_TOKEN", ""), help="Telegram bot token (enables real initData auth)")
    ap.add_argument("--demo", action="store_true", help="bind all requests to the demo user")
    a = ap.parse_args()
    admin_token = a.token or os.environ.get("ADMIN_TOKEN", "")
    init_db(a.db)
    httpd = ThreadingHTTPServer((a.host, int(a.port)), make_handler(a.db, admin_token, a.bot_token, a.demo))
    mode = "DEMO" if (a.demo or not a.bot_token) else "TELEGRAM"
    print(f"tap-game API on http://{a.host}:{a.port}/  mode={mode} db={a.db}")
    httpd.serve_forever()


if __name__ == "__main__":
    import random  # used by spin_wheel default rng
    main()
