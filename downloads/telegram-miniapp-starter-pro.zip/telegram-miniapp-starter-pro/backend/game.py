#!/usr/bin/env python3
"""backend/game.py — thin re-export so bot.py and tests share one import path."""
from .app import (  # noqa: F401
    TAP_MAX_IN_WINDOW, SPIN_DAILY_CAP, WHEEL, SHOP, DEFAULT_TASKS,
    init_db, ensure_user, do_tap, do_spin, spin_wheel, buy_item,
    daily_claim, task_claim, ton_order_create, ton_order_settle,
    admin_summary, admin_balance, admin_task_create, admin_task_toggle,
    verify_init_data, parse_tma_header, state_payload, utc_day, boost_multiplier,
)
