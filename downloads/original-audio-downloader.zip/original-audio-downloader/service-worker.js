// Service worker for Original Video Audio Downloader (Online 1-Click)

// Cache for direct audio streams: tabId -> { url, title, format, extension }
const directAudios = new Map();

// Helper to sanitize filenames for OS compatibility
function sanitizeFilename(title) {
  if (!title) return "audio_track";
  return title
    .replace(/[\\/:*?"<>|]/g, "_")
    .replace(/\s+/g, " ")
    .replace(/ - YouTube$/, "")
    .replace(/ — Видео ВКонтакте$/, "")
    .trim()
    .slice(0, 120);
}

// Check if a URL is a YouTube video
function isYouTubeVideoUrl(url) {
  if (!url) return false;
  return url.includes("youtube.com/watch") || url.includes("youtu.be/");
}

// Update badge when tab changes or navigates
function updateTabBadge(tabId, url) {
  if (!url || tabId < 0) return;
  if (isYouTubeVideoUrl(url)) {
    chrome.action.setBadgeText({ tabId, text: "MP3" });
    chrome.action.setBadgeBackgroundColor({ tabId, color: "#0071E3" }); // Apple System Blue
    chrome.action.setTitle({ tabId, title: "Готово к скачиванию звука видео (YouTube MP3)" });
  } else if (directAudios.has(tabId)) {
    const audio = directAudios.get(tabId);
    chrome.action.setBadgeText({ tabId, text: "MP3" });
    chrome.action.setBadgeBackgroundColor({ tabId, color: "#34C759" }); // Apple Green
    chrome.action.setTitle({ tabId, title: `Аудио найдено (${audio.format})` });
  } else {
    chrome.action.setBadgeText({ tabId, text: "" });
  }
}

// Set up declarativeNetRequest dynamic header rules on install / startup
function setupHeaderRules() {
  if (!chrome.declarativeNetRequest) return;
  chrome.declarativeNetRequest.updateDynamicRules({
    removeRuleIds: [101, 102, 103],
    addRules: [
      {
        id: 101,
        priority: 1,
        action: {
          type: "modifyHeaders",
          requestHeaders: [
            { header: "Origin", operation: "set", value: "https://loader.to" },
            { header: "Referer", operation: "set", value: "https://loader.to/" }
          ]
        },
        condition: {
          urlFilter: "*loader.to*",
          resourceTypes: ["xmlhttprequest", "other", "sub_frame"]
        }
      },
      {
        id: 102,
        priority: 1,
        action: {
          type: "modifyHeaders",
          requestHeaders: [
            { header: "Origin", operation: "set", value: "https://loader.to" },
            { header: "Referer", operation: "set", value: "https://loader.to/" }
          ]
        },
        condition: {
          urlFilter: "*affadaffa.com*",
          resourceTypes: ["xmlhttprequest", "other", "sub_frame"]
        }
      },
      {
        id: 103,
        priority: 1,
        action: {
          type: "modifyHeaders",
          requestHeaders: [
            { header: "Origin", operation: "set", value: "https://loader.to" },
            { header: "Referer", operation: "set", value: "https://loader.to/" }
          ]
        },
        condition: {
          urlFilter: "*savenow.to*",
          resourceTypes: ["xmlhttprequest", "other", "sub_frame"]
        }
      }
    ]
  }).catch(() => {});
}

chrome.runtime.onInstalled.addListener(setupHeaderRules);
chrome.runtime.onStartup.addListener(setupHeaderRules);
setupHeaderRules();

chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
  if (changeInfo.status === "complete" || changeInfo.url) {
    updateTabBadge(tabId, tab.url);
  }
});

chrome.tabs.onActivated.addListener((activeInfo) => {
  chrome.tabs.get(activeInfo.tabId).then((tab) => {
    if (tab) updateTabBadge(activeInfo.tabId, tab.url);
  }).catch(() => {});
});

// Sniff direct complete audio streams (VK, Rutube, direct MP3s/podcasts, etc.)
chrome.webRequest.onResponseStarted.addListener(
  (details) => {
    const { url, tabId, responseHeaders } = details;
    if (tabId < 0) return;
    if (url.includes("googlevideo.com")) return; // Exclude chunked MSE segments

    let isAudio = false;
    let format = "MP3 Audio";
    let extension = "mp3";

    if (responseHeaders) {
      for (const h of responseHeaders) {
        const name = h.name.toLowerCase();
        const val = (h.value || "").toLowerCase();
        if (name === "content-type") {
          if (val.includes("audio/mpeg") || val.includes("audio/mp3")) {
            isAudio = true;
            format = "MP3 (MPEG Audio)";
            extension = "mp3";
          } else if (val.includes("audio/mp4") || val.includes("audio/x-m4a")) {
            isAudio = true;
            format = "M4A / AAC";
            extension = "m4a";
          } else if (val.includes("audio/aac")) {
            isAudio = true;
            format = "AAC Audio";
            extension = "aac";
          }
        }
      }
    }

    if (!isAudio) {
      if (url.includes(".mp3")) {
        isAudio = true;
        format = "MP3 Audio";
        extension = "mp3";
      } else if (url.includes(".m4a")) {
        isAudio = true;
        format = "M4A Audio";
        extension = "m4a";
      }
    }

    if (isAudio) {
      chrome.tabs.get(tabId).then((tab) => {
        const title = tab ? tab.title : "аудио_видео";
        directAudios.set(tabId, {
          url,
          title,
          format,
          extension,
          timestamp: Date.now()
        });
        updateTabBadge(tabId, tab ? tab.url : null);
      }).catch(() => {});
    }
  },
  { urls: ["<all_urls>"] },
  ["responseHeaders"]
);

// Clean up closed tabs
chrome.tabs.onRemoved.addListener((tabId) => {
  directAudios.delete(tabId);
});

// Perform online conversion via loader.to API (zero local bloat, full audio track)
async function performOnlineConversion(videoUrl, format = "mp3") {
  const reqUrl = `https://loader.to/ajax/download.php?format=${encodeURIComponent(format)}&url=${encodeURIComponent(videoUrl)}`;
  
  const initResp = await fetch(reqUrl, {
    headers: {
      "Origin": "https://loader.to",
      "Referer": "https://loader.to/"
    }
  });
  
  if (!initResp.ok) {
    throw new Error(`Ошибка сервиса: HTTP ${initResp.status}`);
  }
  
  const initData = await initResp.json();
  if (!initData.success && !initData.progress_url) {
    throw new Error(initData.message || "Не удалось запустить онлайн-конвертацию");
  }
  
  const progressUrl = initData.progress_url;
  const videoTitle = initData.title || (initData.info && initData.info.title) || "";
  
  // If download URL is immediately available (cached)
  if (initData.download_url) {
    return { downloadUrl: initData.download_url, title: videoTitle };
  }
  
  // Poll progress until finished
  for (let attempt = 0; attempt < 35; attempt++) {
    await new Promise((resolve) => setTimeout(resolve, 1000));
    
    try {
      const pResp = await fetch(progressUrl, {
        headers: {
          "Origin": "https://loader.to",
          "Referer": "https://loader.to/"
        }
      });
      if (!pResp.ok) continue;
      
      const pData = await pResp.json();
      if (pData.download_url) {
        return {
          downloadUrl: pData.download_url,
          title: videoTitle || pData.title || (pData.info && pData.info.title)
        };
      }
      
      if (pData.success === 0 && pData.text && pData.text.toLowerCase().includes("error")) {
        throw new Error(pData.text);
      }
    } catch (e) {
      if (attempt > 25) throw e;
    }
  }
  
  throw new Error("Превышено время ожидания сервера");
}

// Message handler for popup
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === "get_audio_info") {
    const tabId = request.tabId;
    if (!tabId || tabId < 0) {
      sendResponse({ isYouTube: false, tabUrl: "", tabTitle: "", directAudio: null });
      return false;
    }

    chrome.tabs.get(tabId).then((tab) => {
      const isYouTube = isYouTubeVideoUrl(tab?.url);
      const direct = directAudios.get(tabId) || null;
      sendResponse({
        isYouTube,
        tabUrl: tab?.url || "",
        tabTitle: tab?.title || "",
        directAudio: direct
      });
    }).catch(() => {
      sendResponse({ isYouTube: false, tabUrl: "", tabTitle: "", directAudio: null });
    });
    return true; // async
  }

  // Handle online conversion & download
  if (request.action === "start_conversion") {
    const { videoUrl, format = "mp3", title } = request;
    
    performOnlineConversion(videoUrl, format)
      .then((result) => {
        const finalTitle = sanitizeFilename(title || result.title);
        const filename = `${finalTitle}_оригинал.${format}`;
        
        chrome.downloads.download(
          {
            url: result.downloadUrl,
            filename,
            conflictAction: "uniquify",
            saveAs: false
          },
          (downloadId) => {
            const err = chrome.runtime.lastError ? chrome.runtime.lastError.message : null;
            if (err) {
              sendResponse({ success: false, error: err });
            } else {
              sendResponse({ success: true, downloadId, filename });
            }
          }
        );
      })
      .catch((err) => {
        sendResponse({ success: false, error: err.message || "Ошибка конвертации" });
      });
    return true; // async
  }

  // Handle direct download for detected non-YouTube streams
  if (request.action === "download_direct") {
    const { url, title, extension = "mp3" } = request;
    const finalTitle = sanitizeFilename(title);
    const filename = `${finalTitle}_оригинал.${extension}`;

    chrome.downloads.download(
      {
        url,
        filename,
        conflictAction: "uniquify",
        saveAs: false
      },
      (downloadId) => {
        const err = chrome.runtime.lastError ? chrome.runtime.lastError.message : null;
        if (err) {
          sendResponse({ success: false, error: err });
        } else {
          sendResponse({ success: true, downloadId, filename });
        }
      }
    );
    return true; // async
  }

  return false;
});
