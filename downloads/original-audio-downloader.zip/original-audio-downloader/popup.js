// Minimalist Apple-style Popup Controller for Original Audio Downloader

document.addEventListener("DOMContentLoaded", async () => {
  const statusText = document.getElementById("status-text");
  const videoContainer = document.getElementById("video-container");
  const emptyContainer = document.getElementById("empty-container");
  const videoTitle = document.getElementById("video-title");
  const platformBadge = document.getElementById("platform-badge");
  const downloadBtn = document.getElementById("download-btn");
  const downloadBtnText = document.getElementById("download-btn-text");
  const progressContainer = document.getElementById("progress-container");
  const progressStatus = document.getElementById("progress-status");
  const progressPercent = document.getElementById("progress-percent");
  const progressFill = document.getElementById("progress-fill");

  const FORMAT = "mp3"; // Strictly MP3 per user request
  let currentTab = null;
  let audioInfo = null;

  try {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (!tab) {
      statusText.textContent = "Вкладка не найдена";
      return;
    }
    currentTab = tab;

    chrome.runtime.sendMessage({ action: "get_audio_info", tabId: tab.id }, (info) => {
      if (chrome.runtime.lastError) {
        const isYt = tab.url && (tab.url.includes("youtube.com/watch") || tab.url.includes("youtu.be/"));
        info = { isYouTube: isYt, tabUrl: tab.url, tabTitle: tab.title, directAudio: null };
      }

      audioInfo = info;
      
      if (info && (info.isYouTube || info.directAudio)) {
        statusText.textContent = "Готово к скачиванию";
        statusText.style.color = "#0a84ff";

        const title = info.tabTitle || (info.directAudio && info.directAudio.title) || tab.title || "Видео";
        videoTitle.textContent = title;

        if (info.isYouTube) {
          platformBadge.textContent = "YouTube";
          platformBadge.style.background = "#ff3b30";
        } else if (info.directAudio) {
          platformBadge.textContent = "АУДИО";
          platformBadge.style.background = "#34c759";
        }

        videoContainer.classList.remove("hidden");
        emptyContainer.classList.add("hidden");

        setTimeout(() => downloadBtn.focus(), 50);
      } else {
        statusText.textContent = "Видео не обнаружено";
        videoContainer.classList.add("hidden");
        emptyContainer.classList.remove("hidden");
      }
    });
  } catch (err) {
    statusText.textContent = "Ошибка";
  }

  // Trigger download on click or Enter
  downloadBtn.addEventListener("click", triggerDownload);

  document.addEventListener("keydown", (e) => {
    if (e.key === "Enter" && !downloadBtn.disabled) {
      triggerDownload();
    }
  });

  function triggerDownload() {
    if (!audioInfo && !currentTab) return;
    
    const videoUrl = (audioInfo && audioInfo.tabUrl) || currentTab.url;
    const title = (audioInfo && audioInfo.tabTitle) || currentTab.title;
    const isYt = (audioInfo && audioInfo.isYouTube) || (videoUrl && (videoUrl.includes("youtube.com/watch") || videoUrl.includes("youtu.be/")));

    downloadBtn.disabled = true;
    progressContainer.classList.remove("hidden");
    progressStatus.textContent = "Подключение к серверу...";
    progressPercent.textContent = "20%";
    progressFill.style.width = "20%";
    downloadBtnText.textContent = "Конвертация MP3...";

    if (isYt) {
      let currentProgress = 20;
      const progressTimer = setInterval(() => {
        if (currentProgress < 90) {
          currentProgress += Math.floor(Math.random() * 10) + 5;
          if (currentProgress > 90) currentProgress = 90;
          progressPercent.textContent = `${currentProgress}%`;
          progressFill.style.width = `${currentProgress}%`;
          progressStatus.textContent = currentProgress > 60 ? "Сборка MP3 дорожки..." : "Получение аудиопотока...";
        }
      }, 700);

      chrome.runtime.sendMessage(
        {
          action: "start_conversion",
          videoUrl,
          format: FORMAT,
          title
        },
        (res) => {
          clearInterval(progressTimer);

          if (chrome.runtime.lastError) {
            progressContainer.classList.add("hidden");
            downloadBtnText.textContent = "❌ Ошибка связи";
            enableFallback(videoUrl);
            return;
          }

          if (res && res.success) {
            progressPercent.textContent = "100%";
            progressFill.style.width = "100%";
            progressStatus.textContent = "Готово!";
            
            downloadBtn.classList.add("success");
            downloadBtnText.textContent = "✅ Скачано в Загрузки";
            
            setTimeout(() => {
              downloadBtn.classList.remove("success");
              downloadBtn.disabled = false;
              downloadBtnText.textContent = "Скачать MP3";
              progressContainer.classList.add("hidden");
            }, 3000);
          } else {
            progressContainer.classList.add("hidden");
            downloadBtnText.textContent = "❌ Сбой онлайн-сервиса";
            enableFallback(videoUrl);
          }
        }
      );
    } else if (audioInfo && audioInfo.directAudio) {
      chrome.runtime.sendMessage(
        {
          action: "download_direct",
          url: audioInfo.directAudio.url,
          title,
          extension: "mp3"
        },
        (res) => {
          if (res && res.success) {
            progressPercent.textContent = "100%";
            progressFill.style.width = "100%";
            downloadBtn.classList.add("success");
            downloadBtnText.textContent = "✅ Скачано в Загрузки";
          } else {
            downloadBtnText.textContent = "❌ Ошибка скачивания";
          }
          setTimeout(() => {
            downloadBtn.classList.remove("success");
            downloadBtn.disabled = false;
            downloadBtnText.textContent = "Скачать MP3";
            progressContainer.classList.add("hidden");
          }, 3000);
        }
      );
    }
  }

  function enableFallback(videoUrl) {
    setTimeout(() => {
      downloadBtn.disabled = false;
      downloadBtnText.textContent = "🌐 Открыть веб-скачивание (Yout)";
      downloadBtn.onclick = () => {
        window.open(`https://yout.com/video/?url=${encodeURIComponent(videoUrl)}`, "_blank");
      };
    }, 2000);
  }
});
