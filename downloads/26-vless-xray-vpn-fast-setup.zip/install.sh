#!/usr/bin/env bash
# Быстрая установка сервера VLESS-Reality на Ubuntu 22.04 / 24.04
set -e
echo "=== 🛡️ Установка Xray Core (VLESS-Reality) ==="
bash -c "$(curl -L https://github.com/XTLS/Xray-install/raw/main/install-release.sh)"

echo "[+] Генерация ключей Xray..."
xray x25519 > /tmp/xray_keys.txt
cat /tmp/xray_keys.txt
echo "✅ Xray успешно установлен!"
