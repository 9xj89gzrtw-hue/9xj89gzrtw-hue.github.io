# Настройка VLESS-Reality сервера за 5 минут
1. Запустите скрипт `install_3x_ui.sh` на чистом Ubuntu 22.04 / 24.04 VPS.
2. Откройте панель в браузере `http://IP:2053`.
3. Добавьте подключение: Протокол: VLESS, Сеть: TCP, Безопасность: Reality.
4. Скопируйте QR-код или vless:// ссылку в v2rayN, Nekobox или Shadowrocket.
