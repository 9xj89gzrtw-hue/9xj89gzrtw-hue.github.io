# 🛡️ Настройка своего VLESS / Xray VPN сервера за 5 минут

Пошаговая инструкция запуска самого устойчивого протокола обхода блокировок:
- Скрипт быстрой автоматической установки на чистый VPS
- Готовые клиенты под Windows (v2rayN), Android (v2rayNG) и iOS (Streisand / Shadowrocket)
- Маскировка под TLS трафик зарубежных CDN (Apple / Microsoft / Cloudflare)
