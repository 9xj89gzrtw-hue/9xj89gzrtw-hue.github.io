#!/usr/bin/env bash
# Быстрая установка панели 3X-UI с поддержкой VLESS-Reality
bash <(curl -Ls https://raw.githubusercontent.com/mhsanaei/3x-ui/master/install.sh)
