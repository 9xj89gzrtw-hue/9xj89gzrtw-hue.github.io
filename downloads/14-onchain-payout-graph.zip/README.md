# 🔍 On-Chain Payout Graph & Crypto Bounty Scanner (Python CLI)
Комплекс утилит от профессиональных Web3-баунти хантеров и ончейн-аналитиков.

### Компоненты:
1. `payout_tracker.py` — трекинг выплат USDC, USDT, ETH на Base, Arbitrum, Ethereum и Solana через нативные RPC.
2. `payout_graph_render.py` — генерация интерактивного графа связей кошельков спонсоров и получателей баунти в HTML/D3.js.
3. `keeper_scanner.py` — сканер ончейн-киперов и транзакций ретрансляторов.
4. `sample_payout_graph.html` — интерактивный визуализатор ончейн-графа с узлами и кластерами.

### Запуск:
```bash
python3 payout_tracker.py --address 0xYourWalletAddress --network base
python3 payout_graph_render.py --input sample_payout_graph.json --output graph.html
```
Откройте `graph.html` в браузере для интерактивного анализа связей!
