#!/usr/bin/env python3
"""tools_onchain_keeper_scanner.py — Base/Arbitrum keeper-income scanner v3.

Finds live contracts that pay the CALLER inside the tx:
  harvest()/tend()/compound()/skim(address)/distribute()/claimBounty()/...

v3 architecture (no explorer dependency — explorer dies under Cloudflare):
  1. Candidates: Beefy public vaults API (base+arbitrum strategies) AND
     DefiLlama protocol pages for the agent-2 CSV slugs -> llama addresses.
  2. Bytecode approach: eth_getCode each candidate; <400B = proxy -> resolve
     EIP-1967 impl slot or beacon-delegated implementation; recurse once.
     Then grep the bytecode for keeper-function selectors (keccak4).
  3. Present keepers -> eth_call simulation from our wallet address
     (latest state) -> 'success' = keeper-callable & potentially fee-paying.
  4. Ranked JSON report + printed table.

Read-only: no tx is ever signed or broadcast. Silent backend log for the
orchestrator's report. Output: out6/keeper_scan_<Ts>.json.
"""
from __future__ import annotations

import argparse
import csv
import json
import subprocess
import sys
import time
import urllib.request
from pathlib import Path

from Crypto.Hash import keccak

ROOT = Path(__file__).resolve().parent
OUT = ROOT / "out6"
OUT.mkdir(exist_ok=True)
CSV_DIRS = [
    ROOT / "dfll" / "defillama-fee-feed-audit" / "data",
    ROOT / "ffaudit" / "data",
]

RPCS = {
    "base": ["https://base-rpc.publicnode.com", "https://mainnet.base.org",
             "https://base-mainnet.public.blastapi.io"],
    "arbitrum": ["https://arb1.arbitrum.io/rpc",
                 "https://arbitrum-rpc.publicnode.com"],
}

WALLET_CALLER = "0x72Aa6edDE71B94f6b99c8e52EdC02B5C75F74d1a"

SLOT_IMPL = "0x360894a13ba1a3210667c828492db98dca3e2076cc3735a920a837d6ec30eed"
SLOT_BEACON = "0xa3f0ad74e5423aebfd80d3ef4346578335a9a72aeaee59ff6cb3582b35133d50"

KEEPER_SIGS = [
    "harvest()", "harvest(address)", "harvestAll()", "harvestMany(address)",
    "tend()", "tend(address)", "compound()", "compound(address)",
    "skim(address)", "sweep(address)", "sweepToken(address)", "distribute()",
    "claimBounty()", "liquidate()", "liquidate(address)",
    "processKeeper(address)", "processShares(address)", "claim(address)",
    "claimFees()", "claimTimely(address)", "operatorHarvest(address)",
]


def selector(sig: str) -> str:
    k = keccak.new(digest_bits=256)
    k.update(sig.encode())
    return k.hexdigest()[:8]


def rpc_json(chain: str, method: str, params: list) -> dict:
    body = json.dumps({"jsonrpc": "2.0", "id": 1, "method": method,
                       "params": params})
    for url in RPCS[chain]:
        r = subprocess.run(
            ["curl", "-s", "--max-time", "35", "-X", "POST", url,
             "-H", "Content-Type: application/json", "-d", body],
            capture_output=True, text=True)
        try:
            return json.loads(r.stdout)
        except Exception:
            continue
    return {}


_last_call = 0.0


def _pacing(gap: float = 0.12) -> None:
    global _last_call
    dt = time.time() - _last_call
    if dt < gap:
        time.sleep(gap - dt)
    _last_call = time.time()


def raw_call(chain: str, to: str, data: str, from_addr: str,
             ) -> tuple[str, str]:
    """-> (status, result_or_error). status: success/revert/rpc-fail."""
    body = json.dumps({"jsonrpc": "2.0", "id": 1, "method": "eth_call",
                       "params": [{"to": to, "data": "0x" + data,
                                   "from": from_addr}, "latest"]})
    for url in RPCS[chain]:
        _pacing()
        r = subprocess.run(
            ["curl", "-s", "--max-time", "35", "-X", "POST", url,
             "-H", "Content-Type: application/json", "-d", body],
            capture_output=True, text=True)
        try:
            res = json.loads(r.stdout)
        except Exception:
            continue
        if "error" in res:
            return "revert", json.dumps(res["error"])[:200]
        if "result" in res:
            return "success", res["result"]
    return "rpc-fail", ""


def get_code(chain: str, addr: str) -> str:
    res = raw_call(chain, addr, "", WALLET_CALLER)[1]
    got = rpc_json(chain, "eth_getCode", [addr, "latest"])
    return (got.get("result") or "")


def get_storage(chain: str, addr: str, slot: str) -> str:
    got = rpc_json(chain, "eth_getStorageAt", [addr, slot, "latest"])
    return got.get("result") or ""


def slot_impl(chain: str, addr: str, depth: int) -> str | None:
    for slot, beacon in ((SLOT_IMPL, False), (SLOT_BEACON, True)):
        r = get_storage(chain, addr, slot)
        if not r or int(r, 16) == 0:
            continue
        got = "0x" + r[-40:]
        if not beacon or depth > 0:
            return got
        res = raw_call(chain, got, selector("implementation()"),
                       WALLET_CALLER)
        val = res[1]
        if res[0] == "success" and val and int(val[-40:], 16):
            return "0x" + val[-40:]
    return None


def sniff(chain: str, addr: str, depth: int = 0) -> list[tuple[str, str]]:
    """-> [(sig, sel)]... keeper functions physically present in bytecode."""
    code = get_code(chain, addr)
    if len(code) < 400:
        impl = slot_impl(chain, addr, depth)
        if impl and depth < 1:
            return sniff(chain, impl, depth + 1)
        return []
    hits = []
    for sig in KEEPER_SIGS:
        s = selector(sig)
        if s in code:
            hits.append((sig, s))
    return hits


def curl(url: str, timeout: int = 30) -> str:
    r = subprocess.run(["curl", "-s", "--http2", "--max-time",
                        str(timeout), url], capture_output=True, text=True)
    return r.stdout


def llama_slugs() -> list[str]:
    slugs = set()
    for d in CSV_DIRS:
        if not d.is_dir():
            continue
        for f in d.glob("*.csv"):
            try:
                with f.open() as fh:
                    rows = list(csv.DictReader(fh))
            except Exception:
                continue
            for row in rows:
                chains = row.get("chains", "") or ""
                if ("Base" in chains) and row.get("slug"):
                    slugs.add(row["slug"])
    return sorted(slugs)


def llama_addresses(slug: str) -> list[tuple[str, str]]:
    """-> [(chain, address)] from DefiLlama protocol metadata."""
    try:
        d = json.load(urllib.request.urlopen(
            "https://api.llama.fi/protocol/" + slug, timeout=25))
    except Exception:
        return []
    out = []
    raw = d.get("address") or []
    if isinstance(raw, str):
        raw = [raw]
    for item in raw or []:
        cs, _, addr = str(item).partition(":")
        addr = addr if addr else cs
        cs = cs.lower().replace(" ", "")
        if not addr.startswith("0x") or len(addr) != 42:
            continue
        for ch in RPCS:
            if cs == ch:
                out.append((ch, addr.lower()))
    return out


def beefy_strategies() -> list[dict]:
    try:
        raw = curl("https://api.beefy.finance/vaults", 60)
        data = json.loads(raw)
    except Exception:
        return []
    out = []
    vaults = data if isinstance(data, list) else list(data.values())
    for v in vaults:
        if not isinstance(v, dict) or v.get("chain") not in RPCS:
            continue
        if v.get("status") not in (None, "active"):
            continue
        s = v.get("strategy")
        if isinstance(s, dict):
            s = s.get("address")
        if not (isinstance(s, str) and s.startswith("0x")):
            continue
        out.append({"addr": s.lower(), "chain": v.get("chain"),
                    "name": v.get("name"), "src": "beefy"})
    return out


def collect_candidates() -> dict[str, dict]:
    cands: dict[str, dict] = {}
    for st in beefy_strategies():
        cands.setdefault(st["addr"], {
            "addr": st["addr"], "chain": st.get("chain") or "base",
            "name": f"Beefy:{(st['name'] or '')[:44]}", "src": "beefy"})
    for slug in llama_slugs():
        for ch, addr in llama_addresses(slug):
            cands.setdefault(addr, {
                "addr": addr, "chain": ch, "name": f"llama:{slug}",
                "src": "llama"})
    return cands


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--limit", type=int, default=400)
    ap.add_argument("--sleep", type=float, default=0.1)
    args = ap.parse_args()

    cands = collect_candidates()
    print(f"candidates: {len(cands)}", flush=True)

    results = []
    live = []
    for idx, (addr, info) in enumerate(sorted(cands.items(),
                                              key=lambda kv: kv[1]["chain"])):
        if idx >= args.limit:
            break
        ch = info.get("chain") or "base"
        hits = sniff(ch, addr)
        if not hits:
            continue
        for sig, s in hits:
            n_args = sig.count("(") and (
                0 if sig.endswith("()") else 1)
            if n_args == 0:
                data = s
            elif "(address)" == sig[sig.index("("):]:
                probe_addr = ("0x" + "9" * 40).replace(
                    "0x", "000000000000000000000000") + WALLET_CALLER[2:]
                data = s + probe_addr
            else:
                data = s + "0" * 128
            status, res = raw_call(ch, addr, data, WALLET_CALLER)
            row = {**info, "fn": sig, "sel": "0x" + s,
                   "call": status, "info": res[:160]}
            results.append(row)
            mark = "LIVE" if status == "success" else "    "
            print(f"{mark} [{idx}] {ch} {addr} 0x{s} {sig} "
                  f"-> {status[:60]}", flush=True)
            if status == "success":
                live.append(row)
        time.sleep(args.sleep)

    stamp = time.strftime("%m%d-%H%M")
    outp = OUT / f"keeper_scan_{stamp}.json"
    outp.write_text(json.dumps({
        "candidates": len(cands),
        "contracts_with_keeperSelectors": len({(r["chain"], r["addr"])
                                                for r in results}),
        "keeper_functions_tested": len(results),
        "live": live, "all": results}, indent=2))
    print(f"\n=== {len(live)} LIVE keeper-calls / {len(results)} tested "
          f"-> {outp.name} ===")
    for r in live:
        print(f"  LIVE {r['chain']} {r['addr']} 0x{r['sel']} {r['fn']} "
              f"[{r.get('name')}] src={r['src']}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
