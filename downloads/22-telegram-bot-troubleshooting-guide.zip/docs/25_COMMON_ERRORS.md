# Скорая помощь Telegram-ботам: 25 частых ошибок и решений

### 1. `TelegramConflictError: Conflict: terminated by other getUpdates request`
- **Причина**: Бот запущен одновременно в двух терминалах (локально и на сервере).
- **Решение**: Убейте старый процесс: `pkill -f python` или остановите службу systemd.

### 2. `TelegramNetworkError: Cannot connect to host api.telegram.org`
- **Причина**: Блокировка провайдером или сбой локального DNS.
- **Решение**: Пропишите в `/etc/resolv.conf` публичные DNS `1.1.1.1` и `8.8.8.8` или используйте локальный прокси `aiohttp.TCPConnector`.

### 3. `TelegramBadRequest: Bad Request: can't parse entities`
- **Причина**: Неэкранированные спецсимволы в режиме `HTML` (`<`, `>`, `&`) или `MarkdownV2` (`_`, `*`, `[`).
- **Решение**: Используйте вспомогательную функцию `html.escape(text)`.
