# Чеклист починки Telegram-ботов
1. Ошибка 'Conflict: terminated by other getUpdates request':
   - Причина: запущено 2 экземпляра бота с одним токеном.
   - Решение: `pkill -f bot.py` или смените токен в @BotFather.
2. Ошибка 'TelegramForbiddenError: bot was blocked by the user':
   - Решение: перехватывать исключение и помечать пользователя неактивным в БД.
3. Ошибка Webhook conflict:
   - Сброс вебхука: `https://api.telegram.org/bot<TOKEN>/deleteWebhook?drop_pending_updates=True`
