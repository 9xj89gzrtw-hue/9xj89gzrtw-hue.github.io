"""Telegram Bot Environment & Diagnostic Checker."""
import sys
import urllib.request
import json

def check_telegram_api():
    print("[*] Проверка доступности серверов Telegram Bot API...")
    try:
        resp = urllib.request.urlopen("https://api.telegram.org", timeout=5)
        print("✅ Telegram API доступен из текущей сети!")
    except Exception as e:
        print(f"❌ Сбой подключения к Telegram API: {e}. Проверьте VPN / Прокси.")

def check_webhook(bot_token: str):
    url = f"https://api.telegram.org/bot{bot_token}/getWebhookInfo"
    try:
        with urllib.request.urlopen(url) as r:
            data = json.loads(r.read().decode())
            print("Webhook Info:", json.dumps(data, indent=2))
    except Exception as e:
        print("[-] Ошибка запроса:", e)

if __name__ == "__main__":
    check_telegram_api()
