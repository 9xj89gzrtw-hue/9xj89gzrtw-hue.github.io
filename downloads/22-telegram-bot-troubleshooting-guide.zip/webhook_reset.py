import urllib.request, sys
print('Usage: python3 webhook_reset.py <TOKEN>')
