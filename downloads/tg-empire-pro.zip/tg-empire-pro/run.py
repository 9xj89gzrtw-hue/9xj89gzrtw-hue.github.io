#!/usr/bin/env python3
"""TG-Empire Pro — точка входа.

    python3 run.py                 # http://127.0.0.1:8080
    python3 run.py --port 9000     # другой порт
    python3 run.py --demo          # демо-данные (по умолчанию включены)
    python3 run.py --bot           # плюс Telegram-бот в отдельном потоке
"""
from __future__ import annotations

import argparse
import os
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))

from app.core import DB, seed_demo  # noqa: E402
from app.server import serve  # noqa: E402


def main() -> int:
    parser = argparse.ArgumentParser(description="TG-Empire Pro admin server")
    parser.add_argument("--port", type=int, default=int(os.environ.get("PORT", 8080)))
    parser.add_argument("--host", default=os.environ.get("HOST", "127.0.0.1"))
    parser.add_argument("--demo", action="store_true", help="наполнить демо-данными")
    parser.add_argument("--no-demo", action="store_true", help="не добавлять демо-данные")
    parser.add_argument("--bot", action="store_true", help="запустить Telegram-бота")
    args = parser.parse_args()

    db = DB()
    if args.demo or (not args.no_demo and db.get_setting("demo_mode") == "1"):
        seed_demo(db)

    if args.bot:
        token = db.get_setting("bot_token")
        if not token:
            print("[bot] токен не задан: Настройки → Telegram-бот. Бот не запущен.")
        else:
            from app.bot import start_bot_thread
            start_bot_thread(token, db)
            print("[bot] запущен в фоне")

    httpd = serve(port=args.port, host=args.host)
    print(f"\n  TG-Empire Pro  ·  http://{args.host}:{args.port}")
    print(f"  Логин: admin / admin123 (смените в Настройках)\n")
    try:
        httpd.serve_forever()
    except KeyboardInterrupt:
        print("\n[server] остановлен")
    finally:
        httpd.server_close()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
