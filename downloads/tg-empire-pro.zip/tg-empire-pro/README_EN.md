# 🛍 TG-Empire Pro

**A turnkey Telegram store builder with a web admin panel.**
Catalog, orders, payments (Telegram Stars / USDT / SBP), automatic file delivery,
broadcasts and analytics — in one archive, with zero pip dependencies and no monthly fees.

![Dashboard](screenshots/01-dashboard.png)

---

## What you get

| Module | Features |
|---|---|
| **Web admin** | Dark UI, 6 sections, revenue chart, top products, live activity feed |
| **Catalog** | Emoji categories, products, prices in RUB / USD / Stars, stock, visibility |
| **Orders** | Status flow (pending → review → delivered), one-click confirm, CSV export |
| **Payments** | Telegram Stars, CryptoBot (USDT), SBP bank transfer with receipt upload |
| **Auto-delivery** | Text key + file (up to 30 MB) sent to the buyer right after payment |
| **Broadcasts** | Segments (all / buyers / inactive), campaign history |
| **Security** | PBKDF2-SHA256, HttpOnly 12-hour session, path-traversal protection |

**Stack:** Python 3.9+, standard library only, SQLite, Telegram Bot API.
No Flask / FastAPI / aiogram, **no `pip install`**, no CDN — runs fully offline.

---

## Screenshots

| Products | Orders | Broadcast |
|---|---|---|
| ![](screenshots/02-products.png) | ![](screenshots/03-orders.png) | ![](screenshots/04-broadcast.png) |

---

## Quick start (60 seconds)

### macOS / Linux
```bash
unzip tg-empire-pro.zip && cd tg-empire-pro
./start.sh
```

### Windows
Unzip and double-click **`start.bat`**.

### Docker
```bash
docker compose up -d --build
```

Open **http://127.0.0.1:8080**, password **`admin123`**, then change it under
*Settings → Security*.

> Demo data (8 products, 4 categories, 14 days of orders) is loaded with `--demo`.
> For a clean store run `python3 run.py --no-demo`.

---

## Connecting the Telegram bot

1. Message **@BotFather** → `/newbot` → copy the token.
2. In the admin: **Settings → Telegram bot** → paste token, username and your admin chat ID
   (get it from **@userinfobot**).
3. Start with the bot enabled:
   ```bash
   python3 run.py --bot
   ```
   The Docker command already includes `--bot`.

The bot uses **long polling** — no public IP, domain or SSL certificate required.

### Bot commands
| Command | Action |
|---|---|
| `/start` | Category catalog |
| `/orders` | Buyer's last 5 orders |
| `/help` | Help and support contact |

---

## Payments

### ⭐ Telegram Stars
Works out of the box — no tokens, no contracts. Set the Stars price per product.
Funds land on the bot balance; withdraw via @BotFather → *Bot Settings → Payments*.

### 💎 CryptoBot (USDT)
1. Open **@CryptoBot** → *Crypto Pay* → *Create App* → copy the API token.
2. Paste it into **Settings → Payment methods**.
3. The bot creates an invoice; the buyer pays and taps “Check payment” — delivery is automatic.

### 🏦 SBP (Russian bank transfer)
Set phone and bank in settings. The buyer transfers the amount and uploads a receipt;
you confirm with one click in **Orders** and the product is delivered.

> Every method can be enabled or disabled independently.

---

## Project layout

```
tg-empire-pro/
├── run.py              # entry point
├── app/
│   ├── core.py         # database, settings, stats, demo seed
│   ├── server.py       # admin HTTP server + JSON API
│   ├── bot.py          # Telegram bot (long polling)
│   └── payments.py     # Stars, CryptoBot, SBP
├── web/                # SPA admin (HTML/CSS/JS, no CDN)
├── tests/              # 9 API tests (unittest)
├── data/               # SQLite, uploads, session secret
├── start.sh / start.bat
└── docker-compose.yml
```

### API (for integrations)
```
POST /api/login              {"password": "..."}
GET  /api/stats              KPIs + 14-day series
GET  /api/products           product list
POST /api/products           create product
GET  /api/orders?status=     orders
POST /api/orders/{id}/confirm
POST /api/broadcast          {"text": "...", "audience": "all"}
GET  /api/settings
```

---

## Tests

```bash
python3 -m unittest discover -s tests -v
```
```
Ran 9 tests in 0.9s — OK
```

Covers auth, product/category CRUD, order lifecycle, broadcasts, secret masking and
password hashing.

---

## FAQ

**Do I need a domain?** No. The admin binds to `127.0.0.1`; to use it from your phone run
`HOST=0.0.0.0 ./start.sh` and open the machine's LAN IP.

**Where is the data?** `data/shop.db` (SQLite) and `data/uploads/`. Back up the `data/`
folder and you have everything.

**How many products can it handle?** SQLite handles tens of thousands of products and
hundreds of thousands of orders. The real limit is Telegram's ~30 messages/sec, not the DB.

**Can I use it for several stores?** Yes — the license allows unlimited own projects.
Reselling the archive itself is prohibited.

**How do I update?** Replace `app/` and `web/`, keep `data/`.

---

## License

Commercial usage license (see `LICENSE.txt`): one buyer, unlimited own projects.
Resale of the archive, public redistribution and rebranding for resale are prohibited.

© 2026 TG-Empire Pro · v1.0.0
