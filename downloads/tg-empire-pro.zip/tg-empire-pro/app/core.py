"""TG-Empire Pro — ядро: конфигурация, SQLite-схема, настройки, деньги.

Zero-dependency: только стандартная библиотека Python 3.9+.
"""
from __future__ import annotations

import hashlib
import hmac
import json
import os
import secrets
import sqlite3
import threading
import time
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent.parent
DATA_DIR = Path(os.environ.get("TG_EMPIRE_DATA", BASE_DIR / "data"))
UPLOAD_DIR = DATA_DIR / "uploads"
DB_PATH = Path(os.environ.get("TG_EMPIRE_DB", DATA_DIR / "shop.db"))

DATA_DIR.mkdir(parents=True, exist_ok=True)
UPLOAD_DIR.mkdir(parents=True, exist_ok=True)

DEFAULTS = {
    "shop_name": "TG-Empire Store",
    "shop_tagline": "Цифровые товары с моментальной выдачей",
    "currency": "RUB",
    "admin_password": "",          # заполняется при первом старте
    "bot_token": "",
    "bot_username": "",
    "cryptobot_token": "",
    "sbp_phone": "+7 900 000-00-00",
    "sbp_bank": "Сбербанк",
    "admin_chat_id": "",
    "support_username": "",
    "demo_mode": "1",
    "auto_delivery": "1",
    "stars_enabled": "1",
    "crypto_enabled": "1",
    "sbp_enabled": "1",
}


def now() -> int:
    return int(time.time())


def hash_password(password: str, salt: str | None = None) -> str:
    salt = salt or secrets.token_hex(16)
    digest = hashlib.pbkdf2_hmac("sha256", password.encode(), salt.encode(), 120_000)
    return f"{salt}${digest.hex()}"


def verify_password(password: str, stored: str) -> bool:
    if not stored or "$" not in stored:
        return False
    salt, _ = stored.split("$", 1)
    return hmac.compare_digest(hash_password(password, salt), stored)


class DB:
    """Тонкая обёртка над sqlite3 с авто-схемой."""

    def __init__(self, path: Path | str = DB_PATH):
        self.path = str(path)
        self._local = threading.local()
        self.conn.execute("PRAGMA journal_mode=WAL")
        self.conn.execute("PRAGMA busy_timeout=5000")
        self.conn.execute("PRAGMA foreign_keys=ON")
        self._init_schema()
        self._seed_defaults()

    @property
    def conn(self) -> sqlite3.Connection:
        """Отдельное соединение на поток — ThreadingHTTPServer безопасен."""
        conn = getattr(self._local, "conn", None)
        if conn is None:
            conn = sqlite3.connect(self.path, timeout=10, check_same_thread=False)
            conn.row_factory = sqlite3.Row
            conn.execute("PRAGMA journal_mode=WAL")
            conn.execute("PRAGMA busy_timeout=5000")
            conn.execute("PRAGMA foreign_keys=ON")
            self._local.conn = conn
        return conn

    # ---------- schema ----------
    def _init_schema(self) -> None:
        c = self.conn
        c.executescript(
            """
            CREATE TABLE IF NOT EXISTS categories(
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT NOT NULL,
                emoji TEXT DEFAULT '📦',
                sort INTEGER DEFAULT 100,
                created_at INTEGER NOT NULL
            );
            CREATE TABLE IF NOT EXISTS products(
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                category_id INTEGER REFERENCES categories(id) ON DELETE SET NULL,
                title TEXT NOT NULL,
                description TEXT DEFAULT '',
                price_rub REAL NOT NULL DEFAULT 0,
                price_usd REAL NOT NULL DEFAULT 0,
                price_stars INTEGER NOT NULL DEFAULT 0,
                stock INTEGER NOT NULL DEFAULT -1,
                active INTEGER NOT NULL DEFAULT 1,
                delivery_text TEXT DEFAULT '',
                file_path TEXT DEFAULT '',
                file_name TEXT DEFAULT '',
                sales INTEGER NOT NULL DEFAULT 0,
                created_at INTEGER NOT NULL
            );
            CREATE TABLE IF NOT EXISTS orders(
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                public_id TEXT NOT NULL UNIQUE,
                product_id INTEGER REFERENCES products(id) ON DELETE SET NULL,
                product_title TEXT DEFAULT '',
                buyer_id TEXT DEFAULT '',
                buyer_username TEXT DEFAULT '',
                amount REAL NOT NULL DEFAULT 0,
                currency TEXT NOT NULL DEFAULT 'RUB',
                method TEXT NOT NULL DEFAULT 'stars',
                status TEXT NOT NULL DEFAULT 'pending',
                payload TEXT DEFAULT '',
                receipt TEXT DEFAULT '',
                created_at INTEGER NOT NULL,
                paid_at INTEGER DEFAULT 0,
                delivered_at INTEGER DEFAULT 0
            );
            CREATE TABLE IF NOT EXISTS broadcasts(
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                text TEXT NOT NULL,
                audience TEXT NOT NULL DEFAULT 'all',
                sent INTEGER NOT NULL DEFAULT 0,
                failed INTEGER NOT NULL DEFAULT 0,
                status TEXT NOT NULL DEFAULT 'draft',
                created_at INTEGER NOT NULL
            );
            CREATE TABLE IF NOT EXISTS customers(
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                tg_id TEXT NOT NULL UNIQUE,
                username TEXT DEFAULT '',
                first_seen INTEGER NOT NULL,
                last_seen INTEGER NOT NULL
            );
            CREATE TABLE IF NOT EXISTS settings(key TEXT PRIMARY KEY, value TEXT NOT NULL);
            CREATE TABLE IF NOT EXISTS events(
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                kind TEXT NOT NULL,
                message TEXT NOT NULL,
                created_at INTEGER NOT NULL
            );
            CREATE INDEX IF NOT EXISTS idx_orders_created ON orders(created_at);
            CREATE INDEX IF NOT EXISTS idx_products_cat ON products(category_id);
            """
        )
        c.commit()

    def _seed_defaults(self) -> None:
        for key, value in DEFAULTS.items():
            self.conn.execute(
                "INSERT OR IGNORE INTO settings(key, value) VALUES(?,?)", (key, value)
            )
        row = self.conn.execute("SELECT value FROM settings WHERE key='admin_password'").fetchone()
        if row and not row["value"]:
            self.set_setting("admin_password", hash_password("admin123"))
            self.log("system", "Создан пароль администратора по умолчанию (admin123) — смените его.")
        self.conn.commit()

    # ---------- settings ----------
    def get_setting(self, key: str, default: str = "") -> str:
        row = self.conn.execute("SELECT value FROM settings WHERE key=?", (key,)).fetchone()
        return row["value"] if row else default

    def set_setting(self, key: str, value: str) -> None:
        self.conn.execute(
            "INSERT INTO settings(key,value) VALUES(?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value",
            (key, str(value)),
        )
        self.conn.commit()

    def settings_dict(self, safe: bool = True) -> dict:
        data = {r["key"]: r["value"] for r in self.conn.execute("SELECT * FROM settings")}
        if safe:
            data.pop("admin_password", None)
            if data.get("bot_token"):
                data["bot_token"] = mask_secret(data["bot_token"])
            if data.get("cryptobot_token"):
                data["cryptobot_token"] = mask_secret(data["cryptobot_token"])
        return data

    # ---------- events ----------
    def log(self, kind: str, message: str) -> None:
        self.conn.execute(
            "INSERT INTO events(kind,message,created_at) VALUES(?,?,?)", (kind, message, now())
        )
        self.conn.commit()

    # ---------- categories ----------
    def categories(self) -> list[dict]:
        rows = self.conn.execute(
            """SELECT c.*, (SELECT COUNT(*) FROM products p WHERE p.category_id=c.id AND p.active=1) AS products
               FROM categories c ORDER BY c.sort, c.id"""
        ).fetchall()
        return [dict(r) for r in rows]

    def add_category(self, name: str, emoji: str = "📦", sort: int = 100) -> int:
        cur = self.conn.execute(
            "INSERT INTO categories(name,emoji,sort,created_at) VALUES(?,?,?,?)",
            (name.strip(), emoji.strip() or "📦", sort, now()),
        )
        self.conn.commit()
        return int(cur.lastrowid)

    def update_category(self, cid: int, **fields) -> None:
        allowed = {k: v for k, v in fields.items() if k in {"name", "emoji", "sort"}}
        if not allowed:
            return
        sets = ", ".join(f"{k}=?" for k in allowed)
        self.conn.execute(f"UPDATE categories SET {sets} WHERE id=?", (*allowed.values(), cid))
        self.conn.commit()

    def delete_category(self, cid: int) -> None:
        self.conn.execute("DELETE FROM categories WHERE id=?", (cid,))
        self.conn.commit()

    # ---------- products ----------
    def products(self, active_only: bool = False, category_id: int | None = None) -> list[dict]:
        sql = """SELECT p.*, c.name AS category_name, c.emoji AS category_emoji
                 FROM products p LEFT JOIN categories c ON c.id=p.category_id WHERE 1=1"""
        args: list = []
        if active_only:
            sql += " AND p.active=1"
        if category_id is not None:
            sql += " AND p.category_id=?"
            args.append(category_id)
        sql += " ORDER BY p.id DESC"
        return [dict(r) for r in self.conn.execute(sql, args)]

    def product(self, pid: int) -> dict | None:
        row = self.conn.execute("SELECT * FROM products WHERE id=?", (pid,)).fetchone()
        return dict(row) if row else None

    def add_product(self, **f) -> int:
        fields = {
            "category_id": f.get("category_id"),
            "title": f.get("title", "").strip(),
            "description": f.get("description", ""),
            "price_rub": float(f.get("price_rub") or 0),
            "price_usd": float(f.get("price_usd") or 0),
            "price_stars": int(f.get("price_stars") or 0),
            "stock": int(f.get("stock", -1)),
            "active": int(f.get("active", 1)),
            "delivery_text": f.get("delivery_text", ""),
            "file_path": f.get("file_path", ""),
            "file_name": f.get("file_name", ""),
            "created_at": now(),
        }
        cols = ", ".join(fields)
        marks = ", ".join("?" for _ in fields)
        cur = self.conn.execute(
            f"INSERT INTO products({cols}) VALUES({marks})", tuple(fields.values())
        )
        self.conn.commit()
        return int(cur.lastrowid)

    def update_product(self, pid: int, **f) -> None:
        allowed_keys = {
            "category_id", "title", "description", "price_rub", "price_usd",
            "price_stars", "stock", "active", "delivery_text", "file_path", "file_name",
        }
        data = {k: v for k, v in f.items() if k in allowed_keys}
        if not data:
            return
        sets = ", ".join(f"{k}=?" for k in data)
        self.conn.execute(f"UPDATE products SET {sets} WHERE id=?", (*data.values(), pid))
        self.conn.commit()

    def delete_product(self, pid: int) -> None:
        self.conn.execute("DELETE FROM products WHERE id=?", (pid,))
        self.conn.commit()

    # ---------- orders ----------
    def create_order(self, product: dict, buyer_id: str = "", buyer_username: str = "",
                     method: str = "stars", amount: float | None = None,
                     currency: str | None = None, status: str = "pending",
                     payload: str = "") -> dict:
        public_id = "TE-" + secrets.token_hex(4).upper()
        amount = product["price_rub"] if amount is None else amount
        currency = currency or (self.get_setting("currency") or "RUB")
        self.conn.execute(
            """INSERT INTO orders(public_id,product_id,product_title,buyer_id,buyer_username,
                                   amount,currency,method,status,payload,created_at)
               VALUES(?,?,?,?,?,?,?,?,?,?,?)""",
            (public_id, product["id"], product["title"], str(buyer_id), buyer_username,
             amount, currency, method, status, payload, now()),
        )
        self.conn.commit()
        return self.order_by_public_id(public_id)  # type: ignore[return-value]

    def order_by_public_id(self, public_id: str) -> dict | None:
        row = self.conn.execute("SELECT * FROM orders WHERE public_id=?", (public_id,)).fetchone()
        return dict(row) if row else None

    def mark_paid(self, public_id: str, delivered: bool = False) -> dict | None:
        order = self.order_by_public_id(public_id)
        if not order:
            return None
        ts = now()
        self.conn.execute(
            "UPDATE orders SET status=?, paid_at=?, delivered_at=? WHERE public_id=?",
            ("delivered" if delivered else "paid", ts, ts if delivered else 0, public_id),
        )
        self.conn.execute(
            "UPDATE products SET sales=sales+1, stock=CASE WHEN stock>0 THEN stock-1 ELSE stock END WHERE id=?",
            (order["product_id"],),
        )
        self.conn.commit()
        self.log("order", f"Оплачен заказ {public_id} — {order['product_title']}")
        return self.order_by_public_id(public_id)

    def mark_delivered(self, public_id: str) -> None:
        self.conn.execute(
            "UPDATE orders SET status='delivered', delivered_at=? WHERE public_id=?", (now(), public_id)
        )
        self.conn.commit()

    def cancel_order(self, public_id: str) -> None:
        self.conn.execute("UPDATE orders SET status='cancelled' WHERE public_id=?", (public_id,))
        self.conn.commit()

    def orders(self, limit: int = 100, status: str | None = None) -> list[dict]:
        sql = "SELECT * FROM orders WHERE 1=1"
        args: list = []
        if status:
            sql += " AND status=?"
            args.append(status)
        sql += " ORDER BY id DESC LIMIT ?"
        args.append(limit)
        return [dict(r) for r in self.conn.execute(sql, args)]

    # ---------- customers ----------
    def touch_customer(self, tg_id: str, username: str = "") -> None:
        ts = now()
        self.conn.execute(
            """INSERT INTO customers(tg_id,username,first_seen,last_seen) VALUES(?,?,?,?)
               ON CONFLICT(tg_id) DO UPDATE SET last_seen=excluded.last_seen,
                 username=CASE WHEN excluded.username<>'' THEN excluded.username ELSE customers.username END""",
            (str(tg_id), username, ts, ts),
        )
        self.conn.commit()

    def customers(self, limit: int = 500) -> list[dict]:
        return [dict(r) for r in self.conn.execute(
            "SELECT * FROM customers ORDER BY last_seen DESC LIMIT ?", (limit,))]

    # ---------- stats ----------
    def stats(self, days: int = 14) -> dict:
        paid = ("paid", "delivered")
        row = self.conn.execute(
            "SELECT COUNT(*) n, COALESCE(SUM(amount),0) s FROM orders WHERE status IN (?,?)", paid
        ).fetchone()
        delivered = self.conn.execute(
            "SELECT COUNT(*) n FROM orders WHERE status='delivered'"
        ).fetchone()["n"]
        pending = self.conn.execute(
            "SELECT COUNT(*) n FROM orders WHERE status='pending'"
        ).fetchone()["n"]
        customers = self.conn.execute("SELECT COUNT(*) n FROM customers").fetchone()["n"]
        products = self.conn.execute("SELECT COUNT(*) n FROM products WHERE active=1").fetchone()["n"]
        revenue = float(row["s"] or 0)
        orders_n = int(row["n"] or 0)

        # дневной ряд для графика
        series = []
        today = time.gmtime()
        day_start = int(time.mktime((today.tm_year, today.tm_mon, today.tm_mday, 0, 0, 0, 0, 0, -1)))
        for i in range(days - 1, -1, -1):
            start = day_start - i * 86400
            end = start + 86400
            r = self.conn.execute(
                "SELECT COUNT(*) n, COALESCE(SUM(amount),0) s FROM orders "
                "WHERE status IN ('paid','delivered') AND created_at>=? AND created_at<?",
                (start, end),
            ).fetchone()
            series.append({
                "date": time.strftime("%d.%m", time.localtime(start)),
                "orders": int(r["n"] or 0),
                "revenue": round(float(r["s"] or 0), 2),
            })

        last7 = sum(d["revenue"] for d in series[-7:])
        prev7 = sum(d["revenue"] for d in series[-14:-7]) or 0
        rev_delta = round((last7 - prev7) / prev7 * 100, 1) if prev7 else 0.0
        o_last7 = sum(d["orders"] for d in series[-7:])
        o_prev7 = sum(d["orders"] for d in series[-14:-7]) or 0
        ord_delta = round((o_last7 - o_prev7) / o_prev7 * 100, 1) if o_prev7 else 0.0

        by_method = [dict(r) for r in self.conn.execute(
            """SELECT method, COUNT(*) n, COALESCE(SUM(amount),0) s FROM orders
               WHERE status IN ('paid','delivered') GROUP BY method ORDER BY s DESC"""
        )]
        top = [dict(r) for r in self.conn.execute(
            """SELECT product_title, COUNT(*) n, COALESCE(SUM(amount),0) s FROM orders
               WHERE status IN ('paid','delivered') GROUP BY product_title ORDER BY s DESC LIMIT 5"""
        )]
        return {
            "revenue": round(revenue, 2),
            "orders": orders_n,
            "delivered": delivered,
            "pending": pending,
            "customers": customers,
            "products": products,
            "avg_check": round(revenue / orders_n, 2) if orders_n else 0,
            "repeat_rate": round(max(0, orders_n - customers) / orders_n * 100, 1) if orders_n else 0.0,
            "revenue_delta": rev_delta,
            "orders_delta": ord_delta,
            "series": series,
            "by_method": by_method,
            "top_products": top,
            "currency": self.get_setting("currency") or "RUB",
        }

    # ---------- events ----------
    def events(self, limit: int = 12) -> list[dict]:
        return [dict(r) for r in self.conn.execute(
            "SELECT * FROM events ORDER BY id DESC LIMIT ?", (limit,))]


def mask_secret(value: str) -> str:
    value = value.strip()
    if len(value) <= 8:
        return "•" * len(value)
    return value[:4] + "•" * 8 + value[-4:]


def money(amount: float, currency: str = "RUB") -> str:
    if currency == "USD":
        return f"${amount:,.2f}"
    if currency == "XTR":
        return f"{int(amount)} ⭐"
    return f"{amount:,.0f} ₽".replace(",", " ")


def seed_demo(db: DB) -> None:
    """Наполняет магазин демо-данными для витрины/скриншотов (идемпотентно)."""
    if db.conn.execute("SELECT COUNT(*) n FROM products").fetchone()["n"] > 0:
        return
    cats = [
        ("Telegram-боты", "🤖", 10),
        ("Гайды и курсы", "📚", 20),
        ("Шаблоны", "🧩", 30),
        ("Подписки", "🔑", 40),
    ]
    ids = [db.add_category(name, emoji, sort) for name, emoji, sort in cats]
    demo = [
        (ids[0], "Бот-магазин «под ключ»", "Готовый Telegram-бот с каталогом, корзиной и оплатой. Исходники + инструкция.",
         2490, 29, 149, -1, "Спасибо за покупку! Архив: github.com/your/bot-shop\nКлюч активации: TGEMP-2026-XXXX"),
        (ids[0], "Бот-визитка Premium", "Минималистичный бот-визитка с меню, портфолио и заявками.", 990, 12, 59, 50, ""),
        (ids[1], "Гайд: 100 000 ₽ на цифровых товарах", "PDF на 48 страниц: выбор ниши, поставщики, автовыдача, первые продажи.", 1490, 17, 89, -1, ""),
        (ids[1], "Мини-курс «Telegram Stars»", "5 видеоуроков: приём Stars, возвраты, выплаты, налоги.", 1990, 23, 119, -1, ""),
        (ids[2], "Шаблон лендинга Dark Premium", "HTML/CSS/JS, адаптив, анимации, форма заявки. Без зависимостей.", 790, 9, 45, -1, ""),
        (ids[2], "Набор иконок 240 SVG", "240 иконок в едином стиле, оптимизированы, подключение в 1 строку.", 590, 7, 35, -1, ""),
        (ids[3], "VPN на 12 месяцев", "Ключ активации на 12 месяцев, 5 устройств, без логов.", 2990, 35, 179, 25, ""),
        (ids[3], "Подписка на нейросети", "Доступ к 12 моделям, 1 месяц, личный кабинет.", 1290, 15, 79, 100, ""),
    ]
    for cat, title, desc, rub, usd, stars, stock, delivery in demo:
        db.add_product(category_id=cat, title=title, description=desc, price_rub=rub,
                       price_usd=usd, price_stars=stars, stock=stock, delivery_text=delivery)

    # покупатели + заказы за две недели
    buyers = [("501234567", "ivan_petrov"), ("502345678", "digi_hunter"),
              ("503456789", "maria_s"), ("504567890", "nordwind"),
              ("505678901", "tg_deals"), ("506789012", "alexey_k")]
    for tg_id, username in buyers:
        db.touch_customer(tg_id, username)

    products = db.products()
    methods = ["stars", "cryptobot", "sbp", "stars", "cryptobot"]
    seq = 0
    for day in range(13, -1, -1):
        # лёгкий рост продаж к сегодняшнему дню
        count = 1 if day > 10 else (2 if day > 6 else 3)
        for i in range(count):
            p = products[seq % len(products)]
            seq += 1
            o = db.create_order(p, buyer_id=buyers[seq % len(buyers)][0],
                                buyer_username=buyers[seq % len(buyers)][1],
                                method=methods[seq % len(methods)],
                                amount=p["price_rub"], currency="RUB",
                                status="delivered")
            ts = now() - day * 86400 - 3600 * (3 + i * 2)
            db.conn.execute(
                "UPDATE orders SET created_at=?, paid_at=?, delivered_at=? WHERE id=?",
                (ts, ts + 90, ts + 120, o["id"]),
            )
            db.conn.execute("UPDATE products SET sales=sales+1 WHERE id=?", (p["id"],))
    # один заказ ждёт подтверждения оплаты по СБП
    pending = db.create_order(products[2], buyer_id="507890123", buyer_username="new_buyer",
                              method="sbp", amount=products[2]["price_rub"], status="pending")
    db.conn.execute("UPDATE orders SET created_at=? WHERE id=?", (now() - 420, pending["id"]))
    db.conn.commit()
    db.log("system", "Демо-данные загружены: 8 товаров, 4 категории, 14 дней заказов.")
