"""TG-Empire Pro — HTTP-сервер админки (stdlib only).

Запуск: python3 run.py [--port 8080]
"""
from __future__ import annotations

import hmac
import json
import mimetypes
import os
import re
import secrets
import time
from http import cookies
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import parse_qs, urlparse

from .core import BASE_DIR, DATA_DIR, DB, UPLOAD_DIR, hash_password, now, verify_password

WEB_DIR = BASE_DIR / "web"
SECRET_FILE = DATA_DIR / "secret.key"

SESSION_COOKIE = "te_session"
SESSION_TTL = 60 * 60 * 12


def _secret() -> bytes:
    if SECRET_FILE.exists():
        return SECRET_FILE.read_bytes()
    value = secrets.token_bytes(32)
    SECRET_FILE.write_bytes(value)
    try:
        SECRET_FILE.chmod(0o600)
    except OSError:
        pass
    return value


SECRET = _secret()


def make_session() -> str:
    ts = str(int(time.time()))
    sig = hmac.new(SECRET, ts.encode(), "sha256").hexdigest()[:40]
    return f"{ts}.{sig}"


def valid_session(token: str) -> bool:
    if not token or "." not in token:
        return False
    ts, sig = token.split(".", 1)
    expected = hmac.new(SECRET, ts.encode(), "sha256").hexdigest()[:40]
    if not hmac.compare_digest(sig, expected):
        return False
    try:
        return time.time() - int(ts) < SESSION_TTL
    except ValueError:
        return False


class ApiError(Exception):
    def __init__(self, message: str, status: int = 400):
        super().__init__(message)
        self.message = message
        self.status = status


class Handler(BaseHTTPRequestHandler):
    db: DB
    server_version = "TGEmpire/1.0"

    # ---------- helpers ----------
    def log_message(self, fmt, *args):  # тише в консоли
        if os.environ.get("TG_EMPIRE_QUIET") == "1":
            return
        print("[http] " + fmt % args)

    def _send(self, status: int, body: bytes, content_type: str = "application/json; charset=utf-8",
              extra: dict | None = None) -> None:
        self.send_response(status)
        self.send_header("Content-Type", content_type)
        self.send_header("Content-Length", str(len(body)))
        self.send_header("X-Content-Type-Options", "nosniff")
        self.send_header("Cache-Control", "no-store")
        for k, v in (extra or {}).items():
            self.send_header(k, v)
        self.end_headers()
        if self.command != "HEAD":
            self.wfile.write(body)

    def json(self, data, status: int = 200, extra: dict | None = None) -> None:
        self._send(status, json.dumps(data, ensure_ascii=False).encode(), extra=extra)

    def error(self, message: str, status: int = 400) -> None:
        self.json({"ok": False, "error": message}, status)

    def session_token(self) -> str:
        raw = self.headers.get("Cookie", "")
        jar = cookies.SimpleCookie()
        try:
            jar.load(raw)
        except cookies.CookieError:
            return ""
        morsel = jar.get(SESSION_COOKIE)
        return morsel.value if morsel else ""

    def require_auth(self) -> None:
        if not valid_session(self.session_token()):
            raise ApiError("Требуется вход в панель", 401)

    def body(self) -> dict:
        length = int(self.headers.get("Content-Length") or 0)
        if length > 30 * 1024 * 1024:
            raise ApiError("Слишком большое тело запроса", 413)
        raw = self.rfile.read(length) if length else b""
        if not raw:
            return {}
        ctype = self.headers.get("Content-Type", "")
        if "application/json" in ctype:
            try:
                data = json.loads(raw.decode("utf-8"))
            except (ValueError, UnicodeDecodeError):
                raise ApiError("Некорректный JSON")
            if not isinstance(data, dict):
                raise ApiError("Ожидался JSON-объект")
            return data
        if "multipart/form-data" in ctype:
            return {"_multipart": self.parse_multipart(raw, ctype)}
        return {k: v[0] for k, v in parse_qs(raw.decode("utf-8", "replace")).items()}

    def parse_multipart(self, raw: bytes, ctype: str) -> dict:
        m = re.search(r"boundary=([^;]+)", ctype)
        if not m:
            raise ApiError("Нет boundary в multipart")
        boundary = ("--" + m.group(1).strip('"')).encode()
        result: dict = {"fields": {}, "files": []}
        for part in raw.split(boundary):
            part = part.strip(b"\r\n")
            if not part or part == b"--":
                continue
            if b"\r\n\r\n" not in part:
                continue
            head, payload = part.split(b"\r\n\r\n", 1)
            headers = head.decode("utf-8", "replace")
            name_m = re.search(r'name="([^"]*)"', headers)
            file_m = re.search(r'filename="([^"]*)"', headers)
            if not name_m:
                continue
            name = name_m.group(1)
            if file_m:
                result["files"].append({
                    "field": name,
                    "filename": Path(file_m.group(1)).name,
                    "data": payload,
                })
            else:
                result["fields"][name] = payload.decode("utf-8", "replace")
        return result

    # ---------- routing ----------
    def do_GET(self):
        parsed = urlparse(self.path)
        path, query = parsed.path, parse_qs(parsed.query)
        try:
            if path.startswith("/api/"):
                self.handle_api("GET", path, query, None)
            elif path.startswith("/files/"):
                self.serve_upload(path)
            else:
                self.serve_static(path)
        except ApiError as e:
            self.error(e.message, e.status)
        except BrokenPipeError:
            pass
        except Exception as e:  # noqa: BLE001
            print("[error]", repr(e))
            self.error("Внутренняя ошибка сервера", 500)

    def do_HEAD(self):
        self.do_GET()

    def do_POST(self):
        self._mutate("POST")

    def do_PUT(self):
        self._mutate("PUT")

    def do_DELETE(self):
        self._mutate("DELETE")

    def _mutate(self, method: str):
        parsed = urlparse(self.path)
        try:
            data = self.body()
            self.handle_api(method, parsed.path, parse_qs(parsed.query), data)
        except ApiError as e:
            self.error(e.message, e.status)
        except BrokenPipeError:
            pass
        except Exception as e:  # noqa: BLE001
            print("[error]", repr(e))
            self.error("Внутренняя ошибка сервера", 500)

    # ---------- static ----------
    def serve_static(self, path: str) -> None:
        if path in ("/", ""):
            path = "/index.html"
        target = (WEB_DIR / path.lstrip("/")).resolve()
        if not str(target).startswith(str(WEB_DIR.resolve())) or not target.is_file():
            # SPA-fallback только для не-API путей
            target = WEB_DIR / "index.html"
            if not target.is_file():
                self.error("Файл не найден", 404)
                return
        ctype = mimetypes.guess_type(str(target))[0] or "application/octet-stream"
        self._send(200, target.read_bytes(), ctype + ("; charset=utf-8" if ctype.startswith("text/") or ctype.endswith("javascript") else ""))

    def serve_upload(self, path: str) -> None:
        name = Path(path).name
        target = (UPLOAD_DIR / name).resolve()
        if not str(target).startswith(str(UPLOAD_DIR.resolve())) or not target.is_file():
            self.error("Файл не найден", 404)
            return
        ctype = mimetypes.guess_type(str(target))[0] or "application/octet-stream"
        self._send(200, target.read_bytes(), ctype, {"Content-Disposition": f'inline; filename="{name}"'})

    # ---------- api ----------
    def handle_api(self, method: str, path: str, query: dict, data: dict | None) -> None:
        db = self.db

        if path == "/api/health":
            return self.json({"ok": True, "service": "tg-empire-pro", "version": "1.0.0"})

        if path == "/api/login" and method == "POST":
            password = str((data or {}).get("password", ""))
            if verify_password(password, db.get_setting("admin_password")):
                token = make_session()
                return self.json({"ok": True}, extra={
                    "Set-Cookie": f"{SESSION_COOKIE}={token}; Path=/; HttpOnly; SameSite=Lax; Max-Age={SESSION_TTL}"
                })
            db.log("auth", "Неудачная попытка входа в админку")
            return self.error("Неверный пароль", 401)

        if path == "/api/logout" and method == "POST":
            return self.json({"ok": True}, extra={
                "Set-Cookie": f"{SESSION_COOKIE}=; Path=/; HttpOnly; SameSite=Lax; Max-Age=0"
            })

        if path == "/api/me":
            return self.json({"ok": True, "authenticated": valid_session(self.session_token()),
                              "demo": db.get_setting("demo_mode") == "1"})

        self.require_auth()

        if path == "/api/stats" and method == "GET":
            return self.json({"ok": True, "data": db.stats()})

        if path == "/api/events" and method == "GET":
            return self.json({"ok": True, "data": db.events()})

        if path == "/api/categories":
            if method == "GET":
                return self.json({"ok": True, "data": db.categories()})
            if method == "POST":
                name = str((data or {}).get("name", "")).strip()
                if not name:
                    raise ApiError("Название категории обязательно")
                cid = db.add_category(name, str((data or {}).get("emoji", "📦")),
                                      int((data or {}).get("sort", 100)))
                return self.json({"ok": True, "id": cid}, 201)

        m = re.match(r"^/api/categories/(\d+)$", path)
        if m:
            cid = int(m.group(1))
            if method == "PUT":
                db.update_category(cid, **(data or {}))
                return self.json({"ok": True})
            if method == "DELETE":
                db.delete_category(cid)
                return self.json({"ok": True})

        if path == "/api/products":
            if method == "GET":
                category = query.get("category", [None])[0]
                return self.json({"ok": True, "data": db.products(
                    active_only=query.get("active", ["0"])[0] == "1",
                    category_id=int(category) if category else None)})
            if method == "POST":
                payload = data or {}
                if not str(payload.get("title", "")).strip():
                    raise ApiError("Название товара обязательно")
                pid = db.add_product(**payload)
                db.log("product", f"Создан товар «{payload.get('title')}»")
                return self.json({"ok": True, "id": pid}, 201)

        m = re.match(r"^/api/products/(\d+)$", path)
        if m:
            pid = int(m.group(1))
            if method == "GET":
                product = db.product(pid)
                if not product:
                    raise ApiError("Товар не найден", 404)
                return self.json({"ok": True, "data": product})
            if method == "PUT":
                db.update_product(pid, **(data or {}))
                return self.json({"ok": True})
            if method == "DELETE":
                db.delete_product(pid)
                return self.json({"ok": True})

        if path == "/api/orders" and method == "GET":
            status = query.get("status", [None])[0]
            return self.json({"ok": True, "data": db.orders(status=status)})

        m = re.match(r"^/api/orders/([\w-]+)/(confirm|cancel|deliver)$", path)
        if m and method == "POST":
            public_id, action = m.group(1), m.group(2)
            if action == "confirm":
                order = db.mark_paid(public_id, delivered=db.get_setting("auto_delivery") == "1")
                if not order:
                    raise ApiError("Заказ не найден", 404)
                return self.json({"ok": True, "data": order})
            if action == "deliver":
                db.mark_delivered(public_id)
                return self.json({"ok": True})
            db.cancel_order(public_id)
            return self.json({"ok": True})

        if path == "/api/customers" and method == "GET":
            return self.json({"ok": True, "data": db.customers()})

        if path == "/api/broadcast" and method == "POST":
            text = str((data or {}).get("text", "")).strip()
            if len(text) < 3:
                raise ApiError("Текст рассылки слишком короткий")
            audience = str((data or {}).get("audience", "all"))
            cur = db.conn.execute(
                "INSERT INTO broadcasts(text,audience,status,created_at) VALUES(?,?,?,?)",
                (text, audience, "queued", now()),
            )
            db.conn.commit()
            db.log("broadcast", f"Рассылка #{cur.lastrowid} поставлена в очередь ({audience})")
            return self.json({"ok": True, "id": cur.lastrowid,
                              "queued": db.conn.execute("SELECT COUNT(*) n FROM customers").fetchone()["n"]})

        if path == "/api/broadcasts" and method == "GET":
            rows = [dict(r) for r in db.conn.execute("SELECT * FROM broadcasts ORDER BY id DESC LIMIT 50")]
            return self.json({"ok": True, "data": rows})

        if path == "/api/settings":
            if method == "GET":
                return self.json({"ok": True, "data": db.settings_dict()})
            if method == "PUT":
                payload = data or {}
                if payload.get("new_password"):
                    pwd = str(payload.pop("new_password"))
                    if len(pwd) < 8:
                        raise ApiError("Пароль должен быть не короче 8 символов")
                    db.set_setting("admin_password", hash_password(pwd))
                    payload.pop("new_password_repeat", None)
                for key, value in payload.items():
                    if key in {"admin_password"}:
                        continue
                    db.set_setting(key, str(value))
                db.log("settings", "Настройки магазина обновлены")
                return self.json({"ok": True})

        if path == "/api/upload" and method == "POST":
            mp = (data or {}).get("_multipart")
            if not mp:
                raise ApiError("Нужен multipart/form-data")
            saved = []
            for f in mp["files"]:
                if not f["data"]:
                    continue
                safe = re.sub(r"[^\w.\-А-Яа-яЁё ]+", "_", f["filename"])[:120]
                name = f"{now()}-{secrets.token_hex(3)}-{safe}"
                (UPLOAD_DIR / name).write_bytes(f["data"])
                saved.append({"name": f["filename"], "path": name, "url": f"/files/{name}",
                              "size": len(f["data"])})
            if not saved:
                raise ApiError("Файл не получен")
            return self.json({"ok": True, "files": saved})

        raise ApiError("Метод API не найден", 404)


def serve(port: int = 8080, host: str = "127.0.0.1") -> ThreadingHTTPServer:
    db = DB()
    Handler.db = db
    httpd = ThreadingHTTPServer((host, port), Handler)
    httpd.daemon_threads = True
    return httpd
