"""Пакет приложения TG-Empire Pro."""
__version__ = "1.0.0"
