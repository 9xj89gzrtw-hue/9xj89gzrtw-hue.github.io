"""Telegram-бот магазина: каталог, оплата, автовыдача.

Работает через Bot API напрямую (long polling), без aiogram/telebot.
"""
from __future__ import annotations

import html
import json
import mimetypes
import os
import threading
import time
import urllib.error
import urllib.request
import uuid
from pathlib import Path

from .core import DATA_DIR, DB, UPLOAD_DIR
from .payments import CryptoBot, PaymentError, sbp_text

API = "https://api.telegram.org/bot{token}/{method}"
OFFSET_FILE = DATA_DIR / "bot_offset.txt"


class BotAPI:
    def __init__(self, token: str):
        self.token = token

    def call(self, method: str, _read_timeout: int = 40, **params):
        url = API.format(token=self.token, method=method)
        data = json.dumps(params).encode()
        req = urllib.request.Request(url, data=data, method="POST")
        req.add_header("Content-Type", "application/json")
        try:
            with urllib.request.urlopen(req, timeout=_read_timeout) as resp:
                payload = json.loads(resp.read().decode())
        except urllib.error.HTTPError as e:
            payload = json.loads(e.read().decode("utf-8", "replace") or "{}")
        except (urllib.error.URLError, TimeoutError) as e:
            raise ConnectionError(f"Telegram API недоступен: {e}") from e
        if not payload.get("ok"):
            raise RuntimeError(payload.get("description") or "Telegram API error")
        return payload.get("result")

    def send_message(self, chat_id, text: str, keyboard: dict | None = None,
                     parse_mode: str = "HTML", preview: bool = False):
        params = {"chat_id": chat_id, "text": text, "parse_mode": parse_mode,
                  "disable_web_page_preview": not preview}
        if keyboard:
            params["reply_markup"] = keyboard
        return self.call("sendMessage", **params)

    def edit(self, chat_id, message_id, text: str, keyboard: dict | None = None):
        params = {"chat_id": chat_id, "message_id": message_id, "text": text, "parse_mode": "HTML"}
        if keyboard:
            params["reply_markup"] = keyboard
        try:
            return self.call("editMessageText", **params)
        except RuntimeError:
            return None

    def answer(self, callback_id: str, text: str = "", alert: bool = False):
        return self.call("answerCallbackQuery", callback_query_id=callback_id,
                         text=text[:190], show_alert=alert)

    def send_document(self, chat_id, path: Path, caption: str = ""):
        boundary = uuid.uuid4().hex
        ctype = mimetypes.guess_type(str(path))[0] or "application/octet-stream"
        parts = [
            f"--{boundary}\r\nContent-Disposition: form-data; name=\"chat_id\"\r\n\r\n{chat_id}\r\n".encode(),
            f"--{boundary}\r\nContent-Disposition: form-data; name=\"caption\"\r\n\r\n{caption}\r\n".encode(),
            (f"--{boundary}\r\nContent-Disposition: form-data; name=\"document\"; "
             f"filename=\"{path.name}\"\r\nContent-Type: {ctype}\r\n\r\n").encode(),
            path.read_bytes(),
            f"\r\n--{boundary}--\r\n".encode(),
        ]
        body = b"".join(parts)
        req = urllib.request.Request(
            API.format(token=self.token, method="sendDocument"), data=body, method="POST")
        req.add_header("Content-Type", f"multipart/form-data; boundary={boundary}")
        with urllib.request.urlopen(req, timeout=120) as resp:
            return json.loads(resp.read().decode())


def btn(text: str, data: str) -> dict:
    return {"text": text, "callback_data": data}


def kb(rows: list[list[dict]]) -> dict:
    return {"inline_keyboard": rows}


class ShopBot:
    def __init__(self, token: str, db: DB):
        self.api = BotAPI(token)
        self.db = db
        self.pending_receipts: dict[str, str] = {}
        self._stop = threading.Event()

    # ---------- запуск ----------
    def run_forever(self) -> None:
        print("[bot] polling started")
        offset = 0
        if OFFSET_FILE.exists():
            try:
                offset = int(OFFSET_FILE.read_text().strip() or 0)
            except ValueError:
                offset = 0
        while not self._stop.is_set():
            try:
                updates = self.api.call("getUpdates", _read_timeout=60, offset=offset,
                                        timeout=30, allowed_updates=["message", "callback_query",
                                                                     "pre_checkout_query"])
            except Exception as e:  # noqa: BLE001
                print("[bot] polling error:", e)
                time.sleep(5)
                continue
            for upd in updates or []:
                offset = upd["update_id"] + 1
                OFFSET_FILE.write_text(str(offset))
                try:
                    self.handle(upd)
                except Exception as e:  # noqa: BLE001
                    print("[bot] handler error:", repr(e))

    def stop(self) -> None:
        self._stop.set()

    # ---------- dispatcher ----------
    def handle(self, upd: dict) -> None:
        if "message" in upd:
            self.on_message(upd["message"])
        elif "callback_query" in upd:
            self.on_callback(upd["callback_query"])
        elif "pre_checkout_query" in upd:
            self.api.call("answerPreCheckoutQuery",
                          pre_checkout_query_id=upd["pre_checkout_query"]["id"], ok=True)

    # ---------- messages ----------
    def on_message(self, msg: dict) -> None:
        if msg.get("successful_payment"):
            self.on_successful_payment(msg)
            return
        chat_id = msg["chat"]["id"]
        user = msg.get("from") or {}
        uid = str(user.get("id", chat_id))
        text = (msg.get("text") or "").strip()
        self.db.touch_customer(uid, user.get("username", ""))

        if uid in self.pending_receipts and (msg.get("photo") or msg.get("document")):
            self.save_receipt(msg, self.pending_receipts.pop(uid))
            return

        if text.startswith("/start"):
            self.send_catalog(chat_id, edit=False, first_name=user.get("first_name", ""))
        elif text.startswith("/help"):
            self.api.send_message(
                chat_id,
                "🛍 <b>Как купить</b>\n\n1. Выберите товар в каталоге.\n"
                "2. Нажмите «Купить» и выберите способ оплаты.\n"
                "3. После оплаты товар придёт автоматически.\n\n"
                "Поддержка: " + (self.db.get_setting("support_username") or "@support"),
            )
        elif text.startswith("/orders"):
            rows = self.db.conn.execute(
                "SELECT public_id,product_title,amount,status FROM orders WHERE buyer_id=? "
                "ORDER BY id DESC LIMIT 5", (uid,)).fetchall()
            if not rows:
                self.api.send_message(chat_id, "У вас пока нет заказов.")
                return
            lines = ["🧾 <b>Ваши заказы</b>", ""]
            for r in rows:
                icon = {"delivered": "✅", "paid": "✅", "pending": "⏳", "cancelled": "✖️"}.get(r["status"], "•")
                lines.append(f"{icon} <code>{r['public_id']}</code> — {html.escape(r['product_title'])} "
                             f"({r['amount']:.0f} ₽)")
            self.api.send_message(chat_id, "\n".join(lines))
        else:
            self.send_catalog(chat_id, edit=False)

    # ---------- catalog ----------
    def send_catalog(self, chat_id, edit: bool = False, message_id: int | None = None,
                     first_name: str = "") -> None:
        name = self.db.get_setting("shop_name")
        cats = self.db.categories()
        rows = [[btn(f"{c['emoji']} {c['name']} · {c['products']}", f"cat:{c['id']}")] for c in cats]
        rows.append([btn("🔥 Хиты продаж", "top"), btn("🆘 Поддержка", "support")])
        greeting = (
            f"👋 <b>{html.escape(name)}</b>\n"
            f"{html.escape(self.db.get_setting('shop_tagline'))}\n\n"
            + (f"Привет, {html.escape(first_name)}! " if first_name else "")
            + "Выберите категорию — оплата Stars, USDT или СБП, выдача сразу после платежа."
        )
        if edit and message_id:
            self.api.edit(chat_id, message_id, greeting, kb(rows))
        else:
            self.api.send_message(chat_id, greeting, kb(rows))

    def send_category(self, chat_id, message_id, cid: int) -> None:
        products = self.db.products(active_only=True, category_id=cid)
        cat = next((c for c in self.db.categories() if c["id"] == cid), {"name": "Товары", "emoji": "📦"})
        if not products:
            self.api.edit(chat_id, message_id, "В этой категории пока пусто.", kb([[btn("← Назад", "home")]]))
            return
        rows = [[btn(f"{p['title']} — {p['price_rub']:.0f} ₽", f"prod:{p['id']}")] for p in products]
        rows.append([btn("← Назад", "home")])
        self.api.edit(chat_id, message_id,
                      f"{cat['emoji']} <b>{html.escape(cat['name'])}</b>\nВыберите товар:",
                      kb(rows))

    def send_product(self, chat_id, message_id, pid: int) -> None:
        p = self.db.product(pid)
        if not p or not p["active"]:
            self.api.edit(chat_id, message_id, "Товар недоступен.", kb([[btn("← В каталог", "home")]]))
            return
        stock = "∞" if p["stock"] < 0 else f"{p['stock']} шт."
        text = (
            f"<b>{html.escape(p['title'])}</b>\n\n"
            f"{html.escape(p['description'] or '')}\n\n"
            f"💰 Цена: <b>{p['price_rub']:.0f} ₽</b> · {p['price_stars']} ⭐ · ${p['price_usd']:.2f}\n"
            f"📦 В наличии: {stock}\n"
            f"⚡ Выдача: моментально после оплаты"
        )
        self.api.edit(chat_id, message_id, text, kb([
            [btn("💳 Купить", f"buy:{p['id']}")],
            [btn("← Назад", f"cat:{p['category_id'] or 0}"), btn("🏠 Каталог", "home")],
        ]))

    def send_methods(self, chat_id, message_id, pid: int) -> None:
        p = self.db.product(pid)
        if not p:
            return
        rows = []
        if self.db.get_setting("stars_enabled") == "1" and p["price_stars"] > 0:
            rows.append([btn(f"⭐ Telegram Stars — {p['price_stars']}", f"pay:stars:{pid}")])
        if self.db.get_setting("crypto_enabled") == "1" and p["price_usd"] > 0:
            rows.append([btn(f"💎 USDT (CryptoBot) — ${p['price_usd']:.2f}", f"pay:crypto:{pid}")])
        if self.db.get_setting("sbp_enabled") == "1":
            rows.append([btn(f"🏦 СБП — {p['price_rub']:.0f} ₽", f"pay:sbp:{pid}")])
        rows.append([btn("← Назад", f"prod:{pid}")])
        self.api.edit(chat_id, message_id,
                      f"Выберите способ оплаты для «{html.escape(p['title'])}»:", kb(rows))

    # ---------- callbacks ----------
    def on_callback(self, cb: dict) -> None:
        data = cb.get("data", "")
        msg = cb.get("message") or {}
        chat_id = msg.get("chat", {}).get("id")
        message_id = msg.get("message_id")
        user = cb.get("from") or {}
        uid = str(user.get("id", ""))
        self.db.touch_customer(uid, user.get("username", ""))
        self.api.answer(cb["id"])

        if data == "home":
            self.send_catalog(chat_id, edit=True, message_id=message_id)
        elif data == "support":
            self.api.send_message(chat_id, "🆘 Напишите нам: " +
                                  (self.db.get_setting("support_username") or "@support"))
        elif data == "top":
            products = sorted(self.db.products(active_only=True), key=lambda p: -p["sales"])[:6]
            rows = [[btn(f"{p['title']} — {p['price_rub']:.0f} ₽", f"prod:{p['id']}")] for p in products]
            rows.append([btn("← Назад", "home")])
            self.api.edit(chat_id, message_id, "🔥 <b>Хиты продаж</b>", kb(rows))
        elif data.startswith("cat:"):
            cid = int(data.split(":")[1])
            if cid == 0:
                self.send_catalog(chat_id, edit=True, message_id=message_id)
            else:
                self.send_category(chat_id, message_id, cid)
        elif data.startswith("prod:"):
            self.send_product(chat_id, message_id, int(data.split(":")[1]))
        elif data.startswith("buy:"):
            self.send_methods(chat_id, message_id, int(data.split(":")[1]))
        elif data.startswith("pay:"):
            _, method, pid = data.split(":")
            self.start_payment(chat_id, message_id, int(pid), method, uid, user.get("username", ""))
        elif data.startswith("check:"):
            self.check_crypto(chat_id, data.split(":", 1)[1])
        elif data.startswith("paid:"):
            public_id = data.split(":", 1)[1]
            self.pending_receipts[uid] = public_id
            self.api.send_message(chat_id, "📎 Пришлите чек одним сообщением: фото или PDF.\n"
                                           f"Заказ <code>{public_id}</code> ждёт подтверждения.")
        elif data.startswith("deliver:"):
            self.deliver(chat_id, data.split(":", 1)[1])

    # ---------- payments ----------
    def start_payment(self, chat_id, message_id, pid: int, method: str, uid: str, username: str) -> None:
        p = self.db.product(pid)
        if not p:
            return
        if method == "stars":
            order = self.db.create_order(p, uid, username, method="stars",
                                         amount=p["price_stars"], currency="XTR")
            self.api.call(
                "sendInvoice",
                chat_id=chat_id,
                title=p["title"][:32],
                description=(p["description"] or p["title"])[:255],
                payload=order["public_id"],
                provider_token="",
                currency="XTR",
                prices=[{"label": p["title"][:32], "amount": int(p["price_stars"])}],
            )
        elif method == "crypto":
            order = self.db.create_order(p, uid, username, method="cryptobot",
                                         amount=p["price_usd"], currency="USD")
            token = self.db.get_setting("cryptobot_token")
            try:
                inv = CryptoBot(token).create_invoice(
                    p["price_usd"], f"{self.db.get_setting('shop_name')}: {p['title']}",
                    order["public_id"])
            except PaymentError as e:
                self.api.send_message(chat_id, f"⚠️ CryptoBot недоступен: {html.escape(str(e))}\n"
                                               "Выберите другой способ оплаты.")
                return
            self.db.conn.execute("UPDATE orders SET payload=? WHERE id=?",
                                 (str(inv["invoice_id"]), order["id"]))
            self.db.conn.commit()
            url = inv.get("mini_app_invoice_url") or inv.get("bot_invoice_url") or inv.get("pay_url")
            self.api.send_message(
                chat_id,
                f"💎 Счёт на <b>${p['price_usd']:.2f} USDT</b> создан.\n"
                f"Заказ: <code>{order['public_id']}</code>\n\n"
                "Оплатите по кнопке ниже, затем нажмите «Проверить оплату».",
                kb([[{"text": "💎 Оплатить USDT", "url": url}],
                    [btn("🔄 Проверить оплату", f"check:{order['public_id']}")]]),
            )
        else:  # sbp
            order = self.db.create_order(p, uid, username, method="sbp",
                                         amount=p["price_rub"], currency="RUB")
            text = sbp_text(self.db.get_setting("sbp_phone"), self.db.get_setting("sbp_bank"),
                            p["price_rub"], order["public_id"])
            self.api.send_message(chat_id, text, kb([[btn("✅ Я оплатил", f"paid:{order['public_id']}")]]))

    def check_crypto(self, chat_id, public_id: str) -> None:
        order = self.db.order_by_public_id(public_id)
        if not order:
            return
        if order["status"] in ("paid", "delivered"):
            self.deliver(chat_id, public_id)
            return
        try:
            status = CryptoBot(self.db.get_setting("cryptobot_token")).invoice_status(order["payload"])
        except PaymentError as e:
            self.api.send_message(chat_id, f"⚠️ Не удалось проверить счёт: {html.escape(str(e))}")
            return
        if status == "paid":
            self.db.mark_paid(public_id, delivered=self.db.get_setting("auto_delivery") == "1")
            self.notify_admin(f"💰 Оплата USDT: {public_id} · {order['product_title']}")
            self.deliver(chat_id, public_id)
        else:
            self.api.send_message(chat_id, f"⏳ Статус счёта: <b>{status}</b>. "
                                           "Если вы только что оплатили — подождите 30 секунд и проверьте снова.")

    def on_successful_payment(self, msg: dict) -> None:
        payment = msg["successful_payment"]
        public_id = payment.get("invoice_payload", "")
        chat_id = msg["chat"]["id"]
        order = self.db.order_by_public_id(public_id)
        if not order:
            return
        self.db.mark_paid(public_id, delivered=self.db.get_setting("auto_delivery") == "1")
        self.db.conn.execute(
            "UPDATE orders SET payload=? WHERE public_id=?",
            (payment.get("telegram_payment_charge_id", ""), public_id))
        self.db.conn.commit()
        self.notify_admin(f"⭐ Оплата Stars: {public_id} · {order['product_title']}")
        self.deliver(chat_id, public_id)

    def save_receipt(self, msg: dict, public_id: str) -> None:
        chat_id = msg["chat"]["id"]
        file_id = None
        ext = "jpg"
        if msg.get("photo"):
            file_id = msg["photo"][-1]["file_id"]
        elif msg.get("document"):
            file_id = msg["document"]["file_id"]
            ext = Path(msg["document"].get("file_name", "receipt.pdf")).suffix or ".pdf"
        if not file_id:
            return
        try:
            info = self.api.call("getFile", file_id=file_id)
            url = f"https://api.telegram.org/file/bot{self.api.token}/{info['file_path']}"
            name = f"receipt-{public_id}-{int(time.time())}{ext}"
            with urllib.request.urlopen(url, timeout=60) as resp:
                (UPLOAD_DIR / name).write_bytes(resp.read())
            self.db.conn.execute("UPDATE orders SET receipt=?, status='review' WHERE public_id=?",
                                 (name, public_id))
            self.db.conn.commit()
            self.api.send_message(chat_id, "✅ Чек получен. Менеджер подтвердит оплату и товар придёт "
                                           "автоматически.")
            self.notify_admin(f"🧾 Чек по СБП: {public_id}. Проверьте в админке → Заказы.")
        except Exception as e:  # noqa: BLE001
            print("[bot] receipt error:", repr(e))
            self.api.send_message(chat_id, "⚠️ Не удалось сохранить чек, попробуйте ещё раз.")

    # ---------- delivery ----------
    def deliver(self, chat_id, public_id: str) -> None:
        order = self.db.order_by_public_id(public_id)
        if not order:
            return
        if order["status"] == "delivered":
            self.api.send_message(chat_id, "Этот заказ уже выдан ✅")
            return
        p = self.db.product(order["product_id"]) or {}
        self.db.mark_delivered(public_id)
        text = p.get("delivery_text") or "Спасибо за покупку! Товар: " + order["product_title"]
        self.api.send_message(chat_id, f"🎉 <b>Заказ {public_id} оплачен</b>\n\n{html.escape(text)}",
                              parse_mode="HTML")
        file_path = p.get("file_path") or ""
        if file_path:
            target = UPLOAD_DIR / Path(file_path).name
            if target.is_file():
                try:
                    self.api.send_document(chat_id, target, caption=order["product_title"])
                except Exception as e:  # noqa: BLE001
                    print("[bot] sendDocument error:", e)

    def notify_admin(self, text: str) -> None:
        admin = self.db.get_setting("admin_chat_id")
        if admin:
            try:
                self.api.send_message(admin, "🔔 " + text)
            except Exception:  # noqa: BLE001
                pass


def start_bot_thread(token: str, db: DB) -> threading.Thread:
    bot = ShopBot(token, db)

    def runner():
        try:
            bot.run_forever()
        except Exception as e:  # noqa: BLE001
            print("[bot] stopped:", repr(e))

    t = threading.Thread(target=runner, name="shop-bot", daemon=True)
    t.start()
    return t
