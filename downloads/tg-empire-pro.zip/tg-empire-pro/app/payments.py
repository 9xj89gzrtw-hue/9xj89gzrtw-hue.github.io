"""Платёжные провайдеры: Telegram Stars, CryptoBot (USDT), СБП по реквизитам.

Все вызовы — обычный HTTPS через urllib, без сторонних SDK.
"""
from __future__ import annotations

import json
import urllib.error
import urllib.request
from dataclasses import dataclass

CRYPTOBOT_API = "https://pay.crypt.bot/api"


class PaymentError(RuntimeError):
    pass


def _post(url: str, payload: dict, headers: dict | None = None, timeout: int = 25) -> dict:
    body = json.dumps(payload).encode()
    req = urllib.request.Request(url, data=body, method="POST")
    req.add_header("Content-Type", "application/json")
    for key, value in (headers or {}).items():
        req.add_header(key, value)
    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            return json.loads(resp.read().decode())
    except urllib.error.HTTPError as e:
        detail = e.read().decode("utf-8", "replace")[:300]
        raise PaymentError(f"HTTP {e.code}: {detail}") from e
    except (urllib.error.URLError, TimeoutError) as e:
        raise PaymentError(f"Сеть недоступна: {e}") from e


@dataclass
class CryptoBot:
    token: str

    def _call(self, method: str, payload: dict) -> dict:
        if not self.token:
            raise PaymentError("Не задан токен CryptoBot")
        data = _post(f"{CRYPTOBOT_API}/{method}", payload, {"Crypto-Pay-API-Token": self.token})
        if not data.get("ok"):
            raise PaymentError(str(data.get("error") or "CryptoBot вернул ошибку"))
        return data["result"]

    def create_invoice(self, amount: float, description: str, payload: str,
                       asset: str = "USDT") -> dict:
        return self._call("createInvoice", {
            "asset": asset,
            "amount": f"{amount:.2f}",
            "description": description[:1024],
            "payload": payload,
            "allow_comments": False,
            "allow_anonymous": True,
            "expires_in": 3600,
        })

    def invoice_status(self, invoice_id: int | str) -> str:
        result = self._call("getInvoices", {"invoice_ids": str(invoice_id), "count": 1})
        items = result.get("items") or []
        return items[0].get("status", "unknown") if items else "unknown"

    def balance(self) -> list[dict]:
        return self._call("getBalance", {})


def sbp_text(phone: str, bank: str, amount: float, order_id: str) -> str:
    return (
        "💳 <b>Оплата по СБП</b>\n\n"
        f"Сумма: <b>{amount:,.0f} ₽</b>\n".replace(",", " ") +
        f"Банк: {bank}\nТелефон: <code>{phone}</code>\n"
        f"Назначение: <code>{order_id}</code>\n\n"
        "После перевода нажмите «Я оплатил» и пришлите чек (фото или PDF). "
        "Менеджер подтвердит оплату в течение 15 минут."
    )
