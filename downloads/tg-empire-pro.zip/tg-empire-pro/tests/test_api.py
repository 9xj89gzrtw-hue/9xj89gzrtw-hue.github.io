"""API-тесты TG-Empire Pro. Запуск: python3 -m unittest discover -s tests -v"""
from __future__ import annotations

import json
import os
import sys
import tempfile
import threading
import unittest
import urllib.error
import urllib.request
from http.cookiejar import CookieJar
from http.server import ThreadingHTTPServer
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

os.environ.setdefault("TG_EMPIRE_QUIET", "1")

from app.core import DB, hash_password, verify_password  # noqa: E402
from app.server import Handler  # noqa: E402


class ShopApiTest(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.tmp = tempfile.TemporaryDirectory()
        cls.db = DB(Path(cls.tmp.name) / "test.db")
        cls.db.set_setting("admin_password", hash_password("test-pass-123"))
        Handler.db = cls.db
        cls.httpd = ThreadingHTTPServer(("127.0.0.1", 0), Handler)
        cls.port = cls.httpd.server_address[1]
        cls.thread = threading.Thread(target=cls.httpd.serve_forever, daemon=True)
        cls.thread.start()
        cls.jar = CookieJar()
        cls.opener = urllib.request.build_opener(urllib.request.HTTPCookieProcessor(cls.jar))
        cls.base = f"http://127.0.0.1:{cls.port}"

    @classmethod
    def tearDownClass(cls):
        cls.httpd.shutdown()
        cls.httpd.server_close()
        cls.db.conn.close()
        cls.tmp.cleanup()

    def call(self, path: str, method: str = "GET", payload=None):
        data = json.dumps(payload).encode() if payload is not None else None
        req = urllib.request.Request(self.base + path, data=data, method=method)
        req.add_header("Content-Type", "application/json")
        try:
            with self.opener.open(req, timeout=10) as resp:
                return resp.status, json.loads(resp.read().decode())
        except urllib.error.HTTPError as e:
            return e.code, json.loads(e.read().decode())

    def login(self):
        code, _ = self.call("/api/login", "POST", {"password": "test-pass-123"})
        self.assertEqual(code, 200)

    # ---------- tests ----------
    def test_01_health(self):
        code, body = self.call("/api/health")
        self.assertEqual(code, 200)
        self.assertEqual(body["service"], "tg-empire-pro")

    def test_02_auth_required(self):
        code, body = self.call("/api/stats")
        self.assertEqual(code, 401)
        self.assertIn("вход", body["error"])

    def test_03_wrong_password(self):
        code, _ = self.call("/api/login", "POST", {"password": "nope"})
        self.assertEqual(code, 401)

    def test_04_login_and_stats(self):
        self.login()
        code, body = self.call("/api/stats")
        self.assertEqual(code, 200)
        data = body["data"]
        for key in ("revenue", "orders", "customers", "series", "by_method", "repeat_rate"):
            self.assertIn(key, data)
        self.assertEqual(len(data["series"]), 14)

    def test_05_category_and_product_crud(self):
        self.login()
        code, body = self.call("/api/categories", "POST", {"name": "Тесты", "emoji": "🧪"})
        self.assertEqual(code, 201)
        cid = body["id"]

        code, body = self.call("/api/products", "POST", {
            "title": "Тестовый товар", "category_id": cid, "price_rub": 100,
            "price_usd": 1.2, "price_stars": 10, "stock": 5,
            "delivery_text": "Ключ: TEST-1",
        })
        self.assertEqual(code, 201)
        pid = body["id"]

        code, body = self.call(f"/api/products/{pid}")
        self.assertEqual(body["data"]["title"], "Тестовый товар")

        code, _ = self.call(f"/api/products/{pid}", "PUT", {"price_rub": 250})
        self.assertEqual(code, 200)
        code, body = self.call(f"/api/products/{pid}")
        self.assertEqual(body["data"]["price_rub"], 250)

        code, _ = self.call(f"/api/products/{pid}", "DELETE")
        self.assertEqual(code, 200)
        code, _ = self.call(f"/api/products/{pid}")
        self.assertEqual(code, 404)

    def test_06_order_lifecycle(self):
        self.login()
        _, body = self.call("/api/products", "POST", {
            "title": "Заказ-тест", "price_rub": 500, "price_usd": 5, "price_stars": 50,
        })
        pid = body["id"]
        product = self.db.product(pid)
        order = self.db.create_order(product, buyer_id="1", buyer_username="tester", method="sbp")
        self.assertEqual(order["status"], "pending")

        code, body = self.call(f"/api/orders/{order['public_id']}/confirm", "POST")
        self.assertEqual(code, 200)
        self.assertEqual(body["data"]["status"], "delivered")

        code, body = self.call("/api/orders")
        self.assertTrue(any(o["public_id"] == order["public_id"] for o in body["data"]))

    def test_07_broadcast(self):
        self.login()
        code, body = self.call("/api/broadcast", "POST", {"text": "Привет из теста", "audience": "all"})
        self.assertEqual(code, 200)
        self.assertGreaterEqual(body["queued"], 0)
        code, body = self.call("/api/broadcasts")
        self.assertEqual(code, 200)
        self.assertTrue(body["data"])

    def test_08_settings_masked(self):
        self.login()
        code, body = self.call("/api/settings")
        self.assertEqual(code, 200)
        self.assertNotIn("admin_password", body["data"])
        code, _ = self.call("/api/settings", "PUT", {"shop_name": "Test Shop"})
        self.assertEqual(code, 200)
        self.assertEqual(self.db.get_setting("shop_name"), "Test Shop")

    def test_09_password_hashing(self):
        stored = hash_password("secret")
        self.assertTrue(verify_password("secret", stored))
        self.assertFalse(verify_password("Secret", stored))
        self.assertNotIn("secret", stored)


if __name__ == "__main__":
    unittest.main(verbosity=2)
