#!/usr/bin/env bash
# TG-Empire Pro — запуск одной командой (macOS / Linux)
set -euo pipefail
cd "$(dirname "$0")"

PY="${PYTHON:-python3}"
if ! command -v "$PY" >/dev/null 2>&1; then
  echo "❌ Python 3 не найден. Установите Python 3.9+ и повторите."
  exit 1
fi

PORT="${PORT:-8080}"
echo "🛍  TG-Empire Pro"
echo "    панель: http://127.0.0.1:${PORT}"
echo "    логин:  admin / admin123 (смените в Настройках)"
echo

exec "$PY" run.py --port "$PORT" --demo "$@"
