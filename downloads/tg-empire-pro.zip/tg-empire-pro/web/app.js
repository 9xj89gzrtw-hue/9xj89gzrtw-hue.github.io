/* TG-Empire Pro — admin SPA. Vanilla JS, без зависимостей. */
'use strict';

const $ = (s, r = document) => r.querySelector(s);
const $$ = (s, r = document) => Array.from(r.querySelectorAll(s));
const esc = (v) => String(v ?? '').replace(/[&<>"']/g, (c) => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const fmt = (n, cur = 'RUB') => cur === 'USD' ? '$' + Number(n).toLocaleString('en-US', {maximumFractionDigits: 2})
  : cur === 'XTR' ? Math.round(n) + ' ⭐' : Number(n).toLocaleString('ru-RU', {maximumFractionDigits: 0}) + ' ₽';
const dt = (ts) => ts ? new Date(ts * 1000).toLocaleString('ru-RU', {day: '2-digit', month: 'short', hour: '2-digit', minute: '2-digit'}) : '—';

const state = { stats: null, products: [], cats: [], orders: [], settings: {}, metric: 'revenue', orderFilter: '' };

async function api(path, opts = {}) {
  const res = await fetch(path, {
    headers: opts.body instanceof FormData ? {} : {'Content-Type': 'application/json'},
    ...opts,
    body: opts.body instanceof FormData ? opts.body : (opts.body ? JSON.stringify(opts.body) : undefined),
  });
  let data = {};
  try { data = await res.json(); } catch (e) { /* empty */ }
  if (!res.ok) throw new Error(data.error || 'Ошибка запроса ' + res.status);
  return data;
}

function toast(msg, isErr = false) {
  const el = document.createElement('div');
  el.className = 'toast' + (isErr ? ' err' : '');
  el.textContent = msg;
  $('#toasts').appendChild(el);
  setTimeout(() => { el.style.opacity = '0'; el.style.transform = 'translateX(10px)'; }, 3200);
  setTimeout(() => el.remove(), 3600);
}

/* ---------------- auth ---------------- */
async function boot() {
  const me = await api('/api/me');
  if (!me.authenticated) {
    $('#loginScreen').hidden = false;
    $('#app').hidden = true;
    return;
  }
  $('#loginScreen').hidden = true;
  $('#app').hidden = false;
  await Promise.all([loadSettings(), loadCats(), loadProducts()]);
  await loadDashboard();
  await loadOrders();
  route();
  tickClock();
  setInterval(tickClock, 30000);
}

$('#loginForm').addEventListener('submit', async (e) => {
  e.preventDefault();
  $('#loginErr').textContent = '';
  try {
    await api('/api/login', {method: 'POST', body: {password: $('#password').value}});
    await boot();
  } catch (err) {
    $('#loginErr').textContent = err.message;
  }
});

$('#logoutBtn').addEventListener('click', async () => {
  await api('/api/logout', {method: 'POST'});
  location.reload();
});

/* ---------------- router ---------------- */
const TITLES = {
  dashboard: ['Дашборд', 'Сводка по магазину за 14 дней'],
  products: ['Товары', 'Каталог, цены и автовыдача'],
  categories: ['Категории', 'Структура меню в Telegram-боте'],
  orders: ['Заказы', 'Оплаты, чеки и выдача товаров'],
  broadcast: ['Рассылка', 'Сообщения покупателям бота'],
  settings: ['Настройки', 'Бот, платежи и безопасность'],
};

function route() {
  const view = (location.hash || '#dashboard').slice(1);
  const name = TITLES[view] ? view : 'dashboard';
  $$('.view').forEach((v) => v.classList.toggle('active', v.id === 'view-' + name));
  $$('.nav a').forEach((a) => a.classList.toggle('active', a.dataset.view === name));
  $('#pageTitle').textContent = TITLES[name][0];
  $('#pageSub').textContent = TITLES[name][1];
  window.scrollTo({top: 0, behavior: 'smooth'});
  if (name === 'dashboard') loadDashboard();
  if (name === 'orders') loadOrders();
  if (name === 'broadcast') loadBroadcastHistory();
}
window.addEventListener('hashchange', route);
document.addEventListener('click', (e) => {
  const a = e.target.closest('[data-view]');
  if (a && a.tagName === 'A') { e.preventDefault(); location.hash = '#' + a.dataset.view; }
});

function tickClock() {
  $('#clock').textContent = new Date().toLocaleTimeString('ru-RU', {hour: '2-digit', minute: '2-digit'});
}

/* ---------------- dashboard ---------------- */
async function loadDashboard() {
  const {data} = await api('/api/stats');
  state.stats = data;
  renderKpis(data);
  renderChart(data);
  renderDonut(data);
  renderTop(data);
  renderRecent();
  renderFeed();
  $('#sideShop').textContent = state.settings.shop_name || 'TG-Empire Store';
  $('#sideBot').textContent = state.settings.bot_username || '@your_shop_bot';
}

function renderKpis(s) {
  const cur = s.currency;
  const cards = [
    ['Выручка', fmt(s.revenue, cur), `${s.revenue_delta >= 0 ? '▲' : '▼'} ${Math.abs(s.revenue_delta)}% к прошлой неделе`, '◈'],
    ['Заказы', String(s.orders), `${s.orders_delta >= 0 ? '▲' : '▼'} ${Math.abs(s.orders_delta)}% · ${s.delivered} выдано, ${s.pending} ждёт`, '▦'],
    ['Средний чек', fmt(s.avg_check, cur), `повторных покупок ${s.repeat_rate}%`, '◷'],
    ['Покупатели', String(s.customers), `▲ ${s.products} активных товаров`, '◎'],
  ];
  $('#kpis').innerHTML = cards.map(([label, value, delta, ico]) => `
    <div class="card kpi">
      <div class="ico-badge">${ico}</div>
      <div class="label">${label}</div>
      <div class="value">${value}</div>
      <div class="delta">${delta}</div>
      <svg class="spark" viewBox="0 0 200 46" preserveAspectRatio="none">
        <path d="M0,38 C25,32 35,40 55,30 C75,20 90,28 110,18 C130,8 150,16 175,8 L200,12 L200,46 L0,46 Z" fill="url(#sparkGrad)" opacity=".35"/>
      </svg>
    </div>`).join('') + `
    <svg width="0" height="0"><defs><linearGradient id="sparkGrad" x1="0" y1="0" x2="0" y2="1">
      <stop offset="0%" stop-color="#7c5cff"/><stop offset="100%" stop-color="#7c5cff" stop-opacity="0"/></linearGradient></defs></svg>`;
}

$('#chartSeg').addEventListener('click', (e) => {
  const b = e.target.closest('button'); if (!b) return;
  $$('#chartSeg button').forEach((x) => x.classList.toggle('active', x === b));
  state.metric = b.dataset.metric;
  renderChart(state.stats);
});

function smoothPath(points) {
  if (!points.length) return '';
  let d = `M ${points[0][0]},${points[0][1]}`;
  for (let i = 0; i < points.length - 1; i++) {
    const p0 = points[i - 1] || points[i];
    const p1 = points[i];
    const p2 = points[i + 1];
    const p3 = points[i + 2] || p2;
    const c1x = p1[0] + (p2[0] - p0[0]) / 6;
    const c1y = p1[1] + (p2[1] - p0[1]) / 6;
    const c2x = p2[0] - (p3[0] - p1[0]) / 6;
    const c2y = p2[1] - (p3[1] - p1[1]) / 6;
    d += ` C ${c1x},${c1y} ${c2x},${c2y} ${p2[0]},${p2[1]}`;
  }
  return d;
}

function renderChart(s) {
  if (!s) return;
  const metric = state.metric;
  const values = s.series.map((d) => d[metric]);
  const max = Math.max(...values, 1) * 1.15;
  const W = 720, H = 250, pad = {t: 14, r: 8, b: 26, l: 8};
  const iw = W - pad.l - pad.r, ih = H - pad.t - pad.b;
  const points = values.map((v, i) => [pad.l + (i * iw) / (values.length - 1), pad.t + ih - (v / max) * ih]);
  const line = smoothPath(points);
  const area = `${line} L ${points[points.length - 1][0]},${H - pad.b} L ${points[0][0]},${H - pad.b} Z`;
  const ma = values.map((v, i) => {
    const slice = values.slice(Math.max(0, i - 2), Math.min(values.length, i + 3));
    return [points[i][0], pad.t + ih - (slice.reduce((a, b) => a + b, 0) / slice.length / max) * ih];
  });

  const grid = [0, 0.25, 0.5, 0.75, 1].map((p) => {
    const y = pad.t + ih * p;
    const val = Math.round(max * (1 - p));
    return `<line x1="${pad.l}" y1="${y}" x2="${W - pad.r}" y2="${y}" stroke="rgba(255,255,255,.055)" stroke-dasharray="4 6"/>
            <text x="${pad.l}" y="${y - 5}" fill="#5d6579" font-size="9">${metric === 'revenue' ? val.toLocaleString('ru-RU') : val}</text>`;
  }).join('');

  const labels = s.series.map((d, i) => i % 3 === 0 || i === s.series.length - 1
    ? `<text x="${points[i][0]}" y="${H - 6}" fill="#5d6579" font-size="9" text-anchor="middle">${d.date}</text>` : '').join('');

  $('#mainChart').innerHTML = `
    <defs>
      <linearGradient id="areaGrad" x1="0" y1="0" x2="0" y2="1">
        <stop offset="0%" stop-color="#7c5cff" stop-opacity=".38"/>
        <stop offset="100%" stop-color="#7c5cff" stop-opacity="0"/>
      </linearGradient>
      <linearGradient id="lineGrad" x1="0" y1="0" x2="1" y2="0">
        <stop offset="0%" stop-color="#7c5cff"/><stop offset="100%" stop-color="#22d3ee"/>
      </linearGradient>
    </defs>
    ${grid}
    <path d="${area}" fill="url(#areaGrad)"/>
    <path d="${smoothPath(ma)}" fill="none" stroke="rgba(255,255,255,.16)" stroke-width="1.5" stroke-dasharray="5 5"/>
    <path d="${line}" fill="none" stroke="url(#lineGrad)" stroke-width="2.6" stroke-linecap="round"/>
    ${points.map((p, i) => `<circle cx="${p[0]}" cy="${p[1]}" r="7" fill="transparent" class="pt" data-i="${i}"/>
      <circle cx="${p[0]}" cy="${p[1]}" r="2.6" fill="#0b0e15" stroke="#9d8bff" stroke-width="1.8" opacity="0"/>`).join('')}
    ${labels}`;

  const tip = $('#chartTip');
  const box = $('#chartBox');
  $$('.pt').forEach((c) => {
    c.addEventListener('mouseenter', () => {
      const i = +c.dataset.i; const d = s.series[i];
      const r = box.getBoundingClientRect();
      const svg = $('#mainChart').getBoundingClientRect();
      tip.innerHTML = `<b>${d.date}</b> · ${fmt(d.revenue, s.currency)} · ${d.orders} зак.`;
      tip.style.left = (c.getBoundingClientRect().left - svg.left + c.getBoundingClientRect().width / 2) + 'px';
      tip.style.top = (c.getBoundingClientRect().top - svg.top) + 'px';
      tip.style.opacity = '1';
    });
    c.addEventListener('mouseleave', () => { tip.style.opacity = '0'; });
  });
}

function renderDonut(s) {
  const colors = {stars: '#7c5cff', cryptobot: '#22d3ee', sbp: '#2ee6a8'};
  const names = {stars: 'Telegram Stars', cryptobot: 'USDT · CryptoBot', sbp: 'СБП'};
  const items = s.by_method.length ? s.by_method : [{method: 'stars', s: 0, n: 0}];
  const total = items.reduce((a, b) => a + b.s, 0) || 1;
  let offset = 0;
  const arcs = items.map((m) => {
    const frac = m.s / total;
    const dash = `${(frac * 100).toFixed(2)} ${(100 - frac * 100).toFixed(2)}`;
    const el = `<circle r="15.9" cx="21" cy="21" fill="none" stroke="${colors[m.method] || '#7c5cff'}"
      stroke-width="6" stroke-dasharray="${dash}" stroke-dashoffset="${(-offset * 100).toFixed(2)}"
      transform="rotate(-90 21 21)" stroke-linecap="butt"/>`;
    offset += frac;
    return el;
  }).join('');
  $('#donut').innerHTML = `<circle r="15.9" cx="21" cy="21" fill="none" stroke="rgba(255,255,255,.05)" stroke-width="6"/>${arcs}
    <text x="21" y="20" text-anchor="middle" fill="#eef1f8" font-size="4.6" font-weight="700">${fmt(s.revenue, s.currency)}</text>
    <text x="21" y="25" text-anchor="middle" fill="#8b93a7" font-size="2.6">выручка</text>`;
  $('#donutLegend').innerHTML = items.map((m) => `
    <div class="item"><i style="background:${colors[m.method] || '#7c5cff'}"></i>${names[m.method] || m.method}
      <b>${Math.round(m.s / total * 100)}%</b></div>`).join('');
}

function renderTop(s) {
  const el = $('#topProducts');
  if (!s.top_products.length) { el.innerHTML = '<div class="dim" style="font-size:12.5px">Пока нет продаж</div>'; return; }
  const max = Math.max(...s.top_products.map((p) => p.s), 1);
  el.innerHTML = s.top_products.map((p) => `
    <div>
      <div style="display:flex;justify-content:space-between;font-size:12.5px;margin-bottom:5px">
        <span style="overflow:hidden;text-overflow:ellipsis;white-space:nowrap;max-width:70%">${esc(p.product_title)}</span>
        <span class="mono">${fmt(p.s, s.currency)}</span>
      </div>
      <div style="height:5px;border-radius:4px;background:rgba(255,255,255,.06)">
        <div style="height:100%;width:${(p.s / max * 100).toFixed(1)}%;border-radius:4px;background:linear-gradient(90deg,#7c5cff,#22d3ee)"></div>
      </div>
    </div>`).join('');
}

function renderRecent() {
  const rows = state.orders.slice(0, 6);
  $('#recentOrders').innerHTML = rows.length ? rows.map((o) => `
    <tr><td class="mono">${o.public_id}</td><td>${esc(o.product_title)}</td>
    <td class="nowrap">${fmt(o.amount, o.currency)}</td>
    <td><span class="status ${o.status}">${statusRu(o.status)}</span></td></tr>`).join('')
    : '<tr><td colspan="4"><div class="empty">Заказов пока нет</div></td></tr>';
}

function renderFeed() {
  api('/api/events').then(({data}) => {
    $('#feed').innerHTML = data.length ? data.map((e) => `
      <div class="item"><div class="ic">${eventIcon(e.kind)}</div>
        <div><div class="txt">${esc(e.message)}</div><div class="time">${dt(e.created_at)}</div></div></div>`).join('')
      : '<div class="empty">Событий пока нет</div>';
  }).catch(() => {});
}

const eventIcon = (k) => ({order: '💰', product: '📦', broadcast: '📣', settings: '⚙', system: '✨', auth: '🔐'}[k] || '•');
const statusRu = (s) => ({delivered: 'Выдан', paid: 'Оплачен', pending: 'Ожидает', review: 'На проверке', cancelled: 'Отменён'}[s] || s);

/* ---------------- products ---------------- */
async function loadProducts() {
  const {data} = await api('/api/products');
  state.products = data;
  renderProducts();
}

function renderProducts() {
  const q = ($('#productSearch').value || '').toLowerCase();
  const cat = $('#productCat').value;
  const rows = state.products.filter((p) =>
    (!q || p.title.toLowerCase().includes(q)) && (!cat || String(p.category_id) === cat));
  $('#productCat').innerHTML = '<option value="">Все категории</option>' +
    state.cats.map((c) => `<option value="${c.id}">${c.emoji} ${esc(c.name)}</option>`).join('');
  $('#productsBody').innerHTML = rows.length ? rows.map((p) => `
    <tr>
      <td><div class="t-title"><div class="thumb">${p.category_emoji || '📦'}</div>
        <div><div>${esc(p.title)}</div><div class="t-sub">${esc((p.description || '').slice(0, 48))}${p.file_name ? ' · 📎 ' + esc(p.file_name) : ''}</div></div></div></td>
      <td><span class="tag">${esc(p.category_name || 'без категории')}</span></td>
      <td class="nowrap"><b>${fmt(p.price_rub, 'RUB')}</b><div class="t-sub">${p.price_stars} ⭐ · $${p.price_usd}</div></td>
      <td>${p.stock < 0 ? '∞' : p.stock}</td>
      <td>${p.sales}</td>
      <td><span class="status ${p.active ? 'delivered' : 'cancelled'}">${p.active ? 'активен' : 'скрыт'}</span></td>
      <td class="right"><div class="actions">
        <button class="btn ghost sm" data-edit="${p.id}">✎</button>
        <button class="btn danger sm" data-del="${p.id}">✕</button></div></td>
    </tr>`).join('') : '<tr><td colspan="7"><div class="empty"><span class="big">📦</span>Товаров нет — добавьте первый</div></td></tr>';
}

$('#productSearch').addEventListener('input', renderProducts);
$('#productCat').addEventListener('change', renderProducts);
$('#addProductBtn').addEventListener('click', () => openProductModal());
$('#productsBody').addEventListener('click', async (e) => {
  const ed = e.target.closest('[data-edit]');
  const del = e.target.closest('[data-del]');
  if (ed) openProductModal(state.products.find((p) => p.id === +ed.dataset.edit));
  if (del) {
    if (!confirm('Удалить товар? Действие необратимо.')) return;
    await api('/api/products/' + del.dataset.del, {method: 'DELETE'});
    toast('Товар удалён'); await loadProducts();
  }
});

function openProductModal(p = null) {
  const isEdit = !!p;
  p = p || {title: '', description: '', price_rub: 0, price_usd: 0, price_stars: 0, stock: -1,
            category_id: state.cats[0]?.id || null, active: 1, delivery_text: '', file_path: '', file_name: ''};
  $('#modalTitle').textContent = isEdit ? 'Редактировать товар' : 'Новый товар';
  $('#modalBody').innerHTML = `
    <div class="form-grid">
      <div class="full"><label>Название</label><input class="field" name="title" value="${esc(p.title)}" required></div>
      <div class="full"><label>Описание</label><textarea class="field" name="description" style="min-height:76px">${esc(p.description)}</textarea></div>
      <div><label>Цена, ₽</label><input class="field" name="price_rub" type="number" min="0" step="1" value="${p.price_rub}"></div>
      <div><label>Цена, $</label><input class="field" name="price_usd" type="number" min="0" step="0.01" value="${p.price_usd}"></div>
      <div><label>Цена, Stars</label><input class="field" name="price_stars" type="number" min="0" step="1" value="${p.price_stars}"></div>
      <div><label>Остаток (−1 = ∞)</label><input class="field" name="stock" type="number" min="-1" step="1" value="${p.stock}"></div>
      <div><label>Категория</label><select class="field" name="category_id">
        <option value="">Без категории</option>
        ${state.cats.map((c) => `<option value="${c.id}" ${c.id === p.category_id ? 'selected' : ''}>${c.emoji} ${esc(c.name)}</option>`).join('')}
      </select></div>
      <div><label>Видимость</label><select class="field" name="active">
        <option value="1" ${p.active ? 'selected' : ''}>Активен</option>
        <option value="0" ${!p.active ? 'selected' : ''}>Скрыт</option></select></div>
      <div class="full"><label>Текст выдачи (ключ, ссылка, инструкция)</label>
        <textarea class="field" name="delivery_text" style="min-height:64px">${esc(p.delivery_text)}</textarea></div>
      <div class="full"><label>Файл для автовыдачи</label>
        <div class="file-drop" id="fileDrop">${p.file_name ? '📎 ' + esc(p.file_name) + ' — заменить' : 'Нажмите, чтобы выбрать файл (до 30 МБ)'}
        <input type="file" id="fileInput" hidden></div></div>
    </div>`;
  const form = $('#modalForm');
  form.dataset.id = isEdit ? p.id : '';
  form.dataset.file = p.file_path || '';
  form.dataset.fileName = p.file_name || '';
  modalSubmit = submitProduct;
  $('#fileDrop').onclick = () => $('#fileInput').click();
  $('#fileInput').onchange = async (e) => {
    const f = e.target.files[0]; if (!f) return;
    const fd = new FormData(); fd.append('file', f);
    $('#fileDrop').textContent = 'Загрузка…';
    try {
      const {files} = await api('/api/upload', {method: 'POST', body: fd});
      form.dataset.file = files[0].path; form.dataset.fileName = files[0].name;
      $('#fileDrop').textContent = '📎 ' + files[0].name;
    } catch (err) { toast(err.message, true); $('#fileDrop').textContent = 'Ошибка загрузки'; }
  };
  openModal();
}

let modalSubmit = null;

$('#modalForm').addEventListener('submit', async (e) => {
  e.preventDefault();
  if (modalSubmit) await modalSubmit(e.currentTarget);
  else closeModal();
});

async function submitProduct(form) {
  const fd = new FormData(form);
  const body = Object.fromEntries(fd.entries());
  body.active = +body.active;
  body.category_id = body.category_id ? +body.category_id : null;
  ['price_rub', 'price_usd'].forEach((k) => body[k] = parseFloat(body[k] || 0));
  body.price_stars = parseInt(body.price_stars || 0, 10);
  body.stock = parseInt(body.stock ?? -1, 10);
  body.file_path = form.dataset.file || '';
  body.file_name = form.dataset.fileName || '';
  try {
    if (form.dataset.id) await api('/api/products/' + form.dataset.id, {method: 'PUT', body});
    else await api('/api/products', {method: 'POST', body});
    closeModal(); toast('Сохранено'); await loadProducts(); await loadDashboard();
  } catch (err) { toast(err.message, true); }
}

/* ---------------- categories ---------------- */
async function loadCats() {
  const {data} = await api('/api/categories');
  state.cats = data;
  $('#catsGrid').innerHTML = data.map((c) => `
    <div class="cat-card">
      <button class="del" data-delcat="${c.id}">✕</button>
      <div class="em">${c.emoji}</div>
      <b>${esc(c.name)}</b>
      <small>${c.products} товаров · сортировка ${c.sort}</small>
    </div>`).join('') + `
    <button class="cat-card" id="catAddTile" style="align-items:center;justify-content:center;border-style:dashed;color:var(--dim)">
      <div style="font-size:22px">＋</div><small>Добавить категорию</small></button>`;
  const tile = $('#catAddTile'); if (tile) tile.onclick = openCatModal;
  $$('[data-delcat]').forEach((b) => b.onclick = async () => {
    if (!confirm('Удалить категорию? Товары останутся без категории.')) return;
    await api('/api/categories/' + b.dataset.delcat, {method: 'DELETE'});
    await loadCats(); await loadProducts();
  });
}

function openCatModal() {
  $('#modalTitle').textContent = 'Новая категория';
  $('#modalSub').textContent = 'Появится в меню бота сразу после сохранения';
  $('#modalBody').innerHTML = `
    <div class="form-grid">
      <div><label>Эмодзи</label><input class="field" name="emoji" value="📦" maxlength="4"></div>
      <div><label>Сортировка</label><input class="field" name="sort" type="number" value="100"></div>
      <div class="full"><label>Название</label><input class="field" name="name" placeholder="Например: Шаблоны" required></div>
    </div>`;
  const form = $('#modalForm'); form.dataset.id = '';
  modalSubmit = async (f) => {
    const body = Object.fromEntries(new FormData(f).entries());
    body.sort = +body.sort;
    try {
      await api('/api/categories', {method: 'POST', body});
      closeModal(); await loadCats(); await loadProducts(); await loadDashboard();
      toast('Категория добавлена');
    } catch (err) { toast(err.message, true); }
  };
  openModal();
}
$('#addCatBtn').onclick = openCatModal;

/* ---------------- orders ---------------- */
async function loadOrders() {
  const q = state.orderFilter ? '?status=' + state.orderFilter : '';
  const {data} = await api('/api/orders' + q);
  state.orders = data;
  const pending = data.filter((o) => o.status === 'pending' || o.status === 'review').length;
  const badge = $('#pendingBadge');
  badge.hidden = !pending; badge.textContent = pending;

  $('#ordersBody').innerHTML = data.length ? data.map((o) => `
    <tr>
      <td class="mono">${o.public_id}</td>
      <td>${o.buyer_username ? '@' + esc(o.buyer_username) : '<span class="dim">—</span>'}<div class="t-sub">${esc(o.buyer_id)}</div></td>
      <td>${esc(o.product_title)}</td>
      <td class="nowrap">${fmt(o.amount, o.currency)}</td>
      <td><span class="tag">${o.method}</span></td>
      <td class="nowrap dim">${dt(o.created_at)}</td>
      <td><span class="status ${o.status}">${statusRu(o.status)}</span></td>
      <td class="right"><div class="actions">
        ${['pending', 'review'].includes(o.status) ? `<button class="btn sm" data-confirm="${o.public_id}">Подтвердить</button>` : ''}
        ${o.status === 'paid' ? `<button class="btn ghost sm" data-deliver="${o.public_id}">Выдать</button>` : ''}
        ${o.status !== 'cancelled' && o.status !== 'delivered' ? `<button class="btn danger sm" data-cancel="${o.public_id}">✕</button>` : ''}
      </div></td>
    </tr>`).join('') : '<tr><td colspan="8"><div class="empty"><span class="big">🧾</span>Заказов нет</div></td></tr>';
}

$('#orderSeg').addEventListener('click', (e) => {
  const b = e.target.closest('button'); if (!b) return;
  $$('#orderSeg button').forEach((x) => x.classList.toggle('active', x === b));
  state.orderFilter = b.dataset.status;
  loadOrders();
});

$('#ordersBody').addEventListener('click', async (e) => {
  const c = e.target.closest('[data-confirm]');
  const d = e.target.closest('[data-deliver]');
  const x = e.target.closest('[data-cancel]');
  try {
    if (c) { await api(`/api/orders/${c.dataset.confirm}/confirm`, {method: 'POST'}); toast('Оплата подтверждена, товар выдан'); }
    if (d) { await api(`/api/orders/${d.dataset.deliver}/deliver`, {method: 'POST'}); toast('Заказ выдан'); }
    if (x) { if (!confirm('Отменить заказ?')) return; await api(`/api/orders/${x.dataset.cancel}/cancel`, {method: 'POST'}); toast('Заказ отменён'); }
    await loadOrders(); await loadDashboard();
  } catch (err) { toast(err.message, true); }
});

$('#csvOrders').onclick = () => {
  const header = 'public_id,product,buyer,amount,currency,method,status,created_at\n';
  const rows = state.orders.map((o) => [o.public_id, `"${o.product_title.replace(/"/g, '""')}"`,
    o.buyer_username || o.buyer_id, o.amount, o.currency, o.method, o.status,
    new Date(o.created_at * 1000).toISOString()].join(',')).join('\n');
  const blob = new Blob(['\ufeff' + header + rows], {type: 'text/csv;charset=utf-8'});
  const a = document.createElement('a');
  a.href = URL.createObjectURL(blob); a.download = 'orders.csv'; a.click();
  toast('CSV выгружен');
};

/* ---------------- broadcast ---------------- */
$('#bcText').addEventListener('input', (e) => {
  $('#bcCount').textContent = e.target.value.length + ' символов';
  if ($('#bcPreviewBox').textContent === 'Текст появится здесь…') return;
  $('#bcPreviewBox').textContent = e.target.value || 'Текст появится здесь…';
});
$('#bcPreview').onclick = () => { $('#bcPreviewBox').textContent = $('#bcText').value || 'Текст появится здесь…'; };
$('#bcSend').onclick = async () => {
  const text = $('#bcText').value.trim();
  if (text.length < 3) return toast('Введите текст рассылки', true);
  if (!confirm('Отправить рассылку всем выбранным покупателям?')) return;
  try {
    const r = await api('/api/broadcast', {method: 'POST', body: {text, audience: $('#bcAudience').value}});
    toast(`Рассылка #${r.id} в очереди: ${r.queued} получателей`);
    $('#bcText').value = ''; $('#bcCount').textContent = '0 символов';
    await loadBroadcastHistory();
  } catch (err) { toast(err.message, true); }
};

async function loadBroadcastHistory() {
  const {data} = await api('/api/broadcasts');
  $('#bcHistory').innerHTML = data.length ? data.map((b) => `
    <div class="item"><div class="ic">📣</div><div><div class="txt">${esc(b.text.slice(0, 70))}${b.text.length > 70 ? '…' : ''}</div>
    <div class="time">${dt(b.created_at)} · ${b.audience} · ${b.status}</div></div></div>`).join('')
    : '<div class="dim" style="font-size:12.5px">Рассылок ещё не было</div>';
}

/* ---------------- settings ---------------- */
async function loadSettings() {
  const {data} = await api('/api/settings');
  state.settings = data;
  $('#setShopName').value = data.shop_name || '';
  $('#setTagline').value = data.shop_tagline || '';
  $('#setCurrency').value = data.currency || 'RUB';
  $('#setSupport').value = data.support_username || '';
  $('#setBotToken').value = data.bot_token || '';
  $('#setBotUsername').value = data.bot_username || '';
  $('#setAdminChat').value = data.admin_chat_id || '';
  $('#setCryptoToken').value = data.cryptobot_token || '';
  $('#setSbpPhone').value = data.sbp_phone || '';
  $('#setSbpBank').value = data.sbp_bank || '';
  $$('.switch').forEach((s) => s.classList.toggle('on', data[s.dataset.key] === '1'));
  $('#sideShop').textContent = data.shop_name || 'TG-Empire Store';
  $('#sideBot').textContent = data.bot_username || '@your_shop_bot';
}

$$('.switch').forEach((s) => s.addEventListener('click', () => s.classList.toggle('on')));

$('#saveSettings').onclick = async () => {
  const body = {
    shop_name: $('#setShopName').value,
    shop_tagline: $('#setTagline').value,
    currency: $('#setCurrency').value,
    support_username: $('#setSupport').value,
    bot_token: $('#setBotToken').value,
    bot_username: $('#setBotUsername').value,
    admin_chat_id: $('#setAdminChat').value,
    cryptobot_token: $('#setCryptoToken').value,
    sbp_phone: $('#setSbpPhone').value,
    sbp_bank: $('#setSbpBank').value,
    demo_mode: state.settings.demo_mode || '0',
  };
  $$('.switch').forEach((s) => body[s.dataset.key] = s.classList.contains('on') ? '1' : '0');
  const p1 = $('#setNewPass').value, p2 = $('#setNewPass2').value;
  if (p1 || p2) {
    if (p1 !== p2) return toast('Пароли не совпадают', true);
    if (p1.length < 8) return toast('Пароль короче 8 символов', true);
    body.new_password = p1; body.new_password_repeat = p2;
  }
  try {
    await api('/api/settings', {method: 'PUT', body});
    toast('Настройки сохранены');
    $('#setNewPass').value = ''; $('#setNewPass2').value = '';
    await loadSettings();
  } catch (err) { toast(err.message, true); }
};

$('#refreshBtn').onclick = async () => {
  await Promise.all([loadProducts(), loadCats(), loadSettings(), loadOrders()]);
  await loadDashboard(); toast('Данные обновлены');
};

/* ---------------- modal ---------------- */
function openModal() { $('#modalBack').classList.add('open'); }
function closeModal() { $('#modalBack').classList.remove('open'); }
$('#modalCancel').onclick = closeModal;
$('#modalBack').addEventListener('click', (e) => { if (e.target === $('#modalBack')) closeModal(); });
document.addEventListener('keydown', (e) => { if (e.key === 'Escape') closeModal(); });

boot().catch((e) => { $('#loginScreen').hidden = false; $('#loginErr').textContent = e.message; });
setInterval(() => { if (!$('#app').hidden) loadDashboard().catch(() => {}); }, 30000);
