@echo off
echo === 🚀 Оптимизация Windows для максимального FPS в CS2 ===
powercfg -duplicatescheme e9a42b02-d5df-448d-aa00-03f14749eb61
echo [+] Схема питания 'Максимальная производительность' активирована.
