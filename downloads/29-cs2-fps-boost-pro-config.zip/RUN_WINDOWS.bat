@echo off
chcp 65001 >nul
title CS2 FPS Boost Installer
echo ===================================================
echo   CS2 FPS Boost - Автоматическая установка конфига
echo ===================================================
echo.
set "DEST1=C:\Program Files (x86)\Steam\steamapps\common\Counter-Strike Global Offensive\game\csgo\cfg"
set "DEST2=D:\SteamLibrary\steamapps\common\Counter-Strike Global Offensive\game\csgo\cfg"
set "INSTALLED=0"

if exist "%DEST1%" (
    copy /y "cfg\autoexec.cfg" "%DEST1%\autoexec.cfg" >nul
    echo [+] Конфиг успешно скопирован в: %DEST1%
    set "INSTALLED=1"
)
if exist "%DEST2%" (
    copy /y "cfg\autoexec.cfg" "%DEST2%\autoexec.cfg" >nul
    echo [+] Конфиг успешно скопирован в: %DEST2%
    set "INSTALLED=1"
)

if "%INSTALLED%"=="0" (
    echo [*] Авто-поиск Steam не нашел стандартную папку.
    echo [*] Открываем интерактивную инструкцию в браузере...
)

start "" "ЗАПУСТИТЬ_В_1_КЛИК.html"
echo.
echo Установка завершена! Приятной игры!
timeout /t 3 >nul
