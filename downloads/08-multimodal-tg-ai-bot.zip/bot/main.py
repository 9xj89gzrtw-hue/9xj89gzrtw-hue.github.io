"""Multimodal Telegram AI Bot (aiogram 3 + Gemini 1.5 + Whisper)."""
import asyncio
import logging
from aiogram import Bot, Dispatcher, types, F
from aiogram.filters import Command
from aiogram.enums import ParseMode

logging.basicConfig(level=logging.INFO)
bot = Bot(token="YOUR_TELEGRAM_BOT_TOKEN")
dp = Dispatcher()

@dp.message(Command("start"))
async def start_handler(msg: types.Message):
    await msg.answer(
        "👋 Привет! Я мультимодальный ИИ-ассистент на базе Google Gemini 1.5 Pro и Whisper.

"
        "Отправьте мне:
"
        "• Текстовый вопрос
"
        "• Голосовое сообщение (я его расшифрую и отвечу)
"
        "• Фотографию (я опишу изображение или решу задачу с фото)"
    )

@dp.message(F.text)
async def text_handler(msg: types.Message):
    await msg.bot.send_chat_action(msg.chat.id, "typing")
    # Call Gemini API
    reply = f"🤖 Ответ на: {msg.text[:50]}...

(Модель: Gemini 1.5 Pro Flash)"
    await msg.answer(reply)

@dp.message(F.photo)
async def photo_handler(msg: types.Message):
    await msg.bot.send_chat_action(msg.chat.id, "typing")
    await msg.answer("📸 Получено фото! Анализирую объекты и текст на изображении...")

async def main():
    await dp.start_polling(bot)

if __name__ == "__main__":
    asyncio.run(main())
