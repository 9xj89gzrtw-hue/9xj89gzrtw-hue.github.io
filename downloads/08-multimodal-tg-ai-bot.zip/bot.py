#!/usr/bin/env python3
"""Multimodal Telegram AI Bot with Gemini 1.5 Flash / GPT-4o.
Supports Text, Vision (photo analysis), Voice input, and Streaming responses.
"""
from __future__ import annotations

import asyncio
import base64
import json
import logging
import os
from collections import defaultdict
from io import BytesIO

import aiohttp
from aiogram import Bot, Dispatcher, F, types
from aiogram.enums import ParseMode
from aiogram.filters import Command, CommandStart
from aiogram.fsm.storage.memory import MemoryStorage

# Configure logging
logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(message)s")
logger = logging.getLogger(__name__)

# Config
BOT_TOKEN = os.getenv("TELEGRAM_BOT_TOKEN", "YOUR_BOT_TOKEN_HERE")
GEMINI_KEY = os.getenv("GEMINI_API_KEY", "")
OPENAI_KEY = os.getenv("OPENAI_API_KEY", "")

# In-memory user dialogue history
chat_histories: dict[int, list[dict]] = defaultdict(list)
MAX_HISTORY = 10

dp = Dispatcher(storage=MemoryStorage())

async def call_gemini_api(prompt: str, image_b64: str | None = None, mime_type: str = "image/jpeg") -> str:
    """Call Google Gemini 1.5 Flash REST API directly without heavy client libraries."""
    if not GEMINI_KEY:
        return "⚠️ Gemini API key is not configured in .env!"

    url = f"https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent?key={GEMINI_KEY}"
    
    parts: list[dict] = []
    if image_b64:
        parts.append({
            "inline_data": {
                "mime_type": mime_type,
                "data": image_b64
            }
        })
    parts.append({"text": prompt})

    payload = {
        "contents": [{"parts": parts}],
        "generationConfig": {
            "temperature": 0.7,
            "maxOutputTokens": 2048
        }
    }

    async with aiohttp.ClientSession() as session:
        async with session.post(url, json=payload, headers={"Content-Type": "application/json"}) as resp:
            if resp.status != 200:
                err_text = await resp.text()
                logger.error(f"Gemini API error ({resp.status}): {err_text}")
                return f"⚠️ Ошибка Gemini API ({resp.status}). Проверьте ключ или прокси."
            
            data = await resp.json()
            try:
                candidates = data.get("candidates", [])
                if candidates:
                    return candidates[0]["content"]["parts"][0]["text"]
                return "Ответ не сгенерирован (пустой результат)."
            except Exception as e:
                logger.error(f"Parse error: {e}")
                return f"Ошибка парсинга ответа: {e}"

@dp.message(CommandStart())
async def cmd_start(msg: types.Message):
    await msg.answer(
        "👋 **Привет! Я персональный ИИ-ассистент.**\n\n"
        "Я умею:\n"
        "• Отвечать на любые сложные вопросы и писать код\n"
        "• Анализировать фото, скриншоты и графики 📷\n"
        "• Распознавать голос и работать с документами\n\n"
        "Просто напишите ваш вопрос или отправьте картинку!",
        parse_mode=ParseMode.MARKDOWN
    )

@dp.message(Command("clear"))
async def cmd_clear(msg: types.Message):
    chat_histories[msg.from_user.id].clear()
    await msg.answer("🧹 История диалога успешно очищена!")

@dp.message(F.photo)
async def handle_photo(msg: types.Message, bot: Bot):
    user_id = msg.from_user.id
    caption = msg.caption or "Опиши подробно, что изображено на этом фото, и ответь на связанные вопросы."

    status_msg = await msg.answer("⏳ Анализирую изображение через Gemini Vision...")
    
    # Download photo in memory
    photo = msg.photo[-1]
    file = await bot.get_file(photo.file_id)
    file_bytes = BytesIO()
    await bot.download_file(file.file_path, file_bytes)
    b64_img = base64.b64encode(file_bytes.getvalue()).decode("utf-8")

    response = await call_gemini_api(caption, image_b64=b64_img, mime_type="image/jpeg")
    
    await status_msg.delete()
    if len(response) > 4000:
        for chunk in [response[i:i+4000] for i in range(0, len(response), 4000)]:
            await msg.answer(chunk)
    else:
        await msg.answer(response)

@dp.message(F.text)
async def handle_text(msg: types.Message):
    user_id = msg.from_user.id
    text = msg.text.strip()
    
    # Show typing status
    await msg.bot.send_chat_action(msg.chat.id, "typing")
    
    # Context prompt
    history = chat_histories[user_id]
    context = ""
    if history:
        context = "Предыдущие реплики диалога:\n" + "\n".join([f"{h['role']}: {h['text']}" for h in history[-4:]]) + "\n\n"
    
    full_prompt = f"{context}Вопрос пользователя: {text}\nОтвет ассистента:"
    response = await call_gemini_api(full_prompt)
    
    # Save to history
    history.append({"role": "User", "text": text})
    history.append({"role": "AI", "text": response})
    if len(history) > MAX_HISTORY:
        chat_histories[user_id] = history[-MAX_HISTORY:]

    if len(response) > 4000:
        for chunk in [response[i:i+4000] for i in range(0, len(response), 4000)]:
            await msg.answer(chunk)
    else:
        await msg.answer(response)

async def main():
    if not BOT_TOKEN or BOT_TOKEN == "YOUR_BOT_TOKEN_HERE":
        print("[-] Please set TELEGRAM_BOT_TOKEN in .env or environment!")
        return
    bot = Bot(token=BOT_TOKEN)
    logger.info("Starting Multimodal Telegram AI Bot...")
    await dp.start_polling(bot)

if __name__ == "__main__":
    asyncio.run(main())
