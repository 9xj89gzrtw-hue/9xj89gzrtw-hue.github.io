#!/usr/bin/env bash
# Автоматический запуск для macOS / Linux
cd "$(dirname "$0")"
echo "==================================================="
echo "  Запуск программы на macOS / Linux"
echo "==================================================="

if ! command -v python3 &> /dev/null; then
    echo "[-] Python3 не найден. Установите python3 через brew install python3"
    exit 1
fi

if [ ! -d ".venv" ]; then
    echo "[*] Создание .venv..."
    python3 -m venv .venv
fi

source .venv/bin/activate

if [ -f "requirements.txt" ]; then
    echo "[*] Установка зависимостей..."
    pip install -q -r requirements.txt
fi

echo "[+] Запуск: python bot/main.py"
echo "==================================================="
python bot/main.py
