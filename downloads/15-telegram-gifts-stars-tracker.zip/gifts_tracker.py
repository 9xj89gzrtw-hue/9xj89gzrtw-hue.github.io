#!/usr/bin/env python3
"""Telegram Gifts & Stars Rate Tracker CLI.
Parses active and limited Telegram gifts, supply metrics, floor price, and Stars-to-TON conversion rate.
"""
import json, time

SAMPLE_GIFTS = [
    {"name": "Delicious Cake", "supply": 500000, "floor_stars": 50, "rarity": "Common", "est_ton": 0.25},
    {"name": "Green Star", "supply": 100000, "floor_stars": 150, "rarity": "Rare", "est_ton": 0.85},
    {"name": "Plush Bear", "supply": 25000, "floor_stars": 500, "rarity": "Epic", "est_ton": 2.90},
    {"name": "Durovs Cap", "supply": 5000, "floor_stars": 2500, "rarity": "Legendary", "est_ton": 15.50}
]

def analyze_gifts():
    print("=== Telegram Gifts & Stars Arbitrage Scanner ===")
    print(f"Timestamp: {time.strftime("%Y-%m-%d %H:%M:%S")}")
    print("-" * 55)
    for g in SAMPLE_GIFTS:
        roi = round((g["est_ton"] * 5.2 / (g["floor_stars"] * 0.015) - 1) * 100, 1)
        print(f"🎁 {g["name"]} | Rarity: {g["rarity"]} | Floor: {g["floor_stars"]} Stars | Est. TON: {g["est_ton"]} (~{roi}% ROI)")

if __name__ == "__main__":
    analyze_gifts()
