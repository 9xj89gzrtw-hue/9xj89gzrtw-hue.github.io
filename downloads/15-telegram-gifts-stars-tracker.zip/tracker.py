"""Telegram Gifts & Stars Price Tracker with SQLite logging."""
import sqlite3
import time
import json
from typing import Dict, Any

class GiftsTracker:
    def __init__(self, db_path="gifts_market.db"):
        self.conn = sqlite3.connect(db_path)
        self.create_tables()

    def create_tables(self):
        cur = self.conn.cursor()
        cur.execute("""
            CREATE TABLE IF NOT EXISTS price_history (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                gift_name TEXT,
                stars_cost INTEGER,
                ton_floor REAL,
                rub_equivalent REAL,
                recorded_at REAL
            )
        """)
        self.conn.commit()

    def record_gift(self, name: str, stars: int, ton_floor: float, ton_rub_rate: float = 650.0):
        rub_val = ton_floor * ton_rub_rate
        cur = self.conn.cursor()
        cur.execute(
            "INSERT INTO price_history (gift_name, stars_cost, ton_floor, rub_equivalent, recorded_at) VALUES (?, ?, ?, ?, ?)",
            (name, stars, ton_floor, rub_val, time.time())
        )
        self.conn.commit()
        print(f"[+] Saved {name}: {stars} Stars | {ton_floor} TON (~{rub_val:.1f} ₽)")

if __name__ == "__main__":
    tracker = GiftsTracker()
    tracker.record_gift("Plush Pepe", 500, 1.85)
    tracker.record_gift("Cyber Skull", 1500, 5.20)
