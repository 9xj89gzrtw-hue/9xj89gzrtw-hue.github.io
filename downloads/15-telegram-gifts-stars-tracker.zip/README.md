# 🎁 Telegram Gifts & Stars Tracker 2026
Таблица и скрипт отслеживания лимитированных Подарков Telegram и арбитража курсов Stars.

### Содержимое:
1. `gifts_tracker.py` — Python CLI утилита для мониторинга редкости подарков и оценки ROI перепродажи.
2. `gifts_table.json` — база редких подарков с метриками сжигания и тиражей.

Запуск:
```bash
python3 gifts_tracker.py
```
