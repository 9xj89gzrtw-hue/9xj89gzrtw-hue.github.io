"""Arbitrage and ROI Calculator for Gifts trading."""
def calculate_arbitrage(stars_cost: int, ton_price: float, ton_rub: float, stars_rub_cost: float = 1.95):
    fiat_spent = stars_cost * stars_rub_cost
    fiat_yield = ton_price * ton_rub * 0.95 # Minus 5% marketplace fee
    profit = fiat_yield - fiat_spent
    roi_percent = (profit / fiat_spent) * 100
    return {
        "spent_rub": round(fiat_spent, 2),
        "yield_rub": round(fiat_yield, 2),
        "net_profit_rub": round(profit, 2),
        "roi_percent": round(roi_percent, 2)
    }

if __name__ == "__main__":
    res = calculate_arbitrage(500, 1.85, 650.0)
    print("ROI Analysis:", res)
