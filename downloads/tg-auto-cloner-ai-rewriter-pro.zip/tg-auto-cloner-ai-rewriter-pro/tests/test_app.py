"""Тесты TG Auto Cloner + AI Rewriter Pro (stdlib unittest)."""
from __future__ import annotations

import json
import os
import sys
import tempfile
import threading
import unittest
import urllib.request
from http.cookiejar import CookieJar
from http.server import ThreadingHTTPServer
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

from app.core import DB, seed_demo, verify_password  # noqa: E402
from app.rewriter import (  # noqa: E402
    Rewriter, clean_local, find_stopword, latin_ratio, score_text, stop_words,
)
from app.telegram import parse_posts  # noqa: E402

FIXTURE = """
<html><body>
<div class="tgme_widget_message" data-post="demo_channel/101">
  <div class="tgme_widget_message_text js-message_text">Первая строка<br/>Вторая строка
    <a href="https://t.me/spam">ссылка</a></div>
  <a class="tgme_widget_message_photo_wrap" style="background-image:url('https://cdn.example/p1.jpg')"></a>
</div>
<div class="tgme_widget_message" data-post="demo_channel/102">
  <div class="tgme_widget_message_text">Пост без фото и без ссылок.</div>
</div>
<div class="tgme_widget_message_service" data-post="demo_channel/103"></div>
</body></html>
"""


class ParserTest(unittest.TestCase):
    def test_extracts_posts_with_photo(self):
        posts = parse_posts(FIXTURE)
        self.assertEqual([p["msg_id"] for p in posts], [101, 102])
        self.assertIn("Первая строка", posts[0]["text"])
        self.assertIn("Вторая строка", posts[0]["text"])
        self.assertEqual(posts[0]["photo"], "https://cdn.example/p1.jpg")
        self.assertEqual(posts[1]["photo"], "")

    def test_empty_html(self):
        self.assertEqual(parse_posts("<html><body></body></html>"), [])


class RewriterTest(unittest.TestCase):
    def test_local_cleaner_strips_links_ads_mentions(self):
        raw = ("Google выпустила Gemini 3. Подписывайтесь на наш канал! "
               "Промокод AI20 внутри. https://spam.example @spam_channel")
        clean = clean_local(raw)
        self.assertIn("Google выпустила Gemini 3", clean)
        self.assertNotIn("http", clean)
        self.assertNotIn("@spam_channel", clean)
        self.assertNotIn("Промокод", clean)
        self.assertNotIn("Подписывайтесь", clean)

    def test_stopword_detection(self):
        words = stop_words("реклама, промокод, erid")
        self.assertEqual(find_stopword("Тут был ПРОМОКОД на скидку", words), "промокод")
        self.assertEqual(find_stopword("Обычные новости технологий", words), "")

    def test_score_prefers_clean_long_text(self):
        clean = ("OpenAI представила новую модель. Она быстрее предыдущей на 40% "
                 "и лучше удерживает контекст диалога. Релиз намечен на весну.")
        spam = "СРОЧНО!!! ЖМИ https://spam.example промокод казино ставки!!!"
        words = stop_words("промокод,казино,ставки,жми")
        self.assertGreater(score_text(clean, words), score_text(spam, words))
        self.assertGreaterEqual(score_text(clean, words), 60)

    def test_latin_ratio(self):
        self.assertGreater(latin_ratio("OpenAI released a new model"), 0.9)
        self.assertLess(latin_ratio("Открыли новую модель"), 0.1)

    def test_llm_without_key_falls_back_to_local(self):
        tmp = tempfile.NamedTemporaryFile(suffix=".db", delete=False).name
        db = DB(tmp)
        db.set("llm_provider", "gemini")
        db.set("llm_api_key", "")
        result = Rewriter(db).rewrite("OpenAI released GPT-5.2 today. Subscribe!")
        self.assertEqual(result["engine"], "local")
        self.assertFalse(result["translated"])
        self.assertIn("ключ", result["note"])
        db.close()
        os.unlink(tmp)


class DBTest(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.NamedTemporaryFile(suffix=".db", delete=False).name
        self.db = DB(self.tmp)

    def tearDown(self):
        self.db.close()
        os.unlink(self.tmp)

    def test_default_password_hashed(self):
        self.assertTrue(verify_password("admin123", self.db.get("admin_password")))
        self.assertFalse(verify_password("wrong", self.db.get("admin_password")))
        self.assertNotIn("admin123", self.db.get("admin_password"))

    def test_draft_dedupe(self):
        sid = self.db.add_source("Demo", "demo_channel")
        first = self.db.add_draft(sid, "demo_channel", 1, "raw", "text")
        second = self.db.add_draft(sid, "demo_channel", 1, "raw", "text")
        self.assertTrue(first)
        self.assertEqual(second, 0)
        self.assertEqual(len(self.db.drafts()), 1)

    def test_seed_demo_creates_queue(self):
        seed_demo(self.db)
        stats = self.db.stats()
        self.assertGreaterEqual(stats["total"], 8)
        self.assertEqual(stats["queue"]["published"], 3)
        self.assertEqual(stats["sources"], 3)


class ApiTest(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.tmpdir = tempfile.mkdtemp()
        os.environ["TG_DB"] = os.path.join(cls.tmpdir, "api.db")
        os.environ["TG_DATA_DIR"] = cls.tmpdir
        os.environ["TG_QUIET"] = "1"
        from app import server
        cls.db = DB(os.environ["TG_DB"])
        seed_demo(cls.db)
        server.Handler.db = cls.db
        cls.httpd = ThreadingHTTPServer(("127.0.0.1", 0), server.Handler)
        cls.port = cls.httpd.server_address[1]
        cls.thread = threading.Thread(target=cls.httpd.serve_forever, daemon=True)
        cls.thread.start()
        cls.jar = CookieJar()
        cls.opener = urllib.request.build_opener(urllib.request.HTTPCookieProcessor(cls.jar))

    @classmethod
    def tearDownClass(cls):
        cls.httpd.shutdown()
        cls.httpd.server_close()
        cls.db.close()

    def call(self, path, method="GET", payload=None):
        data = json.dumps(payload).encode() if payload is not None else None
        req = urllib.request.Request(
            f"http://127.0.0.1:{self.port}{path}", data=data, method=method,
            headers={"Content-Type": "application/json"},
        )
        with self.opener.open(req, timeout=10) as resp:
            return resp.status, json.loads(resp.read().decode())

    def test_01_login_required(self):
        with self.assertRaises(urllib.error.HTTPError) as ctx:
            self.call("/api/stats")
        self.assertEqual(ctx.exception.code, 401)

    def test_02_login_and_stats(self):
        status, data = self.call("/api/login", "POST", {"password": "admin123"})
        self.assertEqual(status, 200)
        self.assertTrue(data["ok"])
        status, data = self.call("/api/stats")
        self.assertEqual(status, 200)
        self.assertGreaterEqual(data["data"]["total"], 8)

    def test_03_sources_crud(self):
        status, data = self.call("/api/sources", "POST",
                                 {"title": "Test", "handle": "test_channel", "interval_min": 15})
        self.assertEqual(status, 201)
        sid = data["id"]
        status, data = self.call(f"/api/sources/{sid}", "PUT", {"enabled": 0})
        self.assertEqual(data["data"]["enabled"], 0)
        status, data = self.call(f"/api/sources/{sid}", "DELETE")
        self.assertTrue(data["ok"])

    def test_04_moderation_flow(self):
        drafts = self.call("/api/drafts?status=pending")[1]["data"]
        self.assertTrue(drafts)
        did = drafts[0]["id"]
        status, data = self.call(f"/api/drafts/{did}/approve", "POST", {})
        self.assertEqual(data["data"]["status"], "approved")
        status, data = self.call(f"/api/drafts/{did}/reject", "POST", {})
        self.assertEqual(data["data"]["status"], "rejected")

    def test_05_settings_masked(self):
        status, data = self.call("/api/settings")
        self.assertNotIn("admin_password", data["data"])
        status, data = self.call("/api/settings", "PUT", {"auto_threshold": "80"})
        self.assertTrue(data["ok"])
        self.assertEqual(self.call("/api/settings")[1]["data"]["auto_threshold"], "80")

    def test_06_export_csv(self):
        with self.opener.open(f"http://127.0.0.1:{self.port}/api/export.csv", timeout=10) as resp:
            body = resp.read().decode("utf-8")
        self.assertIn("канал", body)
        self.assertIn("ai_tech_daily", body)


if __name__ == "__main__":
    unittest.main()
