/* TG Auto Cloner + AI Rewriter Pro — панель */
const $ = (sel, root = document) => root.querySelector(sel);
const $$ = (sel, root = document) => [...root.querySelectorAll(sel)];

const state = {
  stats: null,
  sources: [],
  drafts: [],
  settings: null,
  status: 'all',
  view: 'dashboard',
};

const STATUS_LABEL = {
  pending: 'На модерации',
  approved: 'Одобрено',
  published: 'Опубликовано',
  rejected: 'Отклонено',
  failed: 'Ошибка',
};
const PROVIDER_LABEL = {
  local: 'локальный', gemini: 'Gemini', groq: 'Groq', openai: 'OpenAI', ollama: 'Ollama',
};

async function api(path, opts = {}) {
  const res = await fetch(path, {
    headers: { 'Content-Type': 'application/json' },
    ...opts,
  });
  let data = {};
  try { data = await res.json(); } catch (e) { /* пустой ответ */ }
  if (!res.ok || data.ok === false) {
    throw new Error(data.error || `HTTP ${res.status}`);
  }
  return data;
}

function toast(message, kind = '') {
  const el = $('#toast');
  el.textContent = message;
  el.className = `toast ${kind}`;
  el.hidden = false;
  clearTimeout(toast._t);
  toast._t = setTimeout(() => { el.hidden = true; }, 4200);
}

function fmtTime(epoch) {
  if (!epoch) return '—';
  const d = new Date(epoch * 1000);
  return d.toLocaleString('ru-RU', { day: '2-digit', month: '2-digit', hour: '2-digit', minute: '2-digit' });
}

function ago(epoch) {
  if (!epoch) return 'ещё не запускался';
  const sec = Math.max(0, Math.floor(Date.now() / 1000 - epoch));
  if (sec < 60) return `${sec} сек назад`;
  if (sec < 3600) return `${Math.floor(sec / 60)} мин назад`;
  if (sec < 86400) return `${Math.floor(sec / 3600)} ч назад`;
  return `${Math.floor(sec / 86400)} дн назад`;
}

function scoreClass(score) {
  if (score >= 78) return 'hi';
  if (score >= 55) return 'mid';
  return 'low';
}

function badge(status) {
  return `<span class="badge ${status}">${STATUS_LABEL[status] || status}</span>`;
}

function escapeHtml(text) {
  return String(text || '').replace(/[&<>"']/g, (c) => ({
    '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;',
  }[c]));
}

/* ---------------- boot & auth ---------------- */
async function boot() {
  const me = await api('/api/me');
  if (!me.authenticated) {
    $('#loginScreen').hidden = false;
    $('#app').hidden = true;
    $('#password').focus();
    return;
  }
  $('#loginScreen').hidden = true;
  $('#app').hidden = false;
  await loadAll();
  routeFromHash();
  setInterval(refreshQuiet, 25000);
}

async function loadAll() {
  const [stats, sources, drafts, settings] = await Promise.all([
    api('/api/stats'),
    api('/api/sources'),
    api('/api/drafts?status=all&limit=300'),
    api('/api/settings'),
  ]);
  state.stats = stats.data;
  state.sources = sources.data;
  state.drafts = drafts.data;
  state.settings = settings.data;
  renderAll();
}

async function refreshQuiet() {
  try {
    const [stats, drafts] = await Promise.all([
      api('/api/stats'),
      api('/api/drafts?status=all&limit=300'),
    ]);
    state.stats = stats.data;
    state.drafts = drafts.data;
    renderStats();
    renderQueue();
    renderRecent();
  } catch (e) { /* тихо: панель не должна шуметь */ }
}

$('#loginForm').addEventListener('submit', async (e) => {
  e.preventDefault();
  $('#loginErr').textContent = '';
  try {
    await api('/api/login', { method: 'POST', body: JSON.stringify({ password: $('#password').value }) });
    await boot();
  } catch (err) {
    $('#loginErr').textContent = err.message;
  }
});

$('#logoutBtn').addEventListener('click', async () => {
  await api('/api/logout', { method: 'POST' });
  location.reload();
});

/* ---------------- routing ---------------- */
const TITLES = {
  dashboard: ['Обзор', 'Сбор, очистка и публикация за 5 шагов'],
  sources: ['Каналы-доноры', 'Публичные каналы без Telegram-аккаунта'],
  queue: ['Очередь постов', 'Модерация, редактирование и расписание'],
  settings: ['Настройки', 'LLM, публикация, фильтры и доступ'],
  logs: ['Журнал', 'Что делал конвейер'],
};

function showView(name) {
  if (!TITLES[name]) name = 'dashboard';
  state.view = name;
  $$('.nav a').forEach((a) => a.classList.toggle('active', a.dataset.view === name));
  $$('.view').forEach((v) => v.classList.toggle('active', v.id === `view-${name}`));
  const [title, sub] = TITLES[name];
  $('#pageTitle').textContent = title;
  $('#pageSub').textContent = sub;
  if (name === 'logs') loadLogs();
  if (name === 'settings') fillSettings();
  if (location.hash !== `#${name}`) history.replaceState(null, '', `#${name}`);
}

function routeFromHash() {
  showView((location.hash || '#dashboard').slice(1));
}

$$('.nav a').forEach((a) => a.addEventListener('click', (e) => {
  e.preventDefault();
  showView(a.dataset.view);
}));
window.addEventListener('hashchange', routeFromHash);
$('#refreshBtn').addEventListener('click', async () => {
  await loadAll();
  toast('Данные обновлены', 'ok');
});

document.addEventListener('click', (e) => {
  const goto = e.target.closest('[data-goto]');
  if (goto) showView(goto.dataset.goto);
});

/* ---------------- render: stats ---------------- */
function renderStats() {
  const s = state.stats;
  if (!s) return;
  const q = s.queue || {};
  $('#todayChip').textContent = new Date().toLocaleDateString('ru-RU', { day: 'numeric', month: 'long' });

  $('#kpis').innerHTML = `
    <div class="kpi">
      <div class="label">На модерации <span class="ic">☰</span></div>
      <div class="value">${q.pending || 0}</div>
      <div class="sub">ждут проверки текста</div>
    </div>
    <div class="kpi">
      <div class="label">Одобрено <span class="ic">✓</span></div>
      <div class="value">${q.approved || 0}</div>
      <div class="sub">готовы к публикации</div>
    </div>
    <div class="kpi">
      <div class="label">Опубликовано <span class="ic">↗</span></div>
      <div class="value">${s.published_24h || 0}</div>
      <div class="sub">за последние 24 часа</div>
    </div>
    <div class="kpi">
      <div class="label">Средний балл <span class="ic">◎</span></div>
      <div class="value">${s.avg_score || 0}</div>
      <div class="sub">из 100 · качество очереди</div>
    </div>`;

  const total = Math.max(1, s.total || 0);
  const rows = [
    ['Собрано', s.total || 0, 100],
    ['На модерации', q.pending || 0],
    ['Одобрено', q.approved || 0],
    ['Опубликовано', q.published || 0],
    ['Отклонено', q.rejected || 0],
  ];
  $('#pipeline').innerHTML = rows.map(([label, n], i) => `
    <div class="pipe-row">
      <span class="muted">${label}</span>
      <div class="pipe-bar"><span style="width:${Math.max(1, Math.round(n / total * 100))}%"></span></div>
      <span class="n">${n}</span>
    </div>`).join('');
  $('#pipelineTotal').textContent = `${s.total || 0} постов`;

  $('#avgScore').textContent = s.avg_score || 0;
  $('#thresholdLabel').textContent = state.settings?.auto_threshold || 72;
  $('#scoreMeter').style.width = `${s.avg_score || 0}%`;

  $('#miniStats').innerHTML = `
    <div><b>${s.sources || 0}</b><span>каналов-доноров</span></div>
    <div><b>${s.published_7d || 0}</b><span>публикаций за 7 дней</span></div>
    <div><b>${PROVIDER_LABEL[s.provider] || s.provider || 'local'}</b><span>движок переписывания</span></div>`;

  $('#sideProvider').textContent = `Движок: ${PROVIDER_LABEL[s.provider] || s.provider}`;
  $('#sideTarget').textContent = s.target ? `Канал: ${s.target}` : 'Целевой канал не задан';
  $('#sideStatus').textContent = s.scheduler ? 'Конвейер активен' : 'Планировщик выключен';
  $('#sidePulse').className = 'pulse' + (s.scheduler ? '' : ' off');

  ['all', 'pending', 'approved', 'published', 'rejected'].forEach((k) => {
    const el = $(`#tab-${k}`);
    if (el) el.textContent = k === 'all' ? (s.total || 0) : (q[k] || 0);
  });
}

/* ---------------- render: sources ---------------- */
function renderSources() {
  const box = $('#sourcesList');
  if (!state.sources.length) {
    box.innerHTML = `<div class="empty"><b>Пока нет каналов</b>Добавьте публичный канал — панель начнёт собирать посты.</div>`;
    return;
  }
  box.innerHTML = state.sources.map((s) => `
    <div class="source-card" data-id="${s.id}">
      <div class="source-ava">${escapeHtml((s.title || s.handle).slice(0, 2).toUpperCase())}</div>
      <div>
        <div class="row" style="gap:8px"><b>${escapeHtml(s.title)}</b>
          <span class="chip soft">@${escapeHtml(s.handle)}</span>
          <span class="muted small"><span class="dot ${s.enabled ? 'on' : 'off'}"></span>${s.enabled ? 'включён' : 'выключен'}</span>
        </div>
        <div class="source-meta">
          <span>Интервал: ${s.interval_min} мин</span>
          <span>Собрано: ${s.fetched}</span>
          <span>Последний сбор: ${ago(s.last_fetch)}</span>
        </div>
      </div>
      <div class="source-actions">
        <label class="switch" title="Включить/выключить">
          <input type="checkbox" data-act="toggle" ${s.enabled ? 'checked' : ''}><span></span>
        </label>
        <button class="btn sm ghost" data-act="fetch">Забрать</button>
        <button class="btn sm danger" data-act="del">✕</button>
      </div>
    </div>`).join('');
}

$('#sourcesList').addEventListener('click', async (e) => {
  const card = e.target.closest('.source-card');
  if (!card) return;
  const id = Number(card.dataset.id);
  const act = e.target.closest('[data-act]')?.dataset.act;
  if (!act) return;
  try {
    if (act === 'del') {
      if (!confirm('Удалить канал из списка? Уже собранные посты останутся в очереди.')) return;
      await api(`/api/sources/${id}`, { method: 'DELETE' });
      toast('Канал удалён', 'ok');
    } else if (act === 'fetch') {
      const btn = e.target.closest('button');
      btn.disabled = true; btn.textContent = '…';
      const data = await api(`/api/sources/${id}/fetch`, { method: 'POST' });
      toast(`Новых постов: ${data.data.new}, отфильтровано: ${data.data.rejected}`, 'ok');
    } else if (act === 'toggle') {
      await api(`/api/sources/${id}`, {
        method: 'PUT', body: JSON.stringify({ enabled: e.target.checked ? 1 : 0 }),
      });
    }
    await loadAll();
  } catch (err) {
    toast(err.message, 'err');
    await loadAll();
  }
});

$('#addSourceBtn').addEventListener('click', () => {
  openModal('Новый канал-донор', `
    <div class="field"><label>Название</label><input class="input" id="srcTitle" placeholder="Технологии и AI"></div>
    <div class="field"><label>Username канала (без @)</label><input class="input" id="srcHandle" placeholder="ai_tech_daily"></div>
    <div class="field"><label>Интервал сбора, минут</label><input class="input" id="srcInterval" type="number" min="5" value="30"></div>
    <div class="note-card">Канал должен быть публичным: панель читает <b>t.me/s/&lt;username&gt;</b>.</div>`,
  `<button class="btn ghost" data-close>Отмена</button><button class="btn primary" id="srcSave">Добавить</button>`);
  $('#srcSave').addEventListener('click', async () => {
    try {
      await api('/api/sources', {
        method: 'POST',
        body: JSON.stringify({
          title: $('#srcTitle').value,
          handle: $('#srcHandle').value,
          interval_min: Number($('#srcInterval').value) || 30,
        }),
      });
      closeModal();
      toast('Канал добавлен', 'ok');
      await loadAll();
    } catch (err) { toast(err.message, 'err'); }
  });
});

/* ---------------- render: queue ---------------- */
function renderQueue() {
  const box = $('#queueList');
  const list = state.status === 'all'
    ? state.drafts
    : state.drafts.filter((d) => d.status === state.status);

  if (!list.length) {
    box.innerHTML = `<div class="empty"><b>Здесь пусто</b>Новые посты появятся после сбора каналов.</div>`;
    return;
  }

  box.innerHTML = list.map((d) => {
    const actions = [];
    if (d.status === 'pending') {
      actions.push(`<button class="btn sm primary" data-act="approve" data-id="${d.id}">Одобрить</button>`);
      actions.push(`<button class="btn sm ghost" data-act="edit" data-id="${d.id}">Править</button>`);
      actions.push(`<button class="btn sm danger" data-act="reject" data-id="${d.id}">Отклонить</button>`);
    } else if (d.status === 'approved') {
      actions.push(`<button class="btn sm primary" data-act="publish" data-id="${d.id}">Опубликовать</button>`);
      actions.push(`<button class="btn sm ghost" data-act="schedule" data-id="${d.id}">Расписание</button>`);
      actions.push(`<button class="btn sm ghost" data-act="edit" data-id="${d.id}">Править</button>`);
    } else {
      actions.push(`<button class="btn sm ghost" data-act="edit" data-id="${d.id}">Открыть</button>`);
      if (d.status === 'rejected') {
        actions.push(`<button class="btn sm ghost" data-act="approve" data-id="${d.id}">Вернуть</button>`);
      }
    }
    const sched = d.scheduled_at && d.status === 'approved'
      ? `<span class="muted small">⏱ ${fmtTime(d.scheduled_at)}</span>` : '';
    return `
    <div class="qcard">
      <div class="qhead">
        <div class="who">
          <div class="score ${scoreClass(d.score)}">${d.score}</div>
          <div><b>@${escapeHtml(d.source_handle)}</b>
            <div class="muted small">пост #${d.msg_id} · ${fmtTime(d.created)} ${sched}</div>
          </div>
          <span class="engine">${escapeHtml(d.engine || 'local')}</span>
        </div>
        <div class="row">${d.status === 'published' ? `<span class="muted small">msg ${d.tg_msg_id}</span>` : ''}${badge(d.status)}</div>
      </div>
      <div class="qbody">
        <div>
          <div class="qlabel"><span>Исходник</span><span>${d.raw_text.length} симв.</span></div>
          <div class="qtext raw">${escapeHtml(d.raw_text)}</div>
        </div>
        <div>
          <div class="qlabel"><span>После обработки</span><span>${d.text.length} симв.</span></div>
          <div class="qtext">${escapeHtml(d.text) || '<span class="muted">пусто</span>'}</div>
        </div>
      </div>
      <div class="qfoot">
        <div class="muted small">${d.engine === 'demo' ? 'Демонстрационные данные' : (d.note ? `⚠ ${escapeHtml(d.note)}` : (d.error ? `⚠ ${escapeHtml(d.error)}` : 'Проверено фильтрами'))}</div>
        <div class="qactions">${actions.join('')}</div>
      </div>
    </div>`;
  }).join('');
}

$('#queueTabs').addEventListener('click', (e) => {
  const btn = e.target.closest('button[data-status]');
  if (!btn) return;
  state.status = btn.dataset.status;
  $$('#queueTabs button').forEach((b) => b.classList.toggle('active', b === btn));
  renderQueue();
});

$('#queueList').addEventListener('click', async (e) => {
  const btn = e.target.closest('button[data-act]');
  if (!btn) return;
  const id = Number(btn.dataset.id);
  const act = btn.dataset.act;
  const draft = state.drafts.find((d) => d.id === id);
  if (!draft) return;

  if (act === 'edit') return openEdit(draft);
  if (act === 'schedule') return openSchedule(draft);

  if (act === 'publish' && !confirm('Опубликовать пост в целевой канал сейчас?')) return;
  try {
    btn.disabled = true;
    if (act === 'approve') {
      await api(`/api/drafts/${id}/approve`, { method: 'POST', body: JSON.stringify({}) });
      toast('Пост одобрен', 'ok');
    } else if (act === 'reject') {
      await api(`/api/drafts/${id}/reject`, { method: 'POST', body: JSON.stringify({}) });
      toast('Пост отклонён');
    } else if (act === 'publish') {
      await api(`/api/drafts/${id}/publish`, { method: 'POST', body: JSON.stringify({}) });
      toast('Пост опубликован', 'ok');
    }
    await loadAll();
  } catch (err) {
    toast(err.message, 'err');
    btn.disabled = false;
  }
});

function openEdit(draft) {
  openModal(`Пост #${draft.id}`, `
    <div class="meta-grid">
      <div>Канал<b>@${escapeHtml(draft.source_handle)}</b></div>
      <div>Оценка<b>${draft.score} / 100</b></div>
      <div>Движок<b>${escapeHtml(draft.engine || 'local')}</b></div>
      <div>Статус<b>${STATUS_LABEL[draft.status]}</b></div>
    </div>
    <div class="field">
      <label>Текст для публикации</label>
      <textarea class="input area" id="editText" rows="8">${escapeHtml(draft.text)}</textarea>
    </div>
    <div class="field">
      <label>Исходный текст</label>
      <textarea class="input area" id="editRaw" rows="5" readonly>${escapeHtml(draft.raw_text)}</textarea>
    </div>`,
  `<button class="btn ghost" data-close>Закрыть</button>
   <button class="btn primary" id="editSave">Сохранить</button>`);
  $('#editSave').addEventListener('click', async () => {
    try {
      await api(`/api/drafts/${draft.id}`, {
        method: 'PUT', body: JSON.stringify({ text: $('#editText').value }),
      });
      closeModal();
      toast('Текст обновлён', 'ok');
      await loadAll();
    } catch (err) { toast(err.message, 'err'); }
  });
}

function openSchedule(draft) {
  const at = new Date(Date.now() + 3600 * 1000);
  at.setMinutes(0, 0, 0);
  const local = new Date(at.getTime() - at.getTimezoneOffset() * 60000).toISOString().slice(0, 16);
  openModal('Запланировать публикацию', `
    <div class="field">
      <label>Дата и время (локальное)</label>
      <input class="input" type="datetime-local" id="schedAt" value="${local}">
    </div>
    <div class="note-card">Пост уйдёт в целевой канал, когда наступит время. Планировщик проверяет очередь каждые 20 секунд.</div>`,
  `<button class="btn ghost" data-close>Отмена</button>
   <button class="btn primary" id="schedSave">Запланировать</button>`);
  $('#schedSave').addEventListener('click', async () => {
    const value = $('#schedAt').value;
    if (!value) return toast('Укажите дату', 'err');
    const epoch = new Date(value).getTime() / 1000;
    try {
      await api(`/api/drafts/${draft.id}/schedule`, {
        method: 'POST', body: JSON.stringify({ at: epoch }),
      });
      closeModal();
      toast('Публикация запланирована', 'ok');
      await loadAll();
    } catch (err) { toast(err.message, 'err'); }
  });
}

$('#fetchAllBtn').addEventListener('click', async () => {
  if (!state.sources.length) return toast('Сначала добавьте канал', 'err');
  const btn = $('#fetchAllBtn');
  btn.disabled = true; btn.textContent = 'Собираю…';
  let added = 0, errors = 0;
  for (const src of state.sources) {
    try {
      const r = await api(`/api/sources/${src.id}/fetch`, { method: 'POST' });
      added += r.data.new;
    } catch (e) { errors += 1; }
  }
  btn.disabled = false; btn.textContent = '↻ Собрать со всех';
  toast(`Новых постов: ${added}${errors ? `, ошибок: ${errors}` : ''}`, errors ? 'err' : 'ok');
  await loadAll();
});

$('#exportBtn').addEventListener('click', () => { window.location = '/api/export.csv'; });

/* ---------------- render: recent ---------------- */
function renderRecent() {
  const tbody = $('#recentTable tbody');
  const list = state.drafts.slice(0, 6);
  if (!list.length) {
    tbody.innerHTML = `<tr><td colspan="5" class="muted">Пока нет постов</td></tr>`;
    return;
  }
  tbody.innerHTML = list.map((d) => `
    <tr>
      <td class="mono">@${escapeHtml(d.source_handle)}</td>
      <td><div class="clip">${escapeHtml(d.text)}</div></td>
      <td><span class="score ${scoreClass(d.score)}" style="width:32px;height:32px;font-size:11.5px">${d.score}</span></td>
      <td>${badge(d.status)}</td>
      <td class="muted small">${fmtTime(d.created)}</td>
    </tr>`).join('');
}

/* ---------------- settings ---------------- */
function fillSettings() {
  const s = state.settings;
  if (!s) return;
  const provider = $('#llm_provider');
  provider.innerHTML = (s.providers || []).map((p) =>
    `<option value="${p}">${PROVIDER_LABEL[p] || p}</option>`).join('');
  provider.value = s.llm_provider || 'local';
  $('#llm_model').value = s.llm_model || '';
  $('#llm_model').placeholder = (s.models || {})[provider.value] || 'по умолчанию';
  $('#llm_api_key').value = s.llm_api_key || '';
  $('#llm_base_url').value = s.llm_base_url || '';
  $('#bot_token').value = s.bot_token || '';
  $('#target_channel').value = s.target_channel || '';
  $('#auto_publish').checked = s.auto_publish === '1';
  $('#auto_threshold').value = s.auto_threshold || 72;
  $('#thresholdValue').textContent = s.auto_threshold || 72;
  $('#post_delay_min').value = s.post_delay_min || 15;
  $('#stop_words').value = s.stop_words || '';
  $('#rewrite_prompt').value = s.rewrite_prompt || '';
  $('#max_per_run').value = s.max_per_run || 5;
  $('#default_interval').value = s.default_interval || 30;
  $('#new_password').value = '';
}

$('#llm_provider').addEventListener('change', (e) => {
  const models = state.settings?.models || {};
  $('#llm_model').placeholder = models[e.target.value] || 'по умолчанию';
  if (e.target.value === 'local') $('#llmStatus').textContent = 'Локальный режим работает без ключа';
});
$('#auto_threshold').addEventListener('input', (e) => {
  $('#thresholdValue').textContent = e.target.value;
});
$('#auto_threshold').addEventListener('change', (e) => {
  $('#thresholdLabel').textContent = e.target.value;
});

$('#saveSettingsBtn').addEventListener('click', async () => {
  const payload = {
    llm_provider: $('#llm_provider').value,
    llm_model: $('#llm_model').value,
    llm_api_key: $('#llm_api_key').value,
    llm_base_url: $('#llm_base_url').value,
    bot_token: $('#bot_token').value,
    target_channel: $('#target_channel').value,
    auto_publish: $('#auto_publish').checked ? '1' : '0',
    auto_threshold: $('#auto_threshold').value,
    post_delay_min: $('#post_delay_min').value,
    stop_words: $('#stop_words').value,
    rewrite_prompt: $('#rewrite_prompt').value,
    max_per_run: $('#max_per_run').value,
    default_interval: $('#default_interval').value,
  };
  if ($('#new_password').value) payload.new_password = $('#new_password').value;
  try {
    await api('/api/settings', { method: 'PUT', body: JSON.stringify(payload) });
    toast('Настройки сохранены', 'ok');
    await loadAll();
    fillSettings();
  } catch (err) { toast(err.message, 'err'); }
});

$('#testLlmBtn').addEventListener('click', async () => {
  const btn = $('#testLlmBtn');
  const out = $('#llmResult');
  btn.disabled = true; btn.textContent = 'Проверяю…';
  try {
    const r = await api('/api/llm/test', { method: 'POST', body: JSON.stringify({}) });
    const d = r.data;
    out.hidden = false;
    out.textContent = `Движок: ${d.engine}\nПеревод: ${d.translated ? 'да' : 'нет'}\n${d.note ? 'Примечание: ' + d.note + '\n' : ''}\n${d.text}`;
    $('#llmStatus').textContent = d.engine === 'local' ? 'Работает локальная очистка' : 'LLM ответил успешно';
  } catch (err) {
    toast(err.message, 'err');
  } finally {
    btn.disabled = false; btn.textContent = 'Проверить движок';
  }
});

$('#testBotBtn').addEventListener('click', async () => {
  try {
    const r = await api('/api/telegram/test', { method: 'POST', body: JSON.stringify({}) });
    $('#botStatus').textContent = `@${r.data.username} · ${r.data.name || ''}`;
    toast('Бот отвечает', 'ok');
  } catch (err) {
    $('#botStatus').textContent = '—';
    toast(err.message, 'err');
  }
});

/* ---------------- logs ---------------- */
async function loadLogs() {
  try {
    const r = await api('/api/logs?limit=150');
    const tbody = $('#logsTable tbody');
    tbody.innerHTML = r.data.length ? r.data.map((l) => `
      <tr><td class="mono muted">${fmtTime(l.ts)}</td>
      <td><span class="log-kind">${escapeHtml(l.kind)}</span></td>
      <td>${escapeHtml(l.message)}</td></tr>`).join('')
      : '<tr><td colspan="3" class="muted">Журнал пуст</td></tr>';
  } catch (err) { toast(err.message, 'err'); }
}
$('#refreshLogsBtn').addEventListener('click', loadLogs);

/* ---------------- modal ---------------- */
function openModal(title, body, foot = '') {
  $('#modalTitle').textContent = title;
  $('#modalBody').innerHTML = body;
  $('#modalFoot').innerHTML = foot;
  $('#overlay').hidden = false;
  $$('[data-close]', $('#modal')).forEach((b) => b.addEventListener('click', closeModal));
}
function closeModal() { $('#overlay').hidden = true; }
$('#modalClose').addEventListener('click', closeModal);
$('#overlay').addEventListener('click', (e) => { if (e.target === $('#overlay')) closeModal(); });
document.addEventListener('keydown', (e) => { if (e.key === 'Escape') closeModal(); });

/* ---------------- render all ---------------- */
function renderAll() {
  renderStats();
  renderSources();
  renderQueue();
  renderRecent();
  fillSettings();
}

boot().catch((err) => {
  console.error(err);
  $('#loginScreen').hidden = false;
  $('#loginErr').textContent = 'Сервер недоступен: ' + err.message;
});
