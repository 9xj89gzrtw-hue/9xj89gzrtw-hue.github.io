# TG Auto Cloner + AI Rewriter Pro 1.0

A self-hosted control panel that fills a Telegram channel from public source channels:
collect posts, strip ads, rewrite with an LLM (or locally), moderate, schedule and publish
through the Telegram Bot API.

**No pip dependencies.** Python 3.9+, standard library only. SQLite storage. The panel
only talks to t.me, your chosen LLM provider and api.telegram.org.

![Dashboard](screenshots/01-dashboard.png)

## Features

- **Public channel grabber** — reads `t.me/s/<username>` web preview, no Telegram account.
  Handles photos, multiline text and deduplicates by message id.
- **Pre-filters** — stop words (ads, promo codes, casino, ERID), minimum length and a
  transparent 0–100 quality score.
- **AI rewriting** — Gemini, Groq, OpenAI-compatible APIs, local Ollama. Editable prompt:
  remove links/ads, translate to Russian, keep facts.
- **Local fallback** — without a key or when the LLM fails, text is cleaned with regexes
  (links, @mentions, ad phrases). Translation is **not** performed in this mode and the
  panel says so explicitly.
- **Moderation queue** — pending → approved → published, inline editing, reject, restore.
- **Scheduling** — publish at a specific time; optional auto-approval above a score
  threshold with a safety delay.
- **Publishing** — Bot API `sendPhoto`/`sendMessage` with text fallback. The bot must be
  an admin of the target channel.
- **CSV export** and a full activity log.
- **Dark responsive UI**, password login, HMAC-signed sessions.

## Quick start

```bash
cd tg-auto-cloner-ai-rewriter-pro
python3 run.py --demo          # demo data
# open http://127.0.0.1:8080
# login: admin / admin123
```

Production:

```bash
python3 run.py                 # empty database
python3 run.py --port 9000
python3 run.py --no-scheduler  # panel only
```

Change the password in **Settings → Limits & access**.

### Docker

```bash
docker compose up -d --build
```

## LLM providers

| Provider | Default model | Key |
|---|---|---|
| Gemini | `gemini-2.0-flash` | Google AI Studio, free tier |
| Groq | `llama-3.3-70b-versatile` | console.groq.com, free tier |
| OpenAI | `gpt-4o-mini` | platform.openai.com |
| Ollama | `llama3.1` | local, no key |
| Local | — | no key, cleanup only, no translation |

The **Test engine** button sends a real sample post and shows engine, translation flag and
the result.

## Publishing

1. Create a bot with [@BotFather](https://t.me/BotFather).
2. Add it as an admin of your channel with posting rights.
3. Enter token and channel (`@my_channel` or `-100…`) in Settings.
4. Press **Test bot** (`getMe`).
5. Approve a draft and publish now or schedule it.

## Tests

```bash
python3 -m unittest discover -s tests -v
```

16 offline tests: t.me parser, ad cleanup, stop words, scoring, SQLite dedupe, LLM
fallback, API auth, source CRUD, moderation, settings, CSV export.

## Limitations

- Public channels with web preview only; no private channels, chats or stories.
- t.me exposes recent posts, not the full archive.
- Albums publish as a single photo; video is not transferred.
- Local mode does not translate or restyle text.
- Always review facts, numbers and names before publishing. You are responsible for
  respecting the source channel's copyright and Telegram's rules.

## License

Commercial single-buyer license, see `LICENSE.txt`.
