"""TG Auto Cloner + AI Rewriter Pro — хранилище, настройки, пароли."""
from __future__ import annotations

import hashlib
import hmac
import os
import secrets
import sqlite3
import threading
import time
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent.parent
DATA_DIR = Path(os.environ.get("TG_DATA_DIR", BASE_DIR / "data"))
DATA_DIR.mkdir(parents=True, exist_ok=True)
DB_PATH = DATA_DIR / "app.db"

DEFAULT_PROMPT = (
    "Ты — редактор Telegram-канала. Перепиши пост, сохранив все факты, цифры и имена.\n"
    "Правила:\n"
    "1. Убери рекламу, промокоды, ссылки, упоминания чужих каналов и призывы подписаться.\n"
    "2. Если текст не на русском — переведи на русский.\n"
    "3. Не добавляй фактов, которых нет в исходнике.\n"
    "4. Верни только готовый текст поста, без пояснений и кавычек.\n"
    "5. Максимум 900 символов."
)

DEFAULT_STOP_WORDS = (
    "реклама,промокод,erid,казино,ставки,букмекер,подписывайтесь,подпишись,"
    "переходи по ссылке,жми на ссылку,заработок,криптосигнал,инвестируй,"
    "18+,интим,набор в команду,ищу сотрудников"
)

DEFAULTS = {
    "llm_provider": "local",
    "llm_api_key": "",
    "llm_model": "",
    "llm_base_url": "",
    "bot_token": "",
    "target_channel": "",
    "auto_publish": "0",
    "auto_threshold": "72",
    "default_interval": "30",
    "max_per_run": "5",
    "post_delay_min": "15",
    "stop_words": DEFAULT_STOP_WORDS,
    "rewrite_prompt": DEFAULT_PROMPT,
    "demo_mode": "0",
}

STATUSES = ("pending", "approved", "rejected", "published", "failed")


def now() -> float:
    return time.time()


def hash_password(password: str, salt: str | None = None) -> str:
    salt = salt or secrets.token_hex(8)
    digest = hashlib.pbkdf2_hmac("sha256", password.encode(), salt.encode(), 120_000).hex()
    return f"pbkdf2$120000${salt}${digest}"


def verify_password(password: str, stored: str) -> bool:
    try:
        algo, iterations, salt, digest = stored.split("$", 3)
        if algo != "pbkdf2":
            return False
        calc = hashlib.pbkdf2_hmac("sha256", password.encode(), salt.encode(), int(iterations)).hex()
        return hmac.compare_digest(calc, digest)
    except (ValueError, AttributeError):
        return False


class DB:
    """Тонкая обёртка над sqlite с блокировкой для фонового потока."""

    def __init__(self, path: str | None = None):
        self.path = str(path or os.environ.get("TG_DB", DB_PATH))
        self.lock = threading.RLock()
        self.conn = sqlite3.connect(self.path, check_same_thread=False)
        self.conn.row_factory = sqlite3.Row
        self.conn.execute("PRAGMA journal_mode=WAL")
        self.conn.execute("PRAGMA foreign_keys=ON")
        self._init()

    def _init(self):
        with self.lock:
            self.conn.executescript(
                """
                CREATE TABLE IF NOT EXISTS settings (
                    key TEXT PRIMARY KEY,
                    value TEXT NOT NULL
                );
                CREATE TABLE IF NOT EXISTS sources (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    title TEXT NOT NULL,
                    handle TEXT NOT NULL UNIQUE,
                    enabled INTEGER NOT NULL DEFAULT 1,
                    interval_min INTEGER NOT NULL DEFAULT 30,
                    last_fetch REAL NOT NULL DEFAULT 0,
                    fetched INTEGER NOT NULL DEFAULT 0,
                    created REAL NOT NULL
                );
                CREATE TABLE IF NOT EXISTS drafts (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    source_id INTEGER NOT NULL,
                    source_handle TEXT NOT NULL,
                    msg_id INTEGER NOT NULL,
                    raw_text TEXT NOT NULL,
                    text TEXT NOT NULL,
                    media_url TEXT NOT NULL DEFAULT '',
                    status TEXT NOT NULL DEFAULT 'pending',
                    score INTEGER NOT NULL DEFAULT 0,
                    note TEXT NOT NULL DEFAULT '',
                    engine TEXT NOT NULL DEFAULT '',
                    created REAL NOT NULL,
                    updated REAL NOT NULL,
                    scheduled_at REAL NOT NULL DEFAULT 0,
                    published_at REAL NOT NULL DEFAULT 0,
                    tg_msg_id INTEGER NOT NULL DEFAULT 0,
                    error TEXT NOT NULL DEFAULT '',
                    UNIQUE(source_id, msg_id)
                );
                CREATE INDEX IF NOT EXISTS idx_drafts_status ON drafts(status, created DESC);
                CREATE TABLE IF NOT EXISTS logs (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    ts REAL NOT NULL,
                    kind TEXT NOT NULL,
                    message TEXT NOT NULL
                );
                """
            )
            for key, value in DEFAULTS.items():
                self.conn.execute(
                    "INSERT OR IGNORE INTO settings(key, value) VALUES(?,?)", (key, value)
                )
            if not self.get("admin_password"):
                self.set("admin_password", hash_password("admin123"))
            self.conn.commit()

    # ---------- settings ----------
    def get(self, key: str, default: str = "") -> str:
        with self.lock:
            row = self.conn.execute("SELECT value FROM settings WHERE key=?", (key,)).fetchone()
        return row["value"] if row else default

    def set(self, key: str, value) -> None:
        with self.lock:
            self.conn.execute(
                "INSERT INTO settings(key, value) VALUES(?,?) "
                "ON CONFLICT(key) DO UPDATE SET value=excluded.value",
                (key, str(value)),
            )
            self.conn.commit()

    def int_setting(self, key: str, default: int = 0) -> int:
        try:
            return int(float(self.get(key, str(default))))
        except (TypeError, ValueError):
            return default

    def settings(self, mask: bool = True) -> dict:
        with self.lock:
            rows = self.conn.execute("SELECT key, value FROM settings").fetchall()
        data = {r["key"]: r["value"] for r in rows}
        data.pop("admin_password", None)
        if mask:
            for key in ("llm_api_key", "bot_token"):
                if data.get(key):
                    data[key] = "***"
        return data

    # ---------- sources ----------
    def sources(self) -> list:
        with self.lock:
            rows = self.conn.execute("SELECT * FROM sources ORDER BY id").fetchall()
        return [dict(r) for r in rows]

    def source(self, sid: int):
        with self.lock:
            row = self.conn.execute("SELECT * FROM sources WHERE id=?", (sid,)).fetchone()
        return dict(row) if row else None

    def add_source(self, title: str, handle: str, interval_min: int = 30,
                   enabled: int = 1):
        handle = handle.strip().lstrip("@").lower()
        with self.lock:
            cur = self.conn.execute(
                "INSERT INTO sources(title, handle, enabled, interval_min, created) "
                "VALUES(?,?,?,?,?)",
                (title.strip(), handle, int(enabled), int(interval_min), now()),
            )
            self.conn.commit()
            return cur.lastrowid

    def update_source(self, sid: int, **fields) -> None:
        allowed = ("title", "handle", "enabled", "interval_min", "last_fetch", "fetched")
        if "handle" in fields:
            fields["handle"] = str(fields["handle"]).strip().lstrip("@").lower()
        pairs = [(k, fields[k]) for k in allowed if k in fields]
        if not pairs:
            return
        with self.lock:
            self.conn.execute(
                "UPDATE sources SET " + ", ".join(f"{k}=?" for k, _ in pairs) + " WHERE id=?",
                [v for _, v in pairs] + [sid],
            )
            self.conn.commit()

    def delete_source(self, sid: int) -> None:
        with self.lock:
            self.conn.execute("DELETE FROM sources WHERE id=?", (sid,))
            self.conn.commit()

    def due_sources(self) -> list:
        ts = now()
        out = []
        for src in self.sources():
            if not src["enabled"]:
                continue
            if ts - src["last_fetch"] >= max(5, src["interval_min"]) * 60:
                out.append(src)
        return out

    # ---------- drafts ----------
    def has_post(self, source_id: int, msg_id: int) -> bool:
        with self.lock:
            row = self.conn.execute(
                "SELECT 1 FROM drafts WHERE source_id=? AND msg_id=?", (source_id, msg_id)
            ).fetchone()
        return bool(row)

    def add_draft(self, source_id: int, source_handle: str, msg_id: int, raw_text: str,
                  text: str, media_url: str = "", status: str = "pending", score: int = 0,
                  note: str = "", engine: str = "") -> int:
        ts = now()
        with self.lock:
            cur = self.conn.execute(
                "INSERT OR IGNORE INTO drafts(source_id, source_handle, msg_id, raw_text, text,"
                " media_url, status, score, note, engine, created, updated)"
                " VALUES(?,?,?,?,?,?,?,?,?,?,?,?)",
                (source_id, source_handle, msg_id, raw_text, text, media_url, status,
                 int(score), note, engine, ts, ts),
            )
            self.conn.commit()
            return cur.lastrowid if cur.rowcount else 0

    def drafts(self, status: str | None = None, limit: int = 200) -> list:
        sql = "SELECT * FROM drafts"
        params: list = []
        if status and status != "all":
            sql += " WHERE status=?"
            params.append(status)
        sql += " ORDER BY created DESC LIMIT ?"
        params.append(int(limit))
        with self.lock:
            rows = self.conn.execute(sql, params).fetchall()
        return [dict(r) for r in rows]

    def draft(self, did: int):
        with self.lock:
            row = self.conn.execute("SELECT * FROM drafts WHERE id=?", (did,)).fetchone()
        return dict(row) if row else None

    def update_draft(self, did: int, **fields) -> None:
        allowed = ("text", "status", "score", "note", "scheduled_at", "published_at",
                   "tg_msg_id", "error", "media_url")
        pairs = [(k, fields[k]) for k in allowed if k in fields]
        if not pairs:
            return
        with self.lock:
            self.conn.execute(
                "UPDATE drafts SET " + ", ".join(f"{k}=?" for k, _ in pairs) +
                ", updated=? WHERE id=?",
                [v for _, v in pairs] + [now(), did],
            )
            self.conn.commit()

    def delete_draft(self, did: int) -> None:
        with self.lock:
            self.conn.execute("DELETE FROM drafts WHERE id=?", (did,))
            self.conn.commit()

    def due_drafts(self, limit: int = 10) -> list:
        ts = now()
        with self.lock:
            rows = self.conn.execute(
                "SELECT * FROM drafts WHERE status='approved' AND scheduled_at>0"
                " AND scheduled_at<=? ORDER BY scheduled_at LIMIT ?", (ts, limit)
            ).fetchall()
        return [dict(r) for r in rows]

    def queue_counts(self) -> dict:
        with self.lock:
            rows = self.conn.execute(
                "SELECT status, COUNT(*) AS n FROM drafts GROUP BY status"
            ).fetchall()
        data = {s: 0 for s in STATUSES}
        for r in rows:
            data[r["status"]] = r["n"]
        return data

    def stats(self) -> dict:
        counts = self.queue_counts()
        day_ago = now() - 86400
        week_ago = now() - 7 * 86400
        with self.lock:
            pub24 = self.conn.execute(
                "SELECT COUNT(*) n FROM drafts WHERE status='published' AND published_at>=?",
                (day_ago,),
            ).fetchone()["n"]
            pub7 = self.conn.execute(
                "SELECT COUNT(*) n FROM drafts WHERE status='published' AND published_at>=?",
                (week_ago,),
            ).fetchone()["n"]
            avg = self.conn.execute(
                "SELECT AVG(score) a FROM drafts WHERE status IN ('pending','approved')"
            ).fetchone()["a"]
            src = self.conn.execute("SELECT COUNT(*) n FROM sources WHERE enabled=1").fetchone()["n"]
            last = self.conn.execute("SELECT MAX(ts) t FROM logs").fetchone()["t"]
        total = sum(counts.values())
        return {
            "sources": src,
            "total": total,
            "queue": counts,
            "published_24h": pub24,
            "published_7d": pub7,
            "avg_score": round(avg or 0),
            "last_activity": last or 0,
        }

    # ---------- logs ----------
    def log(self, kind: str, message: str) -> None:
        with self.lock:
            self.conn.execute(
                "INSERT INTO logs(ts, kind, message) VALUES(?,?,?)", (now(), kind, message)
            )
            self.conn.commit()

    def logs(self, limit: int = 120) -> list:
        with self.lock:
            rows = self.conn.execute(
                "SELECT * FROM logs ORDER BY id DESC LIMIT ?", (int(limit),)
            ).fetchall()
        return [dict(r) for r in rows]

    def close(self):
        with self.lock:
            self.conn.close()


def seed_demo(db: DB) -> None:
    """Демо-данные для скриншотов и первого запуска. Реальные публикации не делает."""
    if db.get("demo_mode") == "1" and db.drafts(limit=1):
        return
    db.set("demo_mode", "1")
    if not db.sources():
        for title, handle, interval in (
            ("Технологии и AI", "ai_tech_daily", 30),
            ("Игровые новости", "game_news_ru", 60),
            ("Крипта без воды", "crypto_clean", 45),
        ):
            db.add_source(title, handle, interval)
    samples = [
        ("ai_tech_daily", 101, "OpenAI показала новую модель GPT-5.2. Она быстрее предыдущей на 40% и лучше держит контекст. Подписывайтесь на наш канал! t.me/spam_channel",
         "OpenAI представила модель GPT-5.2: она на 40% быстрее предыдущей версии и лучше удерживает контекст диалога.", "published", 91, "auto", 3),
        ("game_news_ru", 355, "Valve обновила Steam Deck OLED: экран стал ярче, время работы выросло до 9 часов. Промокод на скидку внутри.",
         "Valve выпустила обновлённый Steam Deck OLED: яркость экрана выше, автономность выросла до 9 часов.", "published", 88, "auto", 4),
        ("crypto_clean", 77, "Bitcoin обновил локальный максимум на отметке $112 400. Объёмы торгов выросли на 18% за сутки.",
         "Bitcoin обновил локальный максимум на $112 400. Объёмы торгов за сутки выросли на 18%.", "published", 84, "auto", 5),
        ("ai_tech_daily", 104, "Anthropic открыла доступ к Claude 4.5 Sonnet для разработчиков. Контекст — 1 млн токенов. Ссылка в Bio.",
         "Anthropic открыла доступ к Claude 4.5 Sonnet для разработчиков. Контекстное окно — 1 млн токенов.", "approved", 86, "auto", 0),
        ("game_news_ru", 359, "CD Projekt перенесла релиз продолжения Cyberpunk на второй квартал 2027 года. Причина — полировка качества.",
         "CD Projekt перенесла релиз продолжения Cyberpunk на второй квартал 2027 года. Причина — доработка качества.", "approved", 79, "auto", 0),
        ("crypto_clean", 81, "Ethereum завершил обновление Pectra. Газ для L2 снизился примерно на 30%.",
         "Ethereum завершил обновление Pectra: стоимость газа для L2 снизилась примерно на 30%.", "pending", 74, "auto", 0),
        ("ai_tech_daily", 108, "Вышла open-source модель для генерации видео с открытыми весами. Демо доступно на Hugging Face.",
         "Опубликована open-source модель генерации видео с открытыми весами. Демо доступно на Hugging Face.", "pending", 68, "auto", 0),
        ("game_news_ru", 362, "Слух: новая часть God of War может выйти в 2027 году. Официального анонса пока нет.",
         "По слухам, новая часть God of War может выйти в 2027 году. Официального анонса пока нет.", "pending", 55, "auto", 0),
    ]
    ts = now()
    for i, (handle, msg_id, raw, text, status, score, note, pub_hours_ago) in enumerate(samples):
        src = next((s for s in db.sources() if s["handle"] == handle), None)
        if not src:
            continue
        did = db.add_draft(src["id"], handle, msg_id, raw, text,
                           status=status, score=score, note="", engine="demo")
        if not did:
            continue
        db.update_draft(did, scheduled_at=0 if status != "approved" else ts + 3600 * (i + 1))
        if status == "published":
            db.update_draft(did, published_at=ts - pub_hours_ago * 3600,
                            tg_msg_id=9000 + i, scheduled_at=ts - pub_hours_ago * 3600)
    db.log("demo", "Загружены демонстрационные данные")
    # источники в демо уже «собраны»: планировщик не должен дёргать сеть сразу
    for src in db.sources():
        count = len([d for d in db.drafts() if d["source_id"] == src["id"]])
        db.update_source(src["id"], fetched=count, last_fetch=ts)
