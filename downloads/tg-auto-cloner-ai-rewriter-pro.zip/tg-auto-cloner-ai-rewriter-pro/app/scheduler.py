"""Фоновый цикл: сбор постов, переписывание, отложенная публикация."""
from __future__ import annotations

import threading
import time

from .rewriter import Rewriter, find_stopword, score_text, stop_words
from .telegram import TelegramError, fetch_channel, publish_post

MIN_POST_LEN = 40


class Scheduler(threading.Thread):
    def __init__(self, db, interval: int = 20):
        super().__init__(name="tg-scheduler", daemon=True)
        self.db = db
        self.interval = interval
        self.stop_event = threading.Event()
        self.rewriter = Rewriter(db)
        self.last_error = ""

    def stop(self):
        self.stop_event.set()

    def run(self):
        # первый тик — через пару секунд после старта, чтобы сервер уже отвечал
        if self.stop_event.wait(2):
            return
        while not self.stop_event.is_set():
            try:
                self.tick()
            except Exception as e:  # noqa: BLE001
                self.last_error = str(e)
                self.db.log("error", f"Планировщик: {e}")
            if self.stop_event.wait(self.interval):
                break

    def tick(self):
        for src in self.db.due_sources():
            self.fetch_source(src)
        for draft in self.db.due_drafts():
            try:
                self.publish_draft(draft)
            except TelegramError as e:
                self.db.update_draft(draft["id"], status="failed", error=str(e))
                self.db.log("publish", f"Пост #{draft['id']} не опубликован: {e}")

    # ---------- сбор ----------
    def fetch_source(self, src: dict) -> dict:
        """Забрать новые посты канала. Возвращает сводку для API/логов."""
        self.db.update_source(src["id"], last_fetch=time.time())
        limit = max(1, self.db.int_setting("max_per_run", 5))
        try:
            posts = fetch_channel(src["handle"])
        except TelegramError as e:
            self.db.log("fetch", f"@{src['handle']}: {e}")
            return {"ok": False, "error": str(e), "new": 0}

        words = stop_words(self.db.get("stop_words"))
        threshold = self.db.int_setting("auto_threshold", 72)
        auto = self.db.get("auto_publish") == "1"
        delay = self.db.int_setting("post_delay_min", 15)
        created = rejected = 0

        for post in posts[-limit:]:
            if self.db.has_post(src["id"], post["msg_id"]):
                continue
            text = post["text"]
            if len(text) < MIN_POST_LEN:
                self.db.add_draft(
                    src["id"], src["handle"], post["msg_id"], text, "", post.get("photo", ""),
                    status="rejected", score=0, note="слишком короткий пост", engine="filter",
                )
                rejected += 1
                continue
            hit = find_stopword(text, words)
            if hit:
                self.db.add_draft(
                    src["id"], src["handle"], post["msg_id"], text, "", post.get("photo", ""),
                    status="rejected", score=0, note=f"стоп-слово: {hit}", engine="filter",
                )
                rejected += 1
                continue

            result = self.rewriter.rewrite(text)
            score = score_text(result["text"], words)
            status = "pending"
            scheduled = 0
            if auto and score >= threshold:
                status = "approved"
                scheduled = time.time() + max(1, delay) * 60
            did = self.db.add_draft(
                src["id"], src["handle"], post["msg_id"], text, result["text"],
                post.get("photo", ""), status=status, score=score,
                note=result.get("note", ""), engine=result.get("engine", "local"),
            )
            if did and scheduled:
                self.db.update_draft(did, scheduled_at=scheduled)
            if did:
                created += 1

        self.db.update_source(src["id"], fetched=int(src.get("fetched") or 0) + created)
        self.db.log(
            "fetch",
            f"@{src['handle']}: новых {created}, отфильтровано {rejected}, всего в канале {len(posts)}",
        )
        return {"ok": True, "new": created, "rejected": rejected, "seen": len(posts)}

    # ---------- публикация ----------
    def publish_draft(self, draft: dict) -> dict:
        token = self.db.get("bot_token")
        channel = self.db.get("target_channel")
        if not token or not channel:
            raise TelegramError("Не заданы bot token и целевой канал в настройках")
        text = (draft.get("text") or "").strip()
        if not text:
            raise TelegramError("Пустой текст поста")
        msg_id = publish_post(token, channel, text, draft.get("media_url") or "")
        self.db.update_draft(
            draft["id"], status="published", published_at=time.time(),
            tg_msg_id=msg_id, error="",
        )
        self.db.log("publish", f"Пост #{draft['id']} опубликован в {channel} (msg {msg_id})")
        return {"ok": True, "tg_msg_id": msg_id}
