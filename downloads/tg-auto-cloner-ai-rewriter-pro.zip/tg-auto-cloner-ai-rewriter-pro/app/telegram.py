"""Чтение публичных каналов через t.me/s/<handle> и публикация через Bot API.

Никаких сторонних библиотек: только stdlib. Для чтения не нужен аккаунт
Telegram — работает публичный web-preview. Для публикации нужен бот-токен
и права администратора в целевом канале.
"""
from __future__ import annotations

import json
import re
import socket
import urllib.error
import urllib.parse
import urllib.request
from html.parser import HTMLParser

UA = ("Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 "
      "(KHTML, like Gecko) Chrome/126.0 Safari/537.36")
VOID_TAGS = {"br", "img", "hr", "input", "meta", "link", "source", "wbr"}


class TelegramError(RuntimeError):
    pass


class TelegramHTMLParser(HTMLParser):
    """Достаёт из web-preview посты: id, текст, ссылку на фото."""

    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.posts: list = []
        self._stack: list = []
        self._cur: dict | None = None
        self._text_depth: int | None = None
        self._post_depth: int | None = None
        self._buf: list = []

    def handle_starttag(self, tag, attrs):
        attrs = dict(attrs)
        if tag in VOID_TAGS:
            if tag == "br" and self._text_depth is not None:
                self._buf.append("\n")
            if tag == "img" and self._cur is not None and not self._cur.get("photo"):
                src = attrs.get("src") or ""
                if src.startswith("http"):
                    self._cur["photo"] = src
            return

        self._stack.append(tag)
        depth = len(self._stack)
        cls = attrs.get("class") or ""

        if tag == "div" and "tgme_widget_message" in cls and attrs.get("data-post"):
            self._cur = {"post": attrs["data-post"], "text": "", "photo": ""}
            self._text_depth = None
            self._post_depth = depth
            self._buf = []

        if self._cur is not None:
            if tag == "div" and "tgme_widget_message_text" in cls and self._text_depth is None:
                self._text_depth = depth
                self._buf = []
            elif tag == "a" and "tgme_widget_message_photo_wrap" in cls:
                m = re.search(r"url\(['\"]?(.*?)['\"]?\)", attrs.get("style") or "")
                if m and m.group(1).startswith("http"):
                    self._cur["photo"] = m.group(1)

    def handle_endtag(self, tag):
        if not self._stack or tag in VOID_TAGS:
            return
        depth = len(self._stack)
        if self._text_depth is not None and depth == self._text_depth and tag == "div":
            self._cur["text"] = "".join(self._buf).strip()
            self._text_depth = None
            self._buf = []
        if self._post_depth is not None and depth == self._post_depth and tag == "div":
            if self._cur is not None and self._cur.get("text"):
                self.posts.append(self._cur)
            self._cur = None
            self._post_depth = None
        if self._stack and self._stack[-1] == tag:
            self._stack.pop()
        else:
            while self._stack and self._stack[-1] != tag:
                self._stack.pop()
            if self._stack:
                self._stack.pop()

    def handle_data(self, data):
        if self._text_depth is not None:
            self._buf.append(data)


def http_get(url: str, timeout: int = 25) -> str:
    req = urllib.request.Request(url, headers={
        "User-Agent": UA,
        "Accept-Language": "ru,en;q=0.8",
        "Accept": "text/html,application/xhtml+xml",
    })
    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            raw = resp.read(4_000_000)
            charset = resp.headers.get_content_charset() or "utf-8"
            return raw.decode(charset, "replace")
    except urllib.error.HTTPError as e:
        if e.code == 404:
            raise TelegramError(f"Канал не найден: {url}") from e
        raise TelegramError(f"t.me ответил HTTP {e.code}") from e
    except (urllib.error.URLError, socket.timeout) as e:
        raise TelegramError(f"Сеть недоступна: {e}") from e


def parse_posts(html: str) -> list:
    parser = TelegramHTMLParser()
    parser.feed(html)
    parser.close()
    out = []
    for item in parser.posts:
        post = item.get("post", "")
        msg_id = 0
        if "/" in post:
            try:
                msg_id = int(post.rsplit("/", 1)[1])
            except ValueError:
                msg_id = 0
        if not msg_id:
            continue
        out.append({
            "msg_id": msg_id,
            "text": item.get("text", "").strip(),
            "photo": item.get("photo", ""),
        })
    out.sort(key=lambda p: p["msg_id"])
    return out


def fetch_channel(handle: str, timeout: int = 25) -> list:
    handle = handle.strip().lstrip("@")
    if not re.match(r"^[A-Za-z0-9_]{4,64}$", handle):
        raise TelegramError("Некорректный username канала")
    html = http_get(f"https://t.me/s/{handle}", timeout=timeout)
    posts = parse_posts(html)
    if not posts:
        raise TelegramError(
            "В превью нет постов. Канал приватный, пустой или t.me ограничил доступ."
        )
    return posts


# ---------------- публикация ----------------
def bot_call(token: str, method: str, payload: dict, timeout: int = 30) -> dict:
    if not token or ":" not in token:
        raise TelegramError("Не задан корректный bot token")
    url = f"https://api.telegram.org/bot{token}/{method}"
    data = json.dumps(payload).encode("utf-8")
    req = urllib.request.Request(url, data=data, headers={
        "Content-Type": "application/json",
        "User-Agent": "tg-auto-cloner/1.0",
    })
    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            body = json.loads(resp.read().decode("utf-8", "replace"))
    except urllib.error.HTTPError as e:
        try:
            body = json.loads(e.read().decode("utf-8", "replace"))
        except ValueError:
            raise TelegramError(f"Telegram HTTP {e.code}") from e
    except (urllib.error.URLError, socket.timeout) as e:
        raise TelegramError(f"Нет связи с api.telegram.org: {e}") from e
    if not body.get("ok"):
        raise TelegramError(str(body.get("description") or "Telegram отклонил запрос"))
    return body.get("result") or {}


def publish_post(token: str, channel: str, text: str, photo: str = "") -> int:
    channel = channel.strip()
    if not channel:
        raise TelegramError("Не указан целевой канал")
    if photo:
        try:
            result = bot_call(token, "sendPhoto", {
                "chat_id": channel, "photo": photo, "caption": text[:1024],
            })
            return int(result.get("message_id") or 0)
        except TelegramError:
            # фото могло протухнуть — публикуем текст, чтобы пост не потерялся
            pass
    result = bot_call(token, "sendMessage", {
        "chat_id": channel, "text": text[:4096], "disable_web_page_preview": True,
    })
    return int(result.get("message_id") or 0)


def check_bot(token: str) -> dict:
    me = bot_call(token, "getMe", {})
    return {"username": me.get("username"), "name": me.get("first_name")}
