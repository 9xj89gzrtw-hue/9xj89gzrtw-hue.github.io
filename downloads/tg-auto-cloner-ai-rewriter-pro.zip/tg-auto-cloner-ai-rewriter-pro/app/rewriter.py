"""Переписывание постов: локальная очистка или LLM (Gemini / Groq / OpenAI / Ollama).

Честное поведение: если LLM не настроен или упал — работает локальный режим,
но он НЕ переводит текст. Это явно возвращается в поле note и видно в панели.
"""
from __future__ import annotations

import json
import re
import socket
import urllib.error
import urllib.request

DEFAULT_MODELS = {
    "gemini": "gemini-2.0-flash",
    "groq": "llama-3.3-70b-versatile",
    "openai": "gpt-4o-mini",
    "ollama": "llama3.1",
    "local": "",
}

AD_MARKERS = (
    "реклама", "промокод", "erid", "подписывай", "подпишись", "переходи",
    "жми на ссылку", "жми по ссылке", "казино", "ставки", "букмекер",
    "18+", "интим", "криптосигнал", "инвестируй", "набор в команду",
)

URL_RE = re.compile(r"(https?://\S+|www\.\S+|t\.me/\S+)", re.I)
MENTION_RE = re.compile(r"@[A-Za-z0-9_]{4,}")
ERID_RE = re.compile(r"erid[:\s]*[\w-]+", re.I)
SPACES_RE = re.compile(r"[ \t]{2,}")
BLANK_RE = re.compile(r"\n{3,}")


def latin_ratio(text: str) -> float:
    letters = [c for c in text if c.isalpha()]
    if not letters:
        return 0.0
    return sum(1 for c in letters if c.isascii()) / len(letters)


def cyrillic_ratio(text: str) -> float:
    letters = [c for c in text if c.isalpha()]
    if not letters:
        return 0.0
    return sum(1 for c in letters if "\u0400" <= c <= "\u04ff") / len(letters)


def stop_words(raw: str) -> list:
    return [w.strip().lower() for w in (raw or "").split(",") if w.strip()]


def find_stopword(text: str, words: list) -> str:
    low = text.lower()
    for word in words:
        if word and word in low:
            return word
    return ""


def score_text(text: str, words: list) -> int:
    """Эвристика качества 0..100. Не «AI-оценка», а прозрачные правила."""
    score = 58
    length = len(text)
    if length < 80:
        score -= 22
    elif length < 200:
        score += 4
    elif length <= 900:
        score += 12
    else:
        score -= 6
    links = len(URL_RE.findall(text))
    score -= min(links, 4) * 7
    score -= len(find_all_stopwords(text, words)) * 12
    letters = [c for c in text if c.isalpha()]
    if letters and sum(1 for c in letters if c.isupper()) / len(letters) > 0.5 and length > 30:
        score -= 8
    if text.count("!") > 3:
        score -= 5
    return max(0, min(100, score))


def find_all_stopwords(text: str, words: list) -> list:
    low = text.lower()
    return [w for w in words if w and w in low]


def clean_local(text: str) -> str:
    text = URL_RE.sub("", text)
    text = MENTION_RE.sub("", text)
    text = ERID_RE.sub("", text)
    lines = []
    for line in text.splitlines():
        # режем на предложения: рекламную фразу убираем, полезную оставляем
        sentences = re.split(r"(?<=[.!?…])\s+", line)
        kept = [s for s in sentences
                if s.strip() and not any(marker in s.lower() for marker in AD_MARKERS)]
        if kept:
            lines.append(" ".join(part.strip() for part in kept))
    text = "\n".join(lines)
    text = SPACES_RE.sub(" ", text)
    text = BLANK_RE.sub("\n\n", text)
    return text.strip(" \n\t-—·")


def _postprocess(text: str) -> str:
    text = text.strip()
    if text.startswith("```"):
        text = re.sub(r"^```[a-zA-Z]*\n?", "", text)
        text = re.sub(r"\n?```$", "", text)
    text = text.strip().strip('"').strip("«»").strip()
    text = URL_RE.sub("", text)
    text = MENTION_RE.sub("", text)
    text = SPACES_RE.sub(" ", text)
    text = BLANK_RE.sub("\n\n", text)
    return text.strip()


class LLMError(RuntimeError):
    pass


def _post_json(url: str, payload: dict, headers: dict, timeout: int = 60) -> dict:
    data = json.dumps(payload).encode("utf-8")
    req = urllib.request.Request(url, data=data, headers={
        "Content-Type": "application/json",
        "User-Agent": "tg-auto-cloner/1.0",
        **headers,
    })
    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            return json.loads(resp.read().decode("utf-8", "replace"))
    except urllib.error.HTTPError as e:
        detail = ""
        try:
            body = json.loads(e.read().decode("utf-8", "replace"))
            detail = (body.get("error") or {}).get("message") or str(body)[:200]
        except ValueError:
            detail = e.reason or ""
        raise LLMError(f"HTTP {e.code}: {detail}") from e
    except (urllib.error.URLError, socket.timeout) as e:
        raise LLMError(f"нет соединения: {e}") from e
    except ValueError as e:
        raise LLMError("ответ не является JSON") from e


class Rewriter:
    def __init__(self, db):
        self.db = db

    # ---------- настройки ----------
    def provider(self) -> str:
        return (self.db.get("llm_provider", "local") or "local").lower()

    def model(self) -> str:
        return self.db.get("llm_model") or DEFAULT_MODELS.get(self.provider(), "")

    def available(self) -> bool:
        provider = self.provider()
        if provider == "local":
            return True
        if provider == "ollama":
            return True
        return bool(self.db.get("llm_api_key"))

    # ---------- публичный интерфейс ----------
    def rewrite(self, text: str) -> dict:
        text = (text or "").strip()
        if not text:
            return {"text": "", "engine": "local", "translated": False,
                    "note": "пустой текст"}
        provider = self.provider()
        if provider == "local":
            return self._local(text, "локальный режим")
        if not self.available():
            return self._local(text, f"{provider}: не задан API-ключ")
        try:
            result = self._llm(text, provider)
        except LLMError as e:
            self.db.log("llm", f"{provider}: {e}")
            return self._local(text, f"{provider} недоступен: {e}")
        cleaned = _postprocess(result)
        if len(cleaned) < 30:
            return self._local(text, f"{provider}: слишком короткий ответ")
        translated = latin_ratio(text) > 0.45 and cyrillic_ratio(cleaned) > 0.2
        return {"text": cleaned, "engine": provider, "translated": translated, "note": ""}

    def _local(self, text: str, reason: str) -> dict:
        cleaned = clean_local(text)
        note = f"{reason}; перевод не выполняется"
        if latin_ratio(text) > 0.45:
            note += " (текст на латинице)"
        return {"text": cleaned, "engine": "local", "translated": False, "note": note}

    # ---------- провайдеры ----------
    def _llm(self, text: str, provider: str) -> str:
        prompt = self.db.get("rewrite_prompt") or ""
        key = self.db.get("llm_api_key")
        model = self.model()
        base = (self.db.get("llm_base_url") or "").rstrip("/")

        if provider == "gemini":
            url = (f"https://generativelanguage.googleapis.com/v1beta/models/"
                   f"{model}:generateContent?key={key}")
            body = {
                "contents": [{"parts": [{"text": prompt + "\n\nПост:\n" + text}]}],
                "generationConfig": {"temperature": 0.4, "maxOutputTokens": 1200},
            }
            data = _post_json(url, body, {})
            try:
                parts = data["candidates"][0]["content"]["parts"]
                return "".join(p.get("text", "") for p in parts)
            except (KeyError, IndexError, TypeError):
                raise LLMError("Gemini вернул неожиданный формат")

        if provider == "ollama":
            url = (base or "http://127.0.0.1:11434") + "/api/chat"
            body = {
                "model": model,
                "stream": False,
                "messages": [
                    {"role": "system", "content": prompt},
                    {"role": "user", "content": text},
                ],
                "options": {"temperature": 0.4},
            }
            data = _post_json(url, body, {})
            message = data.get("message") or {}
            return str(message.get("content") or "")

        if provider in ("groq", "openai"):
            default_base = ("https://api.groq.com/openai/v1" if provider == "groq"
                            else "https://api.openai.com/v1")
            url = (base or default_base) + "/chat/completions"
            body = {
                "model": model,
                "temperature": 0.4,
                "max_tokens": 1200,
                "messages": [
                    {"role": "system", "content": prompt},
                    {"role": "user", "content": text},
                ],
            }
            data = _post_json(url, body, {"Authorization": f"Bearer {key}"})
            try:
                return data["choices"][0]["message"]["content"]
            except (KeyError, IndexError, TypeError):
                raise LLMError("провайдер вернул неожиданный формат")

        raise LLMError(f"неизвестный провайдер {provider}")
