"""HTTP-сервер панели и API (stdlib, без фреймворков)."""
from __future__ import annotations

import csv
import hmac
import io
import json
import mimetypes
import os
import re
import secrets
import time
from http import cookies
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import parse_qs, urlparse

from .core import BASE_DIR, DB, now, verify_password
from .rewriter import DEFAULT_MODELS, Rewriter, clean_local, score_text, stop_words
from .scheduler import Scheduler
from .telegram import TelegramError, check_bot

WEB_DIR = BASE_DIR / "web"
DATA_DIR = Path(os.environ.get("TG_DATA_DIR", BASE_DIR / "data"))
SECRET_FILE = DATA_DIR / "secret.key"
COOKIE = "tg_session"
TTL = 60 * 60 * 12
PROVIDERS = ("local", "gemini", "groq", "openai", "ollama")


def _secret() -> bytes:
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    if SECRET_FILE.exists():
        return SECRET_FILE.read_bytes()
    value = secrets.token_bytes(32)
    SECRET_FILE.write_bytes(value)
    try:
        SECRET_FILE.chmod(0o600)
    except OSError:
        pass
    return value


SECRET = _secret()


def make_session() -> str:
    ts = str(int(time.time()))
    sig = hmac.new(SECRET, ts.encode(), "sha256").hexdigest()[:40]
    return f"{ts}.{sig}"


def valid_session(token: str) -> bool:
    if not token or "." not in token:
        return False
    ts, sig = token.split(".", 1)
    expected = hmac.new(SECRET, ts.encode(), "sha256").hexdigest()[:40]
    if not hmac.compare_digest(sig, expected):
        return False
    try:
        return time.time() - int(ts) < TTL
    except ValueError:
        return False


class ApiError(Exception):
    def __init__(self, message: str, status: int = 400):
        super().__init__(message)
        self.message = message
        self.status = status


class Handler(BaseHTTPRequestHandler):
    db: DB
    scheduler: Scheduler | None = None
    server_version = "TGAutoClonerPro/1.0"

    def log_message(self, fmt, *args):
        if os.environ.get("TG_QUIET") == "1":
            return
        print("[http] " + fmt % args)

    def _send(self, status: int, body: bytes, ctype="application/json; charset=utf-8",
              extra: dict | None = None):
        self.send_response(status)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(body)))
        self.send_header("X-Content-Type-Options", "nosniff")
        self.send_header("Cache-Control", "no-store")
        for k, v in (extra or {}).items():
            self.send_header(k, v)
        self.end_headers()
        if self.command != "HEAD":
            self.wfile.write(body)

    def json(self, data, status=200, extra=None):
        self._send(status, json.dumps(data, ensure_ascii=False).encode(), extra=extra)

    def error(self, message, status=400):
        self.json({"ok": False, "error": message}, status)

    def token(self) -> str:
        jar = cookies.SimpleCookie()
        try:
            jar.load(self.headers.get("Cookie", ""))
        except cookies.CookieError:
            return ""
        m = jar.get(COOKIE)
        return m.value if m else ""

    def require_auth(self):
        if not valid_session(self.token()):
            raise ApiError("Требуется вход в панель", 401)

    def body(self) -> dict:
        length = int(self.headers.get("Content-Length") or 0)
        if length > 1_000_000:
            raise ApiError("Слишком большой запрос", 413)
        raw = self.rfile.read(length) if length else b""
        if not raw:
            return {}
        try:
            data = json.loads(raw.decode("utf-8"))
        except (ValueError, UnicodeDecodeError):
            raise ApiError("Некорректный JSON")
        if not isinstance(data, dict):
            raise ApiError("Ожидался JSON-объект")
        return data

    def do_GET(self):
        parsed = urlparse(self.path)
        try:
            if parsed.path.startswith("/api/"):
                self.api("GET", parsed.path, parse_qs(parsed.query), None)
            else:
                self.static(parsed.path)
        except ApiError as e:
            self.error(e.message, e.status)
        except BrokenPipeError:
            pass
        except Exception as e:  # noqa: BLE001
            print("[error]", repr(e))
            self.error("Внутренняя ошибка сервера", 500)

    do_HEAD = do_GET

    def do_POST(self):
        self.mutate("POST")

    def do_PUT(self):
        self.mutate("PUT")

    def do_DELETE(self):
        self.mutate("DELETE")

    def mutate(self, method):
        parsed = urlparse(self.path)
        try:
            self.api(method, parsed.path, parse_qs(parsed.query), self.body())
        except ApiError as e:
            self.error(e.message, e.status)
        except BrokenPipeError:
            pass
        except Exception as e:  # noqa: BLE001
            print("[error]", repr(e))
            self.error("Внутренняя ошибка сервера", 500)

    def static(self, path: str):
        if path in ("/", ""):
            path = "/index.html"
        target = (WEB_DIR / path.lstrip("/")).resolve()
        if not str(target).startswith(str(WEB_DIR.resolve())) or not target.is_file():
            target = WEB_DIR / "index.html"
        if not target.is_file():
            return self.error("Не найдено", 404)
        ctype = mimetypes.guess_type(str(target))[0] or "application/octet-stream"
        if ctype.startswith("text/") or "javascript" in ctype:
            ctype += "; charset=utf-8"
        self._send(200, target.read_bytes(), ctype)

    # ---------- helpers ----------
    def draft_or_404(self, did: int) -> dict:
        draft = self.db.draft(did)
        if not draft:
            raise ApiError("Пост не найден", 404)
        return draft

    def publish(self, draft: dict):
        if not self.scheduler:
            raise ApiError("Планировщик не запущен", 503)
        try:
            result = self.scheduler.publish_draft(draft)
        except TelegramError as e:
            self.db.update_draft(draft["id"], status="failed", error=str(e))
            raise ApiError(f"Telegram: {e}", 422)
        return self.json({"ok": True, "data": result, "draft": self.db.draft(draft["id"])})

    # ---------- api ----------
    def api(self, method: str, path: str, query: dict, data: dict | None):
        db = self.db

        if path == "/api/health":
            return self.json({"ok": True, "service": "tg-auto-cloner-ai-rewriter-pro",
                              "version": "1.0.0"})

        if path == "/api/login" and method == "POST":
            if verify_password(str((data or {}).get("password", "")), db.get("admin_password")):
                return self.json({"ok": True}, extra={
                    "Set-Cookie": f"{COOKIE}={make_session()}; Path=/; HttpOnly; SameSite=Lax; Max-Age={TTL}"})
            db.log("auth", "Неудачная попытка входа")
            return self.error("Неверный пароль", 401)

        if path == "/api/logout" and method == "POST":
            return self.json({"ok": True}, extra={
                "Set-Cookie": f"{COOKIE}=; Path=/; HttpOnly; SameSite=Lax; Max-Age=0"})

        if path == "/api/me":
            return self.json({"ok": True, "authenticated": valid_session(self.token())})

        self.require_auth()

        if path == "/api/stats":
            stats = db.stats()
            stats["provider"] = db.get("llm_provider", "local")
            stats["auto_publish"] = db.get("auto_publish") == "1"
            stats["target"] = db.get("target_channel")
            stats["scheduler"] = bool(self.scheduler and self.scheduler.is_alive())
            return self.json({"ok": True, "data": stats})

        if path == "/api/sources":
            if method == "GET":
                return self.json({"ok": True, "data": db.sources()})
            if method == "POST":
                payload = data or {}
                title = str(payload.get("title", "")).strip()
                handle = str(payload.get("handle", "")).strip().lstrip("@")
                if not title:
                    raise ApiError("Укажите название канала")
                if not re.match(r"^[A-Za-z0-9_]{4,64}$", handle):
                    raise ApiError("Username канала: 4–64 символа, латиница, цифры и _")
                try:
                    sid = db.add_source(title, handle, int(payload.get("interval_min") or 30),
                                        int(payload.get("enabled", 1)))
                except Exception as e:  # noqa: BLE001
                    if "UNIQUE" in str(e):
                        raise ApiError("Такой канал уже добавлен")
                    raise
                db.log("source", f"Добавлен канал @{handle}")
                return self.json({"ok": True, "id": sid}, 201)

        m = re.match(r"^/api/sources/(\d+)$", path)
        if m:
            sid = int(m.group(1))
            src = db.source(sid)
            if not src:
                raise ApiError("Канал не найден", 404)
            if method == "PUT":
                payload = data or {}
                if "interval_min" in payload:
                    payload["interval_min"] = max(5, int(payload["interval_min"]))
                db.update_source(sid, **payload)
                return self.json({"ok": True, "data": db.source(sid)})
            if method == "DELETE":
                db.delete_source(sid)
                db.log("source", f"Канал #{sid} удалён")
                return self.json({"ok": True})

        m = re.match(r"^/api/sources/(\d+)/fetch$", path)
        if m and method == "POST":
            src = db.source(int(m.group(1)))
            if not src:
                raise ApiError("Канал не найден", 404)
            if not self.scheduler:
                raise ApiError("Планировщик не запущен", 503)
            result = self.scheduler.fetch_source(src)
            if not result.get("ok"):
                raise ApiError(result.get("error") or "Не удалось прочитать канал", 422)
            return self.json({"ok": True, "data": result, "stats": db.stats()})

        if path == "/api/drafts" and method == "GET":
            status = query.get("status", ["all"])[0]
            limit = min(500, int(query.get("limit", ["200"])[0]))
            return self.json({"ok": True, "data": db.drafts(status, limit)})

        m = re.match(r"^/api/drafts/(\d+)$", path)
        if m:
            did = int(m.group(1))
            draft = self.draft_or_404(did)
            if method == "GET":
                return self.json({"ok": True, "data": draft})
            if method == "PUT":
                payload = data or {}
                if "text" in payload and not str(payload["text"]).strip():
                    raise ApiError("Текст не может быть пустым")
                db.update_draft(did, **{k: v for k, v in payload.items()
                                        if k in ("text", "media_url")})
                return self.json({"ok": True, "data": db.draft(did)})
            if method == "DELETE":
                db.delete_draft(did)
                return self.json({"ok": True})

        m = re.match(r"^/api/drafts/(\d+)/(approve|reject|publish|schedule)$", path)
        if m and method == "POST":
            did, action = int(m.group(1)), m.group(2)
            draft = self.draft_or_404(did)
            payload = data or {}
            if action == "approve":
                text = str(payload.get("text") or draft["text"]).strip()
                if not text:
                    raise ApiError("Пустой текст")
                score = score_text(text, stop_words(db.get("stop_words")))
                db.update_draft(did, text=text, status="approved", score=score, error="")
                db.log("moderation", f"Пост #{did} одобрен")
                return self.json({"ok": True, "data": db.draft(did)})
            if action == "reject":
                db.update_draft(did, status="rejected", scheduled_at=0,
                                note=str(payload.get("note") or "отклонено вручную"))
                db.log("moderation", f"Пост #{did} отклонён")
                return self.json({"ok": True, "data": db.draft(did)})
            if action == "schedule":
                try:
                    at = float(payload.get("at") or 0)
                except (TypeError, ValueError):
                    raise ApiError("Некорректная дата")
                if at < now() - 60:
                    raise ApiError("Дата уже прошла")
                db.update_draft(did, status="approved", scheduled_at=at, error="")
                db.log("moderation", f"Пост #{did} запланирован")
                return self.json({"ok": True, "data": db.draft(did)})
            if action == "publish":
                return self.publish(draft)

        if path == "/api/logs":
            return self.json({"ok": True, "data": db.logs(int(query.get("limit", ["120"])[0]))})

        if path == "/api/settings":
            if method == "GET":
                payload = db.settings()
                payload["models"] = DEFAULT_MODELS
                payload["providers"] = list(PROVIDERS)
                return self.json({"ok": True, "data": payload})
            if method == "PUT":
                payload = data or {}
                provider = str(payload.get("llm_provider") or db.get("llm_provider"))
                if provider not in PROVIDERS:
                    raise ApiError("Неизвестный LLM-провайдер")
                if payload.get("new_password"):
                    pwd = str(payload["new_password"])
                    if len(pwd) < 8:
                        raise ApiError("Пароль короче 8 символов")
                    from .core import hash_password
                    db.set("admin_password", hash_password(pwd))
                for key in ("llm_provider", "llm_model", "llm_base_url", "target_channel",
                            "auto_publish", "auto_threshold", "post_delay_min",
                            "default_interval", "max_per_run", "stop_words", "rewrite_prompt"):
                    if key in payload:
                        db.set(key, payload[key])
                for secret in ("llm_api_key", "bot_token"):
                    value = payload.get(secret)
                    if value is not None and value != "***":
                        db.set(secret, str(value).strip())
                db.log("settings", "Настройки обновлены")
                return self.json({"ok": True})

        if path == "/api/llm/test" and method == "POST":
            sample = ("OpenAI released a new model today. It is 40% faster and supports "
                      "a 1M token context. Subscribe to our channel and use promo code AI20!")
            result = Rewriter(db).rewrite(sample)
            return self.json({"ok": True, "data": result})

        if path == "/api/telegram/test" and method == "POST":
            try:
                me = check_bot(db.get("bot_token"))
            except TelegramError as e:
                raise ApiError(f"Telegram: {e}", 422)
            return self.json({"ok": True, "data": me})

        if path == "/api/export.csv":
            return self.export_csv()

        raise ApiError("Метод API не найден", 404)

    def export_csv(self):
        buf = io.StringIO()
        writer = csv.writer(buf, delimiter=";")
        writer.writerow(["id", "дата", "канал", "статус", "оценка", "текст"])
        for d in self.db.drafts("all", 1000):
            writer.writerow([
                d["id"],
                time.strftime("%d.%m.%Y %H:%M", time.localtime(d["created"])),
                "@" + d["source_handle"],
                d["status"],
                d["score"],
                d["text"].replace("\n", " "),
            ])
        body = ("\ufeff" + buf.getvalue()).encode("utf-8")
        return self._send(200, body, "text/csv; charset=utf-8", {
            "Content-Disposition": 'attachment; filename="tg-queue.csv"'})


def serve(port: int = 8080, host: str = "127.0.0.1", with_scheduler: bool = True):
    db = DB()
    Handler.db = db
    scheduler = Scheduler(db)
    Handler.scheduler = scheduler
    if with_scheduler:
        scheduler.start()
    httpd = ThreadingHTTPServer((host, port), Handler)
    httpd.daemon_threads = True
    httpd.scheduler = scheduler  # type: ignore[attr-defined]
    return httpd
