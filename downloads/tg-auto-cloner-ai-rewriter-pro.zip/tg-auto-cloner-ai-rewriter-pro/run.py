#!/usr/bin/env python3
"""TG Auto Cloner + AI Rewriter Pro — запуск панели.

    python3 run.py                 # http://127.0.0.1:8080
    python3 run.py --demo          # демо-данные для скриншотов
    python3 run.py --no-scheduler  # только панель, без фонового цикла
"""
from __future__ import annotations

import argparse
import os
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))

from app.core import DB, seed_demo  # noqa: E402
from app.server import serve  # noqa: E402


def main() -> int:
    parser = argparse.ArgumentParser(description="TG Auto Cloner + AI Rewriter Pro")
    parser.add_argument("--port", type=int, default=int(os.environ.get("PORT", 8080)))
    parser.add_argument("--host", default=os.environ.get("HOST", "127.0.0.1"))
    parser.add_argument("--demo", action="store_true")
    parser.add_argument("--no-demo", action="store_true")
    parser.add_argument("--no-scheduler", action="store_true")
    args = parser.parse_args()

    db = DB()
    if args.demo or (not args.no_demo and db.get("demo_mode") == "1"):
        seed_demo(db)

    httpd = serve(port=args.port, host=args.host, with_scheduler=not args.no_scheduler)
    print(f"\n  TG Auto Cloner + AI Rewriter Pro  ·  http://{args.host}:{args.port}")
    print("  Логин: admin / admin123 (смените в Настройках)\n")
    try:
        httpd.serve_forever()
    except KeyboardInterrupt:
        print("\n[server] остановлен")
    finally:
        httpd.scheduler.stop()
        httpd.server_close()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
