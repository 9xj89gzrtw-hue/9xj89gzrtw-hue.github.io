#!/usr/bin/env bash
# Диагностика IP-адреса, утечек WebRTC и DNS-серверов
echo "=== 🔍 Проверка геолокации и DNS ==="
MY_IP=$(curl -s https://api.ipify.org)
echo "Текущий IP: $MY_IP"

COUNTRY=$(curl -s "https://ipapi.co/${MY_IP}/country_name/")
CITY=$(curl -s "https://ipapi.co/${MY_IP}/city/")
echo "Определенная страна: $COUNTRY, Город: $CITY"

if [ "$COUNTRY" == "Russian Federation" ] || [ "$COUNTRY" == "Belarus" ]; then
    echo "❌ ОШИБКА: Ваш реальный IP не защищен! Claude и Gemini выдадут ошибку Ineligible/Unsupported."
else
    echo "✅ УСПЕШНО: Вы находитесь в разрешенной зоне: $COUNTRY"
fi
