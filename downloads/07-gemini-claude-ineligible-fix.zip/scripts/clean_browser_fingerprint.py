"""Очистка кэша, Service Workers и LocalStorage для обхода кэшированных блокировок."""
import os
import shutil
from pathlib import Path

def get_chrome_cache_dirs():
    home = Path.home()
    paths = [
        home / "Library/Application Support/Google/Chrome/Default/Service Worker",
        home / "AppData/Local/Google/Chrome/User Data/Default/Service Worker",
        home / ".config/google-chrome/Default/Service Worker"
    ]
    return [p for p in paths if p.exists()]

def clean():
    print("[*] Поиск кэшированных данных Service Worker Google Chrome...")
    for p in get_chrome_cache_dirs():
        try:
            shutil.rmtree(p)
            print(f"[+] Очищен каталог: {p}")
        except Exception as e:
            print(f"[-] Ошибка очистки {p}: {e}")

if __name__ == "__main__":
    clean()
