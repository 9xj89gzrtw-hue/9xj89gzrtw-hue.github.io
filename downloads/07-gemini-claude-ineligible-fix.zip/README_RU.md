# 🛡️ Руководство: Обход ошибки «Account is ineligible / Region Not Supported» в Gemini и Claude (2026)

Полный рабочий мануал и набор автоматизированных Python-утилит для устранения блокировок доступа к Google Gemini (Advanced, API, AI Studio) и Anthropic Claude (claude.ai, API).

---

> 💡 **НУЖНА НАСТРОЙКА ПОД КЛЮЧ ИЛИ ИНДИВИДУАЛЬНЫЙ СКРИПТ?**
> Если вы не хотите тратить время на настройку прокси и окружения:
> - Напишите мне в личные сообщения на **FunPay (danilaonly)**
> - Или в наш Telegram: **[@Shop010_bot](https://t.me/Shop010_bot)**
> - Настрою чистый доступ или напишу Telegram-бота с AI за 20 минут!

---

## 🔍 Почему возникает ошибка «Account is ineligible»:

1. **WebRTC Leak (Утечка реального IP через браузер):** Даже при включенном VPN/прокси браузер выдает ваш реальный российский IP через протокол WebRTC.
2. **Timezone & Locale Mismatch:** Ваш IP показывает США/Германию, но системное время браузера — `Europe/Moscow`, а язык `ru-RU`. Google и Cloudflare мгновенно помечают сессию флагом несовместимости.
3. **«Грязный» датацентровый IP:** Большинство дешевых VPN используют IP-диапазоны датацентров (Hetzner, OVH, DigitalOcean), которые заблокированы в Google AI Studio и Claude.
4. **Google Account Origin Flag:** Если аккаунт Google был зарегистрирован с российского номера телефона или IP, в профиле навсегда проставлен `Country Association: RU`.

---

## 🚀 Пошаговое решение за 5 минут:

### Шаг 1. Отключение WebRTC в браузере
В Chrome / Brave / Edge:
- Установите расширение **WebRTC Control** (или переключите в `chrome://flags/#webrtc-ip-handling-policy` на `Disable Non-Proxied UDP`).
- Проверьте на сайте `browserleaks.com/webrtc`, чтобы в строке WebRTC не было видно вашего реального IP.

### Шаг 2. Использование резидентного или мобильного прокси
Датацентровые прокси блокируются. Используйте резидентные прокси (ISP / Residential) США, Великобритании или Нидерландов.
Для проверки качества вашего прокси запустите наш скрипт:
```bash
python3 proxy_tester.py --proxy socks5://user:pass@host:port
```
Скрипт проверяет:
- Пинг до `generativelanguage.googleapis.com` и `api.anthropic.com`
- Отсутствие капчи Cloudflare
- Определение страны по базе MaxMind GeoIP2

### Шаг 3. Создание чистого профиля без привязки к РФ
1. Откройте чистый профиль браузера (или инкогнито с активным прокси).
2. Зарегистрируйте новый Google аккаунт БЕЗ указания номера телефона (через временную почту или чистый IP) с языком `en-US`.
3. Перейдите на `aistudio.google.com` или `claude.ai` — доступ открывается сразу без ошибок `ineligible`.

---

## 🐍 Использование проверочного скрипта `proxy_tester.py`:

```bash
# Тестирование прокси для Gemini и Claude
python3 proxy_tester.py
```
Скрипт выведет точный статус готовности прокси к работе с AI API.
