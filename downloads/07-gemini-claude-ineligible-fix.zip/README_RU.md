# 🛡️ Руководство и утилиты обхода блокировок Claude AI & Google Gemini

Пошаговая инструкция и набор скриптов автоматической проверки для решения ошибок:
- `Account is ineligible` (Google Gemini)
- `Claude is not available in your region` (Anthropic)
- Блокировки API ключей в Cursor IDE и Windsurf

## Что входит в комплект
1. `scripts/verify_ip_dns.sh`: Скрипт проверки утечки DNS и геопозиции.
2. `scripts/clean_browser_fingerprint.py`: Утилита удаления кэшированных меток геопозиции из браузера.
3. `docs/SOLUTIONS_MATRIX.md`: Полная матрица устранения 15 видов ошибок доступа.
