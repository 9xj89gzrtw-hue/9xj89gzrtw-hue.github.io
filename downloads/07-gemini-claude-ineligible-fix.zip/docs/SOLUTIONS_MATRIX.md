# Матрица решения ошибок Claude & Google Gemini

| Ошибка | Причина | Шаг 1 | Шаг 2 |
|---|---|---|---|
| Claude: `App unavailable in your region` | Утечка IPv6 / WebRTC | Отключить IPv6 в настройках сети | Включить режим TUN в VPN клиенте |
| Claude: `Account suspended immediately` | Бан по номеру телефона / Fingerprint | Сменить профиль в браузере (Incognito) | Использовать зарубежный e-SIM |
| Gemini: `Account is ineligible` | Google аккаунт зарегистрирован в РФ | Создать новый аккаунт под чистым прокси | Указать возраст 18+ и страну US |
| Cursor: `Request blocked by provider` | Использование дефолтного системного DNS | Прописать DNS 1.1.1.1 и 8.8.8.8 | Проксировать порт 8080 через локальный роутер |
