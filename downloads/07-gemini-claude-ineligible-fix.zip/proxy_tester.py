#!/usr/bin/env python3
"""Proxy and connectivity tester for Google Gemini and Anthropic Claude APIs.
Diagnoses latency, TLS handshakes, Cloudflare blocking, and country origin.
"""
from __future__ import annotations

import argparse
import json
import sys
import time
import urllib.request

ENDPOINTS = {
    "Gemini AI Studio": "https://generativelanguage.googleapis.com",
    "Anthropic Claude API": "https://api.anthropic.com/v1/messages",
    "IP Geolocation": "https://ipinfo.io/json"
}

def test_proxy(proxy_url: str | None = None) -> dict:
    handlers = []
    if proxy_url:
        handlers.append(urllib.request.ProxyHandler({"http": proxy_url, "https": proxy_url}))
    opener = urllib.request.build_opener(*handlers)

    results = {}
    print(f"[*] Testing connectivity (Proxy: {proxy_url or 'Direct'})...")

    # 1. Check IP info
    try:
        t0 = time.time()
        req = urllib.request.Request("https://ipinfo.io/json", headers={"User-Agent": "curl/7.88.1"})
        with opener.open(req, timeout=10) as resp:
            data = json.loads(resp.read().decode())
            ip = data.get("ip")
            country = data.get("country")
            org = data.get("org")
            results["ip_check"] = {"ip": ip, "country": country, "org": org, "latency_ms": int((time.time() - t0) * 1000)}
            print(f"[+] Outgoing IP: {ip} ({country}) - {org}")
            if country in ["RU", "BY", "IR", "KP"]:
                print(f"[-] WARNING: Country {country} is blocked by Anthropic and Google AI Studio!")
    except Exception as e:
        results["ip_check"] = {"error": str(e)}
        print(f"[-] IP check failed: {e}")

    # 2. Check Gemini
    try:
        t0 = time.time()
        req = urllib.request.Request(ENDPOINTS["Gemini AI Studio"], headers={"User-Agent": "Mozilla/5.0"})
        with opener.open(req, timeout=10) as resp:
            status = resp.status
            results["gemini"] = {"status": status, "latency_ms": int((time.time() - t0) * 1000), "supported": True}
            print(f"[+] Gemini endpoint reachable (HTTP {status}) in {results['gemini']['latency_ms']}ms")
    except Exception as e:
        results["gemini"] = {"error": str(e), "supported": False}
        print(f"[-] Gemini endpoint check failed: {e}")

    # 3. Check Claude
    try:
        t0 = time.time()
        req = urllib.request.Request(ENDPOINTS["Anthropic Claude API"], headers={"User-Agent": "Mozilla/5.0"})
        with opener.open(req, timeout=10) as resp:
            status = resp.status
            results["claude"] = {"status": status, "latency_ms": int((time.time() - t0) * 1000)}
            print(f"[+] Claude API reachable (HTTP {status})")
    except urllib.error.HTTPError as e:
        # 401 is expected without auth token - means connection and TLS succeeded!
        latency = int((time.time() - t0) * 1000)
        is_blocked = (e.code == 403 or "blocked" in e.read().decode("utf-8", "ignore").lower())
        results["claude"] = {"status": e.code, "latency_ms": latency, "supported": not is_blocked}
        if is_blocked:
            print(f"[-] Claude blocked request (HTTP {e.code})")
        else:
            print(f"[+] Claude API reached successfully (HTTP {e.code} auth gate) in {latency}ms")
    except Exception as e:
        results["claude"] = {"error": str(e), "supported": False}
        print(f"[-] Claude check failed: {e}")

    return results

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Test proxy suitability for Gemini and Claude")
    parser.add_argument("--proxy", help="SOCKS5 or HTTP proxy URL (e.g. socks5://127.0.0.1:1080)", default=None)
    args = parser.parse_args()

    res = test_proxy(args.proxy)
    print("\nSummary:", json.dumps(res, indent=2))
